package userDefinedPackage;


import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileFilter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.io.comparator.LastModifiedFileComparator;
import org.apache.commons.io.filefilter.WildcardFileFilter;
import org.eclipse.jetty.server.UserIdentity;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cognizant.cognizantits.engine.commands.General;
import com.cognizant.cognizantits.engine.core.CommandControl;
import com.cognizant.cognizantits.engine.support.Status;
import com.cognizant.cognizantits.engine.support.methodInf.Action;
import com.cognizant.cognizantits.engine.support.methodInf.InputType;
import com.cognizant.cognizantits.engine.support.methodInf.ObjectType;
import com.testautomationguru.utility.PDFUtil;


public class CanadaUserDefined extends General {

	public CanadaUserDefined(CommandControl cc) {
		super(cc);
	}


	@Action(object = ObjectType.BROWSER, desc = "Values should be in 1000, 1second =1000 [<Data>]", input = InputType.YES)
	public void thread_Sleep() throws InterruptedException {

		int time = Integer.parseInt(Data);
		Thread.sleep(time);

	}

	@Action(object = ObjectType.BROWSER, desc = "Get Download path from system", input = InputType.NO)
	public void downloadPath_CA() {
		
		String property = System.getProperty("user.home");
		System.out.println(property);
		String replace = property.replace("\\", "\\\\");
		String path =replace+"\\\\Downloads";
		
		
			userData.getData("RegressionData", "Download Path");
			userData.putData("RegressionData", "Download Path", path);
			
			
	
		
	}

	@Action(object = ObjectType.BROWSER, desc = "Close Pending Req Popup", input = InputType.NO)
	public void pendingReqPopUpHandle_CA() {

		try {
			WebElement PendingReqPopUp = Driver.findElement(By.id("shiptoPendingOpen"));
			if (PendingReqPopUp.isDisplayed()) {
				Driver.findElement(By.id("cboxClose")).click();
			} else {
				System.out.println("PendingReqPopUp didn't display");
			} 
		} catch (Exception e) {
			System.out.println("PendingReqPopUp didn't display");
		}		
	}


	@Action(object = ObjectType.BROWSER, desc = "Verify Status Filter on Address Page", input = InputType.NO)
	public void verifyStatusFilterOnAddressPage_CA() {

		try {
			// Storing all the shipto status
			String[] shipToStatusList = {"ACTIVE","PENDING","INACTIVE","REQUESTED"};

			// Iterating through each status
			for (int i =1;i<=4;i++) {

				//Wait until page load is complete	
				WebDriverWait wait = new WebDriverWait(Driver,10);
				wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
						.executeScript("return document.readyState")));

				// Making all the status check boxes unchecked
				for (int j =1;j<=4;j++) {
					Driver.findElement(By.xpath("//div[@class='col-md-12 col-sm-12']/div["+j+"]/input")).click();
				}

				// Checking the respective status check boxes
				WebElement ChkBox = Driver.findElement(By.xpath("//div[@class='col-md-12 col-sm-12']/div["+i+"]/input"));
				ChkBox.click();

				// Get ship to count based of check box selection
				ArrayList<WebElement> list= new ArrayList<>(Driver.findElements(By.xpath("//div[@id='addressesList']/div[not(contains(@style, 'display: none;')) and @class='row addresslist-content accountManageAddressListTr']")));
				int totalMatchingShiptoCount = list.size();

				// Matching Shipto status with check box selected
				if(totalMatchingShiptoCount>0) {
					for (int k=1;k<=totalMatchingShiptoCount;k++) {
						String shipToStatus = Driver.findElement(By.xpath("//div[@id='addressesList']/div[not(contains(@style, 'display: none;')) and @class='row addresslist-content accountManageAddressListTr']["+k+"]/div[11]")).getText();

						if (shipToStatus.equalsIgnoreCase(shipToStatusList[i-1])) {
							Report.updateTestLog(Action, "ShipTo Status is "+ shipToStatus +" And checkbox selected is "+shipToStatusList[i-1], Status.PASS);
						}
						else {
							Report.updateTestLog(Action, "ShipTo Status is "+ shipToStatus +" And checkbox selected is "+shipToStatusList[i-1], Status.FAIL);
						}

					}
				}else {
					Report.updateTestLog(Action, shipToStatusList[i-1] + " checkbox selected but matching shipto is not found" , Status.PASS);
				}

				Driver.navigate().refresh();
			}

			Driver.navigate().refresh();


		} catch (Exception e) {
			System.out.println("Error encountered");
		}		
	}


	
	
	
	@Action(object = ObjectType.BROWSER, desc = "Verify Status Filter on Address Page", input = InputType.NO)
	public void verifyStatusFilterOnAddressPage_CA_FR() {

		try {
			// Storing all the shipto status
			String[] shipToStatusList = {"ACTIF","EN ATTENTE","INACTIF","SOUMIS"};

			// Iterating through each status
			for (int i =1;i<=4;i++) {

				//Wait until page load is complete	
				WebDriverWait wait = new WebDriverWait(Driver,10);
				wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
						.executeScript("return document.readyState")));

				// Making all the status check boxes unchecked
				for (int j =1;j<=4;j++) {
					Driver.findElement(By.xpath("//div[@class='col-md-12 col-sm-12']/div["+j+"]/input")).click();
				}

				// Checking the respective status check boxes
				WebElement ChkBox = Driver.findElement(By.xpath("//div[@class='col-md-12 col-sm-12']/div["+i+"]/input"));
				ChkBox.click();

				// Get ship to count based of check box selection
				ArrayList<WebElement> list= new ArrayList<>(Driver.findElements(By.xpath("//div[@id='addressesList']/div[not(contains(@style, 'display: none;')) and @class='row addresslist-content accountManageAddressListTr']")));
				int totalMatchingShiptoCount = list.size();

				// Matching Shipto status with check box selected
				if(totalMatchingShiptoCount>0) {
					for (int k=1;k<=totalMatchingShiptoCount;k++) {
						String shipToStatus = Driver.findElement(By.xpath("//div[@id='addressesList']/div[not(contains(@style, 'display: none;')) and @class='row addresslist-content accountManageAddressListTr']["+k+"]/div[11]")).getText();

						if (shipToStatus.equalsIgnoreCase(shipToStatusList[i-1])) {
							Report.updateTestLog(Action, "ShipTo Status is "+ shipToStatus +" And checkbox selected is "+shipToStatusList[i-1], Status.PASS);
						}
						else {
							Report.updateTestLog(Action, "ShipTo Status is "+ shipToStatus +" And checkbox selected is "+shipToStatusList[i-1], Status.FAIL);
						}

					}
				}else {
					Report.updateTestLog(Action, shipToStatusList[i-1] + " checkbox selected but matching shipto is not found" , Status.PASS);
				}

				Driver.navigate().refresh();
			}

			Driver.navigate().refresh();


		} catch (Exception e) {
			System.out.println("Error encountered");
		}		
	}



	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	@Action(object = ObjectType.BROWSER, desc = "Edit shipto on Address Page", input = InputType.NO)
	public void editShipToOnAddressPage_CA() {

		try {

			//Wait until page load is complete	
			WebDriverWait wait = new WebDriverWait(Driver,10);
			wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
					.executeScript("return document.readyState")));

			// Making all the status check boxes unchecked
			for (int j =1;j<=4;j++) {
				Driver.findElement(By.xpath("//div[@class='col-md-12 col-sm-12']/div["+j+"]/input")).click();
			}

			// Checking the ACTIVE status check boxes
			WebElement ChkBox = Driver.findElement(By.xpath("//div[@class='col-md-12 col-sm-12']/div[1]/input"));
			ChkBox.click();

			// Get ship to count based of check box selection
			ArrayList<WebElement> list= new ArrayList<>(Driver.findElements(By.xpath("//div[@id='addressesList']/div[not(contains(@style, 'display: none;')) and @class='row addresslist-content accountManageAddressListTr']")));
			int totalMatchingShiptoCount = list.size();

			// Clicking on Edit button for first shipto 
			if(totalMatchingShiptoCount>0) {
				String shipToNumber = Driver.findElement(By.xpath("//div[@id='addressesList']/div[not(contains(@style, 'display: none;')) and @class='row addresslist-content accountManageAddressListTr'][1]/div[9]")).getText();

				WebElement EditButton  = Driver.findElement(By.xpath("//div[@id='addressesList']/div[not(contains(@style, 'display: none;')) and @class='row addresslist-content accountManageAddressListTr'][1]/div/form/button"));
				EditButton.click();
				//Driver.findElement(By.xpath("//button[contains(text(),'Continue to edit')]")).click();
				Driver.findElement(By.id("bindToShippingAddressEditContinue")).click();

				//Wait until page load is complete	
				WebDriverWait wait1 = new WebDriverWait(Driver,10);
				wait1.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
						.executeScript("return document.readyState")));

				// Update ShipTo BillTo and Contact fields
				Driver.findElement(By.xpath("//input[@id='addressDetails_shipto_line1']")).clear();
				Driver.findElement(By.xpath("//input[@id='addressDetails_shipto_line1']")).sendKeys("Test Address Line 1");
				Driver.findElement(By.xpath("//input[@id='addressDetails_shipto_line2']")).clear();
				Driver.findElement(By.xpath("//input[@id='addressDetails_shipto_line2']")).sendKeys("Test Address Line 2");
				Driver.findElement(By.xpath("//input[@id='addressDetails_shipto_town']")).clear();
				Driver.findElement(By.xpath("//input[@id='addressDetails_shipto_town']")).sendKeys("Calgary");

				Select select = new Select(Driver.findElement(By.xpath("//select[@id='addressDetails_invoiceAddress_countryName']")));
				select.selectByVisibleText("Alberta");

				Driver.findElement(By.xpath("//input[@id='addressDetails_shipto_postalCode']")).clear();
				Driver.findElement(By.xpath("//input[@id='addressDetails_shipto_postalCode']")).sendKeys("T2G 0P3");
				Driver.findElement(By.xpath("//textarea[@id='openingHours']")).clear();
				Driver.findElement(By.xpath("//textarea[@id='openingHours']")).sendKeys("10AM-5PM");
try {
				Driver.findElement(By.xpath("//label[contains(text(),'Add/Update Billing address:')]")).click();
				
}catch (Exception e) {
	Driver.findElement(By.xpath("//label[@for='newbillingAddress']")).click();
	
}

				Driver.findElement(By.xpath("//input[@id='addressDetails_billingAddress_name']")).clear();
				Driver.findElement(By.xpath("//input[@id='addressDetails_billingAddress_name']")).sendKeys("Test Billing Address");
				Driver.findElement(By.xpath("//input[@id='addressDetails_billingAddress_line1']")).clear();
				Driver.findElement(By.xpath("//input[@id='addressDetails_billingAddress_line1']")).sendKeys("Test Address Line 1");
				Driver.findElement(By.xpath("//input[@id='addressDetails_billingAddress_line2']")).clear();
				Driver.findElement(By.xpath("//input[@id='addressDetails_billingAddress_line2']")).sendKeys("Test Address Line 2");
				Driver.findElement(By.xpath("//input[@id='addressDetails_billingAddress_town']")).clear();
				Driver.findElement(By.xpath("//input[@id='addressDetails_billingAddress_town']")).sendKeys("Calgay");

				Select select1 = new Select(Driver.findElement(By.xpath("//select[@id='addressDetails_billingAddress_countryName']")));
				select1.selectByVisibleText("Alberta");

				Driver.findElement(By.xpath("//input[@id='addressDetails_billingAddress_postalCode']")).clear();
				Driver.findElement(By.xpath("//input[@id='addressDetails_billingAddress_postalCode']")).sendKeys("T2G 0P4");

				Driver.findElement(By.xpath("//input[@id='addressDetails_billingContact_name']")).clear();
				Driver.findElement(By.xpath("//input[@id='addressDetails_billingContact_name']")).sendKeys("Test Name");
				Driver.findElement(By.xpath("//input[@id='addressDetails_billingContact_email']")).clear();
				Driver.findElement(By.xpath("//input[@id='addressDetails_billingContact_email']")).sendKeys("testname@gmail.com");
				Driver.findElement(By.xpath("//input[@id='addressDetails_billingContact_phone']")).clear();
				Driver.findElement(By.xpath("//input[@id='addressDetails_billingContact_phone']")).sendKeys("789-456-1230");
				Driver.findElement(By.xpath("//input[@id='addressDetails_billingContact_phone_ext']")).clear();
				Driver.findElement(By.xpath("//input[@id='addressDetails_billingContact_phone_ext']")).sendKeys("12345");

				Driver.findElement(By.xpath("//input[@id='addressEditSubmit']")).click();

				//Wait until page load is complete	
				WebDriverWait wait2 = new WebDriverWait(Driver,10);
				wait2.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
						.executeScript("return document.readyState")));

				Driver.findElement(By.xpath("//input[@id='addressSearch']")).sendKeys(shipToNumber);

				String shipToStatus = Driver.findElement(By.xpath("//div[@id='addressesList']/div[not(contains(@style, 'display: none;')) and @class='row addresslist-content accountManageAddressListTr'][1]/div[11]")).getText();

				if (shipToStatus.equalsIgnoreCase("PENDING") || shipToStatus.equalsIgnoreCase("EN ATTENTE")) {
					Report.updateTestLog(Action, "ShipTo Status is "+ shipToStatus +" And expected status is PENDING", Status.PASS);
				}
				else {
					Report.updateTestLog(Action, "ShipTo Status is "+ shipToStatus +" And checkbox selected is PENDING", Status.FAIL);
				}
				
				
				

				String EditButtonTitle = Driver.findElement(By.xpath("//div[@id='addressesList']/div[not(contains(@style, 'display: none;')) and @class='row addresslist-content accountManageAddressListTr'][1]/div/form/button")).getAttribute("title");

				if (EditButtonTitle.contains("Pending")|| EditButtonTitle.contains("en attente")) {
					Report.updateTestLog(Action, "Edit button is Disabled", Status.PASS);
				}
				else {
					Report.updateTestLog(Action, "Edit button is NOT Disabled", Status.FAIL);
				}



			}else {
				Report.updateTestLog(Action, "ACTIVE checkbox selected but matching shipto is not found" , Status.FAIL);
			}		


		} catch (Exception e) {
			e.printStackTrace();
		}		
	}


	/* ************************************************ Activeshipto ***************************** */
	
	@Action(object = ObjectType.BROWSER, desc = "Get active shipTo from addresses tab", input = InputType.NO)
	public void getActiveShipToNumber_CA() throws InterruptedException {
		List<WebElement> findElements = Driver.findElements(By.xpath("//div[@id='addressesList']/div[contains(@class,'row addresslist-content')]")); 
		List<String> e1 = new ArrayList<String>();
		int i=1; 
		for (WebElement webElement:findElements){
		String b = "";
			//System.out.println(Driver.findElement(By.xpath("//tbody/tr[" + i + "]/td[6]")).getText());
			if (Driver.findElement(By.xpath("(//div[@id='addressesList']/div[contains(@class,'row addresslist-content')]/div[11])[" + i + "]")).getText().contains("ACTIVE")) { 
																											 
				String text =
				Driver.findElement(By.xpath("(//div[@id='addressesList']/div[contains(@class,'row addresslist-content')]/div[9])[" + i + "]")).getText();
				b=text.toString();
				/*
				 * String[] split = text.split(" "); String a = split[3].toString(); String[]
				 * split2 = a.split("");
				 * 
				 * for (int j = 0; j < 10; j++) { b = b + split2[j].toString(); }
				 */
				System.out.println(b);
				e1.add(b);
			}
			i = i + 1;

		}
		Driver.findElement(By.id("purchase-products-active")).click(); 
		  Thread.sleep(10000);
		for (String string : e1) {
			System.out.println(string);

		  Thread.sleep(10000);
		 Driver.findElement(By.id("search-ship-to-field")).sendKeys(string);
		 
		// ((JavascriptExecutor) Driver).executeScript("arguments[0].scrollIntoView(true);",  Driver.findElement(By.xpath("//span[contains(text(),'1100551403')]")));
		 Driver.findElement(By.xpath("//span[contains(text(),'"+string+"')]")).click();
		 Driver.findElement(By.xpath("//button[@id='orderForThisAddressBtn']")).click();
		 
		 Thread.sleep(10000);
		 if(Driver.findElement(By.xpath("//*[@id='select-shipTo']/div/div[1]/div[2]")).getText().contains("Not valid") || Driver.findElement(By.xpath("//*[@id='select-shipTo']/div/div[1]/div[2]")).getText().contains("Due to expire on") || Driver.findElement(By.xpath("//*[@id='select-shipTo']/div/div[1]/div[2]")).getText().contains("Class of trade:FEDERAL")) {
			 
			 Driver.findElement(By.id("changeShipToLink")).click();
			 System.out.println("state licence not valid");
		 }else {
			 try {
				// userData.getData("Data", "Active ShipTo");
				 userData.putData("OrderPage", "ShipTo", string); 
				 Report.updateTestLog(Action, "Active Shipto : "+string, Status.PASS);
			} catch (Exception e) {
				
			}
			 
			
			break;
		 }
		}
	}
	
	
	
	
	/*       --------------------------------------- */
	
	@Action(object = ObjectType.BROWSER, desc = "Enter ShipTo,Product ID,Quantity [<Data>]", input = InputType.YES)
	public void CA_addProductToCart() throws InterruptedException {
		
		String[] InputData = Data.split(",");
		String ShipTo = InputData[0]; // 1200082978
		String Product = InputData[1]; // 705809
		String Quantity = InputData[2]; // 10
		
		
		try {

			Driver.findElement(By.xpath("//a[@id='purchase-products-active']")).click();
			Thread.sleep(5000);
			
			try {
				WebElement ChangeShipToPopUp = Driver.findElement(By.id("cboxLoadedContent"));

				if (ChangeShipToPopUp.isDisplayed()) {

					Driver.findElement(By.xpath("//span[contains(text(),'" + ShipTo + "')]")).click();
					Thread.sleep(2000);
					
					Driver.findElement(By.xpath("//button[@id='orderForThisAddressBtn']")).click();
		
					Thread.sleep(2000);
				}
					
			} catch(Exception e) {
				
				Driver.findElement(By.xpath("//a[@id='changeShipToLink']")).click();
				
				Report.updateTestLog(Action, "Change Shipto Link is clicked to change the Shipto Address", Status.PASS);

				Thread.sleep(2000);
				
				Driver.findElement(By.xpath("//span[contains(text(),'" + ShipTo + "')]")).click();
				Driver.findElement(By.xpath("//button[@id='orderForThisAddressBtn'")).click();
				Thread.sleep(2000);
				
			}

			
				Driver.findElement(By.xpath("//input[@id='search_text_complexproducts_orderable']")).sendKeys(Product);
				Driver.findElement(By.xpath("//button[@id='searchtextBtn_complexproducts_orderable']")).click();

				Thread.sleep(4000);

				Driver.findElement(By.xpath("//input[contains(@class,'QuantityText prodOrderListerQty')]")).sendKeys(Quantity);
				Driver.findElement(By.xpath("//span[@class='add-cart-CA']")).click();

				Driver.navigate().refresh();

				// Wait until page load is complete
				WebDriverWait wait = new WebDriverWait(Driver, 10);
				wait.until(webDriver -> "complete"
						.equals(((JavascriptExecutor) webDriver).executeScript("return document.readyState")));

				if (Driver.findElement(By.id("cartTotalNonZero")).isDisplayed()) {

					Report.updateTestLog(Action, Quantity + " Packs of " + Product + " Added To Cart for ShipTo " + ShipTo, Status.PASS);

				} else {
					
					Report.updateTestLog(Action, " No Product Added To Cart for ShipTo " + ShipTo, Status.FAIL);

				}			
	

		} catch (Exception f) {
			
			Report.updateTestLog(Action, " No Product Added To Cart for ShipTo " + ShipTo, Status.FAIL);			
		}
				
	}

	
	
	
	
	
	
	
	
	
	/*------------------------------------------------------  */
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	@Action(object = ObjectType.BROWSER, desc = "Enter ShipTo,Product ID,Quantity [<Data>]", input = InputType.YES)
	public void CA_addProductToCart_old() throws InterruptedException {

		try {
			
			
			//Driver.findElement(By.xpath("//a[contains(text(),'ZÅ‚Ã³Å¼ zamÃ³wienie')]")).click();

			Driver.findElement(By.xpath("//a[contains(text(),'Purchase Products')]")).click();
			
			String[] InputData = Data.split(",");
			String ShipTo = InputData[0]; //1200082978
			String Product = InputData[1]; //705809
			String Quantity = InputData[2]; //10


			Thread.sleep(5000);

			WebElement ChangeShipToPopUp = Driver.findElement(By.id("cboxLoadedContent"));

			if(ChangeShipToPopUp.isDisplayed()) {


				//Driver.findElement(By.xpath("//input[@id='search-ship-to-field']")).sendKeys(ShipTo);
				Driver.findElement(By.xpath("//span[contains(text(),'"+ShipTo+"')]")).click();
				//Driver.findElement(By.xpath("//div[@class='ship-to-list']/div[not(contains(@style, 'display: none;'))]")).click();

				Driver.findElement(By.xpath("//button[@id='orderForThisAddressBtn' and contains(text(),'Order for this address')]")).click();
				//Driver.findElement(By.xpath("//button[@id='orderForThisAddressBtn']")).click();
				Thread.sleep(2000);
				Driver.findElement(By.xpath("//input[@id='search_text_complexproducts_orderable']")).sendKeys(Product);
				Driver.findElement(By.xpath("//button[@id='searchtextBtn_complexproducts_orderable']")).click();

				
				Thread.sleep(4000);


				Driver.findElement(By.xpath("//input[contains(@class,'QuantityText prodOrderListerQty')]")).sendKeys(Quantity);
				Driver.findElement(By.xpath("//span[@class='add-cart-CA' and contains(text(),'Add to cart')]")).click();

				Driver.navigate().refresh();

				//Wait until page load is complete	
				WebDriverWait wait = new WebDriverWait(Driver,10);
				wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
						.executeScript("return document.readyState")));

				if (Driver.findElement(By.id("cartTotalNonZero")).isDisplayed()) {

					Report.updateTestLog(Action, Quantity + " Packs of " +Product+" Added To Cart for ShipTo "+ShipTo, Status.PASS);

				}else {
					Report.updateTestLog(Action, " No Product Added To Cart for ShipTo "+ShipTo, Status.FAIL);

				}


			}else {

				System.out.println("Change ShipTo Pop us not present");

			}

		} catch (NoSuchElementException e) {

			String[] InputData = Data.split(",");
			String ShipTo = InputData[0]; //1200082978
			String Product = InputData[1]; //705809
			String Quantity = InputData[2]; //10
			Thread.sleep(5000);
			Driver.findElement(By.xpath("//a[@id='changeShipToLink']")).click();


			//Driver.findElement(By.xpath("//input[@id='search-ship-to-field']")).sendKeys(ShipTo);
			Thread.sleep(2000);
			Driver.findElement(By.xpath("//span[contains(text(),'"+ShipTo+"')]")).click();
			//Driver.findElement(By.xpath("//div[@class='ship-to-list']/div[not(contains(@style, 'display: none;'))]")).click();

			Driver.findElement(By.xpath("//button[@id='orderForThisAddressBtn' and contains(text(),'Order for this address')]")).click();

			//Driver.findElement(By.xpath("//button[@id='orderForThisAddressBtn']")).click();
			Thread.sleep(2000);

			Driver.findElement(By.xpath("//input[@id='search_text_complexproducts_orderable']")).sendKeys(Product);
			Driver.findElement(By.xpath("//button[@id='searchtextBtn_complexproducts_orderable']")).click();
			Thread.sleep(4000);
			Driver.findElement(By.xpath("//input[contains(@class,'QuantityText prodOrderListerQty')]")).sendKeys(Quantity);
			Driver.findElement(By.xpath("//span[@class='add-cart-CA' and contains(text(),'Add to cart')]")).click();


			Driver.navigate().refresh();

			//Wait until page load is complete	
			WebDriverWait wait = new WebDriverWait(Driver,10);
			wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
					.executeScript("return document.readyState")));

			if (Driver.findElement(By.id("cartTotalNonZero")).isDisplayed()) {

				Report.updateTestLog(Action, Quantity + " Packs of " +Product+" Added To Cart for ShipTo "+ShipTo, Status.PASS);

			}else {
				Report.updateTestLog(Action, " No Product Added To Cart for ShipTo "+ShipTo, Status.FAIL);

			}
		}		
	}
	
	
	@Action(object = ObjectType.BROWSER, desc = "Enter ProductCount,CartCount,ProductPerCart,ShipTo-BillTo [<Data>]", input = InputType.YES)
	public void CA_verifyShoppingCartPage() {
String paymenttype=null;




		try {

			String[] InputData = Data.split(",");

			String ProductCount = InputData[0];
			String CartCount = InputData[1];
			String ProductPerCart = InputData[2];

			HashMap<String,String> ShipToBillTo_Map = new HashMap<String,String>();

			for (int a=3;a<=InputData.length-1;a++) {

				String[] ShipToBillToArray = InputData[a].split("-");
				ShipToBillTo_Map.put(ShipToBillToArray[0], ShipToBillToArray[1]);

			}
			try {
			Driver.findElement(By.xpath("//a[contains(text(),'Shopping cart')]")).click();
			}
			catch(Exception e)
			{
				
				Driver.findElement(By.xpath("//a[contains(text(),'Panier d’achat')]")).click();
			}
			
			//Wait until page load is complete	
			WebDriverWait wait = new WebDriverWait(Driver,10);
			wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
					.executeScript("return document.readyState")));

			String ActualProductCount = Driver.findElement(By.xpath("//span[@id='cartTotalNonZero']/span[contains(@class,'count')]")).getText();

			// Verify total Product Count displayed at Cart Header
			if(ActualProductCount.contains(ProductCount)) {
				Report.updateTestLog(Action, "Expected Total Product in Cart "+ProductCount+" And Actual Total Product in Cart "+ActualProductCount, Status.PASS);
			}else {
				Report.updateTestLog(Action, "Expected Total Product in Cart "+ProductCount+" And Actual Total Product in Cart "+ActualProductCount, Status.FAIL);
			}

			List<WebElement> Carts = Driver.findElements(By.xpath("//div[@class='row ship-to']"));

			// Verify Total Cart displayed
			if(Carts.size()==Integer.parseInt(CartCount)) {
				Report.updateTestLog(Action, "Expected Cart Count "+CartCount+" And Actual Cart Count "+Carts.size(), Status.PASS);
			}else {
				Report.updateTestLog(Action, "Expected Cart Count "+CartCount+" And Actual Cart Count "+Carts.size(), Status.FAIL);
			}

			// Verify Total "New Shopping Cart" section count
			if (ShipToBillTo_Map.size()>1) {
				
				//List<WebElement> Nowy_koszyk = Driver.findElements(By.xpath("//div[contains(text(),'New Shopping Cart')]")); 
				
				List<WebElement> Nowy_koszyk = Driver.findElements(By.xpath("//div[contains(@class,'newCartBanner newCartbanner-CA')]"));
				if(Nowy_koszyk.size()==ShipToBillTo_Map.size()-1) {
					Report.updateTestLog(Action, "Total New Shopping Cart Section Count is "+Nowy_koszyk.size()+" Which is Expected", Status.PASS);
				}else {
					Report.updateTestLog(Action, "Total New Shopping Cart Section Count is "+Nowy_koszyk.size()+" Which is NOT Expected", Status.FAIL);
				}
			}
			// Add Produts button for Another shipto button
			
			if(Driver.findElement(By.xpath("//*[@id='changeShipToLink']")).isDisplayed())
			{
				Report.updateTestLog(Action, "Add Products for Another Ship-To is Displayed ", Status.PASS);
				
			}else {
				Report.updateTestLog(Action, "Add Products for Another Ship-To is Not Displayed ", Status.FAIL);
			}


			double ExpectedTotalPriceWithVat_AllCart = 0.00;

			for (int i=1;i<=Carts.size();i++) {
				
				
				// Verify ShipTo Row expanded by default
				WebElement ShipToToggle = Driver.findElement(By.xpath("//div[@class='row ship-to']["+i+"]//a"));

				if (ShipToToggle.getAttribute("class").equalsIgnoreCase("ship-to-toggle expanded")) {
					Report.updateTestLog(Action, "Cart "+i+ " Expanded By Default", Status.PASS);
				}else {
					Report.updateTestLog(Action, "Cart "+i+ " NOT Expanded By Default", Status.FAIL);
				}

				ShipToToggle.click();

				// Verify ShiTo Row Collapse
				if (ShipToToggle.getAttribute("class").equalsIgnoreCase("ship-to-toggle")) {

					Report.updateTestLog(Action, "Cart "+i+ " Toggle is Collapsed", Status.PASS);

					if (Driver.findElement(By.xpath("//div[@class='row ship-to']["+i+"]//div[@class='ship-to-full']")).isDisplayed()) {
						Report.updateTestLog(Action, "Cart "+i+ " is NOT Collapsed", Status.FAIL);
					}else {
						Report.updateTestLog(Action, "Cart "+i+ " is Collapsed", Status.PASS);

					}
				}else {
					Report.updateTestLog(Action, "Cart "+i+ " Toggle is NOT Collapsed", Status.FAIL);
				}



				ShipToToggle.click();

				// Verify ShiTo Row Expand
				if (ShipToToggle.getAttribute("class").equalsIgnoreCase("ship-to-toggle expanded")) {

					Report.updateTestLog(Action, "Cart "+i+ " Toggle is Expanded", Status.PASS);

					if (Driver.findElement(By.xpath("//div[@class='row ship-to']["+i+"]//div[@class='ship-to-full']")).isDisplayed()) {
						Report.updateTestLog(Action, "Cart "+i+ " is Expanded", Status.PASS);
					}else {
						Report.updateTestLog(Action, "Cart "+i+ " is NOT Expanded", Status.FAIL);
					}
				}else {
					Report.updateTestLog(Action, "Cart "+i+ " Toggle is NOT Expanded", Status.FAIL);
				}
				//Send Weekly Hours of Operation
				weekly_ponum(i)		;	
				
			
				//Payment method check
				paymenttype=userData.getData("RegressionData", "Paymenttype"+i);
				
				String creditcard;
				
				
				
				 //creditcard=Driver.findElement(By.xpath("(//span[contains(text(),'Payment Method')])["+i+"]")).getText();
				 //Driver.findElement(By.xpath("//a[@class='editCardSec']")).isDisplayed();
					if(paymenttype.equalsIgnoreCase("Creditcard") && Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//a[@class='editCardSec']")).isDisplayed() )
					
					{
						
						try {
				
							try {
					creditcard=Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//span[contains(text(),'Payment Method')]")).getText();
							}catch(Exception e)
							
							{
								creditcard=Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//span[contains(text(),'Mode de paiement')]")).getText();
								
							}
					Report.updateTestLog(Action, " Payment Method details :: "+creditcard, Status.PASS);
					
					Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//a[@class='editCardSec']")).click();
					
					Thread.sleep(10000);
					String PaymentInfoTitle = Driver.getTitle();
					if((PaymentInfoTitle.contains("GSK Direct Canada | Payment Information") )   || (PaymentInfoTitle.contains("GSK Direct Canada |Renseignements sur le paiement") )     )
					{
						Report.updateTestLog(Action, "User Navigate to Payment Information Page ", Status.PASS);
												
						
					}else {
						Report.updateTestLog(Action, "User NOT Navigate to Payment Information Page", Status.FAIL);
					}
							
					
						Driver.navigate().back();
						Thread.sleep(10000);
						wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
								.executeScript("return document.readyState")));
						String shoppingcarttitle = Driver.getTitle();
						if((shoppingcarttitle.contains("GSK Direct Canada | Shopping Cart")) || (shoppingcarttitle.contains("GSK Direct Canada | Panier d'achat"))     ) {
							Report.updateTestLog(Action, "User Navigate to  ::  "  +shoppingcarttitle, Status.PASS);
													
							
						}else {
							Report.updateTestLog(Action, "User NOT Navigate to Shopping Cart Page", Status.FAIL);
							
							Driver.findElement(By.xpath("//a[contains(text(),'Shopping cart')]")).click();
						
						
							Thread.sleep(10000);}	
						
						
						
						}
					catch(Exception e){
						Report.updateTestLog(Action, " Payment Method details not available ", Status.FAIL);
						 
					}							
					}
					
					
					if(paymenttype.equalsIgnoreCase("InvoiceMe"))
					{
						
						
						Report.updateTestLog(Action, " Payment Method Is InvoiceMe ", Status.PASS);	
					}
				
				// Verify ShipTo and BillTo
				String ActualShipTo = Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//div[contains(@class,'cart-add-tlt-CA')]//span[contains(@class,'shpAddrAln')]")).getText();
				String ActualBillTo = Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//div[contains(@class,'po-cart')]//span[contains(@class,'shpAddrAln')]")).getText();

				for (String ExpectedShipTo : ShipToBillTo_Map.keySet()) {
					
					if(ActualShipTo.contains(ExpectedShipTo)) {
						
						String ExpectedBillTo = ShipToBillTo_Map.get(ExpectedShipTo);
						if (ActualBillTo.contains(ExpectedBillTo)) {
							userData.putData("OrderDetails", "ExpectedShipTo"+i,ExpectedShipTo );
							userData.putData("OrderDetails", "ExpectedBillTo"+i,ExpectedShipTo );
							Report.updateTestLog(Action, "Cart Created For "+ExpectedShipTo+" And Corresponding BillTo "+ExpectedBillTo, Status.PASS);
						
							
						
						}else {
							Report.updateTestLog(Action, "Cart is NOT Created For Provided ShipTo and BillTo", Status.FAIL);
						}

					}
				}


				
				List<WebElement> ProductRow = Driver.findElements(By.xpath("(//div[@class='row ship-to'])["+i+"]//div[contains(@class,'row product-item')]"));

				// Verify Total Product Per Cart displayed
				if(ProductRow.size()==Integer.parseInt(ProductPerCart)) {
					Report.updateTestLog(Action, "Expected Product Row Per Cart "+ProductPerCart+" And Actual Product Row Per Cart "+ProductRow.size(), Status.PASS);
				}else {
					Report.updateTestLog(Action, "Expected Product Row Per Cart "+ProductPerCart+" And Actual Product Row Per Cart "+ProductRow.size(), Status.FAIL);
				}

				double ExpectedTotalPriceWithVat_PerCart=0.00;

				// Verify each product row
				String ProductQuantity = null;
				for (int j=1;j<=ProductRow.size();j++) {
try {
					// Verify Product Name and PDP
					WebElement ProductNameLink = Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//div[contains(@class,'row product-item')]["+j+"]//a[@class='product-name']"));
					String ProductNameOnCartPage = ProductNameLink.getText();

					ProductNameLink.click();

					WebDriverWait wait1 = new WebDriverWait(Driver,10);
					wait1.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
							.executeScript("return document.readyState")));

//					WebElement PDP = Driver.findElement(By.xpath("//span[contains(text(),'Product Details')]"));
//					String ProductNameOnPDP = Driver.findElement(By.xpath("//h1[@id='productDetail-name']")).getText();
//					
					
					WebElement PDP = Driver.findElement(By.xpath("//span[contains(@class,'product-header-style-CA')]"));
					String ProductNameOnPDP = Driver.findElement(By.xpath("//h1[@id='productDetail-name']")).getText();
					
					if (PDP.isDisplayed() && ProductNameOnPDP.equalsIgnoreCase(ProductNameOnCartPage)) {
						Report.updateTestLog(Action, "PDP Opened For Product Name "+ProductNameOnCartPage, Status.PASS);
					}else {
						Report.updateTestLog(Action, "PDP NOT Opened For Product Name "+ProductNameOnCartPage, Status.FAIL);
					}


					Driver.navigate().back();

					WebDriverWait wait2 = new WebDriverWait(Driver,10);
					wait2.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
							.executeScript("return document.readyState")));

					// Verify "UsuÅ„ z koszyka" link under each product row
					String RemoveLink = Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//div[contains(@class,'row product-item')]["+j+"]//a[@id='removeCartLink']")).getText();

					if ((RemoveLink.equalsIgnoreCase("Remove from cart")) || (RemoveLink.equalsIgnoreCase("Supprimer du panier")) ) {
						Report.updateTestLog(Action, "Remove Link Displayed for "+ProductNameOnCartPage, Status.PASS);
					}else {
						Report.updateTestLog(Action, "Remove Link NOT Displayed for "+ProductNameOnCartPage, Status.FAIL);
					}


					// Verify Product Price With/WithOut VAT
					String PriceWithVat = Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//div[contains(@class,'row product-item')]["+j+"]//div[contains(@class,'pageConfWithVatVal')]")).getText();
					 ProductQuantity = Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//div[contains(@class,'row product-item')]["+j+"]//input[@id='quantity' and @type='number']")).getAttribute("value");
					String ActualTotalPriceWithVat_PerProduct = Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//div[contains(@class,'row product-item')]["+j+"]//div[contains(@class,'product-total')]")).getText();

					PriceWithVat = PriceWithVat.replace(",", "");
					//PriceWithVat = PriceWithVat.replace(",", "");
					String [] PriceWithVatArray = PriceWithVat.split(" ");
					 PriceWithVatArray=PriceWithVatArray[1].split("/");
						
					double PriceWithVat_Double = Double.parseDouble(PriceWithVatArray[0]);
								
						
					int ProductQuantity_Int = Integer.parseInt(ProductQuantity);
							
						
					double ExpectedTotalPriceWithVat_PerProduct =  Math.round((PriceWithVat_Double*ProductQuantity_Int) * 100.0) / 100.0;
					
					
					ActualTotalPriceWithVat_PerProduct = ActualTotalPriceWithVat_PerProduct.replace(",", "");
					String [] ActualTotalPriceWithVat_PerProductArray = ActualTotalPriceWithVat_PerProduct.split(" ");
					
					String ActualTotalProductPriceWithVat_String=ActualTotalPriceWithVat_PerProductArray[1];
					
					double ActualTotalPriceWithVat_PerProduct_Double = Double.parseDouble(ActualTotalProductPriceWithVat_String);
					
					if (ExpectedTotalPriceWithVat_PerProduct==ActualTotalPriceWithVat_PerProduct_Double) {
						Report.updateTestLog(Action, "Expected TotalPriceWithVat "+ExpectedTotalPriceWithVat_PerProduct+" And Actual TotalPriceWithVat "+ActualTotalPriceWithVat_PerProduct_Double, Status.PASS);
						
						String perproduct=String.valueOf(ExpectedTotalPriceWithVat_PerProduct);
								userData.putData("OrderDetails", "C"+i+"product"+j, perproduct);
								
					
					}else {
						Report.updateTestLog(Action, "Expected TotalPriceWithVat "+ExpectedTotalPriceWithVat_PerProduct+" And Actual TotalPriceWithVat "+ActualTotalPriceWithVat_PerProduct_Double, Status.FAIL);
					}

					// Verify Total Price Per Cart
					//ExpectedTotalPriceWithVat_PerCart = Math.round((ExpectedTotalPriceWithVat_PerCart+ExpectedTotalPriceWithVat_PerProduct+ProductQuantity_Int) * 100.0) / 100.0;
					ExpectedTotalPriceWithVat_PerCart = Math.round((ExpectedTotalPriceWithVat_PerCart+ExpectedTotalPriceWithVat_PerProduct) * 100.0) / 100.0;
						//Report.updateTestLog(Action, " ExpectedTotalPriceWithVat_PerCart   :::::::::::  "+ExpectedTotalPriceWithVat_PerCart, Status.DONE);			
				

}
catch (Exception e) {
	Report.updateTestLog(Action," Verify Product Price  getting failed ", Status.FAIL);
}		
				}
				
				try {

				// Verify Total Price Per Cart
				String ActualTotalPriceWithVat_PerCart = Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//div[contains(@class,'grand-total_cad-CA')]")).getText();

				ActualTotalPriceWithVat_PerCart = ActualTotalPriceWithVat_PerCart.replace(",", "");
				String [] ActualTotalPriceWithVat_PerCartArray = ActualTotalPriceWithVat_PerCart.split(" ");
				//ActualTotalPriceWithVat_PerCartArray=ActualTotalPriceWithVat_PerCartArray[1].split("/");
				String ActualTotalPriceWithVat_PerCart_String=ActualTotalPriceWithVat_PerCartArray[1];
				userData.putData("OrderDetails", "C"+i+"Total", ActualTotalPriceWithVat_PerCart_String);
					/*
					 * for (int l=0;l<=ActualTotalPriceWithVat_PerCartArray.length-2;l++) {
					 * ActualTotalPriceWithVat_PerCart_String =
					 * ActualTotalPriceWithVat_PerCart_String+ActualTotalPriceWithVat_PerCartArray[l
					 * ]; }
					 */
//+Integer.parseInt(ProductQuantity)
				double ActualTotalPriceWithVat_PerCart_Double = Double.parseDouble(ActualTotalPriceWithVat_PerCart_String);
				//Report.updateTestLog(Action," ActualTotalPriceWithVat_PerCart_Double:::: "+ActualTotalPriceWithVat_PerCart_Double, Status.DONE);
				if (ExpectedTotalPriceWithVat_PerCart==ActualTotalPriceWithVat_PerCart_Double) {
					Report.updateTestLog(Action, "Expected TotalPriceWithVat For Cart "+i+" is "+ExpectedTotalPriceWithVat_PerCart+" And Actual TotalPriceWithVat For Cart "+i+" is "+ActualTotalPriceWithVat_PerCart_Double, Status.PASS);
				}else {
					Report.updateTestLog(Action, "Expected TotalPriceWithVat For Cart "+i+" is "+ExpectedTotalPriceWithVat_PerCart+" And Actual TotalPriceWithVat For Cart "+i+" is "+ActualTotalPriceWithVat_PerCart_Double, Status.FAIL);
				}
				
				
				

				
			
				// Verify Total Price for ALL Carts
			ExpectedTotalPriceWithVat_AllCart = Math.round((ExpectedTotalPriceWithVat_AllCart+ExpectedTotalPriceWithVat_PerCart) * 100.0) / 100.0;
			
				
				}catch (Exception e) {
					Report.updateTestLog(Action," Verify Total Price Per Cart  getting failed ", Status.FAIL);
				}
				}
			try {	
				
				// Verify Total Price for ALL Carts
			String ActualTotalPriceWithVat_AllCart = Driver.findElement(By.xpath("//div[@class='row cart-bottom']//div[contains(@class,'grandtotalvalue-CA')]")).getText(); 

			ActualTotalPriceWithVat_AllCart = ActualTotalPriceWithVat_AllCart.replace(",", "");
			
			String [] ActualTotalPriceWithVat_AllCartArray = ActualTotalPriceWithVat_AllCart.split(" ");
			//ActualTotalPriceWithVat_AllCartArray=ActualTotalPriceWithVat_AllCartArray[1].split("/");

			String ActualTotalPriceWithVat_AllCart_String=ActualTotalPriceWithVat_AllCartArray[1];

				/*
				 * for (int m=0;m<=ActualTotalPriceWithVat_AllCartArray.length-2;m++) {
				 * ActualTotalPriceWithVat_AllCart_String =
				 * ActualTotalPriceWithVat_AllCart_String+ActualTotalPriceWithVat_AllCartArray[m
				 * ]; }
				 */

			double ActualTotalPriceWithVat_AllCart_Double = Double.parseDouble(ActualTotalPriceWithVat_AllCart_String);


			if (ExpectedTotalPriceWithVat_AllCart==ActualTotalPriceWithVat_AllCart_Double) {
				Report.updateTestLog(Action, "Expected TotalPriceWithVat_AllCart "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPriceWithVat_AllCart "+ActualTotalPriceWithVat_AllCart_Double, Status.PASS);
			}else {
				Report.updateTestLog(Action, "Expected TotalPriceWithVat_AllCart "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPriceWithVat_AllCart "+ActualTotalPriceWithVat_AllCart_Double, Status.FAIL);
			}

			
			}catch (Exception e) {
				Report.updateTestLog(Action," Verify Total Price for ALL Carts  getting failed ", Status.FAIL);
			}
			
			try {
			// Verify total Cart Price displayed at Cart Header
			String ActualTotalPriceAtCartHeader = Driver.findElement(By.xpath("//span[@id='cartTotalNonZero']/span[contains(@class,'count')]/span[2]")).getText();

			ActualTotalPriceAtCartHeader = ActualTotalPriceAtCartHeader.replace(",", "");
			String [] ActualTotalPriceAtCartHeaderArray = ActualTotalPriceAtCartHeader.split(" ");
			//ActualTotalPriceAtCartHeaderArray=ActualTotalPriceAtCartHeaderArray[1].split("/");
			String ActualTotalPriceAtCartHeader_String=ActualTotalPriceAtCartHeaderArray[1];

				/*
				 * for (int m=0;m<=ActualTotalPriceAtCartHeaderArray.length-2;m++) {
				 * ActualTotalPriceAtCartHeader_String =
				 * ActualTotalPriceAtCartHeader_String+ActualTotalPriceAtCartHeaderArray[m]; }
				 */

			double ActualTotalPriceAtCartHeader_Double = Double.parseDouble(ActualTotalPriceAtCartHeader_String);

			if (ExpectedTotalPriceWithVat_AllCart==ActualTotalPriceAtCartHeader_Double) {
				Report.updateTestLog(Action, "Expected TotalPrice_At Cart Header "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPrice_At Cart Header "+ActualTotalPriceAtCartHeader_Double, Status.PASS);
			}else {
				Report.updateTestLog(Action, "Expected TotalPrice_At Cart Header "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPrice_At Cart Header "+ActualTotalPriceAtCartHeader_Double, Status.FAIL);
			}

			}catch (Exception e) {
				Report.updateTestLog(Action," Verify total Cart Price displayed at Cart Header  getting failed ", Status.FAIL);
			}

		}catch(Exception e1) {
			Report.updateTestLog(Action,"Before Verify ShipTo Row expanded by default getting failed "+e1, Status.FAIL);			
		}


	}
	public void weekly_ponum(int l)
	{
		String week_ponumdata=userData.getData("RegressionData", "WeeklyPOnum");
		WebElement Weekly_Hours ;
		
		try {
			
			
			//	Report.updateTestLog(Action, "week_ponum  :::" +week_ponum, Status.DONE);
				String[] week_ponum1=week_ponumdata.split(",");
				
				String weekly=week_ponum1[0];
				String Ponum=week_ponum1[1];
				
				
				Report.updateTestLog(Action, l+"Weekly houres ::: "+weekly  +"    PO Number ::::: "+Ponum, Status.DONE);
				
				WebElement POnumber =Driver.findElement(By.xpath("(//input[@aria-labelledby='poNumberLabel'])["+l+"]"));
				try {
			 Weekly_Hours =	Driver.findElement(By.xpath("(//span[contains(text(),' Weekly Hours of Operation')]/parent::div/textarea)["+l+"]"));
				}catch(Exception e1){
					 Weekly_Hours =	Driver.findElement(By.xpath("(//span[@class='requirednew']/../parent::div//textarea)["+l+"]"));
					 
				}
			
			Weekly_Hours.clear();
			POnumber.clear();
			Weekly_Hours.sendKeys(weekly);
			POnumber.sendKeys(Ponum);
			//Driver.findElement(By.xpath("(//span[contains(text(),' Weekly Hours of Operation')]/parent::div/textarea)["+i+"]")).sendKeys(weekly);
			
			}
			catch(Exception e){
				Report.updateTestLog(Action, " Weekly Hours of Operation details not available ", Status.WARNING);
				 
			}
		
	}
	
	public void weekly_ponum_validation(int l)
	{String week_ponumdata=userData.getData("RegressionData", "WeeklyPOnum");
	
	try {
		
		
		//	Report.updateTestLog(Action, "week_ponum  :::" +week_ponum, Status.DONE);
			String[] week_ponum1=week_ponumdata.split(",");
			
			String weekly=week_ponum1[0];
			String Ponum=week_ponum1[1];
			WebElement POnumber ;
			WebElement Weekly_Hours;
			
			try{
			 POnumber =Driver.findElement(By.xpath("(//span[contains(text(),'P.O.Number')]/parent::div//input)["+l+"]"));
			 Weekly_Hours =	Driver.findElement(By.xpath("(//span[contains(text(),'Weekly Hours of Operation')]/parent::div//textarea)["+l+"]"));
			
			//Report.updateTestLog(Action, "Weekly houres ::: in "+Driver.getTitle() +"Page   :: "+Weekly_Hours.getText()  +"    PO Number ::::: "+POnumber.getAttribute("value"), Status.DONE);
			}
			catch(Exception e){
				
				 POnumber =Driver.findElement(By.xpath("(//span[contains(text(),'Numéro de bon de commande')]/parent::div//input)["+l+"]"));
				 Weekly_Hours =	Driver.findElement(By.xpath("(//span[contains(text(),'Heures d’ouverture pour la semaine :')]/parent::div//textarea)["+l+"]"));
			}
			
			if((Weekly_Hours.getText().equalsIgnoreCase(weekly)) && (POnumber.getAttribute("value").equalsIgnoreCase(Ponum)) )
					
					{
				
				Report.updateTestLog(Action, Driver.getTitle() +"  Page Weekly houres ::: " +Weekly_Hours.getText()  +"    PO Number ::::: "+POnumber.getAttribute("value") +"   are Matching with Input data given in Shipping Page", Status.DONE);
				
				
					}
			
	}
	catch(Exception e){
		Report.updateTestLog(Action, " Weekly Hours of Operation details not available ", Status.WARNING);
		 
	}
		
	}
	
	
	
	
	
	

	@Action(object = ObjectType.BROWSER, desc = "Removing Products from Page", input = InputType.NO)
	public void CA_removeProduct() throws InterruptedException {
		List<WebElement> removeproduct = null;
	
		WebElement Element = Driver.findElement(By.xpath("//span[@id='itemCount']"));
		
		if (!Element.getText().equals("(0)")) {
			
			Driver.findElement(By.xpath("//a[contains(@class,'minicart')]")).click();

			Thread.sleep(10000);

			try {
				
				removeproduct = Driver.findElements(By.xpath("//a[@id='removeCartLink']"));
				
			} catch (Exception e) {
				
				Report.updateTestLog(Action, " No Products avilable ", Status.DONE);
			}

			try {
				if (removeproduct.size() == 0) {

					Report.updateTestLog(Action, " No Products avilable in Page", Status.DONE);
				}

				for (int i = removeproduct.size(); i >= 1; i--) {

					Driver.findElement(By.xpath("(//a[@id='removeCartLink'])[" + i + "]")).click();

					WebDriverWait wait = new WebDriverWait(Driver, 600);
					wait.until(ExpectedConditions
							.presenceOfElementLocated(By.xpath("(//*[@id='removeProduct-confirm'])[2]")));

					Report.updateTestLog(Action, "Sucussfully Clicked on Yes, Remove button product got deleted",
							Status.PASS);

					Driver.findElement(By.xpath("(//*[@id='removeProduct-confirm'])[2]")).click();

					Thread.sleep(5000);

					if (i == 1) {

						if (Driver.findElement(By.xpath("//div[contains(@class,'cad grandtotalinner-CA')]"))
								.isDisplayed()) {

							String TS = Driver.findElement(By.xpath("//div[contains(@class,'cad grandtotalinner-CA')]"))
									.getText();
							Report.updateTestLog(Action, "Total Shipping value become ZERO or  product got deleted",
									Status.PASS);

						} else {

							Report.updateTestLog(Action, "Total Shipping value Not become ZERO ", Status.FAIL);

						}
					}

				}
			} catch (Exception e) {
				System.out.println(e);
			}

		} else {
			Report.updateTestLog(Action, "Cart is null ", Status.PASS);
		}

	}
	
	
	/* ********************* newcode ************* */
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	@Action(object = ObjectType.BROWSER, desc = "Removing Products from Page", input = InputType.NO)
	public void CA_removeProduct_Old() throws InterruptedException {
		List<WebElement> removeproduct=null;
		//WebElement Element = Driver.findElement(By.xpath("//span[@id='cartTotalNonZero']/span[1]"));
		WebElement Element = Driver.findElement(By.xpath("//span[@id='itemCount']"));
		//System.out.println(Element);
		
		/*
		 * String[] qtyarray = Element.getText().split("\\D");
		 * System.out.println(qtyarray); int num = Integer.parseInt(qtyarray[1]);
		 * System.out.println(qtyarray[1]);
		 */
		
		if (!Element.getText().equals("(0)")) {
			Driver.findElement(By.xpath("//a[contains(text(),'Shopping cart')]")).click();
			
			
			Thread.sleep(10000);
			
			try {
				removeproduct =Driver.findElements(By.xpath("//a[@id='removeCartLink']"));
			// Report.updateTestLog(Action,"1st No WYŚWIETL RABATY avialabe   "+removeproduct.size(), Status.DONE);
			}catch (Exception e) {
				Report.updateTestLog(Action," No Products avilable ", Status.DONE);
			}
			
			try {
				if(removeproduct.size()==0) {
					
					Report.updateTestLog(Action," No Products avilable in Page", Status.DONE);	
				}
			
			for(int i =removeproduct.size(); i>=1;i--)
			{
				 
				
				Driver.findElement(By.xpath("(//a[@id='removeCartLink'])["+i+"]")).click();
				
				WebDriverWait wait = new WebDriverWait(Driver, 600);
		        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//*[@id='removeProduct-confirm'])[2]")));

		        Report.updateTestLog(Action,"Sucussfully Clicked on Yes, Remove button product got deleted", Status.PASS);
		        
		        
		        Driver.findElement(By.xpath("(//*[@id='removeProduct-confirm'])[2]")).click();
					
				Thread.sleep(5000);
				
				
				if(i==1 ) {
				
				if(Driver.findElement(By.xpath("//div[contains(@class,'cad grandtotalinner-CA')]")).isDisplayed())
				{
					
					String TS=Driver.findElement(By.xpath("//div[contains(@class,'cad grandtotalinner-CA')]")).getText();
					 Report.updateTestLog(Action,"Total Shipping value become ZERO or  product got deleted", Status.PASS);
					 
					 
			}else {
				
				Report.updateTestLog(Action,"Total Shipping value Not become ZERO ", Status.FAIL);
				
			}}
			
				
				
			}
			}catch (Exception e) {
				//Report.updateTestLog(Action," No WYŚWIETL RABATY avialabe   ", Status.DONE);
				}
			
			
			
		}else {
			Report.updateTestLog(Action, "Cart is null ", Status.PASS);
		}

		
	
	}
	@Action(object = ObjectType.BROWSER, desc = "Close Accept Cookies Popup", input = InputType.NO)
	public void acceptCookiesPopUpHandle_CA() {

		try {
			WebElement AcceptCookiesPopUp = Driver.findElement(By.id("privacy_prompt"));
			if (AcceptCookiesPopUp.isDisplayed()) {
				Driver.findElement(By.id("preferences_prompt_submit")).click();
			} else {
				System.out.println("AcceptCookiesPopUp didn't display");
			} 
		} catch (Exception e) {
			System.out.println("AcceptCookiesPopUp didn't display");
		}		
	}
	
	
	
	@Action(object = ObjectType.BROWSER, desc = "Enter ProductCount,CartCount,ProductPerCart,ShipTo-BillTo [<Data>]", input = InputType.YES)
	public void CA_verifyConfirmOrderPage() {

		String paymenttype=null;
		String week_ponum=userData.getData("RegressionData", "WeeklyPOnum");
		try{

			String[] InputData = Data.split(",");

			String ProductCount = InputData[0];
			String CartCount = InputData[1];
			String ProductPerCart = InputData[2];

			HashMap<String,String> ShipToBillTo_Map = new HashMap<String,String>();

			for (int a=3;a<=InputData.length-1;a++) {

				String[] ShipToBillToArray = InputData[a].split("-");
				ShipToBillTo_Map.put(ShipToBillToArray[0], ShipToBillToArray[1]);

			}

			Driver.findElement(By.xpath("//button[@id='checkoutButton']")).click();
			Thread.sleep(10000);

			// Verify Header Text
						String ConfirmHeader = Driver.findElement(By.xpath("//h3[contains(text(),'Review Your Order')]")).getText();
						if (ConfirmHeader.equalsIgnoreCase("Review Your Order")) {
							Report.updateTestLog(Action, "Review Your Order Text Displayed at Header", Status.PASS);
						}else {
							Report.updateTestLog(Action, "Review Your Order Text NOT Displayed at Header", Status.FAIL);
						}

						// Verify Sale Doc Link displayed
						WebElement SaleDocLink = Driver.findElement(By.xpath("//a[contains(text(),'Terms of Sale')]"));

						if (SaleDocLink.isDisplayed()){
							Report.updateTestLog(Action, "Terms of Sale Link Displayed", Status.PASS);
						}else {
							Report.updateTestLog(Action, "Terms of Sale Link NOT Displayed", Status.FAIL);
						}

			// Verify Sale Doc Link Opened

			SaleDocLink.click();
			Thread.sleep(6000);
			
			pdf_validation_CA("ROW-TERMS-CONDITIONS-EN-CA");
			


			// Verify Navigate Back and Forward pages
			Driver.findElement(By.xpath("//button[contains(@class,'back-to-cart')]")).click();

			WebDriverWait wait1 = new WebDriverWait(Driver,10);
			wait1.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
					.executeScript("return document.readyState")));

			String CartPageTitle = Driver.getTitle();
			if(CartPageTitle.contains("GSK Direct Canada | Shopping Cart")) {
				Report.updateTestLog(Action, "User Navigate to Shopping Cart Page", Status.PASS);
			}else {
				Report.updateTestLog(Action, "User NOT Navigate to Shopping Cart Page", Status.FAIL);
			}

			Driver.findElement(By.xpath("//button[@id='checkoutButton']")).click();
			Thread.sleep(10000);

			String ConfirmOrderPageTitle = Driver.getTitle();
			if(ConfirmOrderPageTitle.contains("GSK Direct Canada | Checkout")) {
				Report.updateTestLog(Action, "User Navigate to ConfirmOrderPageTitle Page", Status.PASS);
			}else {
				Report.updateTestLog(Action, "User NOT Navigate to ConfirmOrderPageTitle Page", Status.FAIL);
			}


			///////////////////////

			String ActualProductCount = Driver.findElement(By.xpath("//span[@id='cartTotalNonZero']/span[contains(@class,'count')]")).getText();

			// Verify total Product Count displayed at Cart Header
			if(ActualProductCount.contains(ProductCount)) {
				Report.updateTestLog(Action, "Expected Total Product in Cart "+ProductCount+" And Actual Total Product in Cart "+ActualProductCount, Status.PASS);
			}else {
				Report.updateTestLog(Action, "Expected Total Product in Cart "+ProductCount+" And Actual Total Product in Cart "+ActualProductCount, Status.FAIL);
			}

			List<WebElement> Carts = Driver.findElements(By.xpath("//div[@class='row ship-to']"));

			// Verify Total Cart displayed
			if(Carts.size()==Integer.parseInt(CartCount)) {
				Report.updateTestLog(Action, "Expected Cart Count "+CartCount+" And Actual Cart Count "+Carts.size(), Status.PASS);
			}else {
				Report.updateTestLog(Action, "Expected Cart Count "+CartCount+" And Actual Cart Count "+Carts.size(), Status.FAIL);
			}

			// Verify Total "Nowy koszyk" section count
			if (ShipToBillTo_Map.size()>1) {
				List<WebElement> Nowy_koszyk = Driver.findElements(By.xpath("//div[contains(text(),'New Shopping Cart')]"));

				if(Nowy_koszyk.size()==ShipToBillTo_Map.size()-1) {
					Report.updateTestLog(Action, "Total New Shopping Cart Section Count is "+Nowy_koszyk.size()+" Which is Expected", Status.PASS);
				}else {
					Report.updateTestLog(Action, "Total New Shopping Cart Section Count is "+Nowy_koszyk.size()+" Which is NOT Expected", Status.FAIL);
				}
			}



			double ExpectedTotalPriceWithVat_AllCart = 0.00;

			for (int i=1;i<=Carts.size();i++) {
				// Verify ShipTo Row expanded by default
				WebElement ShipToToggle = Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//a"));

				if (ShipToToggle.getAttribute("class").equalsIgnoreCase("ship-to-toggle expanded")) {
					Report.updateTestLog(Action, "Cart "+i+ " Expanded By Default", Status.PASS);
				}else {
					Report.updateTestLog(Action, "Cart "+i+ " NOT Expanded By Default", Status.FAIL);
				}

				ShipToToggle.click();

				// Verify ShiTo Row Collapse
				if (ShipToToggle.getAttribute("class").equalsIgnoreCase("ship-to-toggle")) {

					Report.updateTestLog(Action, "Cart "+i+ " Toggle is Collapsed", Status.PASS);

					if (Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//div[@class='ship-to-full']")).isDisplayed()) {
						Report.updateTestLog(Action, "Cart "+i+ " is NOT Collapsed", Status.FAIL);
					}else {
						Report.updateTestLog(Action, "Cart "+i+ " is Collapsed", Status.PASS);

					}
				}else {
					Report.updateTestLog(Action, "Cart "+i+ " Toggle is NOT Collapsed", Status.FAIL);
				}



				ShipToToggle.click();

				// Verify ShipTo Row Expand
				if (ShipToToggle.getAttribute("class").equalsIgnoreCase("ship-to-toggle expanded")) {

					Report.updateTestLog(Action, "Cart "+i+ " Toggle is Expanded", Status.PASS);

					if (Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//div[@class='ship-to-full']")).isDisplayed()) {
						Report.updateTestLog(Action, "Cart "+i+ " is Expanded", Status.PASS);
					}else {
						Report.updateTestLog(Action, "Cart "+i+ " is NOT Expanded", Status.FAIL);
					}
				}else {
					Report.updateTestLog(Action, "Cart "+i+ " Toggle is NOT Expanded", Status.FAIL);
				}
				
			
				//Payment method check
				String creditcard;
				
				paymenttype=userData.getData("RegressionData", "Paymenttype"+i);
				
				 //creditcard=Driver.findElement(By.xpath("(//span[contains(text(),'Payment Method')])["+i+"]")).getText();
				 //Driver.findElement(By.xpath("//a[@class='editCardSec']")).isDisplayed();
					if((paymenttype.equalsIgnoreCase("Creditcard"))&& (Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//span[contains(text(),'Payment Method')]")).isDisplayed()) )
					
					{
						
						try {
				
					creditcard=Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//span[contains(text(),'Payment Method')]")).getText();
				
					Report.updateTestLog(Action, " Payment Method details :: "+creditcard, Status.PASS);
					
						
						}
					catch(Exception e){
						Report.updateTestLog(Action, " Payment Method details not available ", Status.FAIL);
						 
					}							
					}
					
					if(paymenttype.equalsIgnoreCase("InvoiceMe"))
					{
						
						
						Report.updateTestLog(Action, " Payment Method Is InvoiceMe ", Status.PASS);	
					}
				
				
				
				//	Weeekly POnum validation
					weekly_ponum_validation(i);	
				


				// Verify ShipTo and BillTo
				String ActualShipTo = Driver.findElement(By.xpath("((//div[@class='row ship-to'])["+i+"]//div[contains(@class,'cart-add-tlt-CA')]//span[contains(@class,'shpAddrAln')])[1]")).getText();
				String ActualBillTo = Driver.findElement(By.xpath("((//div[@class='row ship-to'])["+i+"]//span[contains(@class,'shpAddrAln')])[2]")).getText();

				for (String ExpectedShipTo : ShipToBillTo_Map.keySet()) {
					if(ActualShipTo.contains(ExpectedShipTo)) {
						String ExpectedBillTo = ShipToBillTo_Map.get(ExpectedShipTo);
						if (ActualBillTo.contains(ExpectedBillTo)) {
							Report.updateTestLog(Action, "Cart Created For "+ExpectedShipTo+" And Corresponding BillTo "+ExpectedBillTo, Status.PASS);
						}else {
							Report.updateTestLog(Action, "Cart is NOT Created For Provided ShipTo and BillTo", Status.FAIL);
						}

					}
				}

//				Report.updateTestLog(Action, "List<WebElement> ProductRow  before:: "+i, Status.PASS);
				
				//List<WebElement> ProductRow = Driver.findElements(By.xpath("(//div[@class='row ship-to']//div[contains(@class,'row product-item')])["+i+"]"));
				
				List<WebElement> ProductRow = Driver.findElements(By.xpath("((//div[@class='row ship-to'])["+i+"]//div[contains(@class,'row gsk-box-productSection')])[1]/following-sibling::div//div[contains(@class,'row product-item')]"));
//System.out.println(":::::::::::::::"+ProductRow.size());
				// Verify Total Product Per Cart displayed
				if(ProductRow.size()==Integer.parseInt(ProductPerCart)) {
					Report.updateTestLog(Action, "Expected Product Row Per Cart "+ProductPerCart+" And Actual Product Row Per Cart "+ProductRow.size(), Status.PASS);
				}else {
					Report.updateTestLog(Action, "Expected Product Row Per Cart "+ProductPerCart+" And Actual Product Row Per Cart "+ProductRow.size(), Status.FAIL);
				}
				double ExpectedTotalPriceWithVat_PerCart=0.00;

				// Verify each product row
				
				String ProductQuantity = null;
					
				
				for (int j=1;j<=ProductRow.size();j++) {
					
					
					

try {
	
	
	
	//WebElement ProductNameLink = Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//div[contains(@class,'row product-item')]["+j+"]//a[@class='product-name']"));
	
	WebElement ProductNameLink = Driver.findElement(By.xpath("((//div[@class='row ship-to'])["+i+"]//div[contains(@class,'row gsk-box-productSection')])[1]/following-sibling::div//div[contains(@class,'row product-item')]["+j+"]//a[@class='product-name']"));
		
	String ProductNameOnCartPage = ProductNameLink.getText();
	Report.updateTestLog(Action, "PDP Opened For Product Name "+ProductNameOnCartPage, Status.PASS);
	ProductNameLink.click();

	WebDriverWait wait = new WebDriverWait(Driver,10);
	wait1.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
			.executeScript("return document.readyState")));

	WebElement PDP = Driver.findElement(By.xpath("//span[contains(text(),'Product Details')]"));
	String ProductNameOnPDP = Driver.findElement(By.xpath("//h1[@id='productDetail-name']")).getText();

	if (PDP.isDisplayed() && ProductNameOnPDP.equalsIgnoreCase(ProductNameOnCartPage)) {
		Report.updateTestLog(Action, "PDP Opened For Product Name "+ProductNameOnCartPage, Status.PASS);
	}else {
		Report.updateTestLog(Action, "PDP NOT Opened For Product Name "+ProductNameOnCartPage, Status.FAIL);
	}


	Driver.navigate().back();

	WebDriverWait wait2 = new WebDriverWait(Driver,10);
	wait2.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
			.executeScript("return document.readyState")));

}
catch (Exception e) {
Report.updateTestLog(Action," Verify Product Price getting failed "+i, Status.FAIL);
}	
	try {
		String [] PriceWithVatArray=null;
		int ProductQuantity_Int=0;
		double PriceWithVat_Double =0;
		String [] ActualTotalPriceWithVat_PerProductArray=null;
	// Verify Product Price With/WithOut VAT
//	String PriceWithVat = Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//div[contains(@class,'row product-item')]["+j+"]//div[contains(@class,'withoutvatcheckout-CA')]")).getText();
//	 ProductQuantity = Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//div[contains(@class,'row product-item')]["+j+"]//div[contains(@class,'summary-qty-val-CA')]")).getText();
//	String ActualTotalPriceWithVat_PerProduct = Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//div[contains(@class,'row product-item')]["+j+"]//div[contains(@class,'product-total')]")).getText();
//	//Report.updateTestLog(Action, "PriceWithVat:::: "+PriceWithVat +"ProductQuantity::: "+ProductQuantity +"ActualTotalPriceWithVat_PerProduct"+ActualTotalPriceWithVat_PerProduct, Status.DONE);
	
	String PriceWithVat = Driver.findElement(By.xpath("((//div[@class='row ship-to'])["+i+"]//div[contains(@class,'row gsk-box-productSection')])[1]/following-sibling::div//div[contains(@class,'row product-item')]["+j+"]//div[contains(@class,'withoutvatcheckout-CA')]")).getText();
	 ProductQuantity = Driver.findElement(By.xpath("((//div[@class='row ship-to'])["+i+"]//div[contains(@class,'row gsk-box-productSection')])[1]/following-sibling::div//div[contains(@class,'row product-item')]["+j+"]//div[contains(@class,'summary-qty-val-CA')]")).getText();
	String ActualTotalPriceWithVat_PerProduct = Driver.findElement(By.xpath("((//div[@class='row ship-to'])["+i+"]//div[contains(@class,'row gsk-box-productSection')])[1]/following-sibling::div//div[contains(@class,'row product-item')]["+j+"]//div[contains(@class,'product-total')]")).getText();
	
	
	
	
	
	try {
	PriceWithVat = PriceWithVat.replace(",", "");
	//PriceWithVat = PriceWithVat.replace(",", "");
	 PriceWithVatArray = PriceWithVat.split(" ");
	// PriceWithVatArray=PriceWithVatArray[1].split("/");
	 
//	 Report.updateTestLog(Action, "PriceWithVatArray:::: "+PriceWithVatArray[0]+"PriceWithVatArray[1]::: "+PriceWithVatArray[1], Status.DONE);
		
		 PriceWithVat_Double = Double.parseDouble(PriceWithVatArray[1]);
					
			
		 ProductQuantity_Int = Integer.parseInt(ProductQuantity);
	}catch (Exception e) {
		PriceWithVatArray = PriceWithVat.split(" ");
		
		Report.updateTestLog(Action," inside PriceWithVatArray ", Status.DONE);
Report.updateTestLog(Action, "PriceWithVatArray:::: "+PriceWithVatArray[0]+"PriceWithVatArray[1]::: "+PriceWithVatArray[1], Status.DONE);
		
		 PriceWithVat_Double = Double.parseDouble(PriceWithVatArray[1]);
					
			
		 ProductQuantity_Int = Integer.parseInt(ProductQuantity);
	}
	
			
		
	double ExpectedTotalPriceWithVat_PerProduct =  Math.round((PriceWithVat_Double*ProductQuantity_Int) * 100.0) / 100.0;
	try {
	
	ActualTotalPriceWithVat_PerProduct = ActualTotalPriceWithVat_PerProduct.replace(",", "");
	ActualTotalPriceWithVat_PerProductArray = ActualTotalPriceWithVat_PerProduct.split(" ");
	}catch (Exception e) {
		
		ActualTotalPriceWithVat_PerProductArray = ActualTotalPriceWithVat_PerProduct.split(" ");
	}
	String ActualTotalProductPriceWithVat_String=ActualTotalPriceWithVat_PerProductArray[1];
	
	double ActualTotalPriceWithVat_PerProduct_Double = Double.parseDouble(ActualTotalProductPriceWithVat_String);
	
	if (ExpectedTotalPriceWithVat_PerProduct==ActualTotalPriceWithVat_PerProduct_Double) {
		Report.updateTestLog(Action, "Expected TotalPriceWithVat "+ExpectedTotalPriceWithVat_PerProduct+" And Actual TotalPriceWithVat "+ActualTotalPriceWithVat_PerProduct_Double, Status.PASS);
	}else {
		Report.updateTestLog(Action, "Expected TotalPriceWithVat "+ExpectedTotalPriceWithVat_PerProduct+" And Actual TotalPriceWithVat "+ActualTotalPriceWithVat_PerProduct_Double, Status.FAIL);
	}

	// Verify Total Price Per Cart
	//ExpectedTotalPriceWithVat_PerCart = Math.round((ExpectedTotalPriceWithVat_PerCart+ExpectedTotalPriceWithVat_PerProduct+ProductQuantity_Int) * 100.0) / 100.0;
	ExpectedTotalPriceWithVat_PerCart = Math.round((ExpectedTotalPriceWithVat_PerCart+ExpectedTotalPriceWithVat_PerProduct) * 100.0) / 100.0;
//		Report.updateTestLog(Action, " ExpectedTotalPriceWithVat_PerCart   :::::::::::  "+ExpectedTotalPriceWithVat_PerCart, Status.DONE);			
	}
	catch (Exception e) {
		Report.updateTestLog(Action," Verify Product Price With/WithOut VAT failed ", Status.FAIL);
	}
	
				
				}
				
				try {

				// Verify Total Price Per Cart
				//String ActualTotalPriceWithVat_PerCart = Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//div[contains(@class,'checkOutSumCa-CA')]")).getText();
				String ActualTotalPriceWithVat_PerCart = Driver.findElement(By.xpath("((//div[@class='row ship-to'])["+i+"]//div[contains(@class,'row gsk-box-productSection')])[1]/following-sibling::div//div[contains(@class,'checkOutSumCa-CA')]")).getText();

				ActualTotalPriceWithVat_PerCart = ActualTotalPriceWithVat_PerCart.replace(",", "");
				String [] ActualTotalPriceWithVat_PerCartArray = ActualTotalPriceWithVat_PerCart.split(" ");
				//ActualTotalPriceWithVat_PerCartArray=ActualTotalPriceWithVat_PerCartArray[1].split("/");
				String ActualTotalPriceWithVat_PerCart_String=ActualTotalPriceWithVat_PerCartArray[1];
				System.out.println("1257 line "+i);
					
				double ActualTotalPriceWithVat_PerCart_Double = Double.parseDouble(ActualTotalPriceWithVat_PerCart_String);
			//	Report.updateTestLog(Action," ActualTotalPriceWithVat_PerCart_Double:::: "+ActualTotalPriceWithVat_PerCart_Double, Status.DONE);
				if (ExpectedTotalPriceWithVat_PerCart==ActualTotalPriceWithVat_PerCart_Double) {
					Report.updateTestLog(Action, "Expected TotalPriceWithVat For Cart "+i+" is "+ExpectedTotalPriceWithVat_PerCart+" And Actual TotalPriceWithVat For Cart "+i+" is "+ActualTotalPriceWithVat_PerCart_Double, Status.PASS);
				}else {
					Report.updateTestLog(Action, "Expected TotalPriceWithVat For Cart "+i+" is "+ExpectedTotalPriceWithVat_PerCart+" And Actual TotalPriceWithVat For Cart "+i+" is "+ActualTotalPriceWithVat_PerCart_Double, Status.FAIL);
				}
				
				
				

				
				System.out.println("1277 line "+i  +"  ::"+ ExpectedTotalPriceWithVat_AllCart);
				// Verify Total Price for ALL Carts
			ExpectedTotalPriceWithVat_AllCart = Math.round((ExpectedTotalPriceWithVat_AllCart+ExpectedTotalPriceWithVat_PerCart) * 100.0) / 100.0;
			
			System.out.println("1277 line "+i  +"  ::"+ ExpectedTotalPriceWithVat_AllCart);
				}catch (Exception e) {
					Report.updateTestLog(Action," Verify Total Price Per Cart  getting failed "+e, Status.FAIL);
				}
				
				
//					
				
				
				}
			try {	
				
				// Verify Total Price for ALL Carts
			String ActualTotalPriceWithVat_AllCart = Driver.findElement(By.xpath("//div[@class='row cart-bottom']//div[contains(@class,' total-ipad-val-CA')]")).getText(); 

			ActualTotalPriceWithVat_AllCart = ActualTotalPriceWithVat_AllCart.replace(",", "");
			
			String [] ActualTotalPriceWithVat_AllCartArray = ActualTotalPriceWithVat_AllCart.split(" ");
			//ActualTotalPriceWithVat_AllCartArray=ActualTotalPriceWithVat_AllCartArray[1].split("/");

			String ActualTotalPriceWithVat_AllCart_String=ActualTotalPriceWithVat_AllCartArray[1];


			double ActualTotalPriceWithVat_AllCart_Double = Double.parseDouble(ActualTotalPriceWithVat_AllCart_String);


			if (ExpectedTotalPriceWithVat_AllCart==ActualTotalPriceWithVat_AllCart_Double) {
				Report.updateTestLog(Action, "Expected TotalPriceWithVat_AllCart "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPriceWithVat_AllCart "+ActualTotalPriceWithVat_AllCart_Double, Status.PASS);
			}else {
				Report.updateTestLog(Action, "Expected TotalPriceWithVat_AllCart "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPriceWithVat_AllCart "+ActualTotalPriceWithVat_AllCart_Double, Status.FAIL);
			}

			
			}catch (Exception e) {
				Report.updateTestLog(Action," Verify Total Price for ALL Carts  getting failed "+e, Status.FAIL);
			}
			
			try {
			// Verify total Cart Price displayed at Cart Header
			String ActualTotalPriceAtCartHeader = Driver.findElement(By.xpath("//span[@id='cartTotalNonZero']/span[contains(@class,'count')]/span[2]")).getText();

			ActualTotalPriceAtCartHeader = ActualTotalPriceAtCartHeader.replace(",", "");
			String [] ActualTotalPriceAtCartHeaderArray = ActualTotalPriceAtCartHeader.split(" ");
			//ActualTotalPriceAtCartHeaderArray=ActualTotalPriceAtCartHeaderArray[1].split("/");
			String ActualTotalPriceAtCartHeader_String=ActualTotalPriceAtCartHeaderArray[1];

				

			double ActualTotalPriceAtCartHeader_Double = Double.parseDouble(ActualTotalPriceAtCartHeader_String);

			if (ExpectedTotalPriceWithVat_AllCart==ActualTotalPriceAtCartHeader_Double) {
				Report.updateTestLog(Action, "Expected TotalPrice_At Cart Header "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPrice_At Cart Header "+ActualTotalPriceAtCartHeader_Double, Status.PASS);
			}else {
				Report.updateTestLog(Action, "Expected TotalPrice_At Cart Header "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPrice_At Cart Header "+ActualTotalPriceAtCartHeader_Double, Status.FAIL);
			}

			
			
			
			}catch (Exception e) {
				Report.updateTestLog(Action," Verify total Cart Price displayed at Cart Header  getting failed ", Status.FAIL);
			}
			
			
			
			
			
			

		}catch(Exception e1) {
			Report.updateTestLog(Action,"Before Verify ShipTo Row expanded by default getting failed "+e1, Status.FAIL);			
		}


	}

	public void pdf_validation_CA(String pdfname )
	{
		File theNewestFile = null;
		int pageCount=0;
		String[] strs=null;
String pdfdata=null;
		String s=null;
		String Loca =null;
		try {
		String path_ca = userData.getData("RegressionData", "Download Path");
		
	//	Report.updateTestLog(Action,  "  path_ca :  "+path_ca, Status.DONE);
		File dir = new File(path_ca);
        
        FileFilter fileFilter = new WildcardFileFilter("*.pdf");
        File[] files = dir.listFiles(fileFilter);
        
      
        
        if (files.length > 0 ) {
            /** The newest file comes first **/
        	
        	
            Arrays.sort(files, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
            
            
            theNewestFile = files[0];
        
            //Report.updateTestLog(Action, theNewestFile+ "  theNewestFile  ", Status.DONE);
            
         
         Loca =theNewestFile.toString();
        
        Thread.sleep(1000);
				
				
        
     s=    Loca.replace("\\", "//");
    
    
   
    
     strs = s.split("//");
    Thread.sleep(15000);
   // Report.updateTestLog(Action,  "  strs :  "+strs[3]+"   ssss  "+strs[4], Status.DONE);
    
    if(strs[4].contains(pdfname))
    {
    	
    	 Report.updateTestLog(Action, strs[4] +" PDF is Dowload sucessfully with Data  " , Status.PASS);
      	 
    	// Report.updateTestLog(Action, s, Status.DONE);
    	   
    	    
		  PDFUtil p = new PDFUtil();
		  pageCount = p.getPageCount(s);
		  pdfdata=p.getText(s) ;
		  
		  if((pdfdata.contains("General Terms and Conditions of Supply") )  || (pdfdata.contains("Conditions générales d’approvisionnement")))
		  {
		  
		  Report.updateTestLog(Action,  "  PDF  PAGE Contains Data: General Terms and Conditions of Supply  and pageCout " +pageCount, Status.PASS);
		  }
		  else
		  {
			  Report.updateTestLog(Action,  "  PAGE Count of PDF :  "+pageCount, Status.DONE);
		  }
    	
    }
    else
    {
    	Report.updateTestLog(Action," Getting Error in PDF Download ", Status.FAIL);
    	
    	
    }
    
    

        }
        
        else
        {
        	
        	Report.updateTestLog(Action, "  PDF downloaded Failed and Getting Error   ", Status.FAIL);
        }
        
        
		}catch (Exception e) {
			Report.updateTestLog(Action, " PDF download failed or getting error in Opening PDF", Status.DONE);
			
		}  
        
        
		
	}

	//Order Page validation
	
	
	@Action(object = ObjectType.BROWSER, desc = "Enter OrderCount,CartCount,ProductPerCart,ShipTo-BillTo [<Data>]", input = InputType.YES)
	public void CA_verifyOrderPage() {



		try{

			String[] InputData = Data.split(",");

			String OrderCount = InputData[0];
			String CartCount = InputData[1];
			String ProductPerCart = InputData[2];

			HashMap<String,String> ShipToBillTo_Map = new HashMap<String,String>();

			for (int a=3;a<=InputData.length-1;a++) {

				String[] ShipToBillToArray = InputData[a].split("-");
				ShipToBillTo_Map.put(ShipToBillToArray[0], ShipToBillToArray[1]);

			}
			Driver.findElement(By.xpath("//button[contains(text(),'Place Order')]")).click();
			

			WebDriverWait wait = new WebDriverWait(Driver,10);
			wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
					.executeScript("return document.readyState")));

			// Verify Header Text, Order Confirmation No and Order Confirmation Date
			String ConfirmOrderHeader = Driver.findElement(By.xpath("//p[contains(text(),' Order Confirmation')]")).getText();
			WebElement OrderConfirmationNumber = Driver.findElement(By.xpath("//strong[contains(text(),'confirmation number ')]"));
			WebElement OrderConfirmationDate = Driver.findElement(By.xpath("//p[@id='order-confirmation-date']"));
			WebElement OrderConfirmationSentto=Driver.findElement(By.xpath("//strong[contains(text(),'Confirmation Sent to:')]/parent::p"));

			String[] OrderConfirmationNumberArray = OrderConfirmationNumber.getText().split("\\s+");
			String[] OrderConfirmationDateArray = OrderConfirmationDate.getText().split(":");
			String[] OrderConfirmationSenttoArray=OrderConfirmationSentto.getText().split(":");


			if (ConfirmOrderHeader.equalsIgnoreCase("Order Confirmation") && OrderConfirmationNumber.isDisplayed() && OrderConfirmationDate.isDisplayed() &&OrderConfirmationSentto.isDisplayed())
			{
				Report.updateTestLog(Action, "Order Placed Successfully. Order Confirmation No ::- "+OrderConfirmationNumberArray[4]+" | Order Confirmation Date - "+OrderConfirmationDateArray[1]+" | Order Confirmation Sent to - "+OrderConfirmationSenttoArray[1], Status.PASS);
			
			//	Report.updateTestLog(Action, "Order Confirmation No 3 ::- "+OrderConfirmationNumberArray[3]+"Order Confirmation No 2 ::- "+OrderConfirmationNumberArray[2], Status.DONE);
			
			
			}else {
				Report.updateTestLog(Action, "Order Place is NOT Successful", Status.FAIL);
			}

			// Verify Drukuj button Print button
try {
			List<WebElement> DrukujButtons = Driver.findElements(By.xpath("//button[contains(text(),'Print')]"));

			if (DrukujButtons.size()==2) {
				//PDF_validation_check();
				//print_buttoncheck(2);
				Report.updateTestLog(Action, "Total Print button count: Expected is 2 And Actual is "+DrukujButtons.size(), Status.PASS);
				
			}else {
				Report.updateTestLog(Action, "Total Print button count: Expected is 2 And Actual is "+DrukujButtons.size(), Status.FAIL);
			}
}catch (Exception e) {
	Report.updateTestLog(Action, "DrukujButtons Failing  ", Status.FAIL);
}


			/////////////////////

			List<WebElement> Carts = Driver.findElements(By.xpath("//div[@class='row ship-to newpage_eachOrder']"));

			// Verify Total Cart displayed
			if(Carts.size()==Integer.parseInt(CartCount)) {
				Report.updateTestLog(Action, "Expected Cart Count "+CartCount+" And Actual Cart Count "+Carts.size(), Status.PASS);
			}else {
				Report.updateTestLog(Action, "Expected Cart Count "+CartCount+" And Actual Cart Count "+Carts.size(), Status.FAIL);
			}
			
			
			
			// Verify Total "Nowy koszyk" section count New Shopping Cart
			if (ShipToBillTo_Map.size()>1) {
				List<WebElement> Nowy_koszyk = Driver.findElements(By.xpath("//div[contains(text(),'New Shopping Cart')]"));
				Report.updateTestLog(Action, OrderCount+"ShipToBillTo_Map.size()"+ShipToBillTo_Map.size()  + " :: "+Nowy_koszyk.size(), Status.DONE);
				if(Nowy_koszyk.size()==Integer.parseInt(OrderCount)-1) {
					Report.updateTestLog(Action, "Total New Shopping Cart Section Count is "+Nowy_koszyk.size()+" Which is Expected", Status.PASS);
				}else {
					Report.updateTestLog(Action, "Total New Shopping Cart Section Count is "+Nowy_koszyk.size()+" Which is NOT Expected", Status.FAIL);
				}
			}



			double ExpectedTotalPriceWithVat_AllCart = 0.00;

			ArrayList<String> OrderNumberList = new ArrayList<String>();

			for (int i=1;i<=Carts.size();i++) {

				// Get Order Number
				WebElement OrderNumber = Driver.findElement(By.xpath("//div[@class='row ship-to newpage_eachOrder']["+i+"]//h2[contains(@class,'ship-to-title')]"));
				String OrderNumberString = OrderNumber.getText();
				String[] OrderNumberArray = OrderNumberString.split("\\s+");
				OrderNumberList.add(OrderNumberArray[1]);

				if(OrderNumber.isDisplayed()) {
					Report.updateTestLog(Action, "Order Number for Cart "+i+" is -->"+OrderNumberArray[1], Status.PASS);
					
					userData.putData("RegressionData", "Order"+i, OrderNumberArray[1]);
				}else {
					Report.updateTestLog(Action, "Order Number for Cart "+i+" NOT Present", Status.FAIL);
				}



				// Verify ShipTo and BillTo
				String ActualShipTo = Driver.findElement(By.xpath("//div[@class='row ship-to newpage_eachOrder']["+i+"]//div[contains(@class,'cart-add-tlt-CA')]//span[contains(@class,'shpAddrAln')]")).getText();
				String ActualBillTo = Driver.findElement(By.xpath("(//div[@class='row ship-to newpage_eachOrder']["+i+"]//span[contains(@class,'shpAddrAln')])[2]")).getText();

				for (String ExpectedShipTo : ShipToBillTo_Map.keySet()) {
					if(ActualShipTo.contains(ExpectedShipTo)) {
						String ExpectedBillTo = ShipToBillTo_Map.get(ExpectedShipTo);
						if (ActualBillTo.contains(ExpectedBillTo)) {
							Report.updateTestLog(Action, "Cart Created For "+ExpectedShipTo+" And Corresponding BillTo "+ExpectedBillTo, Status.PASS);
						}else {
							Report.updateTestLog(Action, "Cart is NOT Created For Provided ShipTo and BillTo", Status.FAIL);
						}

					}
				}


				List<WebElement> ProductRow = Driver.findElements(By.xpath("//div[@class='row ship-to newpage_eachOrder']["+i+"]//div[contains(@class,'row product-ListItem')]"));

				// Verify Total Product Per Cart displayed
				if(ProductRow.size()==Integer.parseInt(ProductPerCart)) {
					Report.updateTestLog(Action, "Expected Product Row Per Cart "+ProductPerCart+" And Actual Product Row Per Cart "+ProductRow.size(), Status.PASS);
				}else {
					Report.updateTestLog(Action, "Expected Product Row Per Cart "+ProductPerCart+" And Actual Product Row Per Cart "+ProductRow.size(), Status.FAIL);
				}

				double ExpectedTotalPriceWithVat_PerCart=0.00;

				// Verify each product row
				String ProductQuantity = null;
				for (int j=1;j<=ProductRow.size();j++) {
try {
					// Verify Product Name and PDP
	// Verify Product Name and PDP
	WebElement ProductNameLink = Driver.findElement(By.xpath("//div[@class='row ship-to newpage_eachOrder']["+i+"]//div[contains(@class,'row product-ListItem')]["+j+"]//a[@class='product-name ']"));
	String ProductNameOnCartPage = ProductNameLink.getText();

	ProductNameLink.click();

	WebDriverWait wait4 = new WebDriverWait(Driver,10);
	wait4.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
			.executeScript("return document.readyState")));

	WebElement PDP = Driver.findElement(By.xpath("//span[contains(text(),'Product Details')]"));
	String ProductNameOnPDP = Driver.findElement(By.xpath("//h1[@id='productDetail-name']")).getText();

	if (PDP.isDisplayed() && ProductNameOnPDP.equalsIgnoreCase(ProductNameOnCartPage)) {
		Report.updateTestLog(Action, "PDP Opened For Product Name "+ProductNameOnCartPage, Status.PASS);
	}else {
		Report.updateTestLog(Action, "PDP NOT Opened For Product Name "+ProductNameOnCartPage, Status.FAIL);
	}


	Driver.navigate().back();

	WebDriverWait wait1 = new WebDriverWait(Driver,10);
	wait1.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
			.executeScript("return document.readyState")));


					// Verify Product Price With/WithOut VAT
					String PriceWithVat = Driver.findElement(By.xpath("//div[@class='row ship-to newpage_eachOrder']["+i+"]//div[contains(@class,'row product-ListItem')]["+j+"]//div[@class='cnd-price-print-CA']")).getText();
					 ProductQuantity = Driver.findElement(By.xpath("//div[@class='row ship-to newpage_eachOrder']["+i+"]//div[contains(@class,'row product-ListItem')]["+j+"]//div[@class='input-control']")).getText();
					String ActualTotalPriceWithVat_PerProduct = Driver.findElement(By.xpath("//div[@class='row ship-to newpage_eachOrder']["+i+"]//div[contains(@class,'row product-ListItem')]["+j+"]//div[contains(@class,'confi-total')]")).getText();

					PriceWithVat = PriceWithVat.replace(",", "");
					//PriceWithVat = PriceWithVat.replace(",", "");
					String [] PriceWithVatArray = PriceWithVat.split(" ");
					// PriceWithVatArray=PriceWithVatArray[1].split("/");
						
					double PriceWithVat_Double = Double.parseDouble(PriceWithVatArray[1]);
								
						
					int ProductQuantity_Int = Integer.parseInt(ProductQuantity);
							
						
					double ExpectedTotalPriceWithVat_PerProduct =  Math.round((PriceWithVat_Double*ProductQuantity_Int) * 100.0) / 100.0;
					
					
					ActualTotalPriceWithVat_PerProduct = ActualTotalPriceWithVat_PerProduct.replace(",", "");
					String [] ActualTotalPriceWithVat_PerProductArray = ActualTotalPriceWithVat_PerProduct.split(" ");
					
					String ActualTotalProductPriceWithVat_String=ActualTotalPriceWithVat_PerProductArray[1];
					
					double ActualTotalPriceWithVat_PerProduct_Double = Double.parseDouble(ActualTotalProductPriceWithVat_String);
					
					if (ExpectedTotalPriceWithVat_PerProduct==ActualTotalPriceWithVat_PerProduct_Double) {
						Report.updateTestLog(Action, "Expected TotalPriceWithVat "+ExpectedTotalPriceWithVat_PerProduct+" And Actual TotalPriceWithVat "+ActualTotalPriceWithVat_PerProduct_Double, Status.PASS);
					}else {
						Report.updateTestLog(Action, "Expected TotalPriceWithVat "+ExpectedTotalPriceWithVat_PerProduct+" And Actual TotalPriceWithVat "+ActualTotalPriceWithVat_PerProduct_Double, Status.FAIL);
					}

					// Verify Total Price Per Cart
					//ExpectedTotalPriceWithVat_PerCart = Math.round((ExpectedTotalPriceWithVat_PerCart+ExpectedTotalPriceWithVat_PerProduct+ProductQuantity_Int) * 100.0) / 100.0;
					ExpectedTotalPriceWithVat_PerCart = Math.round((ExpectedTotalPriceWithVat_PerCart+ExpectedTotalPriceWithVat_PerProduct) * 100.0) / 100.0;
					Report.updateTestLog(Action, " ExpectedTotalPriceWithVat_PerCart   :::::::::::  "+ExpectedTotalPriceWithVat_PerCart, Status.DONE);			


}
catch (Exception e) {
	Report.updateTestLog(Action," Verify Product Price  getting failed ", Status.FAIL);
}		
				}
				
				try {

				// Verify Total Price Per Cart
			String ActualTotalPriceWithVat_PerCart = Driver.findElement(By.xpath("//div[@class='row ship-to newpage_eachOrder']["+i+"]//div[contains(@class,'grand-total-print-CA')]")).getText();

				ActualTotalPriceWithVat_PerCart = ActualTotalPriceWithVat_PerCart.replace(",", "");
				String [] ActualTotalPriceWithVat_PerCartArray = ActualTotalPriceWithVat_PerCart.split(" ");
				//ActualTotalPriceWithVat_PerCartArray=ActualTotalPriceWithVat_PerCartArray[1].split("/");
				String ActualTotalPriceWithVat_PerCart_String=ActualTotalPriceWithVat_PerCartArray[1];

				
				double ActualTotalPriceWithVat_PerCart_Double = Double.parseDouble(ActualTotalPriceWithVat_PerCart_String);
				Report.updateTestLog(Action," ActualTotalPriceWithVat_PerCart_Double:::: "+ActualTotalPriceWithVat_PerCart_Double, Status.DONE);
				if (ExpectedTotalPriceWithVat_PerCart==ActualTotalPriceWithVat_PerCart_Double) {
					Report.updateTestLog(Action, "Expected TotalPriceWithVat For Cart "+i+" is "+ExpectedTotalPriceWithVat_PerCart+" And Actual TotalPriceWithVat For Cart "+i+" is "+ActualTotalPriceWithVat_PerCart_Double, Status.PASS);
				}else {
					Report.updateTestLog(Action, "Expected TotalPriceWithVat For Cart "+i+" is "+ExpectedTotalPriceWithVat_PerCart+" And Actual TotalPriceWithVat For Cart "+i+" is "+ActualTotalPriceWithVat_PerCart_Double, Status.FAIL);
				}
				
				
				

				
			
				// Verify Total Price for ALL Carts
			ExpectedTotalPriceWithVat_AllCart = Math.round((ExpectedTotalPriceWithVat_AllCart+ExpectedTotalPriceWithVat_PerCart) * 100.0) / 100.0;
			
				
				}catch (Exception e) {
					Report.updateTestLog(Action," Verify Total Price Per Cart  getting failed ", Status.FAIL);
				}
				}
			try {	
				
				// Verify Total Price for ALL Carts
			String ActualTotalPriceWithVat_AllCart = Driver.findElement(By.xpath("//div[@class='row cart-bottom']//div[contains(@class,'checkSumFinalCostVal-print-CA gTotalAlgn-CA')]")).getText(); 

			ActualTotalPriceWithVat_AllCart = ActualTotalPriceWithVat_AllCart.replace(",", "");
			
			String [] ActualTotalPriceWithVat_AllCartArray = ActualTotalPriceWithVat_AllCart.split(" ");
			//ActualTotalPriceWithVat_AllCartArray=ActualTotalPriceWithVat_AllCartArray[1].split("/");

			String ActualTotalPriceWithVat_AllCart_String=ActualTotalPriceWithVat_AllCartArray[1];

				

			double ActualTotalPriceWithVat_AllCart_Double = Double.parseDouble(ActualTotalPriceWithVat_AllCart_String);


			if (ExpectedTotalPriceWithVat_AllCart==ActualTotalPriceWithVat_AllCart_Double) {
				Report.updateTestLog(Action, "Expected TotalPriceWithVat_AllCart "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPriceWithVat_AllCart "+ActualTotalPriceWithVat_AllCart_Double, Status.PASS);
			}else {
				Report.updateTestLog(Action, "Expected TotalPriceWithVat_AllCart "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPriceWithVat_AllCart "+ActualTotalPriceWithVat_AllCart_Double, Status.FAIL);
			}

			
			}catch (Exception e) {
				Report.updateTestLog(Action," Verify Total Price for ALL Carts  getting failed ", Status.FAIL);
			}
			
		try {
			WebElement Element = Driver.findElement(By.xpath("//span[@id='cartTotalZeroPrice']"));
			
			
			if (Element.getText().equals("(0)")) {
				
				Report.updateTestLog(Action, "Cart is null ", Status.PASS);
				
			}else {
				
				Report.updateTestLog(Action, "Cart is Not null "+ Element.getText(), Status.FAIL);
			}
			}catch (Exception e) {
				Report.updateTestLog(Action," Verify total Cart Price displayed at Cart Header  getting failed ", Status.FAIL);
			}

		//checking 3 Links bellow the order page
		orderconfirmationLinks();
		
		// Verify Orders on Order History Page
					//Driver.findElement(By.xpath("//a[contains(text(),'PrzeglÄ…daj historiÄ™ zamÃ³wienia')]")).click();
					Driver.findElement(By.xpath("//a[contains(text(),'View your order history')]")).click();

					WebDriverWait wait2 = new WebDriverWait(Driver,10);
					wait2.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
							.executeScript("return document.readyState")));

					for (int x=0;x<OrderNumberList.size();x++) {
						String OrderNumber = OrderNumberList.get(x);

						Driver.findElement(By.xpath("//input[@id='search_text_order']")).clear();
						Driver.findElement(By.xpath("//input[@id='search_text_order']")).sendKeys(OrderNumber);

						Driver.findElement(By.xpath("//button[@id='searchtextBtn_order']")).click();
						
						Thread.sleep(5000);

						String SearchResultOrder = Driver.findElement(By.xpath("//div[@class='row']//div[contains(@class,'reservation-number')]//a")).getText();

						if(SearchResultOrder.equalsIgnoreCase(OrderNumber)) {
							Report.updateTestLog(Action, "Order Number "+OrderNumber+" is Present on Order History Page ", Status.PASS);
							String addfav8=userData.getData("RegressionData", "addfavorite");
							
							if(addfav8.equals("Yes")) {
								addAsFavorite_buttoncheck();
								
							}
							
							orderhistoryPage_OrderDetails(x);
							
							
							
						}else {
							Report.updateTestLog(Action, "Order Number "+OrderNumber+" is NOT Present on Order History Page ", Status.FAIL);
						}
					}
					
					
	
					// Back office Login
					
				// back office last
		
		
		}catch(Exception e1) {
			Report.updateTestLog(Action,"Before Verify ShipTo Row expanded by default getting failed ", Status.FAIL);			
		}


	}
	
	

	
	
	
	@Action(object = ObjectType.BROWSER, desc = "Validating  Remove from cart Link ", input = InputType.NO)
	public void CA_removeProduct_Validation_check() throws InterruptedException {
		List<WebElement> removeproduct=null;
		//WebElement Element = Driver.findElement(By.xpath("//span[@id='cartTotalNonZero']/span[1]"));
		WebElement Element = Driver.findElement(By.xpath("//span[@id='itemCount']"));
		//System.out.println(Element);
		
		/*
		 * String[] qtyarray = Element.getText().split("\\D");
		 * System.out.println(qtyarray); int num = Integer.parseInt(qtyarray[1]);
		 * System.out.println(qtyarray[1]);
		 */
		//AddProduct_button_AnotherShipTo();
		
		if (!Element.getText().equals("(0)")) {
			Driver.findElement(By.xpath(" //span[contains(@class,'yCmsComponent')]")).click();
			
			
			Thread.sleep(10000);
			
			try {
				removeproduct =Driver.findElements(By.xpath("//a[@id='removeCartLink']"));
			// Report.updateTestLog(Action,"1st No WYŚWIETL RABATY avialabe   "+removeproduct.size(), Status.DONE);
			}catch (Exception e) {
				Report.updateTestLog(Action," No Products avilable ", Status.DONE);
			}
			
			try {
				if(removeproduct.size()==0) {
					
					Report.updateTestLog(Action," No Products avilable in Page", Status.DONE);	
				}
			
			for(int i =removeproduct.size(); i>=0;i--)
			{
				
				
				Driver.findElement(By.xpath("(//a[@id='removeCartLink'])["+i+"]")).click();
				
				WebDriverWait wait = new WebDriverWait(Driver, 500);
		        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//*[@id='removeProduct-confirm'])[2]")));

		        Report.updateTestLog(Action,"Removing Product Pop got displayed ", Status.PASS);	
		        
		        
		        Driver.findElement(By.xpath("(//button[@id='removeProduct-close'])[2]")).click();  
		        
		        Report.updateTestLog(Action,"Sucussfully Clicked on No, Don't remove button displayed ", Status.PASS);
		        
		        Driver.findElement(By.xpath("//span[contains(@class,'yCmsComponent')]")).click();
		      //Thread.sleep(10000);
		        CA_removeProduct();
				
				
				
			}
			}catch (Exception e) {
				
				
				}
			
			
			
		}else {
			Report.updateTestLog(Action, "Cart is null ", Status.PASS);
		}

		
	
	}
	
	@Action(object = ObjectType.BROWSER, desc = "Enter ProductCount,CartCount,ProductPerCart,ShipTo-BillTo [<Data>]", input = InputType.YES)
	public void CA_ShoppingCartPage_Quantity_Check() {
		
		
		AddProduct_button_AnotherShipTo();
		String[] InputData = Data.split(",");
		

		
		List<WebElement> pqlist =Driver.findElements(By.xpath("//div[@class='input-control pack-quantity']//input[@id='quantity']"));
		
		for(int i =1;i<=pqlist.size();i++)
		
		{
			
			
			for(int l=0; l<=InputData.length-1 ;l++){
				
			try {
				Report.updateTestLog(Action, " inputdata ::  "+InputData[l], Status.DONE);
			if(!InputData[l].equals("0")) {
				//  //div[@class='input-control pack-quantity']//input[@id='quantity']
				//Driver.findElement(By.xpath("(//div[@class='input-control pack-quantity']/form/input)["+i+"]")).clear();
				
				Driver.findElement(By.xpath("(//div[@class='input-control pack-quantity']/form/input)["+i+"]")).sendKeys(Keys.chord(Keys.CONTROL,"a",Keys.DELETE));
				
				//Driver.findElement(By.xpath("(//div[@class='input-control pack-quantity']/form/input)["+i+"]")).
				//Thread.sleep(5000);
			Driver.findElement(By.xpath("(//div[@class='input-control pack-quantity']/form/input)["+i+"]")).sendKeys(InputData[l]);
			
			Driver.findElement(By.xpath("(//input[@aria-labelledby='poNumberLabel'])["+i+"]")).click();
			Thread.sleep(5000);
			
	String gg=		Driver.findElement(By.xpath("(//div[@class='input-control pack-quantity']//input[@id='quantity'])["+i+"]")).getAttribute("value");
		String tprise=Driver.findElement(By.xpath("((//div[@class='row ship-to']//div[contains(@class,'row product-item')]//div[contains(@class,'product-total')]))["+i+"]")).getText();	
	Report.updateTestLog(Action, " User Able to modify Quantity of Product Sucessfully ::  "+gg  + " ::  Total got updated :: " +tprise, Status.PASS);
	
	
	
	
			}
			else {

				
				Driver.findElement(By.xpath("(//div[@class='input-control pack-quantity']/form/input)["+i+"]")).sendKeys(Keys.chord(Keys.CONTROL,"a",Keys.DELETE));
				
				Driver.findElement(By.xpath("(//div[@class='input-control pack-quantity']/form/input)["+i+"]")).sendKeys(InputData[l]);
				Report.updateTestLog(Action, "  Quantity of Product Updated to ZERO  "+InputData[l], Status.DONE);
				Driver.findElement(By.xpath("(//input[@aria-labelledby='poNumberLabel'])["+i+"]")).click();
				Thread.sleep(5000);
				
				
				
				Thread.sleep(5000);
				if(Driver.findElement(By.xpath("//div[contains(@class,'cad grandtotalinner-CA')]")).isDisplayed())
				{
					
					String TS=Driver.findElement(By.xpath("//div[contains(@class,'cad grandtotalinner-CA')]")).getText();
					 Report.updateTestLog(Action,"Total Shipping value become ZERO or Product got deleted", Status.PASS);
					 
					 
			}else {
				
				Report.updateTestLog(Action,"Total Shipping value Not become ZERO ", Status.FAIL);
				
			}
				
			}
			}catch (Exception e)
			{
				Report.updateTestLog(Action, "Failed in xpath issue "+e, Status.DONE);
			}
			
			
			
			
			
			
			
			
			
		}
		
		}
		
		
		
		
		
	}
	
		
	public void AddProduct_button_AnotherShipTo()
	
	
	{
		WebDriverWait wait = new WebDriverWait(Driver,10);
		
		if(Driver.findElement(By.xpath("//a[@id='changeShipToLink']")).isDisplayed())
		{
			Report.updateTestLog(Action, Driver.findElement(By.xpath("//a[@id='changeShipToLink']")).getText()+"  ::Button Dispalyed ", Status.PASS);
			
			try {
			Driver.findElement(By.xpath("//a[@id='changeShipToLink']")).click();
			
			Report.updateTestLog(Action, Driver.findElement(By.xpath("//a[@id='changeShipToLink']")).getText()+"  ::Clicked on Button ", Status.PASS);
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@id='search-ship-to-field']")));
			
			Report.updateTestLog(Action, "Search and Select the ship to you would like to order for Pop Dispalyed", Status.PASS);
			Driver.findElement(By.xpath("//input[@id='search-ship-to-field']")).sendKeys("11006");
			  
			Driver.findElement(By.xpath("//div[@id='change-ship-to-modal']//div[@class='row ship-to-row'][1]//div/span[2]")).click();
			
			Report.updateTestLog(Action, "Selected ShipTo", Status.DONE);
			
			try {
			Driver.findElement(By.xpath("//button[@id='orderForThisAddressBtn' and contains(text(),'Order for this address')]")).click();
			//Driver.findElement(By.xpath("//button[@id='orderForThisAddressBtn']")).click();
			}catch(Exception e)
			{
				
				Driver.findElement(By.xpath("//button[@id='orderForThisAddressBtn' and contains(text(),'Commander pour cette adresse')]")).click();
			}
			Thread.sleep(2000);
			
			wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
					.executeScript("return document.readyState")));
			
			String PaymentInfoTitle = Driver.getTitle();
			if((PaymentInfoTitle.contains("GSK Direct Canada | Purchase Products")) || (PaymentInfoTitle.contains("GSK Direct Canada | Acheter des produits")) )
			{
				
				Report.updateTestLog(Action, "User Navigate to Purchase Products Page", Status.PASS);
				
				
				try {
					Driver.findElement(By.xpath("//a[contains(text(),'Shopping cart')]")).click();
					}
					catch(Exception e)
					{
						
						Driver.findElement(By.xpath("//a[contains(text(),'Panier d’achat')]")).click();
					}
				
			}else {
				Report.updateTestLog(Action, "User NOT Navigate to Purchase Products Page", Status.FAIL);
			}
					
			
						

			}catch (Exception e)
			{
				Report.updateTestLog(Action, "Failed in xpath issue "+e, Status.DONE);
			}
			
		
		
	}
	
	
	

}
	

//	@Action(object = ObjectType.BROWSER, desc = "PDF Name validations", input = InputType.NO)
	public void CA_PDF_validation_check() {
		Driver.findElement(By.xpath("(//button[contains(text(),'Print')])[1]")).click();
		//Thread.sleep(9000);
		
		
		
		String pdf_name=Data;
		File theNewestFile = null;
		int pageCount=0;
		String[] strs=null;

		String s=null;
		String Loca =null;
		WebDriverWait wait = new WebDriverWait(Driver, 600);
		
		
		WebElement popupdrpdown;
		WebElement pdfselection;
		WebElement Savebutton;
		JavascriptExecutor jsE = (JavascriptExecutor) Driver;
		try {
		 popupdrpdown = (WebElement) jsE.executeScript(" return document.querySelector('print-preview-app')."
				+ "shadowRoot.querySelector('#sidebar').shadowRoot.querySelector('#destinationSettings')."
				+ "shadowRoot.querySelector('#destinationSelect').shadowRoot.querySelector('select')");
		
		wait.until(ExpectedConditions.invisibilityOf(popupdrpdown));
		
		popupdrpdown.click();
		Report.updateTestLog(Action, "Print popup:: ", Status.PASS);
		}
		catch (Exception e)
		{
			Report.updateTestLog(Action, "Unable to click on the popup "+e, Status.DONE);
		}
		
		try {
			pdfselection = (WebElement) jsE.executeScript(" return document.querySelector('print-preview-app')."
					+ "shadowRoot.querySelector('#sidebar').shadowRoot.querySelector('#destinationSettings')."
					+ "shadowRoot.querySelector('#destinationSelect').shadowRoot.querySelector('select > option:nth-child(3)')");
			
			wait.until(ExpectedConditions.invisibilityOf(pdfselection));
			Report.updateTestLog(Action, "Pdff :::"+pdfselection.getText(), Status.DONE);
			pdfselection.click();
			}
			catch (Exception e)
			{
				Report.updateTestLog(Action, "Unable to click on the pdfselection "+e, Status.DONE);
			}
		
		
		
		try {
			Savebutton = (WebElement) jsE.executeScript(" return document.querySelector('print-preview-app').shadowRoot.querySelector('#sidebar')."
					+ "shadowRoot.querySelector('print-preview-button-strip')."
					+ "shadowRoot.querySelector('div > cr-button.action-button')");
			
			wait.until(ExpectedConditions.elementToBeClickable(Savebutton));
			Report.updateTestLog(Action, "Pdff :::"+Savebutton.getText(), Status.DONE);
			Savebutton.click();
			}
			catch (Exception e)
			{
				Report.updateTestLog(Action, "Unable to click on the pdfselection "+e, Status.DONE);
			}
		
		
		
		
		try {
		
					
		Robot robot = new Robot();
//		Thread.sleep(1000);
//		robot.keyPress(KeyEvent.VK_CONTROL);
//		
//		Thread.sleep(1000);
//		robot.keyPress(KeyEvent.VK_S);
//		
//		Thread.sleep(1000);
//		robot.keyRelease(KeyEvent.VK_CONTROL);
//		
//		Thread.sleep(1000);
//		robot.keyRelease(KeyEvent.VK_S);
		
		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_ENTER);
		
		Thread.sleep(1000);
		robot.keyRelease(KeyEvent.VK_ENTER);
		
							 
		String path = userData.getData("RegressionData", "Download Path");
        File dir = new File(path);
          
        FileFilter fileFilter = new WildcardFileFilter("*.pdf");
      
        //Report.updateTestLog(Action, fileFilter.toString() +"   : fileFilter  " , Status.PASS);
        
        File[] files = dir.listFiles(fileFilter);
        
			/*
			 * for(int i=0;i<=files.length-1;i++) { Report.updateTestLog(Action, files[i]
			 * +"  : Files  " , Status.PASS); }
			 */
       
      
        if (files.length > 0 ) {
            /** The newest file comes first **/
        	
        	
            Arrays.sort(files, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
            
            
            theNewestFile = files[0];
        
            //Report.updateTestLog(Action, theNewestFile+ "  theNewestFile  ", Status.DONE);
            
        
         Loca =theNewestFile.toString();
        
        Thread.sleep(1000);
				
				
        
     s=    Loca.replace("\\", "//");
    
    
    
    
     strs = s.split("//");
    Thread.sleep(15000);
  
    
    if(strs[4].contains(Data))
    {
    	
    	 Report.updateTestLog(Action, strs[4] +" PDF is Dowload sucessfully with Data  " , Status.PASS);
    	 
    	    	 
    	 
    	 
    	 Report.updateTestLog(Action, s, Status.DONE);
    	   
    	    
		  PDFUtil p = new PDFUtil();
		  pageCount = p.getPageCount(s);
		  Report.updateTestLog(Action,  "  PAGE Count of PDF :  "+pageCount, Status.DONE);
		  Report.updateTestLog(Action,  "   PDF  PAGE Contains Data:  "+pageCount, Status.PASS);
		  
    	
    }
    else
    {
    	Report.updateTestLog(Action," Getting Error in PDF Download ", Status.FAIL);
    	
    	
    }
    
    
    
 
				/*
				 * System.out.println(pageCount);
				 * 
				 * String text = p.getText(s);
				 */
			
			 
        
        

        }
        
        else
        {
        	
        	Report.updateTestLog(Action, "  PDF downloaded Failed and Getting Error   ", Status.FAIL);
        }
		
				
		
		
		
		
		
		
		
		
		
		
		
		}
		
		catch (Exception e) {
			Report.updateTestLog(Action, "PDF_validation_check Failing  ", Status.FAIL);
		}
		
		
		
		
	}
	

	
	@Action(object = ObjectType.BROWSER, desc = "Validating  Price ", input = InputType.YES)
	public void confirmpage_priceValidations()
	
	{


		String paymenttype=null;
		String week_ponum=userData.getData("RegressionData", "WeeklyPOnum");
		try{

			String[] InputData = Data.split(",");

			String ProductCount = InputData[0];
			String CartCount = InputData[1];
			String ProductPerCart = InputData[2];

			HashMap<String,String> ShipToBillTo_Map = new HashMap<String,String>();

			for (int a=3;a<=InputData.length-1;a++) {

				String[] ShipToBillToArray = InputData[a].split("-");
				ShipToBillTo_Map.put(ShipToBillToArray[0], ShipToBillToArray[1]);

			}

			
			WebDriverWait wait1 = new WebDriverWait(Driver,10);

			
			List<WebElement> Carts = Driver.findElements(By.xpath("//div[@class='row ship-to']"));

			


			double ExpectedTotalPriceWithVat_AllCart = 0.00;

			for (int i=1;i<=Carts.size();i++) {
				
				
				// Verify ShipTo and BillTo
				String ActualShipTo = Driver.findElement(By.xpath("((//div[@class='row ship-to'])["+i+"]//div[contains(@class,'cart-add-tlt-CA')]//span[contains(@class,'shpAddrAln')])[1]")).getText();
				String ActualBillTo = Driver.findElement(By.xpath("((//div[@class='row ship-to'])["+i+"]//span[contains(@class,'shpAddrAln')])[2]")).getText();

				for (String ExpectedShipTo : ShipToBillTo_Map.keySet()) {
					if(ActualShipTo.contains(ExpectedShipTo)) {
						String ExpectedBillTo = ShipToBillTo_Map.get(ExpectedShipTo);
						if (ActualBillTo.contains(ExpectedBillTo)) {
							Report.updateTestLog(Action, "Cart Created For "+ExpectedShipTo+" And Corresponding BillTo "+ExpectedBillTo, Status.PASS);
						}else {
							Report.updateTestLog(Action, "Cart is NOT Created For Provided ShipTo and BillTo", Status.FAIL);
						}

					}
				}

//				Report.updateTestLog(Action, "List<WebElement> ProductRow  before:: "+i, Status.PASS);
				
				List<WebElement> ProductRow = Driver.findElements(By.xpath("(//div[@class='row ship-to']//div[contains(@class,'row product-item')])["+i+"]"));

				// Verify Total Product Per Cart displayed
				if(ProductRow.size()==Integer.parseInt(ProductPerCart)) {
					Report.updateTestLog(Action, "Expected Product Row Per Cart "+ProductPerCart+" And Actual Product Row Per Cart "+ProductRow.size(), Status.PASS);
				}else {
					Report.updateTestLog(Action, "Expected Product Row Per Cart "+ProductPerCart+" And Actual Product Row Per Cart "+ProductRow.size(), Status.FAIL);
				}
System.out.println("1167 line "+i);
				double ExpectedTotalPriceWithVat_PerCart=0.00;

				// Verify each product row
				
				String ProductQuantity = null;
				/*
				 * int prs=0; List<WebElement>
				 * prow=Driver.findElement(By.xpath("//div[@class='row ship-to']["
				 * +i+"]//div[contains(@class,'row product-item')]//a[@class='product-name']"));
				 * 
				 * if(ProductRow.size()==prow.size()) { prs=ProductRow.size();
				 * Report.updateTestLog(Action,
				 * "prow.size()   and  ProductRow equal:: "+prow.size(), Status.PASS);
				 * 
				 * } else {
				 * 
				 * prs=ProductRow.size()-1; Report.updateTestLog(Action, prs+
				 * "prow.size()   and  ProductRow not equal:: "+ProductRow.size(), Status.PASS);
				 * }
				 */
				
				
				for (int j=1;j<=ProductRow.size();j++) {
					
					//Report.updateTestLog(Action, prs+ "prs and I "+i, Status.PASS);
					

try {
	WebElement ProductNameLink = Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//div[contains(@class,'row product-item')]["+j+"]//a[@class='product-name']"));
	String ProductNameOnCartPage = ProductNameLink.getText();
	Report.updateTestLog(Action, "PDP Opened For Product Name "+ProductNameOnCartPage, Status.PASS);
	ProductNameLink.click();

	WebDriverWait wait = new WebDriverWait(Driver,10);
	wait1.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
			.executeScript("return document.readyState")));

	WebElement PDP = Driver.findElement(By.xpath("//span[contains(text(),'Product Details')]"));
	String ProductNameOnPDP = Driver.findElement(By.xpath("//h1[@id='productDetail-name']")).getText();

	if (PDP.isDisplayed() && ProductNameOnPDP.equalsIgnoreCase(ProductNameOnCartPage)) {
		Report.updateTestLog(Action, "PDP Opened For Product Name "+ProductNameOnCartPage, Status.PASS);
	}else {
		Report.updateTestLog(Action, "PDP NOT Opened For Product Name "+ProductNameOnCartPage, Status.FAIL);
	}


	Driver.navigate().back();

	WebDriverWait wait2 = new WebDriverWait(Driver,10);
	wait2.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
			.executeScript("return document.readyState")));

}
catch (Exception e) {
Report.updateTestLog(Action," Verify Product Price getting failed "+i, Status.FAIL);
}	
	try {
		String [] PriceWithVatArray=null;
		int ProductQuantity_Int=0;
		double PriceWithVat_Double =0;
		String [] ActualTotalPriceWithVat_PerProductArray=null;
	// Verify Product Price With/WithOut VAT
	String PriceWithVat = Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//div[contains(@class,'row product-item')]["+j+"]//div[contains(@class,'withoutvatcheckout-CA')]")).getText();
	 ProductQuantity = Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//div[contains(@class,'row product-item')]["+j+"]//div[contains(@class,'summary-qty-val-CA')]")).getText();
	String ActualTotalPriceWithVat_PerProduct = Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//div[contains(@class,'row product-item')]["+j+"]//div[contains(@class,'product-total')]")).getText();
	//Report.updateTestLog(Action, "PriceWithVat:::: "+PriceWithVat +"ProductQuantity::: "+ProductQuantity +"ActualTotalPriceWithVat_PerProduct"+ActualTotalPriceWithVat_PerProduct, Status.DONE);
	try {
	PriceWithVat = PriceWithVat.replace(",", "");
	//PriceWithVat = PriceWithVat.replace(",", "");
	 PriceWithVatArray = PriceWithVat.split(" ");
	// PriceWithVatArray=PriceWithVatArray[1].split("/");
	 
//	 Report.updateTestLog(Action, "PriceWithVatArray:::: "+PriceWithVatArray[0]+"PriceWithVatArray[1]::: "+PriceWithVatArray[1], Status.DONE);
		
		 PriceWithVat_Double = Double.parseDouble(PriceWithVatArray[1]);
					
			
		 ProductQuantity_Int = Integer.parseInt(ProductQuantity);
	}catch (Exception e) {
		PriceWithVatArray = PriceWithVat.split(" ");
		
		Report.updateTestLog(Action," inside PriceWithVatArray ", Status.DONE);
Report.updateTestLog(Action, "PriceWithVatArray:::: "+PriceWithVatArray[0]+"PriceWithVatArray[1]::: "+PriceWithVatArray[1], Status.DONE);
		
		 PriceWithVat_Double = Double.parseDouble(PriceWithVatArray[1]);
					
			
		 ProductQuantity_Int = Integer.parseInt(ProductQuantity);
	}
	
			
		
	double ExpectedTotalPriceWithVat_PerProduct =  Math.round((PriceWithVat_Double*ProductQuantity_Int) * 100.0) / 100.0;
	try {
	
	ActualTotalPriceWithVat_PerProduct = ActualTotalPriceWithVat_PerProduct.replace(",", "");
	ActualTotalPriceWithVat_PerProductArray = ActualTotalPriceWithVat_PerProduct.split(" ");
	}catch (Exception e) {
		
		ActualTotalPriceWithVat_PerProductArray = ActualTotalPriceWithVat_PerProduct.split(" ");
	}
	String ActualTotalProductPriceWithVat_String=ActualTotalPriceWithVat_PerProductArray[1];
	
	double ActualTotalPriceWithVat_PerProduct_Double = Double.parseDouble(ActualTotalProductPriceWithVat_String);
	
	if (ExpectedTotalPriceWithVat_PerProduct==ActualTotalPriceWithVat_PerProduct_Double) {
		Report.updateTestLog(Action, "Expected TotalPriceWithVat "+ExpectedTotalPriceWithVat_PerProduct+" And Actual TotalPriceWithVat "+ActualTotalPriceWithVat_PerProduct_Double, Status.PASS);
	}else {
		Report.updateTestLog(Action, "Expected TotalPriceWithVat "+ExpectedTotalPriceWithVat_PerProduct+" And Actual TotalPriceWithVat "+ActualTotalPriceWithVat_PerProduct_Double, Status.FAIL);
	}

	// Verify Total Price Per Cart
	//ExpectedTotalPriceWithVat_PerCart = Math.round((ExpectedTotalPriceWithVat_PerCart+ExpectedTotalPriceWithVat_PerProduct+ProductQuantity_Int) * 100.0) / 100.0;
	ExpectedTotalPriceWithVat_PerCart = Math.round((ExpectedTotalPriceWithVat_PerCart+ExpectedTotalPriceWithVat_PerProduct) * 100.0) / 100.0;
		Report.updateTestLog(Action, " ExpectedTotalPriceWithVat_PerCart   :::::::::::  "+ExpectedTotalPriceWithVat_PerCart, Status.DONE);			
	}
	catch (Exception e) {
		Report.updateTestLog(Action," Verify Product Price With/WithOut VAT failed ", Status.FAIL);
	}
	
				
				}
				
				try {

				// Verify Total Price Per Cart
				String ActualTotalPriceWithVat_PerCart = Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//div[contains(@class,'checkOutSumCa-CA')]")).getText();

				ActualTotalPriceWithVat_PerCart = ActualTotalPriceWithVat_PerCart.replace(",", "");
				String [] ActualTotalPriceWithVat_PerCartArray = ActualTotalPriceWithVat_PerCart.split(" ");
				//ActualTotalPriceWithVat_PerCartArray=ActualTotalPriceWithVat_PerCartArray[1].split("/");
				String ActualTotalPriceWithVat_PerCart_String=ActualTotalPriceWithVat_PerCartArray[1];
				System.out.println("1257 line "+i);
					
				double ActualTotalPriceWithVat_PerCart_Double = Double.parseDouble(ActualTotalPriceWithVat_PerCart_String);
			//	Report.updateTestLog(Action," ActualTotalPriceWithVat_PerCart_Double:::: "+ActualTotalPriceWithVat_PerCart_Double, Status.DONE);
				if (ExpectedTotalPriceWithVat_PerCart==ActualTotalPriceWithVat_PerCart_Double) {
					Report.updateTestLog(Action, "Expected TotalPriceWithVat For Cart "+i+" is "+ExpectedTotalPriceWithVat_PerCart+" And Actual TotalPriceWithVat For Cart "+i+" is "+ActualTotalPriceWithVat_PerCart_Double, Status.PASS);
				}else {
					Report.updateTestLog(Action, "Expected TotalPriceWithVat For Cart "+i+" is "+ExpectedTotalPriceWithVat_PerCart+" And Actual TotalPriceWithVat For Cart "+i+" is "+ActualTotalPriceWithVat_PerCart_Double, Status.FAIL);
				}
				
				
				

				
				System.out.println("1277 line "+i  +"  ::"+ ExpectedTotalPriceWithVat_AllCart);
				// Verify Total Price for ALL Carts
			ExpectedTotalPriceWithVat_AllCart = Math.round((ExpectedTotalPriceWithVat_AllCart+ExpectedTotalPriceWithVat_PerCart) * 100.0) / 100.0;
			
			System.out.println("1277 line "+i  +"  ::"+ ExpectedTotalPriceWithVat_AllCart);
				}catch (Exception e) {
					Report.updateTestLog(Action," Verify Total Price Per Cart  getting failed "+e, Status.FAIL);
				}
				}
			try {	
				
				// Verify Total Price for ALL Carts
			String ActualTotalPriceWithVat_AllCart = Driver.findElement(By.xpath("//div[@class='row cart-bottom']//div[contains(@class,' total-ipad-val-CA')]")).getText(); 

			ActualTotalPriceWithVat_AllCart = ActualTotalPriceWithVat_AllCart.replace(",", "");
			
			String [] ActualTotalPriceWithVat_AllCartArray = ActualTotalPriceWithVat_AllCart.split(" ");
			//ActualTotalPriceWithVat_AllCartArray=ActualTotalPriceWithVat_AllCartArray[1].split("/");

			String ActualTotalPriceWithVat_AllCart_String=ActualTotalPriceWithVat_AllCartArray[1];


			double ActualTotalPriceWithVat_AllCart_Double = Double.parseDouble(ActualTotalPriceWithVat_AllCart_String);


			if (ExpectedTotalPriceWithVat_AllCart==ActualTotalPriceWithVat_AllCart_Double) {
				Report.updateTestLog(Action, "Expected TotalPriceWithVat_AllCart "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPriceWithVat_AllCart "+ActualTotalPriceWithVat_AllCart_Double, Status.PASS);
			}else {
				Report.updateTestLog(Action, "Expected TotalPriceWithVat_AllCart "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPriceWithVat_AllCart "+ActualTotalPriceWithVat_AllCart_Double, Status.FAIL);
			}

			
			}catch (Exception e) {
				Report.updateTestLog(Action," Verify Total Price for ALL Carts  getting failed "+e, Status.FAIL);
			}
			
			try {
			// Verify total Cart Price displayed at Cart Header
			String ActualTotalPriceAtCartHeader = Driver.findElement(By.xpath("//span[@id='cartTotalNonZero']/span[contains(@class,'count')]/span[2]")).getText();

			ActualTotalPriceAtCartHeader = ActualTotalPriceAtCartHeader.replace(",", "");
			String [] ActualTotalPriceAtCartHeaderArray = ActualTotalPriceAtCartHeader.split(" ");
			//ActualTotalPriceAtCartHeaderArray=ActualTotalPriceAtCartHeaderArray[1].split("/");
			String ActualTotalPriceAtCartHeader_String=ActualTotalPriceAtCartHeaderArray[1];

				

			double ActualTotalPriceAtCartHeader_Double = Double.parseDouble(ActualTotalPriceAtCartHeader_String);

			if (ExpectedTotalPriceWithVat_AllCart==ActualTotalPriceAtCartHeader_Double) {
				Report.updateTestLog(Action, "Expected TotalPrice_At Cart Header "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPrice_At Cart Header "+ActualTotalPriceAtCartHeader_Double, Status.PASS);
			}else {
				Report.updateTestLog(Action, "Expected TotalPrice_At Cart Header "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPrice_At Cart Header "+ActualTotalPriceAtCartHeader_Double, Status.FAIL);
			}

			}catch (Exception e) {
				Report.updateTestLog(Action," Verify total Cart Price displayed at Cart Header  getting failed ", Status.FAIL);
			}

		}catch(Exception e1) {
			Report.updateTestLog(Action,"Before Verify ShipTo Row expanded by default getting failed "+e1, Status.FAIL);			
		}


	
		
		
		
	}
	
	
	
	
	
	@Action(object = ObjectType.BROWSER, desc = "Enter ShipTo,Product ID,Quantity [<Data>]", input = InputType.YES)
	public void AddProductsforAnotherShip_To()
	{
		WebDriverWait wait = new WebDriverWait(Driver,10);
		try {
			
			
			String[] InputData = Data.split(",");
			String ShipTo = InputData[0]; //1200082978
			String Product = InputData[1]; //705809
			String Quantity = InputData[2]; //10
			Thread.sleep(5000);
			Driver.findElement(By.xpath("//a[@id='changeShipToLink']")).click();


			//Driver.findElement(By.xpath("//input[@id='search-ship-to-field']")).sendKeys(ShipTo);
			Thread.sleep(3000);
			Driver.findElement(By.xpath("//span[contains(text(),'"+ShipTo+"')]")).click();
			//Driver.findElement(By.xpath("//div[@class='ship-to-list']/div[not(contains(@style, 'display: none;'))]")).click();
try {
			Driver.findElement(By.xpath("//button[@id='orderForThisAddressBtn' and contains(text(),'Order for this address')]")).click();

			Thread.sleep(2000);
			wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
					.executeScript("return document.readyState")));

			Driver.findElement(By.xpath("//input[@id='search_text_complexproducts_orderable']")).sendKeys(Product);
			Driver.findElement(By.xpath("//button[@id='searchtextBtn_complexproducts_orderable']")).click();
			Thread.sleep(4000);
			Driver.findElement(By.xpath("//input[contains(@class,'QuantityText prodOrderListerQty')]")).sendKeys(Quantity);
			Driver.findElement(By.xpath("//span[@class='add-cart-CA' and contains(text(),'Add to cart')]")).click();
			
			
}catch(Exception e) {
	
	Driver.findElement(By.xpath("//button[@id='orderForThisAddressBtn' and contains(text(),'Commander pour cette adresse')]")).click();
	
	Thread.sleep(3000);
	wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
			.executeScript("return document.readyState")));
	Driver.findElement(By.xpath("//input[@id='search_text_complexproducts_orderable']")).sendKeys(Product);
	Driver.findElement(By.xpath("//button[@id='searchtextBtn_complexproducts_orderable']")).click();
	Thread.sleep(4000);
	Driver.findElement(By.xpath("//input[contains(@class,'QuantityText prodOrderListerQty')]")).sendKeys(Quantity);
	Driver.findElement(By.xpath("//span[@class='add-cart-CA' and contains(text(),'Ajouter au panier')]")).click();
	
}
			//Driver.findElement(By.xpath("//button[@id='orderForThisAddressBtn']")).click();
			


			Driver.navigate().refresh();

			//Wait until page load is complete	
			
			wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
					.executeScript("return document.readyState")));

			if (Driver.findElement(By.id("cartTotalNonZero")).isDisplayed()) {

				Report.updateTestLog(Action, Quantity + " Packs of " +Product+" Added To Cart for ShipTo "+ShipTo, Status.PASS);

			}else {
				Report.updateTestLog(Action, " No Product Added To Cart for ShipTo "+ShipTo, Status.FAIL);

			}
			
			
			cartsizeloop();
		
			
		}catch(Exception e1) {
			Report.updateTestLog(Action,"addanother Product shipto fail "+e1, Status.FAIL);			
		}
		
	}
	
	
	
	public void cartsizeloop()
	{
		try {
			Driver.findElement(By.xpath("//a[contains(text(),'Shopping cart')]")).click();
			}
			catch(Exception e)
			{
				
				Driver.findElement(By.xpath("//a[contains(text(),'Panier d’achat')]")).click();
			}
		
		//Wait until page load is complete	
		WebDriverWait wait = new WebDriverWait(Driver,10);
		wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
				.executeScript("return document.readyState")));
		try {
			
			
			List<WebElement> Carts = Driver.findElements(By.xpath("//div[@class='row ship-to']"));
			
			
			for (int i=1;i<=Carts.size();i++) {
				//Send Weekly Hours of Operation
				weekly_ponum(i)		;	
				
				
			}
			
			Driver.findElement(By.xpath("//button[@id='checkoutButton']")).click();
			Thread.sleep(10000);
			
			
		}catch(Exception e1) {
			Report.updateTestLog(Action,"CartSize issue "+e1, Status.FAIL);			
		}
		
	}
	
	
	public void print_buttoncheck(int k)
	{
		try {
			
Driver.findElement(By.xpath("(//button[contains(text(),'Print')])["+k+"]")).click();



String parentwindow=Driver.getWindowHandle();

Set<String> allwindows= Driver.getWindowHandles();

Iterator<String> it =allwindows.iterator();

while(it.hasNext()) {
	String childWindow=it.next();
	
	if(!parentwindow.equalsIgnoreCase(childWindow))
	{
		
		Driver.switchTo().window(childWindow);
		
		
		Driver.manage().window().maximize();
		
		
		//Driver.findElement(By.xpath("//input[@id='firstName']")).sendKeys("Saikrishna");
		
		Thread.sleep(5000);
		
		System.out.println(Driver.getTitle());
		
		
		
	
		System.out.println("Print button inside");
		WebElement cancle = Driver.findElement(By.cssSelector("document.querySelector('body > print-preview-app').shadowRoot.querySelector('#sidebar').shadowRoot.querySelector('print-preview-button-strip').shadowRoot.querySelector('div > cr-button.cancel-button')"));
	
		System.out.println(cancle.getText());
		Report.updateTestLog(Action,"print_buttoncheck :: "+cancle.getText(), Status.DONE);
		cancle.findElement(By.className("cancel-button")).click();
		
	}

		}
}catch(Exception e1) {
			Report.updateTestLog(Action,"Unable to click  on cancle button "+e1, Status.FAIL);			
		}
	



}
	
	
	public void orderconfirmationLinks()
	{
		String link=null;
		String PaymentInfoTitle =null;
	//Wait until page load is complete	
	WebDriverWait wait = new WebDriverWait(Driver,10);
	
		try {
			List<WebElement> orderconfirmationLinks = Driver.findElements(By.xpath("//div[contains(@class,'order-confirmation-links')]//li/a"));
			
			if(orderconfirmationLinks.size()==3)
			{
				Report.updateTestLog(Action," 3 Links available in order page ", Status.PASS);	
				
				for (int i=1;i<=orderconfirmationLinks.size();i++) {
					
					link= Driver.findElement(By.xpath("(//div[contains(@class,'order-confirmation-links')]//li/a)["+i+"]")).getText();
					
					if(link.equalsIgnoreCase("View your order history"))
						
					{
						Report.updateTestLog(Action," View your order history link available ", Status.PASS);
						Driver.findElement(By.xpath("(//div[contains(@class,'order-confirmation-links')]//li/a)["+i+"]")).click();
						wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
								.executeScript("return document.readyState")));
						
						
						
						 PaymentInfoTitle = Driver.getTitle();
						if(PaymentInfoTitle.contains("GSK Direct Canada | Order History")) 
						{
							Report.updateTestLog(Action, "User Navigate to Order History Page", Status.PASS);
													
							Driver.navigate().back();
														
							wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
									.executeScript("return document.readyState")));
							
							
							
							 PaymentInfoTitle = Driver.getTitle();
							 
							 if(PaymentInfoTitle.contains("GSK Direct Canada | Order Confirmation")) 
								{
								 
								 Report.updateTestLog(Action, "User Navigate to Order Confirmation Page", Status.PASS);
								 
								}else {
									Report.updateTestLog(Action, "User NOT Navigate to Order Confirmation Page", Status.FAIL);
									
								}
							
							
							
						}
						else {
							Report.updateTestLog(Action, "User NOT Navigate to Payment Information Page", Status.FAIL);
						}
						
						
						
					}
					
					else
						
						if(link.equalsIgnoreCase("Create a new order"))
							
						{
							Report.updateTestLog(Action," Create a new order link available ", Status.PASS);
							
							Driver.findElement(By.xpath("(//div[contains(@class,'order-confirmation-links')]//li/a)["+i+"]")).click();
							wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
									.executeScript("return document.readyState")));
							
							
							
							 PaymentInfoTitle = Driver.getTitle();
							if(PaymentInfoTitle.contains("GSK Direct Canada | Purchase Products")) 
							{
								Report.updateTestLog(Action, "User Navigate to Purchase Products Page", Status.PASS);
														
								Driver.navigate().back();
															
								wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
										.executeScript("return document.readyState")));
								
								
								
								 PaymentInfoTitle = Driver.getTitle();
								 
								 if(PaymentInfoTitle.contains("GSK Direct Canada | Order Confirmation")) 
									{
									 
									 Report.updateTestLog(Action, "User Navigate to Order Confirmation Page", Status.PASS);
									 
									}else {
										Report.updateTestLog(Action, "User NOT Navigate to Order Confirmation Page", Status.FAIL);
										
									}
								
								
								
							}
							else {
								Report.updateTestLog(Action, "User NOT Navigate to Payment Information Page", Status.FAIL);
							}
							
							
							
						}
						else
							
							if(link.equalsIgnoreCase("Back to home page"))
								
							{
								Report.updateTestLog(Action," Back to home page link available ", Status.PASS);
								
								Driver.findElement(By.xpath("(//div[contains(@class,'order-confirmation-links')]//li/a)["+i+"]")).click();
								wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
										.executeScript("return document.readyState")));
								
								
								
								 PaymentInfoTitle = Driver.getTitle();
								if(PaymentInfoTitle.contains("GSK Direct Canada | Homepage")) 
								{
									Report.updateTestLog(Action, "User Navigate to Purchase Products Page", Status.PASS);
															
									Driver.navigate().back();
																
									wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
											.executeScript("return document.readyState")));
									
									
									
									 PaymentInfoTitle = Driver.getTitle();
									 
									 if(PaymentInfoTitle.contains("GSK Direct Canada | Order Confirmation")) 
										{
										 
										 Report.updateTestLog(Action, "User Navigate to Order Confirmation Page", Status.PASS);
										 
										}else {
											Report.updateTestLog(Action, "User NOT Navigate to Order Confirmation Page", Status.FAIL);
											
										}
									
									
									
								}
								else {
									Report.updateTestLog(Action, "User NOT Navigate to Payment Information Page", Status.FAIL);
								}
								
								
								
							}
					
					
					//					
					
					
					
				}
				
				
				
				
			}
			else {
				
				Report.updateTestLog(Action, orderconfirmationLinks.size()+ "  Links available in order page ", Status.FAIL);
			}
		
			
			
			
		
		}
		
		catch(Exception e1) {
			Report.updateTestLog(Action,"Unable to Validate Links "+e1, Status.FAIL);			
		}
		
		
		
	}
	
	
	
	
public void addAsFavorite_buttonclick(int l) {
		
	String addfavorite=null;	
	String removefavorite=null;
		
		try {
			
			addfavorite=	Driver.findElement(By.xpath("//a[contains(@class,'button1 ckout-fav-btn-CA') and contains(text(),'[+] Add as favorite')]")).getText();
			
			if(addfavorite.equalsIgnoreCase("[+] Add as favorite"))
			{
				
				Report.updateTestLog(Action,addfavorite +"  :: button available  ", Status.PASS);
				
				Driver.findElement(By.xpath("//a[contains(@class,'button1 ckout-fav-btn-CA') and contains(text(),'[+] Add as favorite')]")).click();
			 removefavorite=	Driver.findElement(By.xpath("//a[contains(text(),'[-] Remove as favorite')]")).getText();
			if(	removefavorite.equalsIgnoreCase("[-] Remove as favorite')]"))
				
			{
				Report.updateTestLog(Action,removefavorite +"  :: button available  ", Status.PASS);
				
			//	Driver.findElement(By.xpath("//a[normalize-space()='View your order history']")).click();
				
				
				
			
				
			}else
			{
				Report.updateTestLog(Action,removefavorite +"  :: button NOT available  ", Status.FAIL);
				
			}
				
				
				
			}else
			{
				Report.updateTestLog(Action,addfavorite +"  :: button NOT available  ", Status.FAIL);
				
			}
			
		}
		catch(Exception e1) {
	Report.updateTestLog(Action,"Unable to click  on cancle button "+e1, Status.FAIL);			
		}
		
		
		
		
	}	
	
	
@Action(object = ObjectType.BROWSER, desc = "  ✔ Mark Check in OrderHistory", input = InputType.NO)

	public void addAsFavorite_buttoncheck() throws Exception
	
	{
	String removefavorite=null;
	WebDriverWait wait = new WebDriverWait(Driver, 600);
	wait.until(ExpectedConditions
			.visibilityOf(Driver.findElement(By.xpath("//div[contains(@class,'title-font-style-')]"))));
	
try {
	
		String tick=Driver.findElement(By.xpath("(//div[@class='row']//div[contains(@class,'reservation-number')])/parent::div/parent::div//img")).getAttribute("style");
		////Report.updateTestLog(Action,"tick:: "+tick, Status.DONE);
	//	 removefavorite=	Driver.findElement(By.xpath("((//div[@class='row']//div[contains(@class,'reservation-number')])/parent::div/following-sibling::div[5]//a[2]")).getText();
		 
		removefavorite=	Driver.findElement(By.xpath("((//div[@class='row']//div[contains(@class,'reservation-number')])/parent::div/following-sibling::div[5]//a[2])[1]")).getAttribute("class");
		 
		
		//Report.updateTestLog(Action,"tick:: "+removefavorite, Status.DONE);
		System.out.println(tick);
		//if((tick.contains("block")) && ( (removefavorite.equalsIgnoreCase("[-] Remove as favorite")) ||(removefavorite.equalsIgnoreCase("[-] Supprimer des favoris")))    ) 
			if((tick.contains("block")) && (removefavorite.contains("btn hide")) ) 
					
		{
			Report.updateTestLog(Action,"  ✔ Mark and  Remove as favorite button displayed in OrderHistory ", Status.PASS);
		}
		else
		{
			Report.updateTestLog(Action,"  ✔ Mark and  Remove as favorite button Not displayed in OrderHistory ", Status.FAIL);
		}
		
}catch(Exception e1) {
	Report.updateTestLog(Action,"  ✔ Mark and  is not dispalyed or unable to get ", Status.DONE);			
}
		
	}
	
	
	
public void orderhistoryPage_OrderDetails(int k) {
	
	try {
	Driver.findElement(By.xpath("//div[@class='row']//div[contains(@class,'reservation-number')]//a")).click();
	
	
	WebDriverWait wait = new WebDriverWait(Driver,10);
	wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
			.executeScript("return document.readyState")));
	 k=k+1;
	 System.out.println("orderhistoryPage::"+k);
	String Order=userData.getData("RegressionData", "Order"+k);
	
	String text=null;
	
	try {
		 text=Driver.findElement(By.xpath("//*[contains(text(),'My Account')]")).getText();
		
	}
		catch(Exception e)
		{
			
			 text=Driver.findElement(By.xpath("//*[contains(text(),'Mon compte')]")).getText();
			
				
				}	

		
	
	
	
	
	if((text.equalsIgnoreCase("My Account")) || (text.equalsIgnoreCase("Mon compte"))) {
		
		Report.updateTestLog(Action,"  Navigated to My Account Orderdetails ", Status.PASS);	
		
		
	WebElement Ordernum=Driver.findElement(By.xpath("//*[@id='order-number']"));
	
	if(Ordernum.getText().contains(Order))
	{
		
		Report.updateTestLog(Action," Order Detail are Matching and the Order No:-->"+Order, Status.PASS);
		
	}else
	{
		Report.updateTestLog(Action," Order Detail are NOT Matching and the Order No:-->"+Order, Status.FAIL);
	}
	try {
	WebElement payment =Driver.findElement(By.xpath("//div[contains(@class,'info-panel print-pay payment-val-CA')]"));
	String Creditcard=userData.getData("RegressionData", "Paymenttype"+k);
	
	if(payment.isDisplayed() && Creditcard.equalsIgnoreCase("Creditcard")  )
	{
		Report.updateTestLog(Action," Payment Method info displayed  : -->"+payment.getText(), Status.PASS);
		
	}
	else if(Creditcard.equalsIgnoreCase("InvoiceMe"))
	{
		Report.updateTestLog(Action," Selected Product have InvoiceMe", Status.PASS);
		
	}
	
	
	}
	catch(Exception e1) {
Report.updateTestLog(Action,"Payment Method : is not dispalyed ", Status.DONE);			
	}
	
	
	List<WebElement> odpage=Driver.findElements(By.xpath("//div[@class='table']//div[@data-test='table-products']"));
	
	for (int j=1;j<=odpage.size();j++)
	{
		String trowsheet=userData.getData("OrderDetails", "C"+k+"product"+j);
		
		String prodname=Driver.findElement(By.xpath("(//div[@class='table']//div[@data-test='table-products']//div//a[@class='product-name'])["+j+"]")).getText();
		String totalrow=Driver.findElement(By.xpath("(//div[@class='table']//div[@data-test='table-products']//span[contains(@style,'word-break')])["+j+"]")).getText();
		
		totalrow = totalrow.replace(",", "");
		String [] productrow = totalrow.split(" ");
		String R1=productrow[1];
		
		if(R1.contains(trowsheet))
		{
			
			Report.updateTestLog(Action, prodname +" ::  is Price matching with the Product :-->"+R1, Status.PASS);
			
		}else
		{
			Report.updateTestLog(Action," Price is NOT matching with the Product", Status.FAIL);
		}
		
		
		
	}
	try {
	String totalsheetprice=userData.getData("OrderDetails", "C"+k+"Total");
	//Report.updateTestLog(Action, "totalsheetprice::::: "+totalsheetprice, Status.DONE);
	String totalprice=Driver.findElement(By.xpath("//div[contains(@class,'table-total')]")).getText();
	
	//Report.updateTestLog(Action, totalprice, Status.DONE);
	
	totalprice=totalprice.replace("Total\n", "");
//	Report.updateTestLog(Action, totalprice, Status.DONE);
	totalprice=totalprice.replace(",", "");
	
	String [] totalprice1 = totalprice.split(" ");
	
	//Report.updateTestLog(Action, totalprice1[1] +":::::::: ", Status.PASS);
	
	String tp=totalprice1[1];
	
	
	
	
	if(tp.contains(totalsheetprice))
	{
		
		Report.updateTestLog(Action, " Total price matching with the Order ::  "+tp, Status.PASS);
		
	}else
	{
		Report.updateTestLog(Action," Price is NOT matching with the Product", Status.FAIL);
	}
	
	}
	catch(Exception e) {
		Report.updateTestLog(Action," Unable to take Total Price in Order details Page ", Status.FAIL);			
			}
	
	
	
	
try {
		
		Driver.findElement(By.xpath("//button[@class='btn-violet1']")).click();
	}
	catch(Exception e1) {
		Report.updateTestLog(Action," Back to List of Orders not available  ", Status.FAIL);			
			}
	
	
	
	}	else
	{
		Report.updateTestLog(Action," Back to List of Orders not available  ", Status.DONE);	
	}
	
	}
	catch(Exception e1) {
		Report.updateTestLog(Action," Back to List of Orders not available  ", Status.FAIL);			
			}

	
	
	}
	
	
		
	
@Action(object = ObjectType.BROWSER, desc = "Enter ShipTo,Product ID,Quantity [<Data>]", input = InputType.NO)
public void Account_ShiptoInfo_CA()
{
	
	String Od=Driver.findElement(By.xpath("//h2[contains(@class,'title-style-odhis-orddet-CA')]")).getText();
	String shpto=null;
	String shpto_adres=null;
	String weeklyhours=null;
	String billto=null;
	String billto_adres=null;
	String Ponum=null;
if(  (("Order Detail").equalsIgnoreCase(Od))|| Od.equalsIgnoreCase("Détail de la commande")  ) 
{
	
	Report.updateTestLog(Action," Order Detail page is available  ", Status.PASS);
	
	
}else {
	Report.updateTestLog(Action," Order Detail page is Not available  ", Status.FAIL);
	
	
	
	
}


	
	try
	{
		
		shpto=Driver.findElement(By.xpath("//span[@class='info-panel-label ship-to-order-dtl print-ship-CA']")).getText();
		shpto_adres=Driver.findElement(By.xpath("//div[contains(@class,'info-panel oderhis-panel-CA')]")).getText();
		
	  	
        addVar("%shiptoaddress%",shpto_adres);
        
		
		Report.updateTestLog(Action,shpto  + " "+shpto_adres , Status.PASS);
		
		try
		{
		
		weeklyhours=Driver.findElement(By.xpath("//div[contains(@class,'info-panel oderhis-panel-CA')]/../following-sibling::div//div")).getText();
		
		Report.updateTestLog(Action,weeklyhours , Status.PASS);
		
		addVar("%weeklyHours%",weeklyhours);
		
		}catch(Exception e1)
		{
			
			Report.updateTestLog(Action,"Ship To: details not displayed "  , Status.FAIL);
		}
		
		
	}catch(Exception e)
	{
		
		Report.updateTestLog(Action,"Ship To: details not displayed "  , Status.FAIL);
	}
	
	
	
	
	
	try
	{
		
		billto=Driver.findElement(By.xpath("//span[@class='info-panel-label ship-to-order-dtl']")).getText();
		billto_adres=Driver.findElement(By.xpath("//div[contains(@class,'print-billTo-CA')]")).getText();
		
		Report.updateTestLog(Action,billto  + " "+billto_adres , Status.PASS);
		addVar("%billToAddress%",billto_adres);
		
		try
		{
		
			Ponum=Driver.findElement(By.xpath("//div[contains(@class,'print-billTo-CA')]/../following-sibling::div")).getText();
			
			String po=Driver.findElement(By.xpath("//div[contains(@class,'print-billTo-CA')]/../following-sibling::div//div")).getText();
			
			addVar("%poNumber%",po);
			
		
		Report.updateTestLog(Action,Ponum , Status.PASS);
		}catch(Exception e1)
		{
			
			Report.updateTestLog(Action,"Ponum details not displayed "  , Status.FAIL);
		}
		
		
	}catch(Exception e)
	{
		
		Report.updateTestLog(Action,"Ship To: details not displayed "  , Status.FAIL);
	}
		
	
	
	
	try
	{
	
	String	Reorder=Driver.findElement(By.xpath("//span[@class='info-panel-label odr-dtl-action-CA']/../div[2]/a[1]")).getText();
	
	if(Reorder.equalsIgnoreCase("Reorder")|| Reorder.contains("Commander de nouveau"))
	{
		Report.updateTestLog(Action,Reorder +" is Displayed " , Status.PASS);
		
	}else
	{
		Report.updateTestLog(Action, "Reorder is not Displayed " , Status.DONE);
	}
	
	
		
	}catch(Exception e1)
	{
		
		Report.updateTestLog(Action, "Reorder is not Displayed " , Status.PASS);
		
	}	
	
	
	try
	{
	
	String	Addfava8=Driver.findElement(By.xpath("//span[@class='info-panel-label odr-dtl-action-CA']/../div[2]/a[2]")).getText();
	
	if(Addfava8.equalsIgnoreCase("[+] Add as favorite")||Addfava8.contains("[+] Ajouter dans les favoris"))
	{
		Report.updateTestLog(Action,Addfava8 +" is Displayed " , Status.PASS);
		
	}else
	{
		Report.updateTestLog(Action, "[+] Add as favorite is not Displayed " , Status.DONE);
	}
	
	
	
	
	
	}catch(Exception e1)
	{
		
		String	removefava8=Driver.findElement(By.xpath("//span[@class='info-panel-label odr-dtl-action-CA']/../div[2]/a[3]")).getText();
		
		if(removefava8.equalsIgnoreCase("[-] Remove as favorite")||removefava8.contains("[-] Supprimer des favoris"))
		{
			Report.updateTestLog(Action,removefava8 +" is Displayed " , Status.PASS);
			
		}else
		{
			Report.updateTestLog(Action, "[-] Remove as favorite is not Displayed " , Status.DONE);
		}
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}





@Action(object = ObjectType.BROWSER, desc = "Validating the ShiptoInformation Link", input = InputType.NO)
public void shipmentInformation_validation_CA()
{
	
try {
	
	if( Driver.findElement(By.xpath("//*[@id='shipmentInformation']")).isDisplayed())
	{
		
		Report.updateTestLog(Action,"Shipment Information is Displayed " , Status.PASS);
		
		Driver.findElement(By.xpath("//*[@id='shipmentInformation']")).click();
		
		WebDriverWait wait = new WebDriverWait(Driver, 600);
		wait.until(ExpectedConditions
								.visibilityOf(Driver.findElement(By.xpath("//*/div[3]/div[@class='row shipmentInfoDiv']"))));
	
	
	List<WebElement> shipinfo=Driver.findElements(By.xpath("//*/div[3]/div[@class='row shipmentInfoDiv']"));
	
	int shipinfo1 = shipinfo.size();
	  Report.updateTestLog(Action, "shipinfo1  ::  " +shipinfo1, Status.DONE);
	// Matching Shipto status with check box selected
	if(shipinfo1>0) {
		
		
	for(int i=1;i<=shipinfo1;i++)
		
	{
		List<WebElement> shipinforow=Driver.findElements(By.xpath("(//*/div[3]/div[@class='row shipmentInfoDiv'])["+i+"]/div"));
		
		
		for(int j=1;j<=shipinforow.size();j++)
			
		{
			
		String row=	Driver.findElement(By.xpath("(//*/div[3]/div[@class='row shipmentInfoDiv'])["+i+"]/div["+j+"]")).getText();
		
		
		if(row.isEmpty()||row.isBlank())
{
			switch (j) {
			 
			 case 1:
				  Report.updateTestLog(Action, "Row Date column is Empty  " , Status.DONE);
			    break;
			  case 2:
				  Report.updateTestLog(Action,"Product column is Empty " , Status.DONE);;
			    break;
			  case 3:
				  Report.updateTestLog(Action,"Invoice Number  column is Empty " , Status.DONE);
			    break;
			  case 4:
				  Report.updateTestLog(Action,"Carrier Name  column is Empty " , Status.DONE);
			    break;
			    
			  case 5:
				  Report.updateTestLog(Action,"	Tracking Number column is Empty " , Status.DONE);
			    break;
			}
			
			
	
}
		else
{
	switch (j) {
	  
	    
	  case 1:
		  Report.updateTestLog(Action,"Date  :: "+row , Status.PASS);
	    break;
	  case 2:
		  Report.updateTestLog(Action,"Product  :: "+row , Status.PASS);;
	    break;
	  case 3:
		  Report.updateTestLog(Action,"Invoice Number  :: "+row , Status.PASS);
	    break;
	  case 4:
		  Report.updateTestLog(Action,"Carrier Name  :: " +row, Status.PASS);
	    break;
	    
	  case 5:
		  Report.updateTestLog(Action,"	Tracking Number  :: "+row , Status.PASS);
	    break;
	    
	    
	}
	
	
	
	
}
		
		
		}
		
		
	}
	
	
	Driver.findElement(By.xpath("//*[@id='shipmentInfoClose']")).click();	
		
		
		
	}else
	{
		
		Report.updateTestLog(Action,"Shipment Information is not Displayed " , Status.FAIL);
		
	}
	
		
		
		
            
            }
	else
	{
		Report.updateTestLog(Action,"Shipment Information is not Displayed " , Status.FAIL);
		
	}
            
	
	
	
	
}catch(Exception e1)
{
	Report.updateTestLog(Action,"Shipment Information is not Displayed " , Status.FAIL);
}
	
	
	
	
	
	
	
	
	
	
	
	
}



@Action(object = ObjectType.BROWSER, desc = "Product details validation in OrderHistorypage", input = InputType.NO)
public void Product_details_OH_Page_validation_CA()
{
	try {
		
		
		List<WebElement> row=Driver.findElements(By.xpath("//div[@data-test='table-header']//div[@class='table-cell']"));
		
		for(int h=1;h<=row.size();h++) {
			
		
	List<WebElement> produt=Driver.findElements(By.xpath("//div[contains(@class,'table-row')]/div["+h+"]"));
	
	for(int i=2;i<=produt.size();i++) {
		
		String pro = Driver.findElement(By.xpath("(//div[contains(@class,'table-row')]/div["+h+"])[1]")).getText();
		
		if(pro.equalsIgnoreCase("Product"))
			
		{
			
			Report.updateTestLog(Action,"Details are avalibale under Product column :::  " +Driver.findElement(By.xpath("(//div[contains(@class,'table-row')]/div["+h+"])["+i+"]")).getText() , Status.DONE);
			
			
			
		}
		 if(pro.equalsIgnoreCase("Lot Number"))
			
		{
			
			Report.updateTestLog(Action,"Details are avalibale under Lot Number column :::  " +Driver.findElement(By.xpath("(//div[contains(@class,'table-row')]/div["+h+"])["+i+"]")).getText() , Status.DONE);
			
		}
if(pro.equalsIgnoreCase("Price"))
			
		{
			
			Report.updateTestLog(Action,"Details are avalibale under Price column :::  " +Driver.findElement(By.xpath("(//div[contains(@class,'table-row')]/div["+h+"])["+i+"]")).getText() , Status.DONE);
			
		}
if(pro.equalsIgnoreCase("Quantity"))
	
{
	
	Report.updateTestLog(Action,"Details are avalibale under Quantity column :::  " +Driver.findElement(By.xpath("(//div[contains(@class,'table-row')]/div["+h+"])["+i+"]")).getText() , Status.DONE);
	
}
if(pro.equalsIgnoreCase("Confirmed Quantity"))
	
{
	
	Report.updateTestLog(Action,"Details are avalibale under Confirmed Quantity column :::  " +Driver.findElement(By.xpath("(//div[contains(@class,'table-row')]/div["+h+"])["+i+"]")).getText() , Status.DONE);
	
}
if(pro.equalsIgnoreCase("Status"))
	
{
	
	Report.updateTestLog(Action,"Details are avalibale under Status column :::  " +Driver.findElement(By.xpath("(//div[contains(@class,'table-row')]/div["+h+"])["+i+"]")).getText() , Status.DONE);
	
}

if(pro.equalsIgnoreCase("Total"))
	
{
	
	Report.updateTestLog(Action,"Details are avalibale under Status column :::  " +Driver.findElement(By.xpath("(//div[contains(@class,'table-row')]/div["+h+"])["+i+"]")).getText() , Status.DONE);
	
}
		
	}
	
	
	
	
	
	
	
	}
			
}catch(Exception e1)
{
	Report.updateTestLog(Action,"Produt details are not avalibale  " , Status.FAIL);
}
	
	
	
	
	
	
	
}
	

@Action(object = ObjectType.BROWSER, desc = "Product Price details validation in OrderHistorypage", input = InputType.NO)
public void Product_details_OH_Price_validation_CA()

{
	
float Total=0;
float Totalamount=0;
try {
List<WebElement> produt=Driver.findElements(By.xpath("//div[contains(@class,'table-row')]/div[7]"));
	
	for(int i=2;i<=produt.size();i++) {
		
		String amount = Driver.findElement(By.xpath("(//div[contains(@class,'table-row')]/div[7])["+i+"]")).getText();
		System.out.println(amount);
		
		amount= amount.replace(",", "");
		
		String[] amount1=amount.split(" ");
		
		System.out.println(amount1[0]+"      "+amount1[1]);
		String l=amount1[1];
				
		float am=Float.parseFloat(l);
		
		Total=Total+am;
		
		Report.updateTestLog(Action,"Total amount of Products ::: "+Total , Status.DONE);
		
				
	}
	
}catch(Exception e1)
{
Report.updateTestLog(Action,"Unable to get Amount details "+e1 , Status.FAIL);
}
	
	
	


try {
	
	String Tamount = Driver.findElement(By.xpath("//div[@class='table-total']")).getText();
	
	Tamount = Tamount.replace(",", "");
		
	String[] amounttot=Tamount.split(" ");
	String l=amounttot[1];
	
	 Totalamount=Float.parseFloat(l);
	
	 Report.updateTestLog(Action,"Total amount ::: "+Totalamount , Status.DONE);
	
}catch(Exception e)
{
Report.updateTestLog(Action,"Total amount details unable to get " +e, Status.FAIL);
}

	


if(Total==Totalamount)
{
	
	Report.updateTestLog(Action,"Total amount  :: "+Totalamount +"  and Product amounts total are Equal  :: "+Total , Status.PASS);
}
else
{
	Report.updateTestLog(Action,"Total amount and Product amounts total are Not Equal " , Status.FAIL);
	
}
	
	
}



//************************____________________  */



@Action(object = ObjectType.BROWSER, desc = "Product Price details validation in OrderHistorypage", input = InputType.NO)
public void Product_details_OH_Price_validation_FR()

{
	
float Total=0;
float Totalamount=0;
try {
List<WebElement> produt=Driver.findElements(By.xpath("//div[contains(@class,'table-row')]/div[7]"));
	
	for(int i=2;i<=produt.size();i++) {
		
		String amount = Driver.findElement(By.xpath("(//div[contains(@class,'table-row')]/div[7])["+i+"]")).getText();
		System.out.println(amount);
		
		amount= amount.replace(",", ".");
		
		String[] amount1=amount.split(" ");
		
		System.out.println(amount1[0]+"      "+amount1[1]);
		String l=null;
		try
		{
		 l=amount1[1].concat(amount1[2]);
				
		}catch(Exception e)
		{
			l=amount1[1];
		}
		float am=Float.parseFloat(l);
		
		Total=Total+am;
		
		Report.updateTestLog(Action,"Total amount of Products ::: "+Total , Status.DONE);
		
				
	}
	
}catch(Exception e1)
{
Report.updateTestLog(Action,"Unable to get Amount details "+e1 , Status.FAIL);
}
	
	
	


try {
	
	String Tamount = Driver.findElement(By.xpath("//div[@class='table-total']")).getText();
	
	Tamount = Tamount.replace(",", ".");
		
	String[] amounttot=Tamount.split(" ");
	String l=null;
	try
	{
	 l=amounttot[1].concat(amounttot[2]);
			
	}catch(Exception e)
	{
		l=amounttot[1];
	}
	
	 Totalamount=Float.parseFloat(l);
	
	 Report.updateTestLog(Action,"Total amount ::: "+Totalamount , Status.DONE);
	
}catch(Exception e)
{
Report.updateTestLog(Action,"Total amount details unable to get " +e, Status.FAIL);
}

	


if(Total==Totalamount)
{
	
	Report.updateTestLog(Action,"Total amount  :: "+Totalamount +"  and Product amounts total are Equal  :: "+Total , Status.PASS);
}
else
{
	Report.updateTestLog(Action,"Total amount and Product amounts total are Not Equal " , Status.FAIL);
	
}
	
	
}












@Action(object = ObjectType.BROWSER, desc = "Product link validation", input = InputType.NO)

public void product_link_validation()


{
	List<WebElement> row=Driver.findElements(By.xpath("(//div[contains(@class,'table-row')]/div[1])"));
	
	String noOfproducts=Integer.toString(row.size());
	addVar("%noofProducts%",noOfproducts);
	//Report.updateTestLog(Action,"noOfproducts ::  " +noOfproducts , Status.DONE);
	
	for(int j=2;j<=row.size();j++) {
		
	try {
		
		String Prodcutname=Driver.findElement(By.xpath("(//div[contains(@class,'table-row')]/div[1])["+j+"]//div/a")).getText().toString();
		
		String pname = "%product"+j+"%";

		addVar(pname, Prodcutname);
		
		//Report.updateTestLog(Action,"Prodcutname ::    "+j+"  ::  " +Prodcutname , Status.DONE);
		
		
		Driver.findElement(By.xpath("(//div[contains(@class,'table-row')]/div[1])["+j+"]//div/a")).click();
		
		//Driver.wait(10000);
		
		WebDriverWait wait = new WebDriverWait(Driver, 600);
		wait.until(ExpectedConditions
								.visibilityOf(Driver.findElement(By.xpath("//*[@type='submit']"))));
		
		String title=Driver.getTitle();
		
		System.out.println(Driver.getTitle());
		
		//Report.updateTestLog(Action,"Navigate to Product Page Successfully  " +title , Status.PASS);
		
		//Driver.navigate().back();
		
					
						  if( (title.contains("| Vaccines | Products | GSK Direct Canada"))   ||(title.contains("| Vaccins | Des produits | GSK Direct Canada"))  )
						 
						 { Report.updateTestLog(Action,"Navigate to Product Page Successfully  "  +title ,	 Status.PASS);
						 
						  Driver.navigate().back();
						  
						 // Driver.wait(6000); 
						  
						  Driver.navigate().refresh();
						  }
		else
						 
					{
					 
						 Report.updateTestLog(Action,"Unable to Navigate to Product Page " , Status.FAIL); }
						 
	}catch(Exception e)
		{
			Report.updateTestLog(Action,"unable to Click on Produt " +e, Status.FAIL);
		}
}
	
}


	
	
@Action(object = ObjectType.BROWSER, desc = "PDF Name validations", input = InputType.YES)
public void PDF_validation_check_CA() {
	File theNewestFile = null;
	int pageCount=0;
	String[] strs=null;
String pdfdata=null;
	String s=null;
	String Loca =null;
	
	
	
	
	
	
	try {
		
		Driver.findElement(By.xpath("//button[contains(@class,'odhis-orddet-CA')]")).click();
		
		Thread.sleep(10000);
		
		
	}catch(Exception e)
	{
		Report.updateTestLog(Action,"unable to Click on Produt " +e, Status.FAIL);
	}
	
	
	
	try {
		
		Thread.sleep(5000);
		Robot robot = new Robot();
		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_CONTROL);
		
		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_S);
		
		Thread.sleep(1000);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		
		Thread.sleep(1000);
		robot.keyRelease(KeyEvent.VK_S);
		
		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_ENTER);
		
		Thread.sleep(1000);
		robot.keyRelease(KeyEvent.VK_ENTER);	
		
		
		
		
		
		
		
		
//String path_ca = userData.getData("RegressionData", "Download Path");
		
		File dir = new File(Data);
        
        FileFilter fileFilter = new WildcardFileFilter("*.pdf");
        File[] files = dir.listFiles(fileFilter);
        
	
	
	
						 
	 if (files.length > 0 ) {
         /** The newest file comes first **/
     	
     	
         Arrays.sort(files, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
         
         
         theNewestFile = files[0];
     
         //Report.updateTestLog(Action, theNewestFile+ "  theNewestFile  ", Status.DONE);
         
     
      Loca =theNewestFile.toString();
     
     Thread.sleep(1000);
				
				
     
  s=    Loca.replace("\\", "//");
 
 
 
 
  strs = s.split("//");
 Thread.sleep(15000);

 
 if(strs[4].contains("Order History - Details"))
 {
 	
 	 Report.updateTestLog(Action, strs[4] +" PDF is Dowload sucessfully with Data  " , Status.PASS);
   	 
 	 Report.updateTestLog(Action, s, Status.DONE);
 	   
 	    
		  PDFUtil p = new PDFUtil();
		  pageCount = p.getPageCount(s);
		  pdfdata=p.getText(s) ;
		  
		  
		  String num=getVar("%noofProducts%");
		  int numprd=Integer.parseInt(num);
		  for(int i=2;i<=numprd;i++)
		  {		
		  String pname = "%product"+i+"%";
		  
		  String prodname=getVar(pname);
		  
		  if(pdfdata.contains(prodname))
		  {
		  
		  Report.updateTestLog(Action,  "  PDF  PAGE Contains Data: General Terms and Conditions of Supply  "+pageCount, Status.PASS);
		  }
		  else
		  {
			  Report.updateTestLog(Action,  "  PAGE Count of PDF :  "+pageCount, Status.DONE);
		  }
		  }
 }
 else
 {
 	Report.updateTestLog(Action," Getting Error in PDF Download ", Status.FAIL);
 	
 	
 }
 }
    
    else
    {
    	
    	Report.updateTestLog(Action, "  PDF downloaded Failed and Getting Error   ", Status.FAIL);
    }
	
			
}
	
	catch (Exception e) {
		Report.updateTestLog(Action, "PDF_validation_check Failing  ", Status.FAIL);
	}
	
	

}


@Action(object = ObjectType.BROWSER, desc = "[+] Add as favorite validations", input = InputType.NO)
public void Addasfavabuttonvalidation_CA() {
	
	WebDriverWait wait = new WebDriverWait(Driver, 600);
	
	String ordernum=Driver.findElement(By.xpath("//label[@id='order-number']")).getText();
	
	String addfavorite=null;	
	String removefavorite=null;
		
		try {
			
			addfavorite=	Driver.findElement(By.xpath("//a[contains(@class,'addfavOrderDetails')]")).getText();
			
			if( (addfavorite.equalsIgnoreCase("[+] Add as favorite")) ||( addfavorite.equalsIgnoreCase("[+] Ajouter dans les favoris")) )
			{
				
				Report.updateTestLog(Action,addfavorite +"  :: button available  ", Status.PASS);
				
				Driver.findElement(By.xpath("//a[contains(@class,'addfavOrderDetails')]")).click();
				wait.until(ExpectedConditions
						.visibilityOf(Driver.findElement(By.xpath("//*[contains(@class,'remfavOrderDetails')]"))));
				
			 removefavorite=	Driver.findElement(By.xpath("//*[contains(@class,'remfavOrderDetails')]")).getText();
			 
			 
			if(	(removefavorite.equalsIgnoreCase("[-] Remove as favorite"))  ||  (removefavorite.equalsIgnoreCase("[-] Supprimer des favoris")) )
				
			{
				Report.updateTestLog(Action,removefavorite +"  :: button available  ", Status.PASS);
				
			Driver.findElement(By.xpath("//button[contains(@class,'btn-violet')]")).click();
			
			Thread.sleep(10000);
			wait.until(ExpectedConditions
					.visibilityOf(Driver.findElement(By.xpath("//div[contains(@class,'title-font-style-')]"))));
			
			if((Driver.getTitle().contains("GSK Direct Canada | Order History"))||(Driver.getTitle().contains("GSK Direct Canada | Historique des commandes")))
				
			{
				
				
				Report.updateTestLog(Action,"  Navigated Sucessfully to :: " +Driver.getTitle() + " ::Page ", Status.PASS);
				
				
				Driver.findElement(By.xpath("//input[@id='search_text_order']")).sendKeys(ordernum);
				
				
				Driver.findElement(By.xpath("//button[@id='searchtextBtn_order']//span[contains(@class,'glyphicon glyphicon-search')]")).click();
				
				wait.until(ExpectedConditions
						.visibilityOf(Driver.findElement(By.xpath("//div[contains(@class,'title-font-style-')]"))));
				
				addAsFavorite_buttoncheck();
				
				Driver.findElement(By.xpath("(//div[contains(@class,'reservation-number')])[1]")).click();	
				
				wait.until(ExpectedConditions
						.visibilityOf(Driver.findElement(By.xpath("//*[contains(@class,'title-style-odhis-orddet-CA')]"))));
				
				if((Driver.getTitle().contains("GSK Direct Canada | Order History - Details"))||(Driver.getTitle().contains("GSK Direct Canada | Historique des commandes - détail")))//GSK Direct Canada | Acheter des produits  
					
				{
					Report.updateTestLog(Action,"  Navigated Sucessfully to :: " +Driver.getTitle() + " ::Page ", Status.PASS);
					
					try {
					if(Driver.findElement(By.xpath("//a[contains(@class,'remfavOrderDetails')]")).isDisplayed())
					{
						
					}
					
					}catch(Exception e)
					{
						Report.updateTestLog(Action,"  unable to click on Remove favaOrderDetails  ", Status.FAIL);
						
					}
					
				}else
				{
					Report.updateTestLog(Action,"  unable to Navigate  :: Page ", Status.FAIL);
				}
				
				
				
			}
			
			else
			{
				Report.updateTestLog(Action,"  unable to Navigate  :: Page ", Status.FAIL);
			}
		
				
			}else
			{
				Report.updateTestLog(Action,removefavorite +" removefavorite :: button NOT available  ", Status.FAIL);
				
			}
				
				
				
			}else
			{
				Report.updateTestLog(Action,addfavorite +"  addfavorite :: button NOT available  ", Status.FAIL);
				
			}
			
		}
		catch(Exception e1) {
	Report.updateTestLog(Action,"Unable to click  on cancle button "+e1, Status.FAIL);			
		}
		
		
		
	
}




@Action(object = ObjectType.BROWSER, desc = "ReOrder button validation and place order", input = InputType.NO)
public void reOrderButtonValidation_CA() {
	
	WebDriverWait wait = new WebDriverWait(Driver, 600);	
	
	try {
		
		Driver.findElement(By.xpath("//*[contains(@class,'btn-actshp-CA')]")).click();
		Thread.sleep(10000);
		Report.updateTestLog(Action,"click  on ReOrder button ", Status.PASS);	
		
	}	catch(Exception e1) {
		Report.updateTestLog(Action,"Unable to click  on ReOrder button "+e1, Status.FAIL);			
	}
	
	
	
try {
	
	
            
            wait.until(ExpectedConditions
					.visibilityOf(Driver.findElement(By.xpath("//p[contains(@class,'cc_heading')]/b")))); 
            
String headding=Driver.findElement(By.xpath("//p[contains(@class,'cc_heading')]/b")).getText();
    		
    		Report.updateTestLog(Action,"Details ::  "+headding, Status.DONE);
            
        
   List<WebElement> produtsize=Driver.findElements(By.xpath("//a[@class='productNameLink']//img"));
   List<WebElement> p1=Driver.findElements(By.xpath("//div[@id='resultsList']//td"));
   
   addVar("%productlistsize%",Integer.toString(produtsize.size()));
   
  // for (int h=1;h<=p1.size();h++) {
            for(int i=1;i<=produtsize.size();i++) {
            	
            	
            	
            	String s=Driver.findElement(By.xpath("(//a[@class='productNameLink']//img)["+i+"]")).getAttribute("class");
            	
            	if(s.contains("img") )
            	{
            		
            		Report.updateTestLog(Action,"Product Image Dispalyed ", Status.DONE);
            		
            	Driver.findElement(By.xpath("(//a[@class='productNameLink']//img)["+i+"]")).click();
            	
            	 wait.until(ExpectedConditions
     					.visibilityOf(Driver.findElement(By.xpath("//h1[@id='productDetail-name']")))); 
            	 
            	 
            	 
            	 String title=Driver.getTitle();
         		
         		System.out.println(Driver.getTitle());
         		
         		Report.updateTestLog(Action,"Navigate to Product Page Successfully  " +title , Status.PASS);
         		//Driver.navigate().back();
         		
         					
         						  if((title.contains("| Vaccines | Products | GSK Direct Canada") )  || title.contains("| Vaccins | Des produits | GSK Direct Canada") )
         						 
         						 { 
         							  
         							//  Report.updateTestLog(Action,"Navigate to Product ::  "+Driver.findElement(By.xpath("//h1[@id='productDetail-name']")).getText()+ " ::Page Successfully  " +title,		 Status.PASS);
         						 
         						  Driver.navigate().back(); 
         						  
         						 
         						 try {
         						 wait.until(ExpectedConditions
         		    					.visibilityOf(Driver.findElement(By.xpath("//*[contains(@class,'btn-actshp-CA')]")))); 
         						
         						 
         						// Driver.wait(6000);
         						 Driver.findElement(By.xpath("//*[contains(@class,'btn-actshp-CA')]")).click();
         						 
         						wait.until(ExpectedConditions
         		    					.visibilityOf(Driver.findElement(By.xpath("//p[contains(@class,'cc_heading')]/b")))); 
         						
         						 }catch(Exception e)
         						 {
         							Report.updateTestLog(Action,"Unable to click ob the element   "+e,		 Status.DONE);
         							 
         						 }
         						  
         						 }
         		else
         						 
         					{
         					 
         						 Report.updateTestLog(Action,"Unable to Navigate to Product Page " , Status.FAIL); } 
            	 
            	 
         	}
            	else {
            		
            		Report.updateTestLog(Action,"Product Image Not Dispalyed ", Status.DONE);
            	}
            	
            	
            	
            	String prod=Driver.findElement(By.xpath("(//div[contains(@class,'productList row product-content')]//td[2]//div[1])["+i+"]")).getText();
            	
               	String monogrpah=Driver.findElement(By.xpath("(//div[contains(@class,'productList row product-content')]//td[2]//div[contains(@id,'pdpProductResourceDiv')])["+i+"]")).getText();
               	String price=Driver.findElement(By.xpath("(//div[contains(@class,'productList row product-content')]//td[3]//div[@class='orderableProductListPrice'])["+i+"]")).getText();
               String qty=Driver.findElement(By.xpath("(//div[contains(@class,'productList row product-content')]//td[4]//div[1]//input)["+i+"]")).getAttribute("value");
               	
               	
               String productVar="%prodnum"+i+"%";
               String priceVar="%priceProd"+i+"%";
               String qtyVar="%qtyProd"+i+"%";
               
                              
               addVar(productVar,prod);
               addVar(priceVar,price);
               addVar(qtyVar,qty);
               
               
               	if(monogrpah.contains("Monograph") ) 
            	{
               		Driver.findElement(By.xpath("(//div[contains(@class,'productList row product-content')]//td[2]//div[contains(@id,'pdpProductResourceDiv')]//a)["+i+"]")).click();
               		

       			 ArrayList<String> tabs = new ArrayList<String> (Driver.getWindowHandles());
       			    Driver.switchTo().window(tabs.get(1));
       			 wait.until(ExpectedConditions
	    					.visibilityOf(Driver.findElement(By.xpath("(//ul[contains(@class,'primary-nav__container')]//li//a)[1]"))));    
       			    
       			
       			    if(Driver.findElement(By.xpath("//a[contains(@data-title,'Innovation')]")).getText().contains("Innovation"))
       			    	
       			    { 
       			    	Report.updateTestLog(Action, "Clicked on Monograph link Successfully Navigated to Product tab  "  , Status.PASS);
       			    	}
    			    else
    			    {
    			    	Report.updateTestLog(Action, "Unable to click on Monograph link Failed to navigate " , Status.FAIL);
    			    	
    			    }
    			    Driver.close();
    			    Driver.switchTo().window(tabs.get(0));
               		
               		
             		
            		Report.updateTestLog(Action, " Monograph displayed under Product :: " +prod   +" and Price  ::  "+price  +"  QTY ::  "+qty , Status.DONE);
            		
            	//Driver.findElement(By.xpath("(//a[@class='productNameLink']//img)["+i+"]")).click();
            	
            		
            	
            		
            		
            	}
            	else {
            		
            		Report.updateTestLog(Action,"Product Image Not Dispalyed ", Status.DONE);
            	}
               	
            	
       
               	
               	
            	
            	
            	
            	
            	
            }
   //}
            
        
		
	Driver.findElement(By.xpath("//button[@id='cboxClose']")).click();
	Report.updateTestLog(Action,"click  on Close X ", Status.PASS);	
	
try {
		
		Driver.findElement(By.xpath("//*[contains(@class,'btn-actshp-CA')]")).click();
		Thread.sleep(5000);
		Report.updateTestLog(Action,"click  on ReOrder button ", Status.PASS);	
		
		
		Driver.findElement(By.xpath("(//*[@id='confirm-Submit'])[2]")).click();
		Thread.sleep(5000);
		Report.updateTestLog(Action,"click  on Cancle button ", Status.PASS);
		
		
		Driver.findElement(By.xpath("//*[contains(@class,'btn-actshp-CA')]")).click();
		Thread.sleep(5000);
		Report.updateTestLog(Action,"click  on ReOrder button ", Status.PASS);
		
	}	catch(Exception e1) {
		Report.updateTestLog(Action,"Unable to click  on ReOrder button "+e1, Status.FAIL);			
	}
	
	
	
		
		
		
	}	catch(Exception e1) {
		Report.updateTestLog(Action,"Unable to get text button "+e1, Status.FAIL);			
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}


@Action(object = ObjectType.BROWSER, desc = "Click on the addtoCart and Validating shipping page info", input = InputType.NO)

public void orderAddcart_ShippingPageValidation_CA()

{
	try {
	Driver.findElement(By.xpath("//input[contains(@class,'reorderBtn reorderBtnn')]")).click();
	
	Report.updateTestLog(Action,"Able to click on the Addcart button" , Status.PASS);	
	
	//Wait until page load is complete	
	WebDriverWait wait = new WebDriverWait(Driver,10);
	wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
			.executeScript("return document.readyState")));
	
	Report.updateTestLog(Action,"Sucessfully navigated to  "+Driver.getTitle(), Status.PASS);
	
	
	String ProductCount=getVar("%productlistsize%");
	

	String ActualProductCount = Driver.findElement(By.xpath("//span[@id='cartTotalNonZero']/span[contains(@class,'count')]")).getText();

	// Verify total Product Count displayed at Cart Header
	if(ActualProductCount.contains(ProductCount)) {
		Report.updateTestLog(Action, "Expected Total Product in Cart "+ProductCount+" And Actual Total Product in Cart "+ActualProductCount, Status.PASS);
	}else {
		Report.updateTestLog(Action, "Expected Total Product in Cart "+ProductCount+" And Actual Total Product in Cart "+ActualProductCount, Status.FAIL);
	}
	
	
	
		
	
	
	String shpto_adress=getVar("%shiptoaddress%");
	String weeklyhours= getVar("%weeklyHours%");
	
	String billto_adress=getVar("%billToAddress%");
	String poNumber= getVar("%poNumber%");
		
	
	
	try {
	
	WebElement POnumber =Driver.findElement(By.xpath("(//span[contains(text(),'P.O.Number')]/parent::div//input)"));
	WebElement Weekly_Hours =	Driver.findElement(By.xpath("(//span[contains(text(),'Weekly Hours of Operation')]/parent::div//textarea)"));
	
	
	
	POnumber.sendKeys(poNumber);
	Weekly_Hours.sendKeys(weeklyhours);
	
	
	Report.updateTestLog(Action,  poNumber +" ::::::::  "+weeklyhours +" :::  details Ent " , Status.PASS);	
	

	}	catch(Exception e) {
		Report.updateTestLog(Action,"unable to Enter the Ponumber and Weekly Houres ", Status.FAIL);			
	}
	
	
	try {

	// Verify ShipTo and BillTo
	String ActualShipTo = Driver.findElement(By.xpath("(//div[@class='row ship-to'])//div[contains(@class,'cart-add-tlt-CA')]//span[contains(@class,'shpAddrAln')]")).getText();
	String ActualBillTo = Driver.findElement(By.xpath("(//div[@class='row ship-to'])//div[contains(@class,'po-cart')]//span[contains(@class,'shpAddrAln')]")).getText();

	String shptodetails=Driver.findElement(By.xpath("(//div[@class='row ship-to'])//div[contains(@class,'cart-add-tlt-CA')]//div[contains(@class,'stAddressAlgn')]")).getText();
	String billtodetails=Driver.findElement(By.xpath("(//div[@class='row ship-to'])//div[contains(@class,'po-cart')]//div[contains(@class,'stAddressAlgn')]")).getText();
	
	
	
	if(shpto_adress.contains(ActualShipTo))
	{
		
		Report.updateTestLog(Action, " ActualShipTo details are matching  "+ActualShipTo , Status.PASS);	
		
	}
	else {
		Report.updateTestLog(Action, " ActualShipTo details are matching  " , Status.FAIL);
		
	}
	
	if(shpto_adress.contains(shptodetails))
	{
		Report.updateTestLog(Action, " shptodetails details are matching  "+shptodetails , Status.PASS);
		
	}else {
		Report.updateTestLog(Action, shpto_adress + " ::   shptodetails details are Not matching   :: "+shptodetails , Status.FAIL);
		
	}
	
	
	
	if(billto_adress.contains(ActualBillTo))
	{
		
		Report.updateTestLog(Action, " ActualBillTo details are matching  "+ActualShipTo , Status.PASS);	
		
	}
	else {
		Report.updateTestLog(Action, " ActualBillTo details are matching  " , Status.FAIL);
		
	}
	
	if(billto_adress.contains(billtodetails))
	{
		Report.updateTestLog(Action, " billtodetails details are matching  "+shptodetails , Status.PASS);
		
	}else {
		Report.updateTestLog(Action, billto_adress+ " :: billtodetails details are Not matching  :: "+billtodetails , Status.FAIL);
		
	}
	
	
	
	
	
	
	
	
	
	}	catch(Exception e) {
		Report.updateTestLog(Action,"unable get Shipto and Billto details", Status.FAIL);			
	}
	
	int ProductRow=Integer.parseInt(ProductCount);
	
	double ExpectedTotalPriceWithVat_PerCart=0.00;
	double ExpectedTotalPriceWithVat_AllCart = 0.00;
	// Verify each product row
	String ProductQuantity = null;
	for (int j=1;j<=ProductRow;j++) {
	try
	{
		
		// Verify Product Price With/WithOut VAT
		String PriceWithVat = Driver.findElement(By.xpath("(//div[@class='row ship-to'])//div[contains(@class,'row product-item')]["+j+"]//div[contains(@class,'pageConfWithVatVal')]")).getText();
			 ProductQuantity = Driver.findElement(By.xpath("(//div[@class='row ship-to'])//div[contains(@class,'row product-item')]["+j+"]//input[@id='quantity' and @type='number']")).getAttribute("value");
		String ActualTotalPriceWithVat_PerProduct = Driver.findElement(By.xpath("(//div[@class='row ship-to'])//div[contains(@class,'row product-item')]["+j+"]//div[contains(@class,'product-total')]")).getText();

		PriceWithVat = PriceWithVat.replace(",", "");
		//PriceWithVat = PriceWithVat.replace(",", "");
		String [] PriceWithVatArray = PriceWithVat.split(" ");
		 PriceWithVatArray=PriceWithVatArray[1].split("/");
			
		double PriceWithVat_Double = Double.parseDouble(PriceWithVatArray[0]);
					
			
		int ProductQuantity_Int = Integer.parseInt(ProductQuantity);
				
			
		double ExpectedTotalPriceWithVat_PerProduct =  Math.round((PriceWithVat_Double*ProductQuantity_Int) * 100.0) / 100.0;
		
		
		ActualTotalPriceWithVat_PerProduct = ActualTotalPriceWithVat_PerProduct.replace(",", "");
		String [] ActualTotalPriceWithVat_PerProductArray = ActualTotalPriceWithVat_PerProduct.split(" ");
		
		String ActualTotalProductPriceWithVat_String=ActualTotalPriceWithVat_PerProductArray[1];
		
		double ActualTotalPriceWithVat_PerProduct_Double = Double.parseDouble(ActualTotalProductPriceWithVat_String);
		
		if (ExpectedTotalPriceWithVat_PerProduct==ActualTotalPriceWithVat_PerProduct_Double) {
			Report.updateTestLog(Action, "Expected TotalPriceWithVat "+ExpectedTotalPriceWithVat_PerProduct+" And Actual TotalPriceWithVat "+ActualTotalPriceWithVat_PerProduct_Double, Status.PASS);
			
			String perproduct=String.valueOf(ExpectedTotalPriceWithVat_PerProduct);
					userData.putData("OrderDetails", "product"+j, perproduct);
					
		
		}else {
			Report.updateTestLog(Action, "Expected TotalPricePer Product "+ExpectedTotalPriceWithVat_PerProduct+" And Actual TotalPricePer Product "+ActualTotalPriceWithVat_PerProduct_Double, Status.FAIL);
		}

		// Verify Total Price Per Cart
		//ExpectedTotalPriceWithVat_PerCart = Math.round((ExpectedTotalPriceWithVat_PerCart+ExpectedTotalPriceWithVat_PerProduct+ProductQuantity_Int) * 100.0) / 100.0;
		ExpectedTotalPriceWithVat_PerCart = Math.round((ExpectedTotalPriceWithVat_PerCart+ExpectedTotalPriceWithVat_PerProduct) * 100.0) / 100.0;
			//Report.updateTestLog(Action, " ExpectedTotalPriceWithVat_PerCart   :::::::::::  "+ExpectedTotalPriceWithVat_PerCart, Status.DONE);			
	

					
		
		
		
		
		
	}catch(Exception e) {
		Report.updateTestLog(Action,"unable get Shipto and Billto details", Status.FAIL);			
	}
	
	
	
	
	
	}
	
	
	try {

		// Verify Total Price Per Cart
		String ActualTotalPriceWithVat_PerCart = Driver.findElement(By.xpath("(//div[@class='row ship-to'])//div[contains(@class,'grand-total_cad-CA')]")).getText();

		ActualTotalPriceWithVat_PerCart = ActualTotalPriceWithVat_PerCart.replace(",", "");
		String [] ActualTotalPriceWithVat_PerCartArray = ActualTotalPriceWithVat_PerCart.split(" ");
		//ActualTotalPriceWithVat_PerCartArray=ActualTotalPriceWithVat_PerCartArray[1].split("/");
		String ActualTotalPriceWithVat_PerCart_String=ActualTotalPriceWithVat_PerCartArray[1];
		userData.putData("OrderDetails", "Total", ActualTotalPriceWithVat_PerCart_String);
		
		double ActualTotalPriceWithVat_PerCart_Double = Double.parseDouble(ActualTotalPriceWithVat_PerCart_String);
		//Report.updateTestLog(Action," ActualTotalPriceWithVat_PerCart_Double:::: "+ActualTotalPriceWithVat_PerCart_Double, Status.DONE);
		if (ExpectedTotalPriceWithVat_PerCart==ActualTotalPriceWithVat_PerCart_Double) {
			Report.updateTestLog(Action, "Expected TotalPriceWithVat For Cart  is "+ExpectedTotalPriceWithVat_PerCart+" And Actual TotalPriceWithVat For Cart is "+ActualTotalPriceWithVat_PerCart_Double, Status.PASS);
		}else {
			Report.updateTestLog(Action, "Expected TotalPriceWithVat For Cart  is "+ExpectedTotalPriceWithVat_PerCart+" And Actual TotalPriceWithVat For Cart is "+ActualTotalPriceWithVat_PerCart_Double, Status.FAIL);
		}
		
		
		

		
	
		// Verify Total Price for ALL Carts
	ExpectedTotalPriceWithVat_AllCart = Math.round((ExpectedTotalPriceWithVat_AllCart+ExpectedTotalPriceWithVat_PerCart) * 100.0) / 100.0;
	
		
		}catch (Exception e) {
			Report.updateTestLog(Action," Verify Total Price Per Cart  getting failed ", Status.FAIL);
		}
		
	try {	
		
		// Verify Total Price for ALL Carts
	String ActualTotalPriceWithVat_AllCart = Driver.findElement(By.xpath("//div[@class='row cart-bottom']//div[contains(@class,'grandtotalvalue-CA')]")).getText(); 

	ActualTotalPriceWithVat_AllCart = ActualTotalPriceWithVat_AllCart.replace(",", "");
	
	String [] ActualTotalPriceWithVat_AllCartArray = ActualTotalPriceWithVat_AllCart.split(" ");
	//ActualTotalPriceWithVat_AllCartArray=ActualTotalPriceWithVat_AllCartArray[1].split("/");

	String ActualTotalPriceWithVat_AllCart_String=ActualTotalPriceWithVat_AllCartArray[1];

	userData.putData("OrderDetails", "TotalShipping", ActualTotalPriceWithVat_AllCart_String);
	double ActualTotalPriceWithVat_AllCart_Double = Double.parseDouble(ActualTotalPriceWithVat_AllCart_String);


	if (ExpectedTotalPriceWithVat_AllCart==ActualTotalPriceWithVat_AllCart_Double) {
		Report.updateTestLog(Action, "Expected TotalPriceWithVat_AllCart "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPriceWithVat_AllCart "+ActualTotalPriceWithVat_AllCart_Double, Status.PASS);
	
		
	
	
	}else {
		Report.updateTestLog(Action, "Expected TotalPriceWithVat_AllCart "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPriceWithVat_AllCart "+ActualTotalPriceWithVat_AllCart_Double, Status.FAIL);
	}

	
	}catch (Exception e) {
		Report.updateTestLog(Action," Verify Total Price for ALL Carts  getting failed ", Status.FAIL);
	}
	
	
	
	
	}	catch(Exception e1) {
		Report.updateTestLog(Action,"Unable to click on the Addcart button "+e1, Status.FAIL);			
	}
	
	
	
	
	
}








@Action(object = ObjectType.BROWSER, desc = "Click on the Review Your Order Validation", input = InputType.NO)

public void reorder_reviewOrderPageValidation_CA()

{
	try {
Driver.findElement(By.xpath("//button[@id='checkoutButton']")).click();
		
		WebDriverWait wait1 = new WebDriverWait(Driver,100);
		wait1.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
				.executeScript("return document.readyState")));
		Thread.sleep(10000);
	
	Report.updateTestLog(Action,"Sucessfully navigated to  "+Driver.getTitle(), Status.PASS);
	
	
	String ProductCount=getVar("%productlistsize%");
	

	
	
	String shpto_adress=getVar("%shiptoaddress%");
	String weeklyhours= getVar("%weeklyHours%");
	
	String billto_adress=getVar("%billToAddress%");
	String poNumber= getVar("%poNumber%");
		
	
	
	try {
	
	WebElement POnumber =Driver.findElement(By.xpath("(//span[contains(text(),'P.O.Number')]/parent::div//input)"));
	WebElement Weekly_Hours =	Driver.findElement(By.xpath("(//span[contains(text(),'Weekly Hours of Operation')]/parent::div//textarea)"));
	
	
	
	//POnumber.sendKeys(poNumber);
	//Weekly_Hours.sendKeys(weeklyhours);

	if(POnumber.getAttribute("value").contains(poNumber)) {
		
		
		
		Report.updateTestLog(Action,   " PO Number Matching with Orderconfirmation page  ::  "+poNumber , Status.PASS);	
		
	}
	else
	{
		Report.updateTestLog(Action,  " PO Number not Matching with Orderconfirmation page  " , Status.FAIL);	
		
		
	}
	
	
	
	if(Weekly_Hours.getText().contains(weeklyhours)) {
		
		
		
		Report.updateTestLog(Action,  " Weeklyhours Matching with Orderconfirmation page  ::  "+weeklyhours , Status.PASS);	
		
	}
	else
	{
		Report.updateTestLog(Action,  " PO Number not Matching with Orderconfirmation page  " , Status.FAIL);	
		
		
	}
	
	

	
	

	}	catch(Exception e) {
		Report.updateTestLog(Action,"unable to Enter the Ponumber and Weekly Houres ", Status.FAIL);			
	}
	
	
	try {

	// Verify ShipTo and BillTo
	String ActualShipTo = Driver.findElement(By.xpath("(//div[@class='row ship-to'])//div[contains(@class,'cart-add-tlt-CA')]//span[contains(@class,'shpAddrAln')]")).getText();
	String ActualBillTo = Driver.findElement(By.xpath("((//div[@class='row ship-to'])//span[contains(@class,'shpAddrAln')])[2]")).getText();

	String shptodetails=Driver.findElement(By.xpath("(//div[@class='row ship-to'])//div[contains(@class,'cart-add-tlt-CA')]//div[contains(@class,'stAddressAlgn')]")).getText();
	String billtodetails=Driver.findElement(By.xpath("((//div[@class='row ship-to'])//div[contains(@class,'stAddressAlgn')])[2]")).getText();
	
	
	
	if(shpto_adress.contains(ActualShipTo))
	{
		
		Report.updateTestLog(Action, " ActualShipTo details are matching  "+ActualShipTo , Status.PASS);	
		
	}
	else {
		Report.updateTestLog(Action, " ActualShipTo details are matching  " , Status.FAIL);
		
	}
	
	if(shpto_adress.contains(shptodetails))
	{
		Report.updateTestLog(Action, " shptodetails details are matching  "+shptodetails , Status.PASS);
		
	}else {
		Report.updateTestLog(Action, shpto_adress + " ::   shptodetails details are Not matching   :: "+shptodetails , Status.FAIL);
		
	}
	
	
	
	if(billto_adress.contains(ActualBillTo))
	{
		
		Report.updateTestLog(Action, " ActualBillTo details are matching  "+ActualShipTo , Status.PASS);	
		
	}
	else {
		Report.updateTestLog(Action, " ActualBillTo details are matching  " , Status.FAIL);
		
	}
	
	if(billto_adress.contains(billtodetails))
	{
		Report.updateTestLog(Action, " billtodetails details are matching  "+shptodetails , Status.PASS);
		
	}else {
		Report.updateTestLog(Action, billto_adress+ " :: billtodetails details are Not matching  :: "+billtodetails , Status.FAIL);
		
	}
	
	
	
	
	
	
	
	
	
	}	catch(Exception e) {
		Report.updateTestLog(Action,"unable get Shipto and Billto details", Status.FAIL);			
	}
	
	int ProductRow=Integer.parseInt(ProductCount);
	
	double ExpectedTotalPriceWithVat_PerCart=0.00;
	double ExpectedTotalPriceWithVat_AllCart = 0.00;
	// Verify each product row
	String ProductQuantity = null;
	for (int j=1;j<=ProductRow;j++) {
	try
	{
		
		// Verify Product Price With/WithOut VAT
		String PriceWithVat = Driver.findElement(By.xpath("((//div[@class='row ship-to'])//div[contains(@class,'row gsk-box-productSection')])[1]/following-sibling::div//div[contains(@class,'row product-item')]["+j+"]//div[contains(@class,'withoutvatcheckout-CA')]")).getText();
			 ProductQuantity = Driver.findElement(By.xpath("((//div[@class='row ship-to'])//div[contains(@class,'row gsk-box-productSection')])[1]/following-sibling::div//div[contains(@class,'row product-item')]["+j+"]//div[contains(@class,'summary-qty-val-CA')]")).getText();
		String ActualTotalPriceWithVat_PerProduct = Driver.findElement(By.xpath("((//div[@class='row ship-to'])//div[contains(@class,'row gsk-box-productSection')])[1]/following-sibling::div//div[contains(@class,'row product-item')]["+j+"]//div[contains(@class,'product-total')]")).getText();

		
		
		
		PriceWithVat = PriceWithVat.replace(",", "");
		//PriceWithVat = PriceWithVat.replace(",", "");
		String [] PriceWithVatArray = PriceWithVat.split(" ");
		 PriceWithVatArray=PriceWithVatArray[1].split("/");
			
		double PriceWithVat_Double = Double.parseDouble(PriceWithVatArray[0]);
					
			
		int ProductQuantity_Int = Integer.parseInt(ProductQuantity);
				
			
		double ExpectedTotalPriceWithVat_PerProduct =  Math.round((PriceWithVat_Double*ProductQuantity_Int) * 100.0) / 100.0;
		
		
		ActualTotalPriceWithVat_PerProduct = ActualTotalPriceWithVat_PerProduct.replace(",", "");
		String [] ActualTotalPriceWithVat_PerProductArray = ActualTotalPriceWithVat_PerProduct.split(" ");
		
		String ActualTotalProductPriceWithVat_String=ActualTotalPriceWithVat_PerProductArray[1];
		
		double ActualTotalPriceWithVat_PerProduct_Double = Double.parseDouble(ActualTotalProductPriceWithVat_String);
		
		if (ExpectedTotalPriceWithVat_PerProduct==ActualTotalPriceWithVat_PerProduct_Double) {
			Report.updateTestLog(Action, "Expected TotalPriceWithVat "+ExpectedTotalPriceWithVat_PerProduct+" And Actual TotalPriceWithVat "+ActualTotalPriceWithVat_PerProduct_Double, Status.PASS);
			
			String perproduct=String.valueOf(ExpectedTotalPriceWithVat_PerProduct);
					
		
		}else {
			Report.updateTestLog(Action, "Expected TotalPriceWithVat "+ExpectedTotalPriceWithVat_PerProduct+" And Actual TotalPriceWithVat "+ActualTotalPriceWithVat_PerProduct_Double, Status.FAIL);
		}

		// Verify Total Price Per Cart
		//ExpectedTotalPriceWithVat_PerCart = Math.round((ExpectedTotalPriceWithVat_PerCart+ExpectedTotalPriceWithVat_PerProduct+ProductQuantity_Int) * 100.0) / 100.0;
		ExpectedTotalPriceWithVat_PerCart = Math.round((ExpectedTotalPriceWithVat_PerCart+ExpectedTotalPriceWithVat_PerProduct) * 100.0) / 100.0;
			//Report.updateTestLog(Action, " ExpectedTotalPriceWithVat_PerCart   :::::::::::  "+ExpectedTotalPriceWithVat_PerCart, Status.DONE);			
	

		
		
	}catch(Exception e) {
		Report.updateTestLog(Action,"unable get Shipto and Billto details", Status.FAIL);			
	}
	
	
	
	
	}
	
	
	try {

	// Verify Total Price Per Cart
	//String ActualTotalPriceWithVat_PerCart = Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//div[contains(@class,'checkOutSumCa-CA')]")).getText();
	String ActualTotalPriceWithVat_PerCart = Driver.findElement(By.xpath("((//div[@class='row ship-to'])//div[contains(@class,'row gsk-box-productSection')])[1]/following-sibling::div//div[contains(@class,'checkOutSumCa-CA')]")).getText();

	ActualTotalPriceWithVat_PerCart = ActualTotalPriceWithVat_PerCart.replace(",", "");
	String [] ActualTotalPriceWithVat_PerCartArray = ActualTotalPriceWithVat_PerCart.split(" ");
	//ActualTotalPriceWithVat_PerCartArray=ActualTotalPriceWithVat_PerCartArray[1].split("/");
	String ActualTotalPriceWithVat_PerCart_String=ActualTotalPriceWithVat_PerCartArray[1];
	
		
	double ActualTotalPriceWithVat_PerCart_Double = Double.parseDouble(ActualTotalPriceWithVat_PerCart_String);
//	Report.updateTestLog(Action," ActualTotalPriceWithVat_PerCart_Double:::: "+ActualTotalPriceWithVat_PerCart_Double, Status.DONE);
	if (ExpectedTotalPriceWithVat_PerCart==ActualTotalPriceWithVat_PerCart_Double) {
		Report.updateTestLog(Action, "Expected TotalPriceWithVat For Cart is "+ExpectedTotalPriceWithVat_PerCart+" And Actual TotalPriceWithVat For Cart is "+ActualTotalPriceWithVat_PerCart_Double, Status.PASS);
	}else {
		Report.updateTestLog(Action, "Expected TotalPriceWithVat For Cart  is "+ExpectedTotalPriceWithVat_PerCart+" And Actual TotalPriceWithVat For Cart  is "+ActualTotalPriceWithVat_PerCart_Double, Status.FAIL);
	}
	
	
	

	
	
	// Verify Total Price for ALL Carts
ExpectedTotalPriceWithVat_AllCart = Math.round((ExpectedTotalPriceWithVat_AllCart+ExpectedTotalPriceWithVat_PerCart) * 100.0) / 100.0;

	}catch (Exception e) {
		Report.updateTestLog(Action," Verify Total Price Per Cart  getting failed "+e, Status.FAIL);
	}
	
	
//		
	
	
	
try {	
	
	// Verify Total Price for ALL Carts
String ActualTotalPriceWithVat_AllCart = Driver.findElement(By.xpath("//div[@class='row cart-bottom']//div[contains(@class,' total-ipad-val-CA')]")).getText(); 

ActualTotalPriceWithVat_AllCart = ActualTotalPriceWithVat_AllCart.replace(",", "");

String [] ActualTotalPriceWithVat_AllCartArray = ActualTotalPriceWithVat_AllCart.split(" ");
//ActualTotalPriceWithVat_AllCartArray=ActualTotalPriceWithVat_AllCartArray[1].split("/");

String ActualTotalPriceWithVat_AllCart_String=ActualTotalPriceWithVat_AllCartArray[1];


double ActualTotalPriceWithVat_AllCart_Double = Double.parseDouble(ActualTotalPriceWithVat_AllCart_String);


if (ExpectedTotalPriceWithVat_AllCart==ActualTotalPriceWithVat_AllCart_Double) {
	Report.updateTestLog(Action, "Expected TotalPriceWithVat_AllCart "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPriceWithVat_AllCart "+ActualTotalPriceWithVat_AllCart_Double, Status.PASS);
}else {
	Report.updateTestLog(Action, "Expected TotalPriceWithVat_AllCart "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPriceWithVat_AllCart "+ActualTotalPriceWithVat_AllCart_Double, Status.FAIL);
}


}catch (Exception e) {
	Report.updateTestLog(Action," Verify Total Price for ALL Carts  getting failed "+e, Status.FAIL);
}

try {
// Verify total Cart Price displayed at Cart Header
String ActualTotalPriceAtCartHeader = Driver.findElement(By.xpath("//span[@id='cartTotalNonZero']/span[contains(@class,'count')]/span[2]")).getText();

ActualTotalPriceAtCartHeader = ActualTotalPriceAtCartHeader.replace(",", "");
String [] ActualTotalPriceAtCartHeaderArray = ActualTotalPriceAtCartHeader.split(" ");
//ActualTotalPriceAtCartHeaderArray=ActualTotalPriceAtCartHeaderArray[1].split("/");
String ActualTotalPriceAtCartHeader_String=ActualTotalPriceAtCartHeaderArray[1];

	

double ActualTotalPriceAtCartHeader_Double = Double.parseDouble(ActualTotalPriceAtCartHeader_String);

if (ExpectedTotalPriceWithVat_AllCart==ActualTotalPriceAtCartHeader_Double) {
	Report.updateTestLog(Action, "Expected TotalPrice_At Cart Header "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPrice_At Cart Header "+ActualTotalPriceAtCartHeader_Double, Status.PASS);
}else {
	Report.updateTestLog(Action, "Expected TotalPrice_At Cart Header "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPrice_At Cart Header "+ActualTotalPriceAtCartHeader_Double, Status.FAIL);
}




}catch (Exception e) {
	Report.updateTestLog(Action," Verify total Cart Price displayed at Cart Header  getting failed ", Status.FAIL);
}
	
	
	
	
	}	catch(Exception e1) {
		Report.updateTestLog(Action,"Unable to click on the Addcart button "+e1, Status.FAIL);			
	}
	
	
	
	
	
}



// ------------------------------------------------------------------------------------------------------------- //



@Action(object = ObjectType.BROWSER, desc = "Click on the Review Your Order Validation", input = InputType.NO)

public void reorder_OrderPageconfirmValidation_CA()

{
	try {
		Driver.findElement(By.xpath("//button[contains(text(),'Place Order')]")).click();
		
		WebDriverWait wait1 = new WebDriverWait(Driver,100);
		wait1.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
				.executeScript("return document.readyState")));
		Thread.sleep(10000);
	
	Report.updateTestLog(Action,"Sucessfully navigated to  "+Driver.getTitle(), Status.PASS);
	
	
	
	// Verify Header Text, Order Confirmation No and Order Confirmation Date
				String ConfirmOrderHeader = Driver.findElement(By.xpath("//p[contains(text(),' Order Confirmation')]")).getText();
				WebElement OrderConfirmationNumber = Driver.findElement(By.xpath("//strong[contains(text(),'confirmation number ')]"));
				WebElement OrderConfirmationDate = Driver.findElement(By.xpath("//p[@id='order-confirmation-date']"));
				WebElement OrderConfirmationSentto=Driver.findElement(By.xpath("//strong[contains(text(),'Confirmation Sent to:')]/parent::p"));

				String[] OrderConfirmationNumberArray = OrderConfirmationNumber.getText().split("\\s+");
				String[] OrderConfirmationDateArray = OrderConfirmationDate.getText().split(":");
				String[] OrderConfirmationSenttoArray=OrderConfirmationSentto.getText().split(":");


				if (ConfirmOrderHeader.equalsIgnoreCase("Order Confirmation") && OrderConfirmationNumber.isDisplayed() && OrderConfirmationDate.isDisplayed() &&OrderConfirmationSentto.isDisplayed())
				{
					Report.updateTestLog(Action, "Order Placed Successfully. Order Confirmation No ::- "+OrderConfirmationNumberArray[4]+" | Order Confirmation Date - "+OrderConfirmationDateArray[1]+" | Order Confirmation Sent to - "+OrderConfirmationSenttoArray[1], Status.PASS);
				
				//	Report.updateTestLog(Action, "Order Confirmation No 3 ::- "+OrderConfirmationNumberArray[3]+"Order Confirmation No 2 ::- "+OrderConfirmationNumberArray[2], Status.DONE);
				
				
				}else {
					Report.updateTestLog(Action, "Order Place is NOT Successful", Status.FAIL);
				}
	
	
	
	
	
	
	
	
	
	
	
	
	String ProductCount=getVar("%productlistsize%");
	

	
	
	String shpto_adress=getVar("%shiptoaddress%");
	String weeklyhours= getVar("%weeklyHours%");
	
	String billto_adress=getVar("%billToAddress%");
	String poNumber= getVar("%poNumber%");
	ArrayList<String> OrderNumberList = new ArrayList<String>();
	
	WebElement OrderNumber = Driver.findElement(By.xpath("//div[@class='row ship-to newpage_eachOrder']//h2[contains(@class,'ship-to-title')]"));
	String OrderNumberString = OrderNumber.getText();
	String[] OrderNumberArray = OrderNumberString.split("\\s+");
	OrderNumberList.add(OrderNumberArray[1]);

	if(OrderNumber.isDisplayed()) {
		Report.updateTestLog(Action, "Order Number for Cart  is -->"+OrderNumberArray[1], Status.PASS);
		
		userData.putData("RegressionData", "Order", OrderNumberArray[1]);
	}else {
		Report.updateTestLog(Action, "Order Number for Cart  NOT Present", Status.FAIL);
	}
	
	
		
	try {

	// Verify ShipTo and BillTo
	String ActualShipTo = Driver.findElement(By.xpath("//div[@class='row ship-to newpage_eachOrder']//div[contains(@class,'cart-add-tlt-CA')]//span[contains(@class,'shpAddrAln')]")).getText();
	String ActualBillTo = Driver.findElement(By.xpath("(//div[@class='row ship-to newpage_eachOrder']//span[contains(@class,'shpAddrAln')])[2]")).getText();

	String shptodetails=Driver.findElement(By.xpath("(//div[@class='row ship-to newpage_eachOrder'])//div[contains(@class,'cart-add-tlt-CA')]//div[contains(@class,'stAddressAlgn')]")).getText();
	String billtodetails=Driver.findElement(By.xpath("((//div[@class='row ship-to newpage_eachOrder'])//div[contains(@class,'stAddressAlgn')])[2]")).getText();
	
	
	
	if(shpto_adress.contains(ActualShipTo))
	{
		
		Report.updateTestLog(Action, " ActualShipTo details are matching  "+ActualShipTo , Status.PASS);	
		
	}
	else {
		Report.updateTestLog(Action, " ActualShipTo details are matching  " , Status.FAIL);
		
	}
	
	if(shpto_adress.contains(shptodetails))
	{
		Report.updateTestLog(Action, " shptodetails details are matching  "+shptodetails , Status.PASS);
		
	}else {
		Report.updateTestLog(Action, shpto_adress + " ::   shptodetails details are Not matching   :: "+shptodetails , Status.FAIL);
		
	}
	
	
	
	if(billto_adress.contains(ActualBillTo))
	{
		
		Report.updateTestLog(Action, " ActualBillTo details are matching  "+ActualShipTo , Status.PASS);	
		
	}
	else {
		Report.updateTestLog(Action, " ActualBillTo details are matching  " , Status.FAIL);
		
	}
	
	if(billto_adress.contains(billtodetails))
	{
		Report.updateTestLog(Action, " billtodetails details are matching  "+shptodetails , Status.PASS);
		
	}else {
		Report.updateTestLog(Action, billto_adress+ " :: billtodetails details are Not matching  :: "+billtodetails , Status.FAIL);
		
	}
	
	
	
	
	
	
	
	
	
	}	catch(Exception e) {
		Report.updateTestLog(Action,"unable get Shipto and Billto details", Status.FAIL);			
	}
	
	

	try {
	
	WebElement POnumber =Driver.findElement(By.xpath("(//span[contains(text(),'P.O.Number')]/parent::div//input)"));
	WebElement Weekly_Hours =	Driver.findElement(By.xpath("(//span[contains(text(),'Weekly Hours of Operation')]/parent::div//textarea)"));
	
	
	Report.updateTestLog(Action,   " PO Number  ::  "+POnumber.getText() , Status.DONE);	
	//POnumber.sendKeys(poNumber);
	//Weekly_Hours.sendKeys(weeklyhours);
	
	if(POnumber.getAttribute("value").contains(poNumber)) {
		
		
		
		Report.updateTestLog(Action,   " PO Number Matching with Orderconfirmation page  ::  "+poNumber , Status.PASS);	
		
	}
	else
	{
		Report.updateTestLog(Action,  " PO Number not Matching with Orderconfirmation page  " , Status.FAIL);	
		
		
	}
	
	
	
	if(Weekly_Hours.getText().contains(weeklyhours)) {
		
		
		
		Report.updateTestLog(Action,  " Weeklyhours Matching with Orderconfirmation page  ::  "+weeklyhours , Status.PASS);	
		
	}
	else
	{
		Report.updateTestLog(Action,  " PO Number not Matching with Orderconfirmation page  " , Status.FAIL);	
		
		
	}
	
	

	

	}	catch(Exception e) {
		Report.updateTestLog(Action,"unable to Enter the Ponumber and Weekly Houres ", Status.FAIL);			
	}
	
	
	
	int ProductRow=Integer.parseInt(ProductCount);
	
	double ExpectedTotalPriceWithVat_PerCart=0.00;
	double ExpectedTotalPriceWithVat_AllCart = 0.00;
	
	// Verify each product row
	String ProductQuantity = null;
	for (int j=1;j<=ProductRow;j++) {
	try
	{
		
		// Verify Product Price With/WithOut VAT
	//	String PriceWithVat = Driver.findElement(By.xpath("((//div[@class='row ship-to'])//div[contains(@class,'row gsk-box-productSection')])[1]/following-sibling::div//div[contains(@class,'row product-item')]["+j+"]//div[contains(@class,'withoutvatcheckout-CA')]")).getText();
	//		 ProductQuantity = Driver.findElement(By.xpath("((//div[@class='row ship-to'])//div[contains(@class,'row gsk-box-productSection')])[1]/following-sibling::div//div[contains(@class,'row product-item')]["+j+"]//div[contains(@class,'summary-qty-val-CA')]")).getText();
	//	String ActualTotalPriceWithVat_PerProduct = Driver.findElement(By.xpath("((//div[@class='row ship-to'])//div[contains(@class,'row gsk-box-productSection')])[1]/following-sibling::div//div[contains(@class,'row product-item')]["+j+"]//div[contains(@class,'product-total')]")).getText();

	
		// Verify Product Price With/WithOut VAT
		String PriceWithVat = Driver.findElement(By.xpath("//div[@class='row ship-to newpage_eachOrder']//div[contains(@class,'row product-ListItem')]["+j+"]//div[@class='cnd-price-print-CA']")).getText();
		 ProductQuantity = Driver.findElement(By.xpath("//div[@class='row ship-to newpage_eachOrder']//div[contains(@class,'row product-ListItem')]["+j+"]//div[@class='input-control']")).getText();
		String ActualTotalPriceWithVat_PerProduct = Driver.findElement(By.xpath("//div[@class='row ship-to newpage_eachOrder']//div[contains(@class,'row product-ListItem')]["+j+"]//div[contains(@class,'confi-total')]")).getText();
	
		
				
		
		
		
		PriceWithVat = PriceWithVat.replace(",", "");
		//PriceWithVat = PriceWithVat.replace(",", "");
		String [] PriceWithVatArray = PriceWithVat.split(" ");
		// PriceWithVatArray=PriceWithVatArray[1].split("/");
			
		double PriceWithVat_Double = Double.parseDouble(PriceWithVatArray[1]);
					
			
		int ProductQuantity_Int = Integer.parseInt(ProductQuantity);
				
			
		double ExpectedTotalPriceWithVat_PerProduct =  Math.round((PriceWithVat_Double*ProductQuantity_Int) * 100.0) / 100.0;
		
		
		ActualTotalPriceWithVat_PerProduct = ActualTotalPriceWithVat_PerProduct.replace(",", "");
		String [] ActualTotalPriceWithVat_PerProductArray = ActualTotalPriceWithVat_PerProduct.split(" ");
		
		String ActualTotalProductPriceWithVat_String=ActualTotalPriceWithVat_PerProductArray[1];
		
		double ActualTotalPriceWithVat_PerProduct_Double = Double.parseDouble(ActualTotalProductPriceWithVat_String);
		
		if (ExpectedTotalPriceWithVat_PerProduct==ActualTotalPriceWithVat_PerProduct_Double) {
			Report.updateTestLog(Action, "Expected TotalPriceWithVat "+ExpectedTotalPriceWithVat_PerProduct+" And Actual TotalPriceWithVat "+ActualTotalPriceWithVat_PerProduct_Double, Status.PASS);
		}else {
			Report.updateTestLog(Action, "Expected TotalPriceWithVat "+ExpectedTotalPriceWithVat_PerProduct+" And Actual TotalPriceWithVat "+ActualTotalPriceWithVat_PerProduct_Double, Status.FAIL);
		}

		// Verify Total Price Per Cart
		//ExpectedTotalPriceWithVat_PerCart = Math.round((ExpectedTotalPriceWithVat_PerCart+ExpectedTotalPriceWithVat_PerProduct+ProductQuantity_Int) * 100.0) / 100.0;
		ExpectedTotalPriceWithVat_PerCart = Math.round((ExpectedTotalPriceWithVat_PerCart+ExpectedTotalPriceWithVat_PerProduct) * 100.0) / 100.0;
		Report.updateTestLog(Action, " ExpectedTotalPriceWithVat_PerCart   :::::::::::  "+ExpectedTotalPriceWithVat_PerCart, Status.DONE);			

	}catch(Exception e) {
		Report.updateTestLog(Action,"unable get Shipto and Billto details", Status.FAIL);			
	}
	
	
	
	
	}
	
	
	
	
	
	
	try {

		// Verify Total Price Per Cart
	String ActualTotalPriceWithVat_PerCart = Driver.findElement(By.xpath("//div[@class='row ship-to newpage_eachOrder']//div[contains(@class,'grand-total-print-CA')]")).getText();

		ActualTotalPriceWithVat_PerCart = ActualTotalPriceWithVat_PerCart.replace(",", "");
		String [] ActualTotalPriceWithVat_PerCartArray = ActualTotalPriceWithVat_PerCart.split(" ");
		//ActualTotalPriceWithVat_PerCartArray=ActualTotalPriceWithVat_PerCartArray[1].split("/");
		String ActualTotalPriceWithVat_PerCart_String=ActualTotalPriceWithVat_PerCartArray[1];

		
		double ActualTotalPriceWithVat_PerCart_Double = Double.parseDouble(ActualTotalPriceWithVat_PerCart_String);
		Report.updateTestLog(Action," ActualTotalPriceWithVat_PerCart_Double:::: "+ActualTotalPriceWithVat_PerCart_Double, Status.DONE);
		if (ExpectedTotalPriceWithVat_PerCart==ActualTotalPriceWithVat_PerCart_Double) {
			Report.updateTestLog(Action, "Expected TotalPriceWithVat For Cart is "+ExpectedTotalPriceWithVat_PerCart+" And Actual TotalPriceWithVat For Cart is "+ActualTotalPriceWithVat_PerCart_Double, Status.PASS);
		}else {
			Report.updateTestLog(Action, "Expected TotalPriceWithVat For Cart is "+ExpectedTotalPriceWithVat_PerCart+" And Actual TotalPriceWithVat For Cart  is "+ActualTotalPriceWithVat_PerCart_Double, Status.FAIL);
		}
		
		
		

		
	
		// Verify Total Price for ALL Carts
	ExpectedTotalPriceWithVat_AllCart = Math.round((ExpectedTotalPriceWithVat_AllCart+ExpectedTotalPriceWithVat_PerCart) * 100.0) / 100.0;
	
		
		}catch (Exception e) {
			Report.updateTestLog(Action," Verify Total Price Per Cart  getting failed ", Status.FAIL);
		}
		
	try {	
		
		// Verify Total Price for ALL Carts
	String ActualTotalPriceWithVat_AllCart = Driver.findElement(By.xpath("//div[@class='row cart-bottom']//div[contains(@class,'checkSumFinalCostVal-print-CA gTotalAlgn-CA')]")).getText(); 

	ActualTotalPriceWithVat_AllCart = ActualTotalPriceWithVat_AllCart.replace(",", "");
	
	String [] ActualTotalPriceWithVat_AllCartArray = ActualTotalPriceWithVat_AllCart.split(" ");
	//ActualTotalPriceWithVat_AllCartArray=ActualTotalPriceWithVat_AllCartArray[1].split("/");

	String ActualTotalPriceWithVat_AllCart_String=ActualTotalPriceWithVat_AllCartArray[1];

		

	double ActualTotalPriceWithVat_AllCart_Double = Double.parseDouble(ActualTotalPriceWithVat_AllCart_String);


	if (ExpectedTotalPriceWithVat_AllCart==ActualTotalPriceWithVat_AllCart_Double) {
		Report.updateTestLog(Action, "Expected TotalPriceWithVat_AllCart "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPriceWithVat_AllCart "+ActualTotalPriceWithVat_AllCart_Double, Status.PASS);
	}else {
		Report.updateTestLog(Action, "Expected TotalPriceWithVat_AllCart "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPriceWithVat_AllCart "+ActualTotalPriceWithVat_AllCart_Double, Status.FAIL);
	}

	
	}catch (Exception e) {
		Report.updateTestLog(Action," Verify Total Price for ALL Carts  getting failed ", Status.FAIL);
	}
	
try {
	WebElement Element = Driver.findElement(By.xpath("//span[@id='cartTotalZeroPrice']"));
	
	
	if (Element.getText().equals("(0)")) {
		
		Report.updateTestLog(Action, "Cart is null ", Status.PASS);
		
	}else {
		
		Report.updateTestLog(Action, "Cart is Not null "+ Element.getText(), Status.FAIL);
	}
	}catch (Exception e) {
		Report.updateTestLog(Action," Verify total Cart Price displayed at Cart Header  getting failed ", Status.FAIL);
	}

	
	
	
	
//Verify Orders on Order History Page
//Driver.findElement(By.xpath("//a[contains(text(),'PrzeglÄ…daj historiÄ™ zamÃ³wienia')]")).click();
Driver.findElement(By.xpath("//a[contains(text(),'View your order history')]")).click();

WebDriverWait wait2 = new WebDriverWait(Driver,10);
wait2.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
		.executeScript("return document.readyState")));

for (int x=0;x<OrderNumberList.size();x++) {
	String OrderNumber1 = OrderNumberList.get(x);

	Driver.findElement(By.xpath("//input[@id='search_text_order']")).clear();
	Driver.findElement(By.xpath("//input[@id='search_text_order']")).sendKeys(OrderNumber1);

	Driver.findElement(By.xpath("//button[@id='searchtextBtn_order']")).click();
	
	Thread.sleep(5000);

	String SearchResultOrder = Driver.findElement(By.xpath("//div[@class='row']//div[contains(@class,'reservation-number')]//a")).getText();

	if(SearchResultOrder.equalsIgnoreCase(OrderNumber1)) {
		Report.updateTestLog(Action, "Order Number "+OrderNumber1+" is Present on Order History Page ", Status.PASS);
		String addfav8=userData.getData("RegressionData", "addfavorite");
		
		if(addfav8.equals("Yes")) {
			addAsFavorite_buttoncheck();
			
		}
		
		orderhistoryPage_OrderDetails(x);
		
		
		
	}else {
		Report.updateTestLog(Action, "Order Number "+OrderNumber1+" is NOT Present on Order History Page ", Status.FAIL);
	}
}

	
	
	
	
	
	
	
	


























	
	
	
	}	catch(Exception e1) {
		Report.updateTestLog(Action,"Unable to click on the Addcart button "+e1, Status.FAIL);			
	}
	
	
	
	
	
}





@Action(object = ObjectType.BROWSER, desc = "Perform Click on the Custom Xpath as Input", input = InputType.YES)

public void clickCustomXpath_CA() {
      
      Driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
      WebElement element = Driver.findElement(By.xpath(Data));
      element.click();
      System.out.println(Data);
      Report.updateTestLog(Action, "The Click is Performed on the custom xpath", Status.PASS);
      
}




@Action(object = ObjectType.BROWSER,desc = "Variable %currentDate% is created with Formatted Date for Current Time",input = InputType.NO)
public void createDateFormatForCurrentTime_CA() {
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MMM dd, yy, hh:mm:ss a");
    LocalDateTime now = LocalDateTime.now();
    String curr_Date = dtf.format(now);
    
    addVar("%currentDate%",curr_Date);
    
    Report.updateTestLog(Action,curr_Date +" is updated in variable %currentDate%", Status.DONE);
    
}



/*  ********************************** RishbhCode start*********************** */








@Action(object = ObjectType.BROWSER, desc = "Deactivate user after Navigating to User Management Page based on the input email", input = InputType.YES)

public void deactivateUser_CA() throws InterruptedException {

	Driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

	String path = "//a[text()='" + Data + "']//..//..//select";

	WebElement user = Driver.findElement(By.xpath(path));
	Select opt = new Select(user);

	opt.selectByValue("deactivateUser");

	String expectedENMsg = "Are you sure you want to deactivate the user ?";
	String expectedFRMsg = "Êtes-vous certain de vouloir désactiver l’utilisateur?";

	String deactivateMsg = Driver
			.findElement(By.xpath("//div[@id='cboxWrapper']//p[contains(@class,'deactivateMessage')]")).getText()
			.trim();

	if (deactivateMsg.equals(expectedENMsg)) {
		Report.updateTestLog(Action, "The Deactivate Pop-up Text is correctly Disaplyed in English", Status.PASS);
	} else if (deactivateMsg.equals(expectedFRMsg)) {
		Report.updateTestLog(Action, "The Deactivate Pop-up Text is correctly Disaplyed in French", Status.PASS);
	} else {
		Report.updateTestLog(Action,
				"The Deactivate Pop-up Text is correctly Not Correct Disaplyed and is: " + deactivateMsg,
				Status.PASS);
	}

	WebElement btnNO = Driver
			.findElement(By.xpath("//div[@id='cboxWrapper']//input[contains(@onclick,'cancelUrl')]"));
	WebElement btnYES = Driver
			.findElement(By.xpath("//div[@id='cboxWrapper']//input[contains(@onclick,'deactivateUser')]"));

	if (btnNO.isDisplayed() && btnYES.isDisplayed()) {
		Report.updateTestLog(Action, "The Deactivate Pop-up has both Yes and No Option Displayed", Status.PASS);
	} else {
		Report.updateTestLog(Action, "The Deactivate Pop-up dosn't have both Yes and No Option Displayed",
				Status.FAIL);
	}

	btnYES.click();
	Thread.sleep(1000);

	if (Driver.findElements(By.xpath("//a[text()='" + Data + "']")).isEmpty()) {
		Report.updateTestLog(Action,
				"The User " + Data
						+ " was successfully Deactivated and No Longer Displayed in User Management List",
				Status.PASS);
	} else {
		Report.updateTestLog(Action, "The User " + Data + " was not successfully Deactivated", Status.FAIL);
	}

}

@Action(object = ObjectType.BROWSER, desc = "Reject user after Navigating to User Management Page based on the input email", input = InputType.YES)

public void rejectUser_CA() throws InterruptedException {

	Driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

	String path = "//a[text()='" + Data + "']//..//..//select";

	WebElement user = Driver.findElement(By.xpath(path));
	Select opt = new Select(user);

	opt.selectByValue("rejectUser");

	String expectedENMsg = "Are you sure you want to reject the user ?";
	String expectedFRMsg = "Êtes-vous certain de vouloir refuser l’utilisateur?";

	String rejectMsg = Driver.findElement(By.xpath("//div[@id='cboxWrapper']//p[@class='rejectUserMessage']"))
			.getText().trim();

	if (rejectMsg.equals(expectedENMsg)) {
		Report.updateTestLog(Action, "The Reject Pop-up Text is correctly Disaplyed in English", Status.PASS);
	} else if (rejectMsg.equals(expectedFRMsg)) {
		Report.updateTestLog(Action, "The Reject Pop-up Text is correctly Disaplyed in French", Status.PASS);
	} else {
		Report.updateTestLog(Action,
				"The Reject Pop-up Text is correctly Not Correct Disaplyed and is: " + rejectMsg, Status.PASS);
	}

	WebElement btnNO = Driver
			.findElement(By.xpath("//div[@id='cboxWrapper']//input[contains(@onclick,'cancelUrl')]"));
	WebElement btnYES = Driver
			.findElement(By.xpath("//div[@id='cboxWrapper']//input[contains(@onclick,'rejectUser')]"));

	if (btnNO.isDisplayed() && btnYES.isDisplayed()) {
		Report.updateTestLog(Action, "The Reject Pop-up has both Yes and No Option Displayed", Status.PASS);
	} else {
		Report.updateTestLog(Action, "The Reject Pop-up dosn't have both Yes and No Option Displayed", Status.FAIL);
	}

	btnYES.click();
	Thread.sleep(1000);

	if (Driver.findElements(By.xpath("//a[text()='" + Data + "']")).isEmpty()) {
		Report.updateTestLog(Action,
				"The User " + Data + " was successfully rejected and No Longer Displayed in User Management List",
				Status.PASS);
	} else {
		Report.updateTestLog(Action, "The User " + Data + " was not successfully rejected", Status.FAIL);
	}

}

@Action(object = ObjectType.BROWSER, desc = "Approve user after Navigating to User Management Page based on the input Email,Shipto", input = InputType.YES)

public void acceptUser_CA() throws InterruptedException {

	Driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

	String user[] = Data.split(",");

	String email = user[0];
	String shipto = user[1];

	try {

		String emailReq = "//a[text()='" + email + "']//..//..//select";
		WebElement userReq = Driver.findElement(By.xpath(emailReq));

		Select opt = new Select(userReq);
		opt.selectByValue("approveUser");

		String shiptChkBox = "//input[@id='shipToCheckbox_" + shipto + "']";
		Driver.findElement(By.xpath(shiptChkBox)).click();

		Thread.sleep(2000);

		Driver.findElement(By.xpath("//a[contains(@onclick,'user.allowAccess()')]")).click();
		Report.updateTestLog(Action, "The user " + email + " was approved for Shipto " + shipto, Status.PASS);

	} catch (Exception e) {

		Report.updateTestLog(Action, "The user " + email + " was not approved for Shipto " + shipto, Status.FAIL);
	}

}

@Action(object = ObjectType.BROWSER, desc = "Removes Soldto/Shipto from List Displayed in General Tab in BO based on the input as sd-/st- before the number if soldto/shipto and Save", input = InputType.YES)

public void CA_removeSoldtoOrShiptofromCustomersNode() throws InterruptedException {

	String selectData = "//span[contains(text(),'" + Data + "')]//parent::div/parent::div";
	String removeData = "//table//span[contains(text(),'" + Data + "')]//following-sibling::div";

	try {
		Driver.findElement(By.xpath(selectData)).click();
		Driver.findElement(By.xpath(removeData)).click();

		Thread.sleep(2000);

		Driver.findElement(By.xpath("//button[text()='Save' and not(@disabled='disabled')]")).click();

		Thread.sleep(3000);

		Report.updateTestLog(Action,
				"The Shipto / Soldto " + Data + " is removed from customer group list and changes are saved",
				Status.PASS);

	} catch (Exception e) {

		Report.updateTestLog(Action, "Soldto/Shipto is not removed", Status.FAIL);
	}

}

@Action(object = ObjectType.BROWSER, desc = "Method to Extract User Based on the Shipto/Soldto linked to the User and create variables %User'number'% list and %NoOfUsersLinked% ", input = InputType.YES)

public void CA_extractUsersBasedOnShiptoLinked() throws InterruptedException {

	String[] splitedData = Data.split(",");
	String userType = splitedData[0];
	String email = splitedData[1];

	List<String> linkedList = new ArrayList<String>();
	List<String> userLinked = new ArrayList<String>();

	Driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	WebElement filterTree = Driver.findElement(By.xpath("(//input[contains(@placeholder,'Filter tree')])[1]"));
	filterTree.sendKeys("Customers");

	Driver.findElement(By.xpath("//span[text()='Customers']")).click();

	WebElement searchBox = Driver.findElement(By.xpath("//input[@class='z-bandbox-input z-bandbox-rightedge']"));
	searchBox.sendKeys(email);

	WebElement searchButton = Driver.findElement(By.xpath("//button[contains(text(),'Search')]"));
	searchButton.click();

	Thread.sleep(5000);

	Driver.findElement(By.xpath("//span[text()='REGISTERED']")).click();

	Thread.sleep(5000);

	Driver.findElement(By.xpath("//span[text()='General']")).click();

	Thread.sleep(5000);

	List<WebElement> shipto;
	int numShip;
	List<WebElement> soldto;
	int numSold;

	try {
		shipto = Driver.findElements(By.xpath("//span[contains(text(),'st-')]"));
		numShip = 1;

	} catch (Exception e) {
		shipto = null;
		numShip = 0;
	}

	try {
		soldto = Driver.findElements(By.xpath("//span[contains(text(),'sd-')]"));
		numSold = 1;

	} catch (Exception f) {
		soldto = null;
		numSold = 0;
	}

	if (numShip == 1) {

		for (int i = 0; i < shipto.size(); i++) {
			String ship = shipto.get(i).getText().split("-")[1];
			linkedList.add(ship);
		}

	} else {
		System.out.println("No Shipto Linked");
	}

	if (numSold == 1) {

		for (int i = 0; i < soldto.size(); i++) {
			String sold = soldto.get(i).getText().split("-")[1];
			linkedList.add(sold);
		}

	} else {
		System.out.println("No Soldto Linked");
	}

	if (userType.equalsIgnoreCase("admin")) {

		Driver.findElement(By.xpath("(//input[contains(@placeholder,'Filter tree')])[1]")).clear();
		Thread.sleep(1000);
		filterTree = Driver.findElement(By.xpath("(//input[contains(@placeholder,'Filter tree')])[1]"));
		filterTree.sendKeys("GSK ShipTo Account");
		Thread.sleep(2000);

		Driver.findElement(By.xpath("//span[text()='GSK ShipTo Account']")).click();

		Thread.sleep(2000);

		for (int j = 0; j < linkedList.size(); j++) {

			Driver.findElement(By.xpath("//input[@class='z-bandbox-input z-bandbox-rightedge']"))
					.sendKeys(linkedList.get(j));

			searchButton = Driver.findElement(By.xpath("//button[contains(text(),'Search')]"));
			searchButton.click();

			Thread.sleep(2000);

			Driver.findElement(By.xpath("//tr[contains(@class,'yw-coll-browser-hyperlink')]")).click();
			Driver.findElement(By.xpath("//span[text()='Organization']")).click();

			Driver.findElement(By.xpath("//span[@title='members']//..//following-sibling::div//button")).click();

			Thread.sleep(3000);

			List<WebElement> user = Driver.findElements(
					By.xpath("//tr//span[contains(@class,'z-listitem-checkbox')]//following-sibling::span"));

			for (int i = 0; i < user.size(); i++) {
				userLinked.add(user.get(i).getText());
			}

			Driver.findElement(By.xpath("//span[text()='GSK ShipTo Account']")).click();
			Thread.sleep(2000);

			Driver.findElement(By.xpath("//button[@title='Switch search mode']")).click();

		}

	}

	Driver.findElement(By.xpath("(//input[contains(@placeholder,'Filter tree')])[1]")).clear();
	Thread.sleep(1000);
	filterTree = Driver.findElement(By.xpath("(//input[contains(@placeholder,'Filter tree')])[1]"));
	filterTree.sendKeys("GSK SoldTo Account");
	Thread.sleep(2000);

	Driver.findElement(By.xpath("//span[text()='GSK SoldTo Account']")).click();

	Thread.sleep(2000);

	for (int j = 0; j < linkedList.size(); j++) {

		Driver.findElement(By.xpath("//input[@class='z-bandbox-input z-bandbox-rightedge']"))
				.sendKeys(linkedList.get(j));

		searchButton = Driver.findElement(By.xpath("//button[contains(text(),'Search')]"));
		searchButton.click();

		Thread.sleep(2000);

		Driver.findElement(By.xpath("//tr[contains(@class,'yw-coll-browser-hyperlink')]")).click();
		Driver.findElement(By.xpath("//span[text()='Organization']")).click();

		Driver.findElement(By.xpath("//span[@title='members']//..//following-sibling::div//button")).click();

		Thread.sleep(3000);

		List<WebElement> user = Driver.findElements(
				By.xpath("//tr//span[contains(@class,'z-listitem-checkbox')]//following-sibling::span"));

		for (int i = 0; i < user.size(); i++) {
			userLinked.add(user.get(i).getText());
		}

		Driver.findElement(By.xpath("//span[text()='GSK SoldTo Account']")).click();
		Thread.sleep(2000);

		Driver.findElement(By.xpath("//button[@title='Switch search mode']")).click();

	}

	// To remove duplicate elements
	Stream<String> stream = userLinked.stream();
	stream = stream.distinct();

	// convert the stream to ArrayList
	userLinked = (ArrayList<String>) stream.collect(Collectors.toList());
	userLinked.removeIf(value -> value.equalsIgnoreCase(email));

	String numberOfUsers = Integer.toString(userLinked.size());
	addVar("%NoOfUsersLinked%", numberOfUsers);//

	for (int i = 1; i <= userLinked.size(); i++) {
		String var = "%User" + i + "%";
		addVar(var, userLinked.get(i - 1));
		
		System.out.println(var);
	}

}

@Action(object = ObjectType.BROWSER, desc = "Verify the Admin User Managemnet Page based on variables %User'number'% list and %NoOfUsersLinked% create by method CA_extractUsersBasedOnShiptoLinked", input = InputType.NO)

public void CA_verifyAdminUserManagementPage() throws InterruptedException {

	int numOfUser = Integer.parseInt(getVar("%NoOfUsersLinked%"));
	List<String> expectedUserList = new ArrayList<String>();
	

	for (int i = 1; i <= numOfUser; i++) {

		String var = "%User" + i + "%";
		expectedUserList.add(getVar(var));

	}
	

	Driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	Driver.findElement(By.id("account-active")).click();

	Driver.findElement(By.xpath("//a[contains(@href,'user-management')]")).click();

	WebElement ActiveChkBox = Driver.findElement(By.xpath("//input[@id='checkbox1']"));
	WebElement PendingChkBox = Driver.findElement(By.xpath("//input[@id='checkbox3']"));

	if (ActiveChkBox.isSelected() && PendingChkBox.isSelected()) {

		Report.updateTestLog(Action,
				"The Active and Pending Checkbox are Selected By Default in User Management Page", Status.PASS);
	} else {
		Report.updateTestLog(Action,
				"The Active and Pending Checkbox are Not Selected By Default in User Management Page", Status.FAIL);
	}

	List<WebElement> pendingUsers;
	String lang = getVar("%Language%");

	try {
		String pendingMsg = Driver.findElement(By.xpath("//span[@class='userPending']")).getText().trim();

		if (pendingMsg.equals("You have a pending status for one/ more of your users")) {

			Report.updateTestLog(Action, "The Pending User Message is Correctly Dispalyed in English", Status.PASS);

		} else if (pendingMsg
				.equals("Vous avez un statut « en attente » pour un ou plusieurs de vos utilisateurs")) {

			Report.updateTestLog(Action, "The Pending User Message is Correctly Dispalyed in French", Status.PASS);

		} else {
			Report.updateTestLog(Action, "The Pending User Message is Not Correctly Dispalyed", Status.FAIL);
		}

		try {
			pendingUsers = Driver
					.findElements(By.xpath("//div[contains(@class,'Status') and contains(text(),'PENDING')]"));

		} catch (Exception f) {
			try {
				
				pendingUsers = Driver
						.findElements(By.xpath("//div[contains(@class,'Status') and contains(text(),'EN ATTENTE')]"));

			} catch (Exception f1) {
			
				pendingUsers = null;
				Report.updateTestLog(Action, "The User have no Pending Users to Approve", Status.PASS);
			
			}
		}

	} catch (Exception e) {

		pendingUsers = null;
		Report.updateTestLog(Action, "The User have no Pending Users to Approve", Status.PASS);
	}
	try {
	int linkedUsers = numOfUser + pendingUsers.size();
	String countUser = Driver.findElement(By.xpath("//span[@class='userAccess']")).getText().trim();
	if (countUser.contains(Integer.toString(linkedUsers))) {

		Report.updateTestLog(Action, "The User Count Displayed at the Top is Correct", Status.PASS);
	} else {
		Report.updateTestLog(Action,
				"The Displayed User Count is " + countUser + " but expected count is " + linkedUsers, Status.PASS);
	}
	} catch (Exception e) {//added newly

		int linkedUsers = numOfUser ;
		String countUser = Driver.findElement(By.xpath("//span[@class='userAccess']")).getText().trim();
		if (countUser.contains(Integer.toString(linkedUsers))) {

			Report.updateTestLog(Action, "The User Count Displayed at the Top is Correct", Status.PASS);
		} else {
			Report.updateTestLog(Action,
					"The Displayed User Count is " + countUser + " but expected count is " + linkedUsers, Status.PASS);
		}
	}

	ActiveChkBox.click();
	PendingChkBox.click();
	Thread.sleep(2000);

	if (!Driver.findElement(By.xpath("//div[contains(@class,'userMgmtStatusCol1')]")).isDisplayed()) {

		Report.updateTestLog(Action, "No Users are Displayed when the Both Checkbox is UnChecked", Status.PASS);
	} else {

		Report.updateTestLog(Action, "Users are Displayed when the Both Checkbox is UnChecked", Status.FAIL);
	}

	PendingChkBox.click();// Check
	Thread.sleep(2000);

	if (pendingUsers != null) {

		if (lang.equals("en_CA")) {

			if (!Driver.findElement(By.xpath("//div[contains(@class,'Status') and contains(text(),'ACTIVE')]"))
					.isDisplayed()) {

				Report.updateTestLog(Action,
						"Only Pending Users are Displayed when the Pending Checkbox is Selected", Status.PASS);
			} else {

				Report.updateTestLog(Action,
						"Only Pending Users are Not Displayed when the Pending Checkbox is Selected", Status.FAIL);
			}

		} else {

			if (!Driver.findElement(By.xpath("//div[contains(@class,'Status') and contains(text(),'ACTIF')]"))
					.isDisplayed()) {

				Report.updateTestLog(Action,
						"Only Pending Users are Displayed when the Pending Checkbox is Selected", Status.PASS);
			} else {

				Report.updateTestLog(Action,
						"Only Pending Users are Not Displayed when the Pending Checkbox is Selected", Status.FAIL);
			}
		}

	}

	PendingChkBox.click(); // UnCheck Pending
	ActiveChkBox.click(); // Check Active
	Thread.sleep(2000);
try {
	if (lang.equals("en_CA")) {

		if (!Driver.findElement(By.xpath("//div[contains(@class,'Status') and contains(text(),'PENDING')]"))
				.isDisplayed()) {

			Report.updateTestLog(Action, "Only Pending Users are Displayed when the Pending Checkbox is Checked",
					Status.PASS);
		} else {

			Report.updateTestLog(Action,
					"Only Pending Users are Not Displayed when the Pending Checkbox is Checked", Status.FAIL);
		}

	} else {

		if (!Driver.findElement(By.xpath("//div[contains(@class,'Status') and contains(text(),'EN ATTENTE')]"))
				.isDisplayed()) {

			Report.updateTestLog(Action, "Only Pending Users are Displayed when the Pending Checkbox is Checked",
					Status.PASS);
		} else {

			Report.updateTestLog(Action,
					"Only Pending Users are Not Displayed when the Pending Checkbox is Checked", Status.FAIL);
		}
	}
	
}catch (Exception e) {
	Report.updateTestLog(Action, "No Pending users are Displayed ", Status.DONE);
	
}

	PendingChkBox.click();// Check
	Thread.sleep(2000);

	verifyUserRowsColumnView(lang);

	List<WebElement> users;

	try {
		users = Driver.findElements(By.xpath(
				"//div[contains(@class,'Status') and contains(text(),'ACTIVE')]//preceding-sibling::div//a"));
		if(users.size()==0)
			
			{
//			Report.updateTestLog(Action, "6378  users.size()==0", Status.DONE);
			users.get(0).click();
			
		}
	} catch (Exception e) {
//		Report.updateTestLog(Action, "6383  catch block", Status.DONE);
		users = Driver.findElements(By
				.xpath("//div[contains(@class,'Status') and contains(text(),'ACTIF')]//preceding-sibling::div//a"));
	}
	
	try {
	List<String> actualUserList = new ArrayList<String>();

	actualUserList = users.stream().map(s -> s.getText().trim().toLowerCase()).collect(Collectors.toList());
	

	if (expectedUserList.size() == actualUserList.size()) {

		expectedUserList = expectedUserList.stream().sorted().collect(Collectors.toList());

		actualUserList = actualUserList.stream().sorted().collect(Collectors.toList());

		if (expectedUserList.equals(actualUserList)) {

			Report.updateTestLog(Action, "Users in the User Management Page is same as Expected", Status.PASS);
		} else {
			Report.updateTestLog(Action, "Users in the User Management Page is not same as Expected", Status.FAIL);
		}

	} else {

		Report.updateTestLog(Action, "Users Count in the User Management Page is not same as Expected",	Status.FAIL);
	}
	} catch (Exception e) {
		
		Report.updateTestLog(Action, "Users Count actualUserList is same",	Status.DONE);
	}
}

public void verifyUserRowsColumnView(String lang) {

	int noOfRows = Driver.findElements(By.xpath("//div[contains(@class,'userManageRow')]")).size();

	boolean UserAction;
	boolean Name;
	boolean Email;
	boolean Admin;
	boolean Phone;
	boolean UserStatus;

	int j = 0;
	List<Integer> error = new ArrayList<Integer>();

	if (lang.equals("en_CA")) {

		for (int i = 1; i <= noOfRows; i++) {

			UserAction = !(Driver
					.findElements(By.xpath(
							"(//div[contains(@class,'userManageRow')])[" + i + "]/div[contains(text(),'Action')]"))
					.isEmpty());
			Name = !(Driver
					.findElements(By.xpath(
							"(//div[contains(@class,'userManageRow')])[" + i + "]/div[contains(text(),'Name')]"))
					.isEmpty());
			Email = !(Driver
					.findElements(By.xpath(
							"(//div[contains(@class,'userManageRow')])[" + i + "]/div[contains(text(),'Email')]"))
					.isEmpty());
			Admin = !(Driver
					.findElements(By.xpath("(//div[contains(@class,'userManageRow')])[" + i
							+ "]/div[contains(text(),'Admin') and not(contains(@class,'user-name-CA'))]"))
					.isEmpty());
			Phone = !(Driver
					.findElements(By.xpath(
							"(//div[contains(@class,'userManageRow')])[" + i + "]/div[contains(text(),'Phone')]"))
					.isEmpty());
			UserStatus = !(Driver
					.findElements(By.xpath(
							"(//div[contains(@class,'userManageRow')])[" + i + "]/div[contains(text(),'Status')]"))
					.isEmpty());

			if (UserAction && Name && Email && Admin && Phone && UserStatus) {
				j++;
			} else {
				error.add(i);
			}

		}

	} else {

		for (int i = 1; i <= noOfRows; i++) {

			UserAction = !(Driver
					.findElements(By.xpath(
							"(//div[contains(@class,'userManageRow')])[" + i + "]/div[contains(text(),'Action')]"))
					.isEmpty());
			Name = !(Driver
					.findElements(By.xpath(
							"(//div[contains(@class,'userManageRow')])[" + i + "]/div[contains(text(),'Nom')]"))
					.isEmpty());
			Email = !(Driver.findElements(By.xpath("(//div[contains(@class,'userManageRow')])[" + i
					+ "]/div[contains(text(),'Adresse courriel')]")).isEmpty());
			Admin = !(Driver
					.findElements(By.xpath("(//div[contains(@class,'userManageRow')])[" + i
							+ "]/div[contains(text(),'Administrateur') and not(contains(@class,'user-name-CA'))]"))
					.isEmpty());
			Phone = !(Driver.findElements(By.xpath(
					"(//div[contains(@class,'userManageRow')])[" + i + "]/div[contains(text(),'No de téléphone')]"))
					.isEmpty());
			UserStatus = !(Driver
					.findElements(By.xpath(
							"(//div[contains(@class,'userManageRow')])[" + i + "]/div[contains(text(),'Statut')]"))
					.isEmpty());

			if (UserAction && Name && Email && Admin && Phone && UserStatus) {
				j++;
			} else {
				error.add(i);
			}

		}
	}

	if (j == noOfRows) {
		Report.updateTestLog(Action, "Users row has all the Column Expected in the User Management Page",
				Status.PASS);
	} else {
		Report.updateTestLog(Action,
				"Users rows " + error + " doesnot have all the Column Expected in the User Management Page",
				Status.FAIL);
	}

	
	
}

@Action(object = ObjectType.BROWSER, desc = "Verify the AcceptUser Shipto List Page with input as Email", input = InputType.YES)
public void verifyAcceptUserPage_CA() throws InterruptedException {

	String email = Data;

	String emailReq = "//a[text()='" + email + "']//..//..//select";
	WebElement userReq = Driver.findElement(By.xpath(emailReq));

	Select opt = new Select(userReq);
	opt.selectByValue("approveUser");
	Thread.sleep(3000);

	int numOfShipto = Driver.findElements(By.xpath("//tbody//tr")).size();
	List<Integer> error = new ArrayList<Integer>();
	int j = 0;
	String Company;
	String Address;
	String ShiptoId;

	for (int i = 1; i <= numOfShipto; i++) {
		Company = Driver.findElement(By.xpath("(//tbody//tr)[" + i + "]//td[contains(@class,'ship-add-cname')]"))
				.getText();
		Address = Driver.findElement(By.xpath("(//tbody//tr)[" + i + "]//td[contains(@class,'user-email-width')]"))
				.getText();
		ShiptoId = Driver.findElement(By.xpath("(//tbody//tr)[" + i + "]//td[contains(@class,'user-email-width')]"))
				.getText();

		if ((!Company.isBlank()) && (!Address.isBlank()) && (!ShiptoId.isBlank())) {
			j++;
		} else {
			error.add(i);
		}
	}

	if (j == numOfShipto) {
		Report.updateTestLog(Action, "Shipto row in Approve User has values in all the Column", Status.PASS);
	} else {
		Report.updateTestLog(Action, "Users rows " + error + " doesnot have values in all the Column", Status.FAIL);
	}

	Driver.findElement(By.xpath("//a[contains(@onclick,'user.allowAccess()')]")).click();

	String errorDisplayed = Driver.findElement(By.xpath("//div[@class='shipToSelectError']//label")).getText()
			.trim();
	String errorExpected = getVar("%errorNoShiptoSelect%");

	if (errorDisplayed.equals(errorExpected)) {

		Report.updateTestLog(Action,
				"The Error Mesage Displayed when No Shipto is Selected for Approve User is Correct", Status.PASS);
	} else {
		Report.updateTestLog(Action, "Expected is: " + errorExpected + " but displayed is: " + errorDisplayed,
				Status.FAIL);
	}

	Driver.findElement(
			By.xpath("//div[contains(@class,'shipToListSection')]//a[contains(@href,'user-management')]")).click();

	if (Driver.findElement(By.xpath("//div[@class='acc_user_bg_uslt']")).isDisplayed()) {

		Report.updateTestLog(Action, "User is Navigated Back to User-Management Page", Status.PASS);
	} else {
		Report.updateTestLog(Action, "User is Not Navigated Back to User-Management Page", Status.FAIL);
	}

}

@Action(object = ObjectType.BROWSER, desc = "Verify the Non-Admin User Managemnet Page based on variables %User'number'% list and %NoOfUsersLinked% create by method CA_extractUsersBasedOnShiptoLinked", input = InputType.NO)
public void CA_verifyNonAdminUserManagementPage() throws InterruptedException {

	int numOfUser = Integer.parseInt(getVar("%NoOfUsersLinked%"));
	List<String> expectedUserList = new ArrayList<String>();
	String lang = getVar("%Language%");

	for (int i = 1; i <= numOfUser; i++) {

		String var = "%User" + i + "%";
		expectedUserList.add(getVar(var));

	}

	Driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	Driver.findElement(By.id("account-active")).click();

	Driver.findElement(By.xpath("//a[contains(@href,'user-management')]")).click();

	String countUser = Driver.findElement(By.xpath("//span[@class='userAccess']")).getText().trim().split(" ")[0];

	int actualCount = Integer.parseInt(countUser);

	if (actualCount >= numOfUser) {

		Report.updateTestLog(Action, "The User Count Displayed at the Top for Non-Admin is Correct", Status.PASS);
	} else {

		Report.updateTestLog(Action,
				"The Displayed User Count for Non-Admin is " + countUser + " but expected count is " + numOfUser,
				Status.PASS);
	}

	List<WebElement> users;

	try {
		users = Driver.findElements(By.xpath(
				"//div[contains(@class,'Status') and contains(text(),'ACTIVE')]//preceding-sibling::div//a"));
		
		
		if(users.size()==0)
		{
//			Report.updateTestLog(Action, "Inside Users try ",Status.DONE);
		users.get(0).click();
		}
		
		
	} catch (Exception e) {
		
//		Report.updateTestLog(Action, "Inside Users catch",Status.DONE);
		users = Driver.findElements(By
				.xpath("//div[contains(@class,'Status') and contains(text(),'ACTIF')]//preceding-sibling::div//a"));
		
	}

	List<String> actualUserList = new ArrayList<String>();

	try {
		
actualUserList = users.stream().map(s -> s.getText().trim().toLowerCase()).collect(Collectors.toList());
	
	
//	Report.updateTestLog(Action,"6600 actualUserList.size() ::  " +actualUserList.size()+"   ::  expectedUserList.size()   ::  "+expectedUserList.size() ,
//			Status.DONE);

	if (actualUserList.size() >= expectedUserList.size()) {

		expectedUserList = expectedUserList.stream().sorted().collect(Collectors.toList());

		actualUserList = actualUserList.stream().sorted().collect(Collectors.toList());

		if (actualUserList.containsAll(expectedUserList)) {

			Report.updateTestLog(Action, "Users in the User Management Page for Non-Admin is same as Expected",
					Status.PASS);
		} else {
			Report.updateTestLog(Action, "Users in the User Management Page for Non-Admin is not same as Expected",
					Status.FAIL);
		}

	} else {

		Report.updateTestLog(Action,
				"Users Count in the User Management Page for Non-Admin is not same as Expected", Status.FAIL);
	
	
	
	}
	}catch (Exception e) {
		
		Report.updateTestLog(Action,
				"actualUserList is Null ", Status.DONE);
	
	}

	int noOfRows = Driver.findElements(By.xpath("//div[contains(@class,'userManageRow')]")).size();
try {
	boolean UserAction;
	boolean Name;
	boolean Email;
	boolean Admin;
	boolean Phone;
	boolean UserStatus;

	int j = 0;
	List<Integer> error = new ArrayList<Integer>();

	if (lang.equals("en_CA")) {

		for (int i = 1; i <= noOfRows; i++) {

			UserAction = Driver
					.findElements(By.xpath(
							"(//div[contains(@class,'userManageRow')])[" + i + "]/div[contains(text(),'Action')]"))
					.isEmpty();

			Name = !(Driver
					.findElements(By.xpath(
							"(//div[contains(@class,'userManageRow')])[" + i + "]/div[contains(text(),'Name')]"))
					.isEmpty());
			Email = !(Driver
					.findElements(By.xpath(
							"(//div[contains(@class,'userManageRow')])[" + i + "]/div[contains(text(),'Email')]"))
					.isEmpty());
			Admin = !(Driver
					.findElements(By.xpath("(//div[contains(@class,'userManageRow')])[" + i
							+ "]/div[contains(text(),'Admin') and not(contains(@class,'user-name-CA'))]"))
					.isEmpty());
			Phone = !(Driver
					.findElements(By.xpath(
							"(//div[contains(@class,'userManageRow')])[" + i + "]/div[contains(text(),'Phone')]"))
					.isEmpty());
			UserStatus = !(Driver
					.findElements(By.xpath(
							"(//div[contains(@class,'userManageRow')])[" + i + "]/div[contains(text(),'Status')]"))
					.isEmpty());

			if (UserAction && Name && Email && Admin && Phone && UserStatus) {
				j++;
			} else {
				error.add(i);
			}

		}

	} else {

		for (int i = 1; i <= noOfRows; i++) {

			UserAction = Driver
					.findElements(By.xpath(
							"(//div[contains(@class,'userManageRow')])[" + i + "]/div[contains(text(),'Action')]"))
					.isEmpty();

			Name = !(Driver
					.findElements(By.xpath(
							"(//div[contains(@class,'userManageRow')])[" + i + "]/div[contains(text(),'Nom')]"))
					.isEmpty());
			Email = !(Driver.findElements(By.xpath("(//div[contains(@class,'userManageRow')])[" + i
					+ "]/div[contains(text(),'Adresse courriel')]")).isEmpty());
			Admin = !(Driver
					.findElements(By.xpath("(//div[contains(@class,'userManageRow')])[" + i
							+ "]/div[contains(text(),'Administrateur') and not(contains(@class,'user-name-CA'))]"))
					.isEmpty());
			Phone = !(Driver.findElements(By.xpath(
					"(//div[contains(@class,'userManageRow')])[" + i + "]/div[contains(text(),'No de téléphone')]"))
					.isEmpty());
			UserStatus = !(Driver
					.findElements(By.xpath(
							"(//div[contains(@class,'userManageRow')])[" + i + "]/div[contains(text(),'Statut')]"))
					.isEmpty());

			if (UserAction && Name && Email && Admin && Phone && UserStatus) {
				j++;
			} else {
				error.add(i);
			}

		}
	}
	


	if (j == noOfRows) {
		Report.updateTestLog(Action,
				"Users row are readyonly and has all the Column Expected in the User Management Page for Non-Admin user",
				Status.PASS);
	} else {
		Report.updateTestLog(Action,
				"Users rows are not readyonly and rows " + error
						+ " doesnot have all the Column Expected in the User Management Page for Non-Admin user",
				Status.FAIL);
	}
}catch (Exception e) {///
	
	Report.updateTestLog(Action,
			"actualUserList is Null ", Status.DONE);

}
	
	
	
	

}

@Action(object = ObjectType.BROWSER, desc = "Set access to a Shipto Only for Non-Admin Users after Navigating to User Management Page based on the input Email,Shipto", input = InputType.YES)

public void setAccess_CA() throws InterruptedException {

	Driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

	String user[] = Data.split(",");

	String email = user[0];
	String shipto = user[1];

	try {

		String emailReq = "//a[text()='" + email + "']//..//..//select";
		WebElement userReq = Driver.findElement(By.xpath(emailReq));

		Select opt = new Select(userReq);
		opt.selectByValue("setAccess");

		// Deselect All Other Ship To
		Driver.findElement(By.xpath("//input[@id='shiptoSelectall']")).click();
		Thread.sleep(1000);
		Driver.findElement(By.xpath("//input[@id='shiptoSelectall']")).click();

		String shiptChkBox = "//input[@id='shipToCheckbox_" + shipto + "']";
		Driver.findElement(By.xpath(shiptChkBox)).click();

		Thread.sleep(2000);

		Driver.findElement(By.xpath("//a[contains(@onclick,'user.allowAccess()')]")).click();
		Report.updateTestLog(Action, "The Access for " + email + " was changed to Shipto " + shipto, Status.PASS);

	} catch (Exception e) {

		Report.updateTestLog(Action, "The Access for " + email + " was changed to Shipto " + shipto, Status.FAIL);
	}

}










/* ********************************** Rishbh Code end ******************************** */





///*****************  Freanch Code ******************** */

@Action(object = ObjectType.BROWSER, desc = "Enter ShipTo,Product ID,Quantity [<Data>]", input = InputType.YES)
public void FR_addProductToCart() throws InterruptedException {

	try {
		
		
		//Driver.findElement(By.xpath("//a[contains(text(),'ZÅ‚Ã³Å¼ zamÃ³wienie')]")).click();

		Driver.findElement(By.xpath("//a[@id='purchase-products-active']")).click();
		
		String[] InputData = Data.split(",");
		String ShipTo = InputData[0]; //1200082978
		String Product = InputData[1]; //705809
		String Quantity = InputData[2]; //10


		Thread.sleep(5000);

		//Wait until page load is complete	
		WebDriverWait wait = new WebDriverWait(Driver,10);
		wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
				.executeScript("return document.readyState")));

		WebElement ChangeShipToPopUp = Driver.findElement(By.id("cboxLoadedContent"));

		if(ChangeShipToPopUp.isDisplayed()) {
wait.until(ExpectedConditions.visibilityOf(ChangeShipToPopUp));

			//Driver.findElement(By.xpath("//input[@id='search-ship-to-field']")).sendKeys(ShipTo);
			Driver.findElement(By.xpath("//span[contains(text(),'"+ShipTo+"')]")).click();
			//Driver.findElement(By.xpath("//div[@class='ship-to-list']/div[not(contains(@style, 'display: none;'))]")).click();

			Driver.findElement(By.xpath("//button[@id='orderForThisAddressBtn' and contains(text(),'Commander pour cette adresse')]")).click();
			//Driver.findElement(By.xpath("//button[@id='orderForThisAddressBtn']")).click();
			Thread.sleep(2000);
			Driver.findElement(By.xpath("//input[@id='search_text_complexproducts_orderable']")).sendKeys(Product);
			Driver.findElement(By.xpath("//button[@id='searchtextBtn_complexproducts_orderable']")).click();

			
			Thread.sleep(4000);


			Driver.findElement(By.xpath("//input[contains(@class,'QuantityText prodOrderListerQty')]")).sendKeys(Quantity);
			Driver.findElement(By.xpath("//span[@class='add-cart-CA' and contains(text(),'Ajouter au panier')]")).click();

			Driver.navigate().refresh();

			//Wait until page load is complete	
			
			wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
					.executeScript("return document.readyState")));

			if (Driver.findElement(By.id("cartTotalNonZero")).isDisplayed()) {

				Report.updateTestLog(Action, Quantity + " Packs of " +Product+" Added To Cart for ShipTo "+ShipTo, Status.PASS);

			}else {
				Report.updateTestLog(Action, " No Product Added To Cart for ShipTo "+ShipTo, Status.FAIL);

			}


		}else {

			System.out.println("Change ShipTo Pop us not present");

		}

	} catch (NoSuchElementException e) {

		String[] InputData = Data.split(",");
		String ShipTo = InputData[0]; //1200082978
		String Product = InputData[1]; //705809
		String Quantity = InputData[2]; //10
		Thread.sleep(5000);
		Driver.findElement(By.xpath("//a[@id='changeShipToLink']")).click();


		//Driver.findElement(By.xpath("//input[@id='search-ship-to-field']")).sendKeys(ShipTo);
		Thread.sleep(2000);
		Driver.findElement(By.xpath("//span[contains(text(),'"+ShipTo+"')]")).click();
		//Driver.findElement(By.xpath("//div[@class='ship-to-list']/div[not(contains(@style, 'display: none;'))]")).click();

			/*
			 * Driver.findElement(By.
			 * xpath("//button[@id='orderForThisAddressBtn' and contains(text(),'Order for this address')]"
			 * )).click();
			 * 
			 * //Driver.findElement(By.xpath("//button[@id='orderForThisAddressBtn']")).
			 * click(); Thread.sleep(2000);
			 * 
			 * Driver.findElement(By.xpath(
			 * "//input[@id='search_text_complexproducts_orderable']")).sendKeys(Product);
			 * Driver.findElement(By.xpath(
			 * "//button[@id='searchtextBtn_complexproducts_orderable']")).click();
			 * Thread.sleep(4000); Driver.findElement(By.
			 * xpath("//input[contains(@class,'QuantityText prodOrderListerQty')]")).
			 * sendKeys(Quantity); Driver.findElement(By.
			 * xpath("//span[@class='add-cart-CA' and contains(text(),'Add to cart')]")).
			 * click();
			 * 
			 * 
			 * Driver.navigate().refresh();
			 */

		
		Driver.findElement(By.xpath("//button[@id='orderForThisAddressBtn' and contains(text(),'Commander pour cette adresse')]")).click();
		//Driver.findElement(By.xpath("//button[@id='orderForThisAddressBtn']")).click();
		Thread.sleep(2000);
		Driver.findElement(By.xpath("//input[@id='search_text_complexproducts_orderable']")).sendKeys(Product);
		Driver.findElement(By.xpath("//button[@id='searchtextBtn_complexproducts_orderable']")).click();

		
		Thread.sleep(4000);


		Driver.findElement(By.xpath("//input[contains(@class,'QuantityText prodOrderListerQty')]")).sendKeys(Quantity);
		Driver.findElement(By.xpath("//span[@class='add-cart-CA' and contains(text(),'Ajouter au panier')]")).click();

		Driver.navigate().refresh();
		
		
		
		
		//Wait until page load is complete	
		WebDriverWait wait = new WebDriverWait(Driver,10);
		wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
				.executeScript("return document.readyState")));

		if (Driver.findElement(By.id("cartTotalNonZero")).isDisplayed()) {

			Report.updateTestLog(Action, Quantity + " Packs of " +Product+" Added To Cart for ShipTo "+ShipTo, Status.PASS);

		}else {
			Report.updateTestLog(Action, " No Product Added To Cart for ShipTo "+ShipTo, Status.FAIL);

		}
	}		
}


/* ***************************** ***************************************** */




@Action(object = ObjectType.BROWSER, desc = "Enter ProductCount,CartCount,ProductPerCart,ShipTo-BillTo [<Data>]", input = InputType.YES)
public void FR_verifyShoppingCartPage() {
String paymenttype=null;




	try {

		String[] InputData = Data.split(",");

		String ProductCount = InputData[0];
		String CartCount = InputData[1];
		String ProductPerCart = InputData[2];

		HashMap<String,String> ShipToBillTo_Map = new HashMap<String,String>();

		for (int a=3;a<=InputData.length-1;a++) {

			String[] ShipToBillToArray = InputData[a].split("-");
			ShipToBillTo_Map.put(ShipToBillToArray[0], ShipToBillToArray[1]);

		}
		try {
		Driver.findElement(By.xpath("//a[contains(text(),'Shopping cart')]")).click();
		}
		catch(Exception e)
		{
			
			Driver.findElement(By.xpath("//a[contains(text(),'Panier d’achat')]")).click();
		}
		
		//Wait until page load is complete	
		WebDriverWait wait = new WebDriverWait(Driver,10);
		wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
				.executeScript("return document.readyState")));

		String ActualProductCount = Driver.findElement(By.xpath("//span[@id='cartTotalNonZero']/span[contains(@class,'count')]")).getText();

		// Verify total Product Count displayed at Cart Header
		if(ActualProductCount.contains(ProductCount)) {
			Report.updateTestLog(Action, "Expected Total Product in Cart "+ProductCount+" And Actual Total Product in Cart "+ActualProductCount, Status.PASS);
		}else {
			Report.updateTestLog(Action, "Expected Total Product in Cart "+ProductCount+" And Actual Total Product in Cart "+ActualProductCount, Status.FAIL);
		}

		List<WebElement> Carts = Driver.findElements(By.xpath("//div[@class='row ship-to']"));

		// Verify Total Cart displayed
		if(Carts.size()==Integer.parseInt(CartCount)) {
			Report.updateTestLog(Action, "Expected Cart Count "+CartCount+" And Actual Cart Count "+Carts.size(), Status.PASS);
		}else {
			Report.updateTestLog(Action, "Expected Cart Count "+CartCount+" And Actual Cart Count "+Carts.size(), Status.FAIL);
		}

		// Verify Total "New Shopping Cart" section count
		if (ShipToBillTo_Map.size()>1) {
			
			//List<WebElement> Nowy_koszyk = Driver.findElements(By.xpath("//div[contains(text(),'New Shopping Cart')]")); 
			
			List<WebElement> Nowy_koszyk = Driver.findElements(By.xpath("//div[contains(@class,'newCartBanner newCartbanner-CA')]"));
			if(Nowy_koszyk.size()==ShipToBillTo_Map.size()-1) {
				Report.updateTestLog(Action, "Total New Shopping Cart Section Count is "+Nowy_koszyk.size()+" Which is Expected", Status.PASS);
			}else {
				Report.updateTestLog(Action, "Total New Shopping Cart Section Count is "+Nowy_koszyk.size()+" Which is NOT Expected", Status.FAIL);
			}
		}
		// Add Produts button for Another shipto button
		
		if(Driver.findElement(By.xpath("//*[@id='changeShipToLink']")).isDisplayed())
		{
			Report.updateTestLog(Action, "Add Products for Another Ship-To is Displayed ", Status.PASS);
			
		}else {
			Report.updateTestLog(Action, "Add Products for Another Ship-To is Not Displayed ", Status.FAIL);
		}


		double ExpectedTotalPriceWithVat_AllCart = 0.00;

		for (int i=1;i<=Carts.size();i++) {
			
			
			// Verify ShipTo Row expanded by default
			WebElement ShipToToggle = Driver.findElement(By.xpath("//div[@class='row ship-to']["+i+"]//a"));

			if (ShipToToggle.getAttribute("class").equalsIgnoreCase("ship-to-toggle expanded")) {
				Report.updateTestLog(Action, "Cart "+i+ " Expanded By Default", Status.PASS);
			}else {
				Report.updateTestLog(Action, "Cart "+i+ " NOT Expanded By Default", Status.FAIL);
			}

			ShipToToggle.click();

			// Verify ShiTo Row Collapse
			if (ShipToToggle.getAttribute("class").equalsIgnoreCase("ship-to-toggle")) {

				Report.updateTestLog(Action, "Cart "+i+ " Toggle is Collapsed", Status.PASS);

				if (Driver.findElement(By.xpath("//div[@class='row ship-to']["+i+"]//div[@class='ship-to-full']")).isDisplayed()) {
					Report.updateTestLog(Action, "Cart "+i+ " is NOT Collapsed", Status.FAIL);
				}else {
					Report.updateTestLog(Action, "Cart "+i+ " is Collapsed", Status.PASS);

				}
			}else {
				Report.updateTestLog(Action, "Cart "+i+ " Toggle is NOT Collapsed", Status.FAIL);
			}



			ShipToToggle.click();

			// Verify ShiTo Row Expand
			if (ShipToToggle.getAttribute("class").equalsIgnoreCase("ship-to-toggle expanded")) {

				Report.updateTestLog(Action, "Cart "+i+ " Toggle is Expanded", Status.PASS);

				if (Driver.findElement(By.xpath("//div[@class='row ship-to']["+i+"]//div[@class='ship-to-full']")).isDisplayed()) {
					Report.updateTestLog(Action, "Cart "+i+ " is Expanded", Status.PASS);
				}else {
					Report.updateTestLog(Action, "Cart "+i+ " is NOT Expanded", Status.FAIL);
				}
			}else {
				Report.updateTestLog(Action, "Cart "+i+ " Toggle is NOT Expanded", Status.FAIL);
			}
			//Send Weekly Hours of Operation
			weekly_ponum(i)		;	
			
		
			//Payment method check
			paymenttype=userData.getData("RegressionData", "Paymenttype"+i);
			
			String creditcard;
			
			
			
			 //creditcard=Driver.findElement(By.xpath("(//span[contains(text(),'Payment Method')])["+i+"]")).getText();
			 //Driver.findElement(By.xpath("//a[@class='editCardSec']")).isDisplayed();
				if(paymenttype.equalsIgnoreCase("Creditcard") && Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//a[@class='editCardSec']")).isDisplayed() )
				
				{
					
					try {
			
						try {
				creditcard=Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//span[contains(text(),'Payment Method')]")).getText();
						}catch(Exception e)
						
						{
							creditcard=Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//span[contains(text(),'Mode de paiement')]")).getText();
							
						}
				Report.updateTestLog(Action, " Payment Method details :: "+creditcard, Status.PASS);
				
				Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//a[@class='editCardSec']")).click();
				
				Thread.sleep(10000);
				String PaymentInfoTitle = Driver.getTitle();
				if((PaymentInfoTitle.contains("GSK Direct Canada | Payment Information") )   || (PaymentInfoTitle.contains("GSK Direct Canada |Renseignements sur le paiement") )     )
				{
					Report.updateTestLog(Action, "User Navigate to Payment Information Page ", Status.PASS);
											
					
				}else {
					Report.updateTestLog(Action, "User NOT Navigate to Payment Information Page", Status.FAIL);
				}
						
				
					Driver.navigate().back();
					Thread.sleep(10000);
					wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
							.executeScript("return document.readyState")));
					String shoppingcarttitle = Driver.getTitle();
					if((shoppingcarttitle.contains("GSK Direct Canada | Shopping Cart")) || (shoppingcarttitle.contains("GSK Direct Canada | Panier d'achat"))     ) {
						Report.updateTestLog(Action, "User Navigate to  ::  "  +shoppingcarttitle, Status.PASS);
												
						
					}else {
						Report.updateTestLog(Action, "User NOT Navigate to Shopping Cart Page", Status.FAIL);
						
						Driver.findElement(By.xpath("//a[contains(text(),'Panier d’achat')]")).click();
					
					
						Thread.sleep(10000);}	
					
					
					
					}
				catch(Exception e){
					Report.updateTestLog(Action, " Payment Method details not available ", Status.FAIL);
					 
				}							
				}
				
				
				if(paymenttype.equalsIgnoreCase("InvoiceMe"))
				{
					
					
					Report.updateTestLog(Action, " Payment Method Is InvoiceMe ", Status.PASS);	
				}
			
			// Verify ShipTo and BillTo
			String ActualShipTo = Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//div[contains(@class,'cart-add-tlt-CA')]//span[contains(@class,'shpAddrAln')]")).getText();
			String ActualBillTo = Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//div[contains(@class,'po-cart')]//span[contains(@class,'shpAddrAln')]")).getText();

			for (String ExpectedShipTo : ShipToBillTo_Map.keySet()) {
				
				if(ActualShipTo.contains(ExpectedShipTo)) {
					
					String ExpectedBillTo = ShipToBillTo_Map.get(ExpectedShipTo);
					if (ActualBillTo.contains(ExpectedBillTo)) {
						userData.putData("OrderDetails", "ExpectedShipTo"+i,ExpectedShipTo );
						userData.putData("OrderDetails", "ExpectedBillTo"+i,ExpectedShipTo );
						Report.updateTestLog(Action, "Cart Created For "+ExpectedShipTo+" And Corresponding BillTo "+ExpectedBillTo, Status.PASS);
					
						
					
					}else {
						Report.updateTestLog(Action, "Cart is NOT Created For Provided ShipTo and BillTo", Status.FAIL);
					}

				}
			}


			
			List<WebElement> ProductRow = Driver.findElements(By.xpath("(//div[@class='row ship-to'])["+i+"]//div[contains(@class,'row product-item')]"));

			// Verify Total Product Per Cart displayed
			if(ProductRow.size()==Integer.parseInt(ProductPerCart)) {
				Report.updateTestLog(Action, "Expected Product Row Per Cart "+ProductPerCart+" And Actual Product Row Per Cart "+ProductRow.size(), Status.PASS);
			}else {
				Report.updateTestLog(Action, "Expected Product Row Per Cart "+ProductPerCart+" And Actual Product Row Per Cart "+ProductRow.size(), Status.FAIL);
			}

			double ExpectedTotalPriceWithVat_PerCart=0.00;

			// Verify each product row
			String ProductQuantity = null;
			for (int j=1;j<=ProductRow.size();j++) {
try {
				// Verify Product Name and PDP
				WebElement ProductNameLink = Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//div[contains(@class,'row product-item')]["+j+"]//a[@class='product-name']"));
				String ProductNameOnCartPage = ProductNameLink.getText();

				ProductNameLink.click();

				WebDriverWait wait1 = new WebDriverWait(Driver,10);
				wait1.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
						.executeScript("return document.readyState")));

//				WebElement PDP = Driver.findElement(By.xpath("//span[contains(text(),'Product Details')]"));
//				String ProductNameOnPDP = Driver.findElement(By.xpath("//h1[@id='productDetail-name']")).getText();
//				
				
				WebElement PDP = Driver.findElement(By.xpath("//span[contains(@class,'product-header-style-CA')]"));
				String ProductNameOnPDP = Driver.findElement(By.xpath("//h1[@id='productDetail-name']")).getText();
				
				if (PDP.isDisplayed() && ProductNameOnPDP.equalsIgnoreCase(ProductNameOnCartPage)) {
					Report.updateTestLog(Action, "PDP Opened For Product Name "+ProductNameOnCartPage, Status.PASS);
				}else {
					Report.updateTestLog(Action, "PDP NOT Opened For Product Name "+ProductNameOnCartPage, Status.FAIL);
				}


				Driver.navigate().back();

				WebDriverWait wait2 = new WebDriverWait(Driver,10);
				wait2.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
						.executeScript("return document.readyState")));

				// Verify "UsuÅ„ z koszyka" link under each product row
				String RemoveLink = Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//div[contains(@class,'row product-item')]["+j+"]//a[@id='removeCartLink']")).getText();

				if ((RemoveLink.equalsIgnoreCase("Remove from cart")) || (RemoveLink.equalsIgnoreCase("Supprimer du panier")) ) {
					Report.updateTestLog(Action, "Remove Link Displayed for "+ProductNameOnCartPage, Status.PASS);
				}else {
					Report.updateTestLog(Action, "Remove Link NOT Displayed for "+ProductNameOnCartPage, Status.FAIL);
				}


				// Verify Product Price With/WithOut VAT
				String PriceWithVat = Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//div[contains(@class,'row product-item')]["+j+"]//div[contains(@class,'pageConfWithVatVal')]")).getText();
				 ProductQuantity = Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//div[contains(@class,'row product-item')]["+j+"]//input[@id='quantity' and @type='number']")).getAttribute("value");
				String ActualTotalPriceWithVat_PerProduct = Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//div[contains(@class,'row product-item')]["+j+"]//div[contains(@class,'product-total')]")).getText();

				PriceWithVat = PriceWithVat.replace(",", ".");
				//PriceWithVat = PriceWithVat.replace(",", "");
				Report.updateTestLog(Action, "PriceWithVat replace "+PriceWithVat, Status.PASS);
				String [] PriceWithVatArray = PriceWithVat.split(" ");
				
				
				
				 PriceWithVatArray=PriceWithVatArray[1].split("/");
					
				double PriceWithVat_Double = Double.parseDouble(PriceWithVatArray[0]);
							
			//	Report.updateTestLog(Action, "PriceWithVat_Double  ::::::::::::;  "+PriceWithVat_Double, Status.PASS);
				int ProductQuantity_Int = Integer.parseInt(ProductQuantity);
						
					
				double ExpectedTotalPriceWithVat_PerProduct =  Math.round((PriceWithVat_Double*ProductQuantity_Int) * 100.00) / 100.00;
				
				Report.updateTestLog(Action, "ExpectedTotalPriceWithVat_PerProduct  ::::::::::::;  "+ExpectedTotalPriceWithVat_PerProduct, Status.PASS);
				
				ActualTotalPriceWithVat_PerProduct = ActualTotalPriceWithVat_PerProduct.replace(",", ".");
				
//				Report.updateTestLog(Action, "ActualTotalPriceWithVat_PerProduct  ::::::::::::;  "+ActualTotalPriceWithVat_PerProduct, Status.PASS);
				String [] ActualTotalPriceWithVat_PerProductArray = ActualTotalPriceWithVat_PerProduct.split(" ");
				String ActualTotalProductPriceWithVat_String=null;
				try {
				 ActualTotalProductPriceWithVat_String=ActualTotalPriceWithVat_PerProductArray[1].concat(ActualTotalPriceWithVat_PerProductArray[2]);
//				 Report.updateTestLog(Action, ActualTotalPriceWithVat_PerProductArray[0]+ "   ::   "+ActualTotalPriceWithVat_PerProductArray[1]+" ::  "+ ActualTotalPriceWithVat_PerProductArray[2], Status.PASS);
					
//				Report.updateTestLog(Action, "ActualTotalProductPriceWithVat_String  ::::::::::::;  "+ActualTotalProductPriceWithVat_String, Status.PASS);
				}
				catch(Exception e)
				{
					
					 ActualTotalProductPriceWithVat_String=ActualTotalPriceWithVat_PerProductArray[1];
					
//					Report.updateTestLog(Action, "ActualTotalProductPriceWithVat_String catch ::::::::::::;  "+ActualTotalProductPriceWithVat_String, Status.PASS);
				}
				double ActualTotalPriceWithVat_PerProduct_Double = Double.parseDouble(ActualTotalProductPriceWithVat_String);
				
				if (ExpectedTotalPriceWithVat_PerProduct==ActualTotalPriceWithVat_PerProduct_Double) {
					Report.updateTestLog(Action, "Expected TotalPriceWithVat "+ExpectedTotalPriceWithVat_PerProduct+" And Actual TotalPriceWithVat "+ActualTotalPriceWithVat_PerProduct_Double, Status.PASS);
					
					String perproduct=String.valueOf(ExpectedTotalPriceWithVat_PerProduct);
							userData.putData("OrderDetails", "C"+i+"product"+j, perproduct);
							
				
				}else {
					Report.updateTestLog(Action, "Expected TotalPriceWithVat "+ExpectedTotalPriceWithVat_PerProduct+" And Actual TotalPriceWithVat "+ActualTotalPriceWithVat_PerProduct_Double, Status.FAIL);
				}

				// Verify Total Price Per Cart
				//ExpectedTotalPriceWithVat_PerCart = Math.round((ExpectedTotalPriceWithVat_PerCart+ExpectedTotalPriceWithVat_PerProduct+ProductQuantity_Int) * 100.0) / 100.0;
				ExpectedTotalPriceWithVat_PerCart = Math.round((ExpectedTotalPriceWithVat_PerCart+ExpectedTotalPriceWithVat_PerProduct) * 100.00) / 100.00;
				
				//	Report.updateTestLog(Action, " ExpectedTotalPriceWithVat_PerCart   :::::::::::  "+ExpectedTotalPriceWithVat_PerCart, Status.DONE);			
			

}
catch (Exception e) {
Report.updateTestLog(Action," Verify Product Price  getting failed ", Status.FAIL);
}		
			}
			
			try {

			// Verify Total Price Per Cart
				String ActualTotalPriceWithVat_PerCart_String=null;
			String ActualTotalPriceWithVat_PerCart = Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//div[contains(@class,'grand-total_cad-CA')]")).getText();

			ActualTotalPriceWithVat_PerCart = ActualTotalPriceWithVat_PerCart.replace(",", ".");
			String [] ActualTotalPriceWithVat_PerCartArray = ActualTotalPriceWithVat_PerCart.split(" ");
			//ActualTotalPriceWithVat_PerCartArray=ActualTotalPriceWithVat_PerCartArray[1].split("/");
			try {
			
			 ActualTotalPriceWithVat_PerCart_String=ActualTotalPriceWithVat_PerCartArray[1].concat(ActualTotalPriceWithVat_PerCartArray[2]);
			userData.putData("OrderDetails", "C"+i+"Total", ActualTotalPriceWithVat_PerCart_String);
			}
			catch (Exception e) {
				 ActualTotalPriceWithVat_PerCart_String=ActualTotalPriceWithVat_PerCartArray[1];
				userData.putData("OrderDetails", "C"+i+"Total", ActualTotalPriceWithVat_PerCart_String);
			}
				/*
				 * for (int l=0;l<=ActualTotalPriceWithVat_PerCartArray.length-2;l++) {
				 * ActualTotalPriceWithVat_PerCart_String =
				 * ActualTotalPriceWithVat_PerCart_String+ActualTotalPriceWithVat_PerCartArray[l
				 * ]; }
				 */
//+Integer.parseInt(ProductQuantity)
			double ActualTotalPriceWithVat_PerCart_Double = Double.parseDouble(ActualTotalPriceWithVat_PerCart_String);
			
			//Report.updateTestLog(Action," ActualTotalPriceWithVat_PerCart_Double:::: "+ActualTotalPriceWithVat_PerCart_Double, Status.DONE);
			if (ExpectedTotalPriceWithVat_PerCart==ActualTotalPriceWithVat_PerCart_Double) {
				Report.updateTestLog(Action, "Expected TotalPriceWithVat For Cart "+i+" is "+ExpectedTotalPriceWithVat_PerCart+" And Actual TotalPriceWithVat For Cart "+i+" is "+ActualTotalPriceWithVat_PerCart_Double, Status.PASS);
			}else {
				Report.updateTestLog(Action, "Expected TotalPriceWithVat For Cart "+i+" is "+ExpectedTotalPriceWithVat_PerCart+" And Actual TotalPriceWithVat For Cart "+i+" is "+ActualTotalPriceWithVat_PerCart_Double, Status.FAIL);
			}
			
			
			

			
		
			// Verify Total Price for ALL Carts
		ExpectedTotalPriceWithVat_AllCart = Math.round((ExpectedTotalPriceWithVat_AllCart+ExpectedTotalPriceWithVat_PerCart) * 100.00) / 100.00;
		
			
			}catch (Exception e) {
				Report.updateTestLog(Action," Verify Total Price Per Cart  getting failed ", Status.FAIL);
			}
			}
		try {	
			
			// Verify Total Price for ALL Carts
		String ActualTotalPriceWithVat_AllCart = Driver.findElement(By.xpath("//div[@class='row cart-bottom']//div[contains(@class,'grandtotalvalue-CA')]")).getText(); 

		ActualTotalPriceWithVat_AllCart = ActualTotalPriceWithVat_AllCart.replace(",", ".");
		
		String [] ActualTotalPriceWithVat_AllCartArray = ActualTotalPriceWithVat_AllCart.split(" ");
		//ActualTotalPriceWithVat_AllCartArray=ActualTotalPriceWithVat_AllCartArray[1].split("/");

		String ActualTotalPriceWithVat_AllCart_String=ActualTotalPriceWithVat_AllCartArray[1]+ActualTotalPriceWithVat_AllCartArray[2];

			/*
			 * for (int m=0;m<=ActualTotalPriceWithVat_AllCartArray.length-2;m++) {
			 * ActualTotalPriceWithVat_AllCart_String =
			 * ActualTotalPriceWithVat_AllCart_String+ActualTotalPriceWithVat_AllCartArray[m
			 * ]; }
			 */

		double ActualTotalPriceWithVat_AllCart_Double = Double.parseDouble(ActualTotalPriceWithVat_AllCart_String);


		if (ExpectedTotalPriceWithVat_AllCart==ActualTotalPriceWithVat_AllCart_Double) {
			Report.updateTestLog(Action, "Expected TotalPriceWithVat_AllCart "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPriceWithVat_AllCart "+ActualTotalPriceWithVat_AllCart_Double, Status.PASS);
		}else {
			Report.updateTestLog(Action, "Expected TotalPriceWithVat_AllCart "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPriceWithVat_AllCart "+ActualTotalPriceWithVat_AllCart_Double, Status.FAIL);
		}

		
		}catch (Exception e) {
			Report.updateTestLog(Action," Verify Total Price for ALL Carts  getting failed ", Status.FAIL);
		}
		
		try {
		// Verify total Cart Price displayed at Cart Header
		String ActualTotalPriceAtCartHeader = Driver.findElement(By.xpath("//span[@id='cartTotalNonZero']/span[contains(@class,'count')]/span[2]")).getText();

		ActualTotalPriceAtCartHeader = ActualTotalPriceAtCartHeader.replace(",", ".");
		String [] ActualTotalPriceAtCartHeaderArray = ActualTotalPriceAtCartHeader.split(" ");
		//ActualTotalPriceAtCartHeaderArray=ActualTotalPriceAtCartHeaderArray[1].split("/");
		String ActualTotalPriceAtCartHeader_String=ActualTotalPriceAtCartHeaderArray[1]+ActualTotalPriceAtCartHeaderArray[2];

			/*
			 * for (int m=0;m<=ActualTotalPriceAtCartHeaderArray.length-2;m++) {
			 * ActualTotalPriceAtCartHeader_String =
			 * ActualTotalPriceAtCartHeader_String+ActualTotalPriceAtCartHeaderArray[m]; }
			 */

		double ActualTotalPriceAtCartHeader_Double = Double.parseDouble(ActualTotalPriceAtCartHeader_String);

		if (ExpectedTotalPriceWithVat_AllCart==ActualTotalPriceAtCartHeader_Double) {
			Report.updateTestLog(Action, "Expected TotalPrice_At Cart Header "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPrice_At Cart Header "+ActualTotalPriceAtCartHeader_Double, Status.PASS);
		}else {
			Report.updateTestLog(Action, "Expected TotalPrice_At Cart Header "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPrice_At Cart Header "+ActualTotalPriceAtCartHeader_Double, Status.FAIL);
		}

		}catch (Exception e) {
			Report.updateTestLog(Action," Verify total Cart Price displayed at Cart Header  getting failed ", Status.FAIL);
		}

	}catch(Exception e1) {
		Report.updateTestLog(Action,"Before Verify ShipTo Row expanded by default getting failed "+e1, Status.FAIL);			
	}


}


	




@Action(object = ObjectType.BROWSER, desc = "Enter ProductCount,CartCount,ProductPerCart,ShipTo-BillTo [<Data>]", input = InputType.YES)
public void FR_verifyConfirmOrderPage() {

	String paymenttype=null;
	String week_ponum=userData.getData("RegressionData", "WeeklyPOnum");
	try{

		String[] InputData = Data.split(",");

		String ProductCount = InputData[0];
		String CartCount = InputData[1];
		String ProductPerCart = InputData[2];

		HashMap<String,String> ShipToBillTo_Map = new HashMap<String,String>();

		for (int a=3;a<=InputData.length-1;a++) {

			String[] ShipToBillToArray = InputData[a].split("-");
			ShipToBillTo_Map.put(ShipToBillToArray[0], ShipToBillToArray[1]);

		}

		Driver.findElement(By.xpath("//button[@id='checkoutButton']")).click();
		
		WebDriverWait wait1 = new WebDriverWait(Driver,100);
		wait1.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
				.executeScript("return document.readyState")));
		Thread.sleep(10000);
		// Verify Header Text
		String ConfirmHeader=null;
		try {
					 ConfirmHeader = Driver.findElement(By.xpath("//*[contains(@class,'review-order chckoutsum-header-CA')]")).getText();
		}
		catch(Exception e)
		{
			 ConfirmHeader = Driver.findElement(By.xpath("//*[contains(text(),'Vérifier votre commande')]")).getText();
		}
					
					if ( (ConfirmHeader.equalsIgnoreCase("Vérifier votre commande")) ) {
						Report.updateTestLog(Action, "Vérifier votre commande Text Displayed at Header", Status.PASS);
					}else  {
						Report.updateTestLog(Action, "Vérifier votre commande Text NOT Displayed at Header", Status.FAIL);
					}

					// Verify Sale Doc Link displayed
					WebElement SaleDocLink = Driver.findElement(By.xpath("//*[contains(@class,'termofsales')]"));

					if (SaleDocLink.isDisplayed()){
						Report.updateTestLog(Action, "Modalités de vente Link Displayed", Status.PASS);
					}else {
						Report.updateTestLog(Action, "Modalités de vente Link NOT Displayed", Status.FAIL);
					}

		// Verify Sale Doc Link Opened

		SaleDocLink.click();
		Thread.sleep(6000);
		
		pdf_validation_CA("ROW-TERMS-CONDITIONS-FR-CA");
		


		// Verify Navigate Back and Forward pages
		Driver.findElement(By.xpath("//button[contains(@class,'back-to-cart')]")).click();

		
		
		wait1.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
				.executeScript("return document.readyState")));
		String CartPageTitle = Driver.getTitle();
		if(CartPageTitle.contains("GSK Direct Canada | Panier d'achat")) {
			Report.updateTestLog(Action, "User Navigate to Shopping Cart Page", Status.PASS);
		}else {
			Report.updateTestLog(Action, "User NOT Navigate to Shopping Cart Page", Status.FAIL);
		}

		Driver.findElement(By.xpath("//button[@id='checkoutButton']")).click();
		wait1.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
				.executeScript("return document.readyState")));
		Thread.sleep(10000);

		String ConfirmOrderPageTitle = Driver.getTitle();
		
		if(ConfirmOrderPageTitle.contains("GSK Direct Canada | Votre panier")) {
			Report.updateTestLog(Action, "User Navigate to ConfirmOrderPageTitle Page", Status.PASS);
		}else {
			Report.updateTestLog(Action, "User NOT Navigate to ConfirmOrderPageTitle Page" +ConfirmOrderPageTitle, Status.FAIL);
		}


		///////////////////////

		String ActualProductCount = Driver.findElement(By.xpath("//span[@id='cartTotalNonZero']/span[contains(@class,'count')]")).getText();

		// Verify total Product Count displayed at Cart Header
		if(ActualProductCount.contains(ProductCount)) {
			Report.updateTestLog(Action, "Expected Total Product in Cart "+ProductCount+" And Actual Total Product in Cart "+ActualProductCount, Status.PASS);
		}else {
			Report.updateTestLog(Action, "Expected Total Product in Cart "+ProductCount+" And Actual Total Product in Cart "+ActualProductCount, Status.FAIL);
		}

		List<WebElement> Carts = Driver.findElements(By.xpath("//div[@class='row ship-to']"));

		// Verify Total Cart displayed
		if(Carts.size()==Integer.parseInt(CartCount)) {
			Report.updateTestLog(Action, "Expected Cart Count "+CartCount+" And Actual Cart Count "+Carts.size(), Status.PASS);
		}else {
			Report.updateTestLog(Action, "Expected Cart Count "+CartCount+" And Actual Cart Count "+Carts.size(), Status.FAIL);
		}

		// Verify Total "Nowy koszyk" section count
		if (ShipToBillTo_Map.size()>1) {
			List<WebElement> Nowy_koszyk = Driver.findElements(By.xpath("//div[contains(text(),'Nouveau panier')]"));

			if(Nowy_koszyk.size()==ShipToBillTo_Map.size()-1) {
				Report.updateTestLog(Action, "Total New Shopping Cart Section Count is "+Nowy_koszyk.size()+" Which is Expected", Status.PASS);
			}else {
				Report.updateTestLog(Action, "Total New Shopping Cart Section Count is "+Nowy_koszyk.size()+" Which is NOT Expected", Status.FAIL);
			}
		}



		double ExpectedTotalPriceWithVat_AllCart = 0.00;

		for (int i=1;i<=Carts.size();i++) {
			// Verify ShipTo Row expanded by default
			WebElement ShipToToggle = Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//a"));

			if (ShipToToggle.getAttribute("class").equalsIgnoreCase("ship-to-toggle expanded")) {
				Report.updateTestLog(Action, "Cart "+i+ " Expanded By Default", Status.PASS);
			}else {
				Report.updateTestLog(Action, "Cart "+i+ " NOT Expanded By Default", Status.FAIL);
			}

			ShipToToggle.click();

			// Verify ShiTo Row Collapse
			if (ShipToToggle.getAttribute("class").equalsIgnoreCase("ship-to-toggle")) {

				Report.updateTestLog(Action, "Cart "+i+ " Toggle is Collapsed", Status.PASS);

				if (Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//div[@class='ship-to-full']")).isDisplayed()) {
					Report.updateTestLog(Action, "Cart "+i+ " is NOT Collapsed", Status.FAIL);
				}else {
					Report.updateTestLog(Action, "Cart "+i+ " is Collapsed", Status.PASS);

				}
			}else {
				Report.updateTestLog(Action, "Cart "+i+ " Toggle is NOT Collapsed", Status.FAIL);
			}



			ShipToToggle.click();

			// Verify ShipTo Row Expand
			if (ShipToToggle.getAttribute("class").equalsIgnoreCase("ship-to-toggle expanded")) {

				Report.updateTestLog(Action, "Cart "+i+ " Toggle is Expanded", Status.PASS);

				if (Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//div[@class='ship-to-full']")).isDisplayed()) {
					Report.updateTestLog(Action, "Cart "+i+ " is Expanded", Status.PASS);
				}else {
					Report.updateTestLog(Action, "Cart "+i+ " is NOT Expanded", Status.FAIL);
				}
			}else {
				Report.updateTestLog(Action, "Cart "+i+ " Toggle is NOT Expanded", Status.FAIL);
			}
			
			wait1.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
					.executeScript("return document.readyState")));
			//Payment method check
			String creditcard;
			
			paymenttype=userData.getData("RegressionData", "Paymenttype"+i);
			
			 //creditcard=Driver.findElement(By.xpath("(//span[contains(text(),'Payment Method')])["+i+"]")).getText();
			 //Driver.findElement(By.xpath("//a[@class='editCardSec']")).isDisplayed();
				if((paymenttype.equalsIgnoreCase("Creditcard"))&& (Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//span[contains(text(),' Mode de paiement')]")).isDisplayed()) )
				
				{
					
					try {
			
				creditcard=Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//span[contains(text(),' Mode de paiement')]")).getText();
			
				Report.updateTestLog(Action, " Payment Method details :: "+creditcard, Status.PASS);
				
					
					}
				catch(Exception e){
					Report.updateTestLog(Action, " Payment Method details not available ", Status.FAIL);
					 
				}							
				}
				
				if(paymenttype.equalsIgnoreCase("InvoiceMe"))
				{
					
					
					Report.updateTestLog(Action, " Payment Method Is InvoiceMe ", Status.PASS);	
				}
			
			
			
			//	Weeekly POnum validation
				weekly_ponum_validation(i);	
			


			// Verify ShipTo and BillTo
			String ActualShipTo = Driver.findElement(By.xpath("((//div[@class='row ship-to'])["+i+"]//div[contains(@class,'cart-add-tlt-CA')]//span[contains(@class,'shpAddrAln')])[1]")).getText();
			String ActualBillTo = Driver.findElement(By.xpath("((//div[@class='row ship-to'])["+i+"]//span[contains(@class,'shpAddrAln')])[2]")).getText();

			for (String ExpectedShipTo : ShipToBillTo_Map.keySet()) {
				if(ActualShipTo.contains(ExpectedShipTo)) {
					String ExpectedBillTo = ShipToBillTo_Map.get(ExpectedShipTo);
					if (ActualBillTo.contains(ExpectedBillTo)) {
						Report.updateTestLog(Action, "Cart Created For "+ExpectedShipTo+" And Corresponding BillTo "+ExpectedBillTo, Status.PASS);
					}else {
						Report.updateTestLog(Action, "Cart is NOT Created For Provided ShipTo and BillTo", Status.FAIL);
					}

				}
			}

			Report.updateTestLog(Action, "List<WebElement> ProductRow  before:: "+i, Status.PASS);
			
			//List<WebElement> ProductRow = Driver.findElements(By.xpath("(//div[@class='row ship-to']//div[contains(@class,'row product-item')])["+i+"]"));
			
			List<WebElement> ProductRow = Driver.findElements(By.xpath("((//div[@class='row ship-to'])["+i+"]//div[contains(@class,'row gsk-box-productSection')])[1]/following-sibling::div//div[contains(@class,'row product-item')]"));
//System.out.println(":::::::::::::::"+ProductRow.size());
			// Verify Total Product Per Cart displayed
			if(ProductRow.size()==Integer.parseInt(ProductPerCart)) {
				Report.updateTestLog(Action, "Expected Product Row Per Cart "+ProductPerCart+" And Actual Product Row Per Cart "+ProductRow.size(), Status.PASS);
			}else {
				Report.updateTestLog(Action, "Expected Product Row Per Cart "+ProductPerCart+" And Actual Product Row Per Cart "+ProductRow.size(), Status.FAIL);
			}
			double ExpectedTotalPriceWithVat_PerCart=0.00;

			// Verify each product row
			
			String ProductQuantity = null;
				
			
			for (int j=1;j<=ProductRow.size();j++) {
				
				
				

try {



//WebElement ProductNameLink = Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//div[contains(@class,'row product-item')]["+j+"]//a[@class='product-name']"));

WebElement ProductNameLink = Driver.findElement(By.xpath("((//div[@class='row ship-to'])["+i+"]//div[contains(@class,'row gsk-box-productSection')])[1]/following-sibling::div//div[contains(@class,'row product-item')]["+j+"]//a[@class='product-name']"));
	
String ProductNameOnCartPage = ProductNameLink.getText();
Report.updateTestLog(Action, "PDP Opened For Product Name "+ProductNameOnCartPage, Status.PASS);
ProductNameLink.click();

WebDriverWait wait = new WebDriverWait(Driver,10);
wait1.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
		.executeScript("return document.readyState")));

WebElement PDP = Driver.findElement(By.xpath("//span[contains(text(),'Renseignements sur le produit')]"));
String ProductNameOnPDP = Driver.findElement(By.xpath("//h1[@id='productDetail-name']")).getText();

if (PDP.isDisplayed() && ProductNameOnPDP.equalsIgnoreCase(ProductNameOnCartPage)) {
	Report.updateTestLog(Action, "PDP Opened For Product Name "+ProductNameOnCartPage, Status.PASS);
}else {
	Report.updateTestLog(Action, "PDP NOT Opened For Product Name "+ProductNameOnCartPage, Status.FAIL);
}


Driver.navigate().back();

WebDriverWait wait2 = new WebDriverWait(Driver,100);
wait2.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
		.executeScript("return document.readyState")));

}
catch (Exception e) {
Report.updateTestLog(Action," Verify Product Price getting failed "+i, Status.FAIL);
}	
try {
	String [] PriceWithVatArray=null;
	int ProductQuantity_Int=0;
	double PriceWithVat_Double =0;
	String [] ActualTotalPriceWithVat_PerProductArray=null;
// Verify Product Price With/WithOut VAT
//String PriceWithVat = Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//div[contains(@class,'row product-item')]["+j+"]//div[contains(@class,'withoutvatcheckout-CA')]")).getText();
// ProductQuantity = Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//div[contains(@class,'row product-item')]["+j+"]//div[contains(@class,'summary-qty-val-CA')]")).getText();
//String ActualTotalPriceWithVat_PerProduct = Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//div[contains(@class,'row product-item')]["+j+"]//div[contains(@class,'product-total')]")).getText();
////Report.updateTestLog(Action, "PriceWithVat:::: "+PriceWithVat +"ProductQuantity::: "+ProductQuantity +"ActualTotalPriceWithVat_PerProduct"+ActualTotalPriceWithVat_PerProduct, Status.DONE);

String PriceWithVat = Driver.findElement(By.xpath("((//div[@class='row ship-to'])["+i+"]//div[contains(@class,'row gsk-box-productSection')])[1]/following-sibling::div//div[contains(@class,'row product-item')]["+j+"]//div[contains(@class,'withoutvatcheckout-CA')]")).getText();
 ProductQuantity = Driver.findElement(By.xpath("((//div[@class='row ship-to'])["+i+"]//div[contains(@class,'row gsk-box-productSection')])[1]/following-sibling::div//div[contains(@class,'row product-item')]["+j+"]//div[contains(@class,'summary-qty-val-CA')]")).getText();
String ActualTotalPriceWithVat_PerProduct = Driver.findElement(By.xpath("((//div[@class='row ship-to'])["+i+"]//div[contains(@class,'row gsk-box-productSection')])[1]/following-sibling::div//div[contains(@class,'row product-item')]["+j+"]//div[contains(@class,'product-total')]")).getText();





try {
PriceWithVat = PriceWithVat.replace(",", ".");
//PriceWithVat = PriceWithVat.replace(",", "");
 PriceWithVatArray = PriceWithVat.split(" ");
// PriceWithVatArray=PriceWithVatArray[1].split("/");
 
// Report.updateTestLog(Action, "PriceWithVatArray:::: "+PriceWithVatArray[0]+"PriceWithVatArray[1]::: "+PriceWithVatArray[1], Status.DONE);
	
	 PriceWithVat_Double = Double.parseDouble(PriceWithVatArray[1]);
				
		
	 ProductQuantity_Int = Integer.parseInt(ProductQuantity);
}catch (Exception e) {
	PriceWithVatArray = PriceWithVat.split(" ");
	
	Report.updateTestLog(Action," inside PriceWithVatArray ", Status.DONE);
//Report.updateTestLog(Action, "PriceWithVatArray:::: "+PriceWithVatArray[0]+"PriceWithVatArray[1]::: "+PriceWithVatArray[1], Status.DONE);
	
	 PriceWithVat_Double = Double.parseDouble(PriceWithVatArray[1]);
				
		
	 ProductQuantity_Int = Integer.parseInt(ProductQuantity);
}

		
	
double ExpectedTotalPriceWithVat_PerProduct =  Math.round((PriceWithVat_Double*ProductQuantity_Int) * 100.00) / 100.00;

try {

ActualTotalPriceWithVat_PerProduct = ActualTotalPriceWithVat_PerProduct.replace(",", ".");
ActualTotalPriceWithVat_PerProductArray = ActualTotalPriceWithVat_PerProduct.split(" ");
}catch (Exception e) {
	
	ActualTotalPriceWithVat_PerProductArray = ActualTotalPriceWithVat_PerProduct.split(" ");
}


String ActualTotalProductPriceWithVat_String=null;
try {
 ActualTotalProductPriceWithVat_String=ActualTotalPriceWithVat_PerProductArray[1].concat(ActualTotalPriceWithVat_PerProductArray[2]);

}
catch(Exception e)
{
	
	 ActualTotalProductPriceWithVat_String=ActualTotalPriceWithVat_PerProductArray[1];
	
	//Report.updateTestLog(Action, "ActualTotalProductPriceWithVat_String catch ::::::::::::;  "+ActualTotalProductPriceWithVat_String, Status.PASS);
}
double ActualTotalPriceWithVat_PerProduct_Double = Double.parseDouble(ActualTotalProductPriceWithVat_String);

if (ExpectedTotalPriceWithVat_PerProduct==ActualTotalPriceWithVat_PerProduct_Double) {
	Report.updateTestLog(Action, "Expected TotalPriceWithVat "+ExpectedTotalPriceWithVat_PerProduct+" And Actual TotalPriceWithVat "+ActualTotalPriceWithVat_PerProduct_Double, Status.PASS);
}else {
	Report.updateTestLog(Action, "Expected TotalPriceWithVat "+ExpectedTotalPriceWithVat_PerProduct+" And Actual TotalPriceWithVat "+ActualTotalPriceWithVat_PerProduct_Double, Status.FAIL);
}

// Verify Total Price Per Cart
//ExpectedTotalPriceWithVat_PerCart = Math.round((ExpectedTotalPriceWithVat_PerCart+ExpectedTotalPriceWithVat_PerProduct+ProductQuantity_Int) * 100.0) / 100.0;
ExpectedTotalPriceWithVat_PerCart = Math.round((ExpectedTotalPriceWithVat_PerCart+ExpectedTotalPriceWithVat_PerProduct) * 100.00) / 100.00;
	//Report.updateTestLog(Action, " ExpectedTotalPriceWithVat_PerCart   :::::::::::  "+ExpectedTotalPriceWithVat_PerCart, Status.DONE);			
}
catch (Exception e) {
	Report.updateTestLog(Action," Verify Product Price With/WithOut VAT failed ", Status.FAIL);
}

			
			}
			
			try {

			// Verify Total Price Per Cart
			//String ActualTotalPriceWithVat_PerCart = Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//div[contains(@class,'checkOutSumCa-CA')]")).getText();
			String ActualTotalPriceWithVat_PerCart = Driver.findElement(By.xpath("((//div[@class='row ship-to'])["+i+"]//div[contains(@class,'row gsk-box-productSection')])[1]/following-sibling::div//div[contains(@class,'checkOutSumCa-CA')]")).getText();

			ActualTotalPriceWithVat_PerCart = ActualTotalPriceWithVat_PerCart.replace(",", ".");
			String [] ActualTotalPriceWithVat_PerCartArray = ActualTotalPriceWithVat_PerCart.split(" ");
			//ActualTotalPriceWithVat_PerCartArray=ActualTotalPriceWithVat_PerCartArray[1].split("/");
			String ActualTotalPriceWithVat_PerCart_String=null;
			try {
			 ActualTotalPriceWithVat_PerCart_String=ActualTotalPriceWithVat_PerCartArray[1].concat(ActualTotalPriceWithVat_PerCartArray[2]);
			System.out.println("1257 line "+i);
			}
			catch(Exception e)
			{
				
				ActualTotalPriceWithVat_PerCart_String=ActualTotalPriceWithVat_PerCartArray[1];
				
//				Report.updateTestLog(Action, "ActualTotalProductPriceWithVat_String catch ::::::::::::;  "+ActualTotalPriceWithVat_PerCart_String, Status.PASS);
			}
			double ActualTotalPriceWithVat_PerCart_Double = Double.parseDouble(ActualTotalPriceWithVat_PerCart_String);
		//	Report.updateTestLog(Action," ActualTotalPriceWithVat_PerCart_Double:::: "+ActualTotalPriceWithVat_PerCart_Double, Status.DONE);
			if (ExpectedTotalPriceWithVat_PerCart==ActualTotalPriceWithVat_PerCart_Double) {
				Report.updateTestLog(Action, "Expected TotalPriceWithVat For Cart "+i+" is "+ExpectedTotalPriceWithVat_PerCart+" And Actual TotalPriceWithVat For Cart "+i+" is "+ActualTotalPriceWithVat_PerCart_Double, Status.PASS);
			}else {
				Report.updateTestLog(Action, "Expected TotalPriceWithVat For Cart "+i+" is "+ExpectedTotalPriceWithVat_PerCart+" And Actual TotalPriceWithVat For Cart "+i+" is "+ActualTotalPriceWithVat_PerCart_Double, Status.FAIL);
			}
			
			
			

			
			System.out.println("1277 line "+i  +"  ::"+ ExpectedTotalPriceWithVat_AllCart);
			// Verify Total Price for ALL Carts
		ExpectedTotalPriceWithVat_AllCart = Math.round((ExpectedTotalPriceWithVat_AllCart+ExpectedTotalPriceWithVat_PerCart) * 100.00) / 100.00;
		
		System.out.println("1277 line "+i  +"  ::"+ ExpectedTotalPriceWithVat_AllCart);
			}catch (Exception e) {
				Report.updateTestLog(Action," Verify Total Price Per Cart  getting failed "+e, Status.FAIL);
			}
			
			
//				
			
			
			}
		try {	
			
			// Verify Total Price for ALL Carts
		String ActualTotalPriceWithVat_AllCart = Driver.findElement(By.xpath("//div[@class='row cart-bottom']//div[contains(@class,' total-ipad-val-CA')]")).getText(); 

		ActualTotalPriceWithVat_AllCart = ActualTotalPriceWithVat_AllCart.replace(",", ".");
		
		String [] ActualTotalPriceWithVat_AllCartArray = ActualTotalPriceWithVat_AllCart.split(" ");
		//ActualTotalPriceWithVat_AllCartArray=ActualTotalPriceWithVat_AllCartArray[1].split("/");

		String ActualTotalPriceWithVat_AllCart_String=null;
		
		try {
		ActualTotalPriceWithVat_AllCart_String=ActualTotalPriceWithVat_AllCartArray[1].concat(ActualTotalPriceWithVat_AllCartArray[2]);
		}
		catch(Exception e)
		{
			ActualTotalPriceWithVat_AllCart_String=ActualTotalPriceWithVat_AllCartArray[1];
			
		}

		double ActualTotalPriceWithVat_AllCart_Double = Double.parseDouble(ActualTotalPriceWithVat_AllCart_String);


		if (ExpectedTotalPriceWithVat_AllCart==ActualTotalPriceWithVat_AllCart_Double) {
			Report.updateTestLog(Action, "Expected TotalPriceWithVat_AllCart "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPriceWithVat_AllCart "+ActualTotalPriceWithVat_AllCart_Double, Status.PASS);
		}else {
			Report.updateTestLog(Action, "Expected TotalPriceWithVat_AllCart "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPriceWithVat_AllCart "+ActualTotalPriceWithVat_AllCart_Double, Status.FAIL);
		}

		
		}catch (Exception e) {
			Report.updateTestLog(Action," Verify Total Price for ALL Carts  getting failed "+e, Status.FAIL);
		}
		
		try {
		// Verify total Cart Price displayed at Cart Header
		String ActualTotalPriceAtCartHeader = Driver.findElement(By.xpath("//span[@id='cartTotalNonZero']/span[contains(@class,'count')]/span[2]")).getText();

		ActualTotalPriceAtCartHeader = ActualTotalPriceAtCartHeader.replace(",", ".");
		String [] ActualTotalPriceAtCartHeaderArray = ActualTotalPriceAtCartHeader.split(" ");
		//ActualTotalPriceAtCartHeaderArray=ActualTotalPriceAtCartHeaderArray[1].split("/");
		String ActualTotalPriceAtCartHeader_String=null;
		try {
		ActualTotalPriceAtCartHeader_String=ActualTotalPriceAtCartHeaderArray[1].concat(ActualTotalPriceAtCartHeaderArray[2]);

//		Report.updateTestLog(Action, "ActualTotalProductPriceWithVat_String  ::::::::::::;  "+ActualTotalPriceAtCartHeaderArray, Status.PASS);
		}
		catch(Exception e)
		{
			ActualTotalPriceAtCartHeader_String=ActualTotalPriceAtCartHeaderArray[1];

//			Report.updateTestLog(Action, "ActualTotalProductPriceWithVat_String  ::::::::::::;  "+ActualTotalPriceAtCartHeaderArray, Status.PASS);
		}

		double ActualTotalPriceAtCartHeader_Double = Double.parseDouble(ActualTotalPriceAtCartHeader_String);

		if (ExpectedTotalPriceWithVat_AllCart==ActualTotalPriceAtCartHeader_Double) {
			Report.updateTestLog(Action, "Expected TotalPrice_At Cart Header "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPrice_At Cart Header "+ActualTotalPriceAtCartHeader_Double, Status.PASS);
		}else {
			Report.updateTestLog(Action, "Expected TotalPrice_At Cart Header "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPrice_At Cart Header "+ActualTotalPriceAtCartHeader_Double, Status.FAIL);
		}

		
		
		
		}catch (Exception e) {
			Report.updateTestLog(Action," Verify total Cart Price displayed at Cart Header  getting failed ", Status.FAIL);
		}
		
		
		
		
		
		

	}catch(Exception e1) {
		Report.updateTestLog(Action,"Before Verify ShipTo Row expanded by default getting failed "+e1, Status.FAIL);			
	}


}


//Order Page validation


@Action(object = ObjectType.BROWSER, desc = "Enter OrderCount,CartCount,ProductPerCart,ShipTo-BillTo [<Data>]", input = InputType.YES)
public void FR_verifyOrderPage() {



	try{

		String[] InputData = Data.split(",");

		String OrderCount = InputData[0];
		String CartCount = InputData[1];
		String ProductPerCart = InputData[2];

		HashMap<String,String> ShipToBillTo_Map = new HashMap<String,String>();

		for (int a=3;a<=InputData.length-1;a++) {

			String[] ShipToBillToArray = InputData[a].split("-");
			ShipToBillTo_Map.put(ShipToBillToArray[0], ShipToBillToArray[1]);

		}
		Driver.findElement(By.xpath("//button[contains(text(),'Passer la commande')]")).click();
		

		WebDriverWait wait = new WebDriverWait(Driver,10);
		wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
				.executeScript("return document.readyState")));
Thread.sleep(10000);
		// Verify Header Text, Order Confirmation No and Order Confirmation Date
		String ConfirmOrderHeader = Driver.findElement(By.xpath("//p[contains(text(),' Confirmation de la commande')]")).getText();
		WebElement OrderConfirmationNumber = Driver.findElement(By.xpath("//*[contains(@class,'orderConfirm-print-CA')]"));
		WebElement OrderConfirmationDate = Driver.findElement(By.xpath("//p[@id='order-confirmation-date']"));
		WebElement OrderConfirmationSentto=Driver.findElement(By.xpath("//strong[contains(text(),'Confirmation envoyée à :')]/parent::p"));

		String[] OrderConfirmationNumberArray = OrderConfirmationNumber.getText().split("\\s+");
		String[] OrderConfirmationDateArray = OrderConfirmationDate.getText().split(":");
		String[] OrderConfirmationSenttoArray=OrderConfirmationSentto.getText().split(":");

try {
	
	//Report.updateTestLog(Action, "Order Confirmation No 5 ::- "+OrderConfirmationNumberArray[5]+"Order Confirmation No 4 ::- "+OrderConfirmationNumberArray[4]+ "Order Confirmation No 3 ::- "+OrderConfirmationNumberArray[3]+"Order Confirmation No 2 ::- "+OrderConfirmationNumberArray[2], Status.DONE);

		if (ConfirmOrderHeader.equalsIgnoreCase("Confirmation de la commande") && OrderConfirmationNumber.isDisplayed() && OrderConfirmationDate.isDisplayed() &&OrderConfirmationSentto.isDisplayed())
		{
			Report.updateTestLog(Action, "Order Placed Successfully. Order Confirmation No ::- "+OrderConfirmationNumberArray[5]+" | Order Confirmation Date - "+OrderConfirmationDateArray[1]+" | Order Confirmation Sent to - "+OrderConfirmationSenttoArray[1], Status.PASS);
		
		
		}else {
			Report.updateTestLog(Action, "Order Place is NOT Successful", Status.FAIL);
		}
		
}catch (Exception e) {
	Report.updateTestLog(Action, "Order Confirmation No 1 ::- "+OrderConfirmationNumberArray[1]+"Order Confirmation No 4 ::- "+OrderConfirmationNumberArray[4]+ "Order Confirmation No 3 ::- "+OrderConfirmationNumberArray[3]+"Order Confirmation No 2 ::- "+OrderConfirmationNumberArray[2], Status.DONE);

}


		// Verify Drukuj button Print button
try {
		List<WebElement> DrukujButtons = Driver.findElements(By.xpath("//button[contains(text(),'Imprimer')]"));

		if (DrukujButtons.size()==2) {
			//PDF_validation_check();
			//print_buttoncheck(2);
			Report.updateTestLog(Action, "Total Print button count: Expected is 2 And Actual is "+DrukujButtons.size(), Status.PASS);
			
		}else {
			Report.updateTestLog(Action, "Total Print button count: Expected is 2 And Actual is "+DrukujButtons.size(), Status.FAIL);
		}
}catch (Exception e) {
Report.updateTestLog(Action, "DrukujButtons Failing  ", Status.FAIL);
}


		/////////////////////

		List<WebElement> Carts = Driver.findElements(By.xpath("//div[@class='row ship-to newpage_eachOrder']"));

		// Verify Total Cart displayed
		if(Carts.size()==Integer.parseInt(CartCount)) {
			Report.updateTestLog(Action, "Expected Cart Count "+CartCount+" And Actual Cart Count "+Carts.size(), Status.PASS);
		}else {
			Report.updateTestLog(Action, "Expected Cart Count "+CartCount+" And Actual Cart Count "+Carts.size(), Status.FAIL);
		}
		
		
		
		// Verify Total "Nowy koszyk" section count New Shopping Cart
		if (ShipToBillTo_Map.size()>1) {
			List<WebElement> Nowy_koszyk = Driver.findElements(By.xpath("//div[contains(text(),'Nouveau panier')]"));
			Report.updateTestLog(Action, OrderCount+"ShipToBillTo_Map.size()"+ShipToBillTo_Map.size()  + " :: "+Nowy_koszyk.size(), Status.DONE);
			if(Nowy_koszyk.size()==Integer.parseInt(OrderCount)-1) {
				Report.updateTestLog(Action, "Total New Shopping Cart Section Count is "+Nowy_koszyk.size()+" Which is Expected", Status.PASS);
			}else {
				Report.updateTestLog(Action, "Total New Shopping Cart Section Count is "+Nowy_koszyk.size()+" Which is NOT Expected", Status.FAIL);
			}
		}



		double ExpectedTotalPriceWithVat_AllCart = 0.00;

		ArrayList<String> OrderNumberList = new ArrayList<String>();

		for (int i=1;i<=Carts.size();i++) {

			// Get Order Number
			WebElement OrderNumber = Driver.findElement(By.xpath("//div[@class='row ship-to newpage_eachOrder']["+i+"]//h2[contains(@class,'ship-to-title')]"));
			String OrderNumberString = OrderNumber.getText();
			String[] OrderNumberArray = OrderNumberString.split("\\s+");
			OrderNumberList.add(OrderNumberArray[1]);

			if(OrderNumber.isDisplayed()) {
				Report.updateTestLog(Action, "Order Number for Cart "+i+" is -->"+OrderNumberArray[1], Status.PASS);
				
				userData.putData("RegressionData", "Order"+i, OrderNumberArray[1]);
			}else {
				Report.updateTestLog(Action, "Order Number for Cart  "+i+" NOT Present", Status.FAIL);
			}



			// Verify ShipTo and BillTo
			String ActualShipTo = Driver.findElement(By.xpath("//div[@class='row ship-to newpage_eachOrder']["+i+"]//div[contains(@class,'cart-add-tlt-CA')]//span[contains(@class,'shpAddrAln')]")).getText();
			String ActualBillTo = Driver.findElement(By.xpath("(//div[@class='row ship-to newpage_eachOrder']["+i+"]//span[contains(@class,'shpAddrAln')])[2]")).getText();

			for (String ExpectedShipTo : ShipToBillTo_Map.keySet()) {
				if(ActualShipTo.contains(ExpectedShipTo)) {
					String ExpectedBillTo = ShipToBillTo_Map.get(ExpectedShipTo);
					if (ActualBillTo.contains(ExpectedBillTo)) {
						Report.updateTestLog(Action, "Cart Created For "+ExpectedShipTo+" And Corresponding BillTo "+ExpectedBillTo, Status.PASS);
					}else {
						Report.updateTestLog(Action, "Cart is NOT Created For Provided ShipTo and BillTo", Status.FAIL);
					}

				}
			}


			List<WebElement> ProductRow = Driver.findElements(By.xpath("//div[@class='row ship-to newpage_eachOrder']["+i+"]//div[contains(@class,'row product-ListItem')]"));

			// Verify Total Product Per Cart displayed
			if(ProductRow.size()==Integer.parseInt(ProductPerCart)) {
				Report.updateTestLog(Action, "Expected Product Row Per Cart "+ProductPerCart+" And Actual Product Row Per Cart "+ProductRow.size(), Status.PASS);
			}else {
				Report.updateTestLog(Action, "Expected Product Row Per Cart "+ProductPerCart+" And Actual Product Row Per Cart "+ProductRow.size(), Status.FAIL);
			}

			double ExpectedTotalPriceWithVat_PerCart=0.00;

			// Verify each product row
			String ProductQuantity = null;
			for (int j=1;j<=ProductRow.size();j++) {
try {
				// Verify Product Name and PDP
// Verify Product Name and PDP
WebElement ProductNameLink = Driver.findElement(By.xpath("//div[@class='row ship-to newpage_eachOrder']["+i+"]//div[contains(@class,'row product-ListItem')]["+j+"]//a[@class='product-name ']"));
String ProductNameOnCartPage = ProductNameLink.getText();

ProductNameLink.click();

WebDriverWait wait4 = new WebDriverWait(Driver,10);
wait4.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
		.executeScript("return document.readyState")));

//WebElement PDP = Driver.findElement(By.xpath("//span[contains(text(),'Product Details')]"));
//String ProductNameOnPDP = Driver.findElement(By.xpath("//h1[@id='productDetail-name']")).getText();



WebElement PDP = Driver.findElement(By.xpath("//span[contains(@class,'product-header-style-CA')]"));
String ProductNameOnPDP = Driver.findElement(By.xpath("//h1[@id='productDetail-name']")).getText();

if (PDP.isDisplayed() && ProductNameOnPDP.equalsIgnoreCase(ProductNameOnCartPage)) {
	Report.updateTestLog(Action, "PDP Opened For Product Name "+ProductNameOnCartPage, Status.PASS);
}else {
	Report.updateTestLog(Action, "PDP NOT Opened For Product Name "+ProductNameOnCartPage, Status.FAIL);
}


Driver.navigate().back();

WebDriverWait wait1 = new WebDriverWait(Driver,10);
wait1.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
		.executeScript("return document.readyState")));


				// Verify Product Price With/WithOut VAT
				String PriceWithVat = Driver.findElement(By.xpath("//div[@class='row ship-to newpage_eachOrder']["+i+"]//div[contains(@class,'row product-ListItem')]["+j+"]//div[@class='cnd-price-print-CA']")).getText();
				 ProductQuantity = Driver.findElement(By.xpath("//div[@class='row ship-to newpage_eachOrder']["+i+"]//div[contains(@class,'row product-ListItem')]["+j+"]//div[@class='input-control']")).getText();
				String ActualTotalPriceWithVat_PerProduct = Driver.findElement(By.xpath("//div[@class='row ship-to newpage_eachOrder']["+i+"]//div[contains(@class,'row product-ListItem')]["+j+"]//div[contains(@class,'confi-total')]")).getText();

				PriceWithVat = PriceWithVat.replace(",", ".");
				//PriceWithVat = PriceWithVat.replace(",", "");
				String [] PriceWithVatArray = PriceWithVat.split(" ");
				// PriceWithVatArray=PriceWithVatArray[1].split("/");
					
				double PriceWithVat_Double = Double.parseDouble(PriceWithVatArray[1]);
							
					
				int ProductQuantity_Int = Integer.parseInt(ProductQuantity);
						
					
				double ExpectedTotalPriceWithVat_PerProduct =  Math.round((PriceWithVat_Double*ProductQuantity_Int) * 100.00) / 100.00;
				
				
				ActualTotalPriceWithVat_PerProduct = ActualTotalPriceWithVat_PerProduct.replace(",", ".");
				String [] ActualTotalPriceWithVat_PerProductArray = ActualTotalPriceWithVat_PerProduct.split(" ");
				
				String ActualTotalProductPriceWithVat_String=null;
				
				try
				{
				ActualTotalProductPriceWithVat_String=ActualTotalPriceWithVat_PerProductArray[1].concat(ActualTotalPriceWithVat_PerProductArray[2]);;
				
				}	catch(Exception e)
				{
					
					 ActualTotalProductPriceWithVat_String=ActualTotalPriceWithVat_PerProductArray[1];
					
					Report.updateTestLog(Action, "ActualTotalProductPriceWithVat_String catch ::::::::::::;  "+ActualTotalProductPriceWithVat_String, Status.PASS);
				}
				double ActualTotalPriceWithVat_PerProduct_Double = Double.parseDouble(ActualTotalProductPriceWithVat_String);
				
				if (ExpectedTotalPriceWithVat_PerProduct==ActualTotalPriceWithVat_PerProduct_Double) {
					Report.updateTestLog(Action, "Expected TotalPriceWithVat "+ExpectedTotalPriceWithVat_PerProduct+" And Actual TotalPriceWithVat "+ActualTotalPriceWithVat_PerProduct_Double, Status.PASS);
				}else {
					Report.updateTestLog(Action, "Expected TotalPriceWithVat "+ExpectedTotalPriceWithVat_PerProduct+" And Actual TotalPriceWithVat "+ActualTotalPriceWithVat_PerProduct_Double, Status.FAIL);
				}

				// Verify Total Price Per Cart
				//ExpectedTotalPriceWithVat_PerCart = Math.round((ExpectedTotalPriceWithVat_PerCart+ExpectedTotalPriceWithVat_PerProduct+ProductQuantity_Int) * 100.0) / 100.0;
				ExpectedTotalPriceWithVat_PerCart = Math.round((ExpectedTotalPriceWithVat_PerCart+ExpectedTotalPriceWithVat_PerProduct) * 100.0) / 100.0;
				Report.updateTestLog(Action, " ExpectedTotalPriceWithVat_PerCart   :::::::::::  "+ExpectedTotalPriceWithVat_PerCart, Status.DONE);			


}
catch (Exception e) {
Report.updateTestLog(Action," Verify Product Price  getting failed ", Status.FAIL);
}		
			}
			
			try {

			// Verify Total Price Per Cart
		String ActualTotalPriceWithVat_PerCart = Driver.findElement(By.xpath("//div[@class='row ship-to newpage_eachOrder']["+i+"]//div[contains(@class,'grand-total-print-CA')]")).getText();

			ActualTotalPriceWithVat_PerCart = ActualTotalPriceWithVat_PerCart.replace(",", ".");
			String [] ActualTotalPriceWithVat_PerCartArray = ActualTotalPriceWithVat_PerCart.split(" ");
			//ActualTotalPriceWithVat_PerCartArray=ActualTotalPriceWithVat_PerCartArray[1].split("/");
			String ActualTotalPriceWithVat_PerCart_String=null;
			try {
			 ActualTotalPriceWithVat_PerCart_String=ActualTotalPriceWithVat_PerCartArray[1].concat(ActualTotalPriceWithVat_PerCartArray[2]);
			}catch(Exception e)
			{
				ActualTotalPriceWithVat_PerCart_String=ActualTotalPriceWithVat_PerCartArray[1];
			}
			
			double ActualTotalPriceWithVat_PerCart_Double = Double.parseDouble(ActualTotalPriceWithVat_PerCart_String);
			Report.updateTestLog(Action," ActualTotalPriceWithVat_PerCart_Double:::: "+ActualTotalPriceWithVat_PerCart_Double, Status.DONE);
			if (ExpectedTotalPriceWithVat_PerCart==ActualTotalPriceWithVat_PerCart_Double) {
				Report.updateTestLog(Action, "Expected TotalPriceWithVat For Cart "+i+" is "+ExpectedTotalPriceWithVat_PerCart+" And Actual TotalPriceWithVat For Cart "+i+" is "+ActualTotalPriceWithVat_PerCart_Double, Status.PASS);
			}else {
				Report.updateTestLog(Action, "Expected TotalPriceWithVat For Cart "+i+" is "+ExpectedTotalPriceWithVat_PerCart+" And Actual TotalPriceWithVat For Cart "+i+" is "+ActualTotalPriceWithVat_PerCart_Double, Status.FAIL);
			}
			
			
			

			
		
			// Verify Total Price for ALL Carts
		ExpectedTotalPriceWithVat_AllCart = Math.round((ExpectedTotalPriceWithVat_AllCart+ExpectedTotalPriceWithVat_PerCart) * 100.00) / 100.00;
		
			
			}catch (Exception e) {
				Report.updateTestLog(Action," Verify Total Price Per Cart  getting failed ", Status.FAIL);
			}
			}
		try {	
			
			// Verify Total Price for ALL Carts
		String ActualTotalPriceWithVat_AllCart = Driver.findElement(By.xpath("//div[@class='row cart-bottom']//div[contains(@class,'checkSumFinalCostVal-print-CA gTotalAlgn-CA')]")).getText(); 

		ActualTotalPriceWithVat_AllCart = ActualTotalPriceWithVat_AllCart.replace(",", ".");
		
		String [] ActualTotalPriceWithVat_AllCartArray = ActualTotalPriceWithVat_AllCart.split(" ");
		//ActualTotalPriceWithVat_AllCartArray=ActualTotalPriceWithVat_AllCartArray[1].split("/");

		String ActualTotalPriceWithVat_AllCart_String=null;
		try {
		
		ActualTotalPriceWithVat_AllCart_String=ActualTotalPriceWithVat_AllCartArray[1].concat(ActualTotalPriceWithVat_AllCartArray[2]);
		}catch(Exception e)
		{
			ActualTotalPriceWithVat_AllCart_String=ActualTotalPriceWithVat_AllCartArray[1];
		}
			

		double ActualTotalPriceWithVat_AllCart_Double = Double.parseDouble(ActualTotalPriceWithVat_AllCart_String);


		if (ExpectedTotalPriceWithVat_AllCart==ActualTotalPriceWithVat_AllCart_Double) {
			Report.updateTestLog(Action, "Expected TotalPriceWithVat_AllCart "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPriceWithVat_AllCart "+ActualTotalPriceWithVat_AllCart_Double, Status.PASS);
		}else {
			Report.updateTestLog(Action, "Expected TotalPriceWithVat_AllCart "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPriceWithVat_AllCart "+ActualTotalPriceWithVat_AllCart_Double, Status.FAIL);
		}

		
		}catch (Exception e) {
			Report.updateTestLog(Action," Verify Total Price for ALL Carts  getting failed ", Status.FAIL);
		}
		
	try {
		WebElement Element = Driver.findElement(By.xpath("//span[@id='cartTotalZeroPrice']"));
		
		
		if (Element.getText().equals("(0)")) {
			
			Report.updateTestLog(Action, "Cart is null ", Status.PASS);
			
		}else {
			
			Report.updateTestLog(Action, "Cart is Not null "+ Element.getText(), Status.FAIL);
		}
		}catch (Exception e) {
			Report.updateTestLog(Action," Verify total Cart Price displayed at Cart Header  getting failed ", Status.FAIL);
		}

	//checking 3 Links bellow the order page
	orderconfirmationLinks();
	
	// Verify Orders on Order History Page
				//Driver.findElement(By.xpath("//a[contains(text(),'PrzeglÄ…daj historiÄ™ zamÃ³wienia')]")).click();
				Driver.findElement(By.xpath("//a[contains(text(),'Voir votre historique de commandes')]")).click();

				WebDriverWait wait2 = new WebDriverWait(Driver,10);
				wait2.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
						.executeScript("return document.readyState")));

				for (int x=0;x<OrderNumberList.size();x++) {
					String OrderNumber = OrderNumberList.get(x);

					Driver.findElement(By.xpath("//input[@id='search_text_order']")).clear();
					Driver.findElement(By.xpath("//input[@id='search_text_order']")).sendKeys(OrderNumber);

					Driver.findElement(By.xpath("//button[@id='searchtextBtn_order']")).click();
					
					Thread.sleep(5000);

					String SearchResultOrder = Driver.findElement(By.xpath("//div[@class='row']//div[contains(@class,'reservation-number')]//a")).getText();

					if(SearchResultOrder.equalsIgnoreCase(OrderNumber)) {
						Report.updateTestLog(Action, "Order Number  :: "+OrderNumber+" is Present on Order History Page ", Status.PASS);
						String addfav8=userData.getData("RegressionData", "addfavorite");
						
						if(addfav8.equals("Yes")) {
							addAsFavorite_buttoncheck();
							
						}
						try
						{
						
						orderhistoryPage_OrderDetails_FR(x);
						}catch(Exception e1){
							
							Report.updateTestLog(Action,"orderhistoryPage_OrderDetails_FR  :: "  +e1, Status.FAIL);	
						}
						
						
					}else {
						Report.updateTestLog(Action, "Order Number "+OrderNumber+" is NOT Present on Order History Page ", Status.FAIL);
					}
				}
				
				

				// Back office Login
				
			// back office last
	
	
	}catch(Exception e1) {
		Report.updateTestLog(Action,"Before Verify ShipTo Row expanded by default getting failed ", Status.FAIL);			
	}


}





public void orderhistoryPage_OrderDetails_FR(int k) {
	
	try {
	Driver.findElement(By.xpath("//div[@class='row']//div[contains(@class,'reservation-number')]//a")).click();
	WebDriverWait wait = new WebDriverWait(Driver,10);
	wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
			.executeScript("return document.readyState")));
	 k=k+1;
	 System.out.println("orderhistoryPage::"+k);
	String Order=userData.getData("RegressionData", "Order"+k);
	
	String text=Driver.findElement(By.xpath("//*[contains(text(),'Mon compte')]")).getText();
	
	if(text.equalsIgnoreCase("Mon compte")) {
		
		Report.updateTestLog(Action,"  Navigated to My Account Orderdetails ", Status.PASS);	
		
		
	WebElement Ordernum=Driver.findElement(By.xpath("//*[@id='order-number']"));
	
	if(Ordernum.getText().contains(Order))
	{
		
		Report.updateTestLog(Action," Order Detail are Matching and the Order No:-->"+Order, Status.PASS);
		
	}else
	{
		Report.updateTestLog(Action," Order Detail are NOT Matching and the Order No:-->"+Order, Status.FAIL);
	}
	try {
	WebElement payment =Driver.findElement(By.xpath("//div[contains(@class,'info-panel print-pay payment-val-CA')]"));
	String Creditcard=userData.getData("RegressionData", "Paymenttype"+k);
	
	if(payment.isDisplayed() && Creditcard.equalsIgnoreCase("Creditcard")  )
	{
		Report.updateTestLog(Action," Payment Method info displayed  : -->"+payment.getText(), Status.PASS);
		
	}
	else if(Creditcard.equalsIgnoreCase("InvoiceMe"))
	{
		Report.updateTestLog(Action," Selected Product have InvoiceMe", Status.PASS);
		
	}
	
	
	}
	catch(Exception e1) {
Report.updateTestLog(Action,"Payment Method : is not dispalyed ", Status.DONE);			
	}
	
	
	List<WebElement> odpage=Driver.findElements(By.xpath("//div[@class='table']//div[@data-test='table-products']"));
	
	for (int j=1;j<=odpage.size();j++)
	{
		String trowsheet=userData.getData("OrderDetails", "C"+k+"product"+j);
		
		String prodname=Driver.findElement(By.xpath("(//div[@class='table']//div[@data-test='table-products']//div//a[@class='product-name'])["+j+"]")).getText();
		String totalrow=Driver.findElement(By.xpath("(//div[@class='table']//div[@data-test='table-products']//span[contains(@style,'word-break')])["+j+"]")).getText();
		
		totalrow = totalrow.replace(",", ".");
		String [] productrow = totalrow.split(" ");
		
		
		String R1=null;
		try {
		
		R1=productrow[1].concat(productrow[2]);
		}catch(Exception e)
		{
			R1=productrow[1];
		}
		
		if(R1.contains(trowsheet))
		{
			
			Report.updateTestLog(Action, prodname +" ::  is Price matching with the Product :-->"+R1, Status.PASS);
			
		}else
		{
			Report.updateTestLog(Action," Price is NOT matching with the Product", Status.FAIL);
		}
		
		
		
	}
	try {
	String totalsheetprice=userData.getData("OrderDetails", "C"+k+"Total");
	//Report.updateTestLog(Action, "totalsheetprice::::: "+totalsheetprice, Status.DONE);
	String totalprice=Driver.findElement(By.xpath("//div[contains(@class,'table-total')]")).getText();
	
	//Report.updateTestLog(Action, totalprice, Status.DONE);
	
	totalprice=totalprice.replace("Total\n", "");
//	Report.updateTestLog(Action, totalprice, Status.DONE);
	totalprice=totalprice.replace(",", ".");
	
	String [] totalprice1 = totalprice.split(" ");
	
	//Report.updateTestLog(Action, totalprice1[1] +":::::::: ", Status.PASS);
	
	String tp=null;
	
try {
		
	tp=totalprice1[1].concat(totalprice1[2]);
		}catch(Exception e)
		{
			tp=totalprice1[1];
		}
		
	
	
	if(tp.contains(totalsheetprice))
	{
		
		Report.updateTestLog(Action, " Total price matching with the Order ::  "+tp, Status.PASS);
		
	}else
	{
		Report.updateTestLog(Action," Price is NOT matching with the Product", Status.FAIL);
	}
	
	}
	catch(Exception e) {
		Report.updateTestLog(Action," Unable to take Total Price in Order details Page ", Status.FAIL);			
			}
	
	
	
	
try {
		
		Driver.findElement(By.xpath("//button[@class='btn-violet1']")).click();
	}
	catch(Exception e1) {
		Report.updateTestLog(Action," Back to List of Orders not available  ", Status.FAIL);			
			}
	
	
	
	}	else
	{
		Report.updateTestLog(Action," Back to List of Orders not available  ", Status.DONE);	
	}
	
	}
	catch(Exception e1) {
		Report.updateTestLog(Action," Back to List of Orders not available  ", Status.FAIL);			
			}

	
	
	}
	
/* ****************************** ReoRder FR *************************** */




@Action(object = ObjectType.BROWSER, desc = "Click on the addtoCart and Validating shipping page info", input = InputType.NO)

public void orderAddcart_ShippingPageValidation_FR()

{
	try {
	Driver.findElement(By.xpath("//input[contains(@class,'reorderBtn reorderBtnn')]")).click();
	
	Report.updateTestLog(Action,"Able to click on the Addcart button" , Status.PASS);	
	
	//Wait until page load is complete	
	WebDriverWait wait = new WebDriverWait(Driver,10);
	wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
			.executeScript("return document.readyState")));
	
	Report.updateTestLog(Action,"Sucessfully navigated to  "+Driver.getTitle(), Status.PASS);
	
	
	String ProductCount=getVar("%productlistsize%");
	

	String ActualProductCount = Driver.findElement(By.xpath("//span[@id='cartTotalNonZero']/span[contains(@class,'count')]")).getText();

	// Verify total Product Count displayed at Cart Header
	if(ActualProductCount.contains(ProductCount)) {
		Report.updateTestLog(Action, "Expected Total Product in Cart "+ProductCount+" And Actual Total Product in Cart "+ActualProductCount, Status.PASS);
	}else {
		Report.updateTestLog(Action, "Expected Total Product in Cart "+ProductCount+" And Actual Total Product in Cart "+ActualProductCount, Status.FAIL);
	}
	
	
	
		
	
	
	String shpto_adress=getVar("%shiptoaddress%");
	String weeklyhours= getVar("%weeklyHours%");
	
	String billto_adress=getVar("%billToAddress%");
	String poNumber= getVar("%poNumber%");
		
	
	
	try {
	
	WebElement POnumber =Driver.findElement(By.xpath("(//span[contains(text(),'Numéro de bon de commande')]/parent::div//input)"));
	WebElement Weekly_Hours =	Driver.findElement(By.xpath("(//span[@class='requirednew']/../parent::div//textarea)"));
	
	
	
	POnumber.sendKeys(poNumber);
	Weekly_Hours.sendKeys(weeklyhours);
	
	
	Report.updateTestLog(Action,  poNumber +" ::::::::  "+weeklyhours +" :::  details Ent " , Status.PASS);	
	

	}	catch(Exception e) {
		Report.updateTestLog(Action,"unable to Enter the Ponumber and Weekly Houres ", Status.FAIL);			
	}
	
	
	try {

	// Verify ShipTo and BillTo
	String ActualShipTo = Driver.findElement(By.xpath("(//div[@class='row ship-to'])//div[contains(@class,'cart-add-tlt-CA')]//span[contains(@class,'shpAddrAln')]")).getText();
	String ActualBillTo = Driver.findElement(By.xpath("(//div[@class='row ship-to'])//div[contains(@class,'po-cart')]//span[contains(@class,'shpAddrAln')]")).getText();

	String shptodetails=Driver.findElement(By.xpath("(//div[@class='row ship-to'])//div[contains(@class,'cart-add-tlt-CA')]//div[contains(@class,'stAddressAlgn')]")).getText();
	String billtodetails=Driver.findElement(By.xpath("(//div[@class='row ship-to'])//div[contains(@class,'po-cart')]//div[contains(@class,'stAddressAlgn')]")).getText();
	
	
	
	if(shpto_adress.contains(ActualShipTo))
	{
		
		Report.updateTestLog(Action, " ActualShipTo details are matching  "+ActualShipTo , Status.PASS);	
		
	}
	else {
		Report.updateTestLog(Action, " ActualShipTo details are matching  " , Status.FAIL);
		
	}
	
	if(shpto_adress.contains(shptodetails))
	{
		Report.updateTestLog(Action, " shptodetails details are matching  "+shptodetails , Status.PASS);
		
	}else {
		Report.updateTestLog(Action, shpto_adress + " ::   shptodetails details are Not matching   :: "+shptodetails , Status.FAIL);
		
	}
	
	
	
	if(billto_adress.contains(ActualBillTo))
	{
		
		Report.updateTestLog(Action, " ActualBillTo details are matching  "+ActualShipTo , Status.PASS);	
		
	}
	else {
		Report.updateTestLog(Action, " ActualBillTo details are matching  " , Status.FAIL);
		
	}
	
	if(billto_adress.contains(billtodetails))
	{
		Report.updateTestLog(Action, " billtodetails details are matching  "+shptodetails , Status.PASS);
		
	}else {
		Report.updateTestLog(Action, billto_adress+ " :: billtodetails details are Not matching  :: "+billtodetails , Status.FAIL);
		
	}
	
	
	
	
	
	
	
	
	
	}	catch(Exception e) {
		Report.updateTestLog(Action,"unable get Shipto and Billto details", Status.FAIL);			
	}
	
	int ProductRow=Integer.parseInt(ProductCount);
	
	double ExpectedTotalPriceWithVat_PerCart=0.00;
	double ExpectedTotalPriceWithVat_AllCart = 0.00;
	// Verify each product row
	String ProductQuantity = null;
	for (int j=1;j<=ProductRow;j++) {
	try
	{
		
		// Verify Product Price With/WithOut VAT
		String PriceWithVat = Driver.findElement(By.xpath("(//div[@class='row ship-to'])//div[contains(@class,'row product-item')]["+j+"]//div[contains(@class,'pageConfWithVatVal')]")).getText();
			 ProductQuantity = Driver.findElement(By.xpath("(//div[@class='row ship-to'])//div[contains(@class,'row product-item')]["+j+"]//input[@id='quantity' and @type='number']")).getAttribute("value");
		String ActualTotalPriceWithVat_PerProduct = Driver.findElement(By.xpath("(//div[@class='row ship-to'])//div[contains(@class,'row product-item')]["+j+"]//div[contains(@class,'product-total')]")).getText();

		PriceWithVat = PriceWithVat.replace(",", ".");
		//PriceWithVat = PriceWithVat.replace(",", "");
		String [] PriceWithVatArray = PriceWithVat.split(" ");
		 PriceWithVatArray=PriceWithVatArray[1].split("/");
			
		double PriceWithVat_Double = Double.parseDouble(PriceWithVatArray[0]);
					
			
		int ProductQuantity_Int = Integer.parseInt(ProductQuantity);
				
			
		double ExpectedTotalPriceWithVat_PerProduct =  Math.round((PriceWithVat_Double*ProductQuantity_Int) * 100.00) / 100.00;
		
		
		ActualTotalPriceWithVat_PerProduct = ActualTotalPriceWithVat_PerProduct.replace(",", ".");
		String [] ActualTotalPriceWithVat_PerProductArray = ActualTotalPriceWithVat_PerProduct.split(" ");
		
		
		
		String ActualTotalProductPriceWithVat_String=null;
		try {
		 ActualTotalProductPriceWithVat_String=ActualTotalPriceWithVat_PerProductArray[1].concat(ActualTotalPriceWithVat_PerProductArray[2]);
//		 Report.updateTestLog(Action, ActualTotalPriceWithVat_PerProductArray[0]+ "   ::   "+ActualTotalPriceWithVat_PerProductArray[1]+" ::  "+ ActualTotalPriceWithVat_PerProductArray[2], Status.PASS);
			
//		Report.updateTestLog(Action, "ActualTotalProductPriceWithVat_String  ::::::::::::;  "+ActualTotalProductPriceWithVat_String, Status.PASS);
		}
		catch(Exception e)
		{
			
			 ActualTotalProductPriceWithVat_String=ActualTotalPriceWithVat_PerProductArray[1];
			
//			Report.updateTestLog(Action, "ActualTotalProductPriceWithVat_String catch ::::::::::::;  "+ActualTotalProductPriceWithVat_String, Status.PASS);
		}
		
		
		double ActualTotalPriceWithVat_PerProduct_Double = Double.parseDouble(ActualTotalProductPriceWithVat_String);
		
		if (ExpectedTotalPriceWithVat_PerProduct==ActualTotalPriceWithVat_PerProduct_Double) {
			Report.updateTestLog(Action, "Expected TotalPriceWithVat "+ExpectedTotalPriceWithVat_PerProduct+" And Actual TotalPriceWithVat "+ActualTotalPriceWithVat_PerProduct_Double, Status.PASS);
			
			String perproduct=String.valueOf(ExpectedTotalPriceWithVat_PerProduct);
					userData.putData("OrderDetails", "product"+j, perproduct);
					
		
		}else {
			Report.updateTestLog(Action, "Expected TotalPricePer Product "+ExpectedTotalPriceWithVat_PerProduct+" And Actual TotalPricePer Product "+ActualTotalPriceWithVat_PerProduct_Double, Status.FAIL);
		}

		// Verify Total Price Per Cart
		//ExpectedTotalPriceWithVat_PerCart = Math.round((ExpectedTotalPriceWithVat_PerCart+ExpectedTotalPriceWithVat_PerProduct+ProductQuantity_Int) * 100.0) / 100.0;
		ExpectedTotalPriceWithVat_PerCart = Math.round((ExpectedTotalPriceWithVat_PerCart+ExpectedTotalPriceWithVat_PerProduct) * 100.00) / 100.00;
			//Report.updateTestLog(Action, " ExpectedTotalPriceWithVat_PerCart   :::::::::::  "+ExpectedTotalPriceWithVat_PerCart, Status.DONE);			
	

					
		
		
		
		
		
	}catch(Exception e) {
		Report.updateTestLog(Action,"unable get Shipto and Billto details", Status.FAIL);			
	}
	
	
	
	
	
	}
	
	
	try {

		// Verify Total Price Per Cart
		String ActualTotalPriceWithVat_PerCart = Driver.findElement(By.xpath("(//div[@class='row ship-to'])//div[contains(@class,'grand-total_cad-CA')]")).getText();

		ActualTotalPriceWithVat_PerCart = ActualTotalPriceWithVat_PerCart.replace(",", ".");
		String [] ActualTotalPriceWithVat_PerCartArray = ActualTotalPriceWithVat_PerCart.split(" ");
		//ActualTotalPriceWithVat_PerCartArray=ActualTotalPriceWithVat_PerCartArray[1].split("/");
		
		
		String ActualTotalPriceWithVat_PerCart_String=null;
		
		
		try {
			
			 ActualTotalPriceWithVat_PerCart_String=ActualTotalPriceWithVat_PerCartArray[1].concat(ActualTotalPriceWithVat_PerCartArray[2]);
			 userData.putData("OrderDetails", "Total", ActualTotalPriceWithVat_PerCart_String);
			}
			catch (Exception e) {
				 ActualTotalPriceWithVat_PerCart_String=ActualTotalPriceWithVat_PerCartArray[1];
				 userData.putData("OrderDetails", "Total", ActualTotalPriceWithVat_PerCart_String);
			}
		
		
		
		
		
		double ActualTotalPriceWithVat_PerCart_Double = Double.parseDouble(ActualTotalPriceWithVat_PerCart_String);
		//Report.updateTestLog(Action," ActualTotalPriceWithVat_PerCart_Double:::: "+ActualTotalPriceWithVat_PerCart_Double, Status.DONE);
		if (ExpectedTotalPriceWithVat_PerCart==ActualTotalPriceWithVat_PerCart_Double) {
			Report.updateTestLog(Action, "Expected TotalPriceWithVat For Cart  is "+ExpectedTotalPriceWithVat_PerCart+" And Actual TotalPriceWithVat For Cart is "+ActualTotalPriceWithVat_PerCart_Double, Status.PASS);
		}else {
			Report.updateTestLog(Action, "Expected TotalPriceWithVat For Cart  is "+ExpectedTotalPriceWithVat_PerCart+" And Actual TotalPriceWithVat For Cart is "+ActualTotalPriceWithVat_PerCart_Double, Status.FAIL);
		}
		
		
		

		
	
		// Verify Total Price for ALL Carts
	ExpectedTotalPriceWithVat_AllCart = Math.round((ExpectedTotalPriceWithVat_AllCart+ExpectedTotalPriceWithVat_PerCart) * 100.00) / 100.00;
	
		
		}catch (Exception e) {
			Report.updateTestLog(Action," Verify Total Price Per Cart  getting failed ", Status.FAIL);
		}
		
	try {	
		
		// Verify Total Price for ALL Carts
	String ActualTotalPriceWithVat_AllCart = Driver.findElement(By.xpath("//div[@class='row cart-bottom']//div[contains(@class,'grandtotalvalue-CA')]")).getText(); 

	ActualTotalPriceWithVat_AllCart = ActualTotalPriceWithVat_AllCart.replace(",", ".");
	
	String [] ActualTotalPriceWithVat_AllCartArray = ActualTotalPriceWithVat_AllCart.split(" ");
	//ActualTotalPriceWithVat_AllCartArray=ActualTotalPriceWithVat_AllCartArray[1].split("/");

	String ActualTotalPriceWithVat_AllCart_String=ActualTotalPriceWithVat_AllCartArray[1]+ActualTotalPriceWithVat_AllCartArray[2];

	
	double ActualTotalPriceWithVat_AllCart_Double = Double.parseDouble(ActualTotalPriceWithVat_AllCart_String);


	userData.putData("OrderDetails", "TotalShipping", ActualTotalPriceWithVat_AllCart_String);//
	


	if (ExpectedTotalPriceWithVat_AllCart==ActualTotalPriceWithVat_AllCart_Double) {
		Report.updateTestLog(Action, "Expected TotalPriceWithVat_AllCart "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPriceWithVat_AllCart "+ActualTotalPriceWithVat_AllCart_Double, Status.PASS);
	
		
	
	
	}else {
		Report.updateTestLog(Action, "Expected TotalPriceWithVat_AllCart "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPriceWithVat_AllCart "+ActualTotalPriceWithVat_AllCart_Double, Status.FAIL);
	}

	
	}catch (Exception e) {
		Report.updateTestLog(Action," Verify Total Price for ALL Carts  getting failed ", Status.FAIL);
	}
	
	
	
	
	}	catch(Exception e1) {
		Report.updateTestLog(Action,"Unable to click on the Addcart button "+e1, Status.FAIL);			
	}
	
	
	
	
	
}








@Action(object = ObjectType.BROWSER, desc = "Click on the Review Your Order Validation", input = InputType.NO)

public void reorder_reviewOrderPageValidation_FR()

{
	try {
Driver.findElement(By.xpath("//button[@id='checkoutButton']")).click();
		
		WebDriverWait wait1 = new WebDriverWait(Driver,100);
		wait1.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
				.executeScript("return document.readyState")));
		Thread.sleep(10000);
	
	Report.updateTestLog(Action,"Sucessfully navigated to  "+Driver.getTitle(), Status.PASS);
	
	
	String ProductCount=getVar("%productlistsize%");
	

	
	
	String shpto_adress=getVar("%shiptoaddress%");
	String weeklyhours= getVar("%weeklyHours%");
	
	String billto_adress=getVar("%billToAddress%");
	String poNumber= getVar("%poNumber%");
		
	
	
	try {
	
	WebElement POnumber =Driver.findElement(By.xpath("(//span[contains(text(),'Numéro de bon de commande')]/parent::div//input)"));
	WebElement Weekly_Hours =	Driver.findElement(By.xpath("(//*[contains(@class,'delivery-instructions')]/../parent::div//textarea)"));
	
	
	
	//POnumber.sendKeys(poNumber);
	//Weekly_Hours.sendKeys(weeklyhours);

	if(POnumber.getAttribute("value").contains(poNumber)) {
		
		
		
		Report.updateTestLog(Action,   " PO Number Matching with Orderconfirmation page  ::  "+poNumber , Status.PASS);	
		
	}
	else
	{
		Report.updateTestLog(Action,  " PO Number not Matching with Orderconfirmation page  " , Status.FAIL);	
		
		
	}
	
	
	
	if(Weekly_Hours.getText().contains(weeklyhours)) {
		
		
		
		Report.updateTestLog(Action,  " Weeklyhours Matching with Orderconfirmation page  ::  "+weeklyhours , Status.PASS);	
		
	}
	else
	{
		Report.updateTestLog(Action,  " PO Number not Matching with Orderconfirmation page  " , Status.FAIL);	
		
		
	}
	
	

	
	

	}	catch(Exception e) {
		Report.updateTestLog(Action,"unable to Enter the Ponumber and Weekly Houres ", Status.FAIL);			
	}
	
	
	try {

	// Verify ShipTo and BillTo
	String ActualShipTo = Driver.findElement(By.xpath("(//div[@class='row ship-to'])//div[contains(@class,'cart-add-tlt-CA')]//span[contains(@class,'shpAddrAln')]")).getText();
	String ActualBillTo = Driver.findElement(By.xpath("((//div[@class='row ship-to'])//span[contains(@class,'shpAddrAln')])[2]")).getText();

	String shptodetails=Driver.findElement(By.xpath("(//div[@class='row ship-to'])//div[contains(@class,'cart-add-tlt-CA')]//div[contains(@class,'stAddressAlgn')]")).getText();
	String billtodetails=Driver.findElement(By.xpath("((//div[@class='row ship-to'])//div[contains(@class,'stAddressAlgn')])[2]")).getText();
	
	
	
	if(shpto_adress.contains(ActualShipTo))
	{
		
		Report.updateTestLog(Action, " ActualShipTo details are matching  "+ActualShipTo , Status.PASS);	
		
	}
	else {
		Report.updateTestLog(Action, " ActualShipTo details are matching  " , Status.FAIL);
		
	}
	
	if(shpto_adress.contains(shptodetails))
	{
		Report.updateTestLog(Action, " shptodetails details are matching  "+shptodetails , Status.PASS);
		
	}else {
		Report.updateTestLog(Action, shpto_adress + " ::   shptodetails details are Not matching   :: "+shptodetails , Status.FAIL);
		
	}
	
	
	
	if(billto_adress.contains(ActualBillTo))
	{
		
		Report.updateTestLog(Action, " ActualBillTo details are matching  "+ActualShipTo , Status.PASS);	
		
	}
	else {
		Report.updateTestLog(Action, " ActualBillTo details are matching  " , Status.FAIL);
		
	}
	
	if(billto_adress.contains(billtodetails))
	{
		Report.updateTestLog(Action, " billtodetails details are matching  "+shptodetails , Status.PASS);
		
	}else {
		Report.updateTestLog(Action, billto_adress+ " :: billtodetails details are Not matching  :: "+billtodetails , Status.FAIL);
		
	}
	
	
	
	
	
	
	
	
	
	}	catch(Exception e) {
		Report.updateTestLog(Action,"unable get Shipto and Billto details", Status.FAIL);			
	}
	
	int ProductRow=Integer.parseInt(ProductCount);
	
	double ExpectedTotalPriceWithVat_PerCart=0.00;
	double ExpectedTotalPriceWithVat_AllCart = 0.00;
	// Verify each product row
	String ProductQuantity = null;
	
	String [] PriceWithVatArray=null;
	int ProductQuantity_Int=0;
	double PriceWithVat_Double =0;
	String [] ActualTotalPriceWithVat_PerProductArray=null;
	for (int j=1;j<=ProductRow;j++) {
	try
	{
		
		// Verify Product Price With/WithOut VAT
		String PriceWithVat = Driver.findElement(By.xpath("((//div[@class='row ship-to'])//div[contains(@class,'row gsk-box-productSection')])[1]/following-sibling::div//div[contains(@class,'row product-item')]["+j+"]//div[contains(@class,'withoutvatcheckout-CA')]")).getText();
			 ProductQuantity = Driver.findElement(By.xpath("((//div[@class='row ship-to'])//div[contains(@class,'row gsk-box-productSection')])[1]/following-sibling::div//div[contains(@class,'row product-item')]["+j+"]//div[contains(@class,'summary-qty-val-CA')]")).getText();
		String ActualTotalPriceWithVat_PerProduct = Driver.findElement(By.xpath("((//div[@class='row ship-to'])//div[contains(@class,'row gsk-box-productSection')])[1]/following-sibling::div//div[contains(@class,'row product-item')]["+j+"]//div[contains(@class,'product-total')]")).getText();

		
		
		
		try {
			PriceWithVat = PriceWithVat.replace(",", ".");
			//PriceWithVat = PriceWithVat.replace(",", "");
			 PriceWithVatArray = PriceWithVat.split(" ");
			 PriceWithVat_Double = Double.parseDouble(PriceWithVatArray[1]);
							
					
				 ProductQuantity_Int = Integer.parseInt(ProductQuantity);
			}catch (Exception e) {
				PriceWithVatArray = PriceWithVat.split(" ");
				
				Report.updateTestLog(Action," inside PriceWithVatArray ", Status.DONE);
				
				 PriceWithVat_Double = Double.parseDouble(PriceWithVatArray[1]);
							
					
				 ProductQuantity_Int = Integer.parseInt(ProductQuantity);
			}
				
			
		double ExpectedTotalPriceWithVat_PerProduct =  Math.round((PriceWithVat_Double*ProductQuantity_Int) * 100.00) / 100.00;
		
		
		try {

			ActualTotalPriceWithVat_PerProduct = ActualTotalPriceWithVat_PerProduct.replace(",", ".");
			ActualTotalPriceWithVat_PerProductArray = ActualTotalPriceWithVat_PerProduct.split(" ");
			}catch (Exception e) {
				
				ActualTotalPriceWithVat_PerProductArray = ActualTotalPriceWithVat_PerProduct.split(" ");
			}


			String ActualTotalProductPriceWithVat_String=null;
			try {
			 ActualTotalProductPriceWithVat_String=ActualTotalPriceWithVat_PerProductArray[1].concat(ActualTotalPriceWithVat_PerProductArray[2]);

			}
			catch(Exception e)
			{
				
				 ActualTotalProductPriceWithVat_String=ActualTotalPriceWithVat_PerProductArray[1];
				
				//Report.updateTestLog(Action, "ActualTotalProductPriceWithVat_String catch ::::::::::::;  "+ActualTotalProductPriceWithVat_String, Status.PASS);
			}

		
		double ActualTotalPriceWithVat_PerProduct_Double = Double.parseDouble(ActualTotalProductPriceWithVat_String);
		
		if (ExpectedTotalPriceWithVat_PerProduct==ActualTotalPriceWithVat_PerProduct_Double) {
			Report.updateTestLog(Action, "Expected TotalPriceWithVat "+ExpectedTotalPriceWithVat_PerProduct+" And Actual TotalPriceWithVat "+ActualTotalPriceWithVat_PerProduct_Double, Status.PASS);
			
			String perproduct=String.valueOf(ExpectedTotalPriceWithVat_PerProduct);
					
		
		}else {
			Report.updateTestLog(Action, "Expected TotalPriceWithVat "+ExpectedTotalPriceWithVat_PerProduct+" And Actual TotalPriceWithVat "+ActualTotalPriceWithVat_PerProduct_Double, Status.FAIL);
		}

		// Verify Total Price Per Cart
		//ExpectedTotalPriceWithVat_PerCart = Math.round((ExpectedTotalPriceWithVat_PerCart+ExpectedTotalPriceWithVat_PerProduct+ProductQuantity_Int) * 100.0) / 100.0;
		ExpectedTotalPriceWithVat_PerCart = Math.round((ExpectedTotalPriceWithVat_PerCart+ExpectedTotalPriceWithVat_PerProduct) * 100.0) / 100.00;
			//Report.updateTestLog(Action, " ExpectedTotalPriceWithVat_PerCart   :::::::::::  "+ExpectedTotalPriceWithVat_PerCart, Status.DONE);			
	

		
		
	}catch(Exception e) {
		Report.updateTestLog(Action,"unable get Shipto and Billto details", Status.FAIL);			
	}
	
	
	
	
	}
	
	
	try {

	// Verify Total Price Per Cart
	//String ActualTotalPriceWithVat_PerCart = Driver.findElement(By.xpath("(//div[@class='row ship-to'])["+i+"]//div[contains(@class,'checkOutSumCa-CA')]")).getText();
	String ActualTotalPriceWithVat_PerCart = Driver.findElement(By.xpath("((//div[@class='row ship-to'])//div[contains(@class,'row gsk-box-productSection')])[1]/following-sibling::div//div[contains(@class,'checkOutSumCa-CA')]")).getText();

	ActualTotalPriceWithVat_PerCart = ActualTotalPriceWithVat_PerCart.replace(",", ".");
	String [] ActualTotalPriceWithVat_PerCartArray = ActualTotalPriceWithVat_PerCart.split(" ");
	
	String ActualTotalPriceWithVat_PerCart_String=null;
	try {
		
	 ActualTotalPriceWithVat_PerCart_String=ActualTotalPriceWithVat_PerCartArray[1].concat(ActualTotalPriceWithVat_PerCartArray[2]);
	
	}
	catch(Exception e)
	{
		
		ActualTotalPriceWithVat_PerCart_String=ActualTotalPriceWithVat_PerCartArray[1];
		
//		Report.updateTestLog(Action, "ActualTotalProductPriceWithVat_String catch ::::::::::::;  "+ActualTotalPriceWithVat_PerCart_String, Status.PASS);
	}
	
		
	double ActualTotalPriceWithVat_PerCart_Double = Double.parseDouble(ActualTotalPriceWithVat_PerCart_String);
//	Report.updateTestLog(Action," ActualTotalPriceWithVat_PerCart_Double:::: "+ActualTotalPriceWithVat_PerCart_Double, Status.DONE);
	if (ExpectedTotalPriceWithVat_PerCart==ActualTotalPriceWithVat_PerCart_Double) {
		Report.updateTestLog(Action, "Expected TotalPriceWithVat For Cart is "+ExpectedTotalPriceWithVat_PerCart+" And Actual TotalPriceWithVat For Cart is "+ActualTotalPriceWithVat_PerCart_Double, Status.PASS);
	}else {
		Report.updateTestLog(Action, "Expected TotalPriceWithVat For Cart  is "+ExpectedTotalPriceWithVat_PerCart+" And Actual TotalPriceWithVat For Cart  is "+ActualTotalPriceWithVat_PerCart_Double, Status.FAIL);
	}
	
	
	

	
	
	// Verify Total Price for ALL Carts
ExpectedTotalPriceWithVat_AllCart = Math.round((ExpectedTotalPriceWithVat_AllCart+ExpectedTotalPriceWithVat_PerCart) * 100.0) / 100.0;

	}catch (Exception e) {
		Report.updateTestLog(Action," Verify Total Price Per Cart  getting failed "+e, Status.FAIL);
	}
	
	
//		
	
	
	
try {	
	
	// Verify Total Price for ALL Carts
String ActualTotalPriceWithVat_AllCart = Driver.findElement(By.xpath("//div[@class='row cart-bottom']//div[contains(@class,' total-ipad-val-CA')]")).getText(); 

ActualTotalPriceWithVat_AllCart = ActualTotalPriceWithVat_AllCart.replace(",", ".");

String [] ActualTotalPriceWithVat_AllCartArray = ActualTotalPriceWithVat_AllCart.split(" ");
//ActualTotalPriceWithVat_AllCartArray=ActualTotalPriceWithVat_AllCartArray[1].split("/");

String ActualTotalPriceWithVat_AllCart_String=null;



try {
	
	ActualTotalPriceWithVat_AllCart_String=ActualTotalPriceWithVat_AllCartArray[1].concat(ActualTotalPriceWithVat_AllCartArray[2]);

}
catch(Exception e)
{
	
	ActualTotalPriceWithVat_AllCart_String=ActualTotalPriceWithVat_AllCartArray[1];
	
//	Report.updateTestLog(Action, "ActualTotalProductPriceWithVat_String catch ::::::::::::;  "+ActualTotalPriceWithVat_PerCart_String, Status.PASS);
}









double ActualTotalPriceWithVat_AllCart_Double = Double.parseDouble(ActualTotalPriceWithVat_AllCart_String);


if (ExpectedTotalPriceWithVat_AllCart==ActualTotalPriceWithVat_AllCart_Double) {
	Report.updateTestLog(Action, "Expected TotalPriceWithVat_AllCart "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPriceWithVat_AllCart "+ActualTotalPriceWithVat_AllCart_Double, Status.PASS);
}else {
	Report.updateTestLog(Action, "Expected TotalPriceWithVat_AllCart "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPriceWithVat_AllCart "+ActualTotalPriceWithVat_AllCart_Double, Status.FAIL);
}


}catch (Exception e) {
	Report.updateTestLog(Action," Verify Total Price for ALL Carts  getting failed "+e, Status.FAIL);
}

try {
// Verify total Cart Price displayed at Cart Header
String ActualTotalPriceAtCartHeader = Driver.findElement(By.xpath("//span[@id='cartTotalNonZero']/span[contains(@class,'count')]/span[2]")).getText();

ActualTotalPriceAtCartHeader = ActualTotalPriceAtCartHeader.replace(",", ".");
String [] ActualTotalPriceAtCartHeaderArray = ActualTotalPriceAtCartHeader.split(" ");
//ActualTotalPriceAtCartHeaderArray=ActualTotalPriceAtCartHeaderArray[1].split("/");
String ActualTotalPriceAtCartHeader_String=null;

try {
	
	ActualTotalPriceAtCartHeader_String=ActualTotalPriceAtCartHeaderArray[1].concat(ActualTotalPriceAtCartHeaderArray[2]);
	
	}
	catch(Exception e)
	{
		
		ActualTotalPriceAtCartHeader_String=ActualTotalPriceAtCartHeaderArray[1];
		
//		Report.updateTestLog(Action, "ActualTotalProductPriceWithVat_String catch ::::::::::::;  "+ActualTotalPriceWithVat_PerCart_String, Status.PASS);
	}



	

double ActualTotalPriceAtCartHeader_Double = Double.parseDouble(ActualTotalPriceAtCartHeader_String);

if (ExpectedTotalPriceWithVat_AllCart==ActualTotalPriceAtCartHeader_Double) {
	Report.updateTestLog(Action, "Expected TotalPrice_At Cart Header "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPrice_At Cart Header "+ActualTotalPriceAtCartHeader_Double, Status.PASS);
}else {
	Report.updateTestLog(Action, "Expected TotalPrice_At Cart Header "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPrice_At Cart Header "+ActualTotalPriceAtCartHeader_Double, Status.FAIL);
}




}catch (Exception e) {
	Report.updateTestLog(Action," Verify total Cart Price displayed at Cart Header  getting failed ", Status.FAIL);
}
	
	
	
	
	}	catch(Exception e1) {
		Report.updateTestLog(Action,"Unable to click on the Addcart button "+e1, Status.FAIL);			
	}
	
	
	
	
	
}



// ------------------------------------------------------------------------------------------------------------- //



@Action(object = ObjectType.BROWSER, desc = "Click on the Review Your Order Validation", input = InputType.NO)

public void reorder_OrderPageconfirmValidation_FR()

{
	try {
		Driver.findElement(By.xpath("//button[contains(text(),'Passer la commande')]")).click();
		
		WebDriverWait wait1 = new WebDriverWait(Driver,100);
		wait1.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
				.executeScript("return document.readyState")));
		Thread.sleep(10000);
	
	Report.updateTestLog(Action,"Sucessfully navigated to  "+Driver.getTitle(), Status.PASS);
	
	
	
	// Verify Header Text, Order Confirmation No and Order Confirmation Date
	String ConfirmOrderHeader = Driver.findElement(By.xpath("//p[contains(text(),' Confirmation de la commande')]")).getText();
	WebElement OrderConfirmationNumber = Driver.findElement(By.xpath("//*[contains(@class,'orderConfirm-print-CA')]"));
	WebElement OrderConfirmationDate = Driver.findElement(By.xpath("//p[@id='order-confirmation-date']"));
	WebElement OrderConfirmationSentto=Driver.findElement(By.xpath("//strong[contains(text(),'Confirmation envoyée à :')]/parent::p"));

	String[] OrderConfirmationNumberArray = OrderConfirmationNumber.getText().split("\\s+");
	String[] OrderConfirmationDateArray = OrderConfirmationDate.getText().split(":");
	String[] OrderConfirmationSenttoArray=OrderConfirmationSentto.getText().split(":");

try {

//Report.updateTestLog(Action, "Order Confirmation No 5 ::- "+OrderConfirmationNumberArray[5]+"Order Confirmation No 4 ::- "+OrderConfirmationNumberArray[4]+ "Order Confirmation No 3 ::- "+OrderConfirmationNumberArray[3]+"Order Confirmation No 2 ::- "+OrderConfirmationNumberArray[2], Status.DONE);

	if (ConfirmOrderHeader.equalsIgnoreCase("Confirmation de la commande") && OrderConfirmationNumber.isDisplayed() && OrderConfirmationDate.isDisplayed() &&OrderConfirmationSentto.isDisplayed())
	{
		Report.updateTestLog(Action, "Order Placed Successfully. Order Confirmation No ::- "+OrderConfirmationNumberArray[5]+" | Order Confirmation Date - "+OrderConfirmationDateArray[1]+" | Order Confirmation Sent to - "+OrderConfirmationSenttoArray[1], Status.PASS);
	
	
	}else {
		Report.updateTestLog(Action, "Order Place is NOT Successful", Status.FAIL);
	}
	
}catch (Exception e) {
Report.updateTestLog(Action, "Order Confirmation No 1 ::- "+OrderConfirmationNumberArray[1]+"Order Confirmation No 4 ::- "+OrderConfirmationNumberArray[4]+ "Order Confirmation No 3 ::- "+OrderConfirmationNumberArray[3]+"Order Confirmation No 2 ::- "+OrderConfirmationNumberArray[2], Status.DONE);

}

	
	///
	
	
	
	String ProductCount=getVar("%productlistsize%");
	

	
	
	String shpto_adress=getVar("%shiptoaddress%");
	String weeklyhours= getVar("%weeklyHours%");
	
	String billto_adress=getVar("%billToAddress%");
	String poNumber= getVar("%poNumber%");
	ArrayList<String> OrderNumberList = new ArrayList<String>();
	
	WebElement OrderNumber = Driver.findElement(By.xpath("//div[@class='row ship-to newpage_eachOrder']//h2[contains(@class,'ship-to-title')]"));
	String OrderNumberString = OrderNumber.getText();
	String[] OrderNumberArray = OrderNumberString.split("\\s+");
	OrderNumberList.add(OrderNumberArray[1]);

	if(OrderNumber.isDisplayed()) {
		Report.updateTestLog(Action, "Order Number for Cart  is -->"+OrderNumberArray[1], Status.PASS);
		
		userData.putData("RegressionData", "Order", OrderNumberArray[1]);
	}else {
		Report.updateTestLog(Action, "Order Number for Cart  NOT Present", Status.FAIL);
	}
	
	
		
	try {

	// Verify ShipTo and BillTo
	String ActualShipTo = Driver.findElement(By.xpath("//div[@class='row ship-to newpage_eachOrder']//div[contains(@class,'cart-add-tlt-CA')]//span[contains(@class,'shpAddrAln')]")).getText();
	String ActualBillTo = Driver.findElement(By.xpath("(//div[@class='row ship-to newpage_eachOrder']//span[contains(@class,'shpAddrAln')])[2]")).getText();

	String shptodetails=Driver.findElement(By.xpath("(//div[@class='row ship-to newpage_eachOrder'])//div[contains(@class,'cart-add-tlt-CA')]//div[contains(@class,'stAddressAlgn')]")).getText();
	String billtodetails=Driver.findElement(By.xpath("((//div[@class='row ship-to newpage_eachOrder'])//div[contains(@class,'stAddressAlgn')])[2]")).getText();
	
	
	
	if(shpto_adress.contains(ActualShipTo))
	{
		
		Report.updateTestLog(Action, " ActualShipTo details are matching  "+ActualShipTo , Status.PASS);	
		
	}
	else {
		Report.updateTestLog(Action, " ActualShipTo details are matching  " , Status.FAIL);
		
	}
	
	if(shpto_adress.contains(shptodetails))
	{
		Report.updateTestLog(Action, " shptodetails details are matching  "+shptodetails , Status.PASS);
		
	}else {
		Report.updateTestLog(Action, shpto_adress + " ::   shptodetails details are Not matching   :: "+shptodetails , Status.FAIL);
		
	}
	
	
	
	if(billto_adress.contains(ActualBillTo))
	{
		
		Report.updateTestLog(Action, " ActualBillTo details are matching  "+ActualShipTo , Status.PASS);	
		
	}
	else {
		Report.updateTestLog(Action, " ActualBillTo details are matching  " , Status.FAIL);
		
	}
	
	if(billto_adress.contains(billtodetails))
	{
		Report.updateTestLog(Action, " billtodetails details are matching  "+shptodetails , Status.PASS);
		
	}else {
		Report.updateTestLog(Action, billto_adress+ " :: billtodetails details are Not matching  :: "+billtodetails , Status.FAIL);
		
	}
	
	
	
	
	
	
	
	
	
	}	catch(Exception e) {
		Report.updateTestLog(Action,"unable get Shipto and Billto details", Status.FAIL);			
	}
	
	

	try {
	
	WebElement POnumber =Driver.findElement(By.xpath("(//span[contains(text(),'Numéro de bon de commande')]/parent::div//input)"));
	WebElement Weekly_Hours =	Driver.findElement(By.xpath("(//*[contains(@class,'delivery-instructions')]/../parent::div//textarea)"));
	
	
	Report.updateTestLog(Action,   " PO Number  ::  "+POnumber.getText() , Status.DONE);	
	//POnumber.sendKeys(poNumber);
	//Weekly_Hours.sendKeys(weeklyhours);
	
	if(POnumber.getAttribute("value").contains(poNumber)) {
		
		
		
		Report.updateTestLog(Action,   " PO Number Matching with Orderconfirmation page  ::  "+poNumber , Status.PASS);	
		
	}
	else
	{
		Report.updateTestLog(Action,  " PO Number not Matching with Orderconfirmation page  " , Status.FAIL);	
		
		
	}
	
	
	
	if(Weekly_Hours.getText().contains(weeklyhours)) {
		
		
		
		Report.updateTestLog(Action,  " Weeklyhours Matching with Orderconfirmation page  ::  "+weeklyhours , Status.PASS);	
		
	}
	else
	{
		Report.updateTestLog(Action,  " PO Number not Matching with Orderconfirmation page  " , Status.FAIL);	
		
		
	}
	
	

	

	}	catch(Exception e) {
		Report.updateTestLog(Action,"unable to Enter the Ponumber and Weekly Houres ", Status.FAIL);			
	}
	
	
	
	int ProductRow=Integer.parseInt(ProductCount);
	
	double ExpectedTotalPriceWithVat_PerCart=0.00;
	double ExpectedTotalPriceWithVat_AllCart = 0.00;
	
	// Verify each product row
	String ProductQuantity = null;
	for (int j=1;j<=ProductRow;j++) {
	try
	{
		
		// Verify Product Price With/WithOut VAT
	//	String PriceWithVat = Driver.findElement(By.xpath("((//div[@class='row ship-to'])//div[contains(@class,'row gsk-box-productSection')])[1]/following-sibling::div//div[contains(@class,'row product-item')]["+j+"]//div[contains(@class,'withoutvatcheckout-CA')]")).getText();
	//		 ProductQuantity = Driver.findElement(By.xpath("((//div[@class='row ship-to'])//div[contains(@class,'row gsk-box-productSection')])[1]/following-sibling::div//div[contains(@class,'row product-item')]["+j+"]//div[contains(@class,'summary-qty-val-CA')]")).getText();
	//	String ActualTotalPriceWithVat_PerProduct = Driver.findElement(By.xpath("((//div[@class='row ship-to'])//div[contains(@class,'row gsk-box-productSection')])[1]/following-sibling::div//div[contains(@class,'row product-item')]["+j+"]//div[contains(@class,'product-total')]")).getText();

	
		// Verify Product Price With/WithOut VAT
		String PriceWithVat = Driver.findElement(By.xpath("//div[@class='row ship-to newpage_eachOrder']//div[contains(@class,'row product-ListItem')]["+j+"]//div[@class='cnd-price-print-CA']")).getText();
		 ProductQuantity = Driver.findElement(By.xpath("//div[@class='row ship-to newpage_eachOrder']//div[contains(@class,'row product-ListItem')]["+j+"]//div[@class='input-control']")).getText();
		String ActualTotalPriceWithVat_PerProduct = Driver.findElement(By.xpath("//div[@class='row ship-to newpage_eachOrder']//div[contains(@class,'row product-ListItem')]["+j+"]//div[contains(@class,'confi-total')]")).getText();
	
		
				
		
		
		
		PriceWithVat = PriceWithVat.replace(",", ".");
		//PriceWithVat = PriceWithVat.replace(",", "");
		String [] PriceWithVatArray = PriceWithVat.split(" ");
		// PriceWithVatArray=PriceWithVatArray[1].split("/");
			
		double PriceWithVat_Double = Double.parseDouble(PriceWithVatArray[1]);
					
			
		int ProductQuantity_Int = Integer.parseInt(ProductQuantity);
				
			
		double ExpectedTotalPriceWithVat_PerProduct =  Math.round((PriceWithVat_Double*ProductQuantity_Int) * 100.00) / 100.00;
		
		
		ActualTotalPriceWithVat_PerProduct = ActualTotalPriceWithVat_PerProduct.replace(",", ".");
		String [] ActualTotalPriceWithVat_PerProductArray = ActualTotalPriceWithVat_PerProduct.split(" ");
		
		String ActualTotalProductPriceWithVat_String=null;
		
		
		try {
			
			ActualTotalProductPriceWithVat_String=ActualTotalPriceWithVat_PerProductArray[1].concat(ActualTotalPriceWithVat_PerProductArray[2]);
			
			}
			catch(Exception e)
			{
				
				ActualTotalProductPriceWithVat_String=ActualTotalPriceWithVat_PerProductArray[1];
				
//				Report.updateTestLog(Action, "ActualTotalProductPriceWithVat_String catch ::::::::::::;  "+ActualTotalPriceWithVat_PerCart_String, Status.PASS);
			}
		
		
		
		
		double ActualTotalPriceWithVat_PerProduct_Double = Double.parseDouble(ActualTotalProductPriceWithVat_String);
		
		if (ExpectedTotalPriceWithVat_PerProduct==ActualTotalPriceWithVat_PerProduct_Double) {
			Report.updateTestLog(Action, "Expected TotalPriceWithVat "+ExpectedTotalPriceWithVat_PerProduct+" And Actual TotalPriceWithVat "+ActualTotalPriceWithVat_PerProduct_Double, Status.PASS);
		}else {
			Report.updateTestLog(Action, "Expected TotalPriceWithVat "+ExpectedTotalPriceWithVat_PerProduct+" And Actual TotalPriceWithVat "+ActualTotalPriceWithVat_PerProduct_Double, Status.FAIL);
		}

		// Verify Total Price Per Cart
		//ExpectedTotalPriceWithVat_PerCart = Math.round((ExpectedTotalPriceWithVat_PerCart+ExpectedTotalPriceWithVat_PerProduct+ProductQuantity_Int) * 100.0) / 100.0;
		ExpectedTotalPriceWithVat_PerCart = Math.round((ExpectedTotalPriceWithVat_PerCart+ExpectedTotalPriceWithVat_PerProduct) * 100.0) / 100.0;
		Report.updateTestLog(Action, " ExpectedTotalPriceWithVat_PerCart   :::::::::::  "+ExpectedTotalPriceWithVat_PerCart, Status.DONE);			

	}catch(Exception e) {
		Report.updateTestLog(Action,"unable get Shipto and Billto details", Status.FAIL);			
	}
	
	
	
	
	}
	
	
	
	
	
	
	try {

		// Verify Total Price Per Cart
	String ActualTotalPriceWithVat_PerCart = Driver.findElement(By.xpath("//div[@class='row ship-to newpage_eachOrder']//div[contains(@class,'grand-total-print-CA')]")).getText();

		ActualTotalPriceWithVat_PerCart = ActualTotalPriceWithVat_PerCart.replace(",", ".");
		String [] ActualTotalPriceWithVat_PerCartArray = ActualTotalPriceWithVat_PerCart.split(" ");
		//ActualTotalPriceWithVat_PerCartArray=ActualTotalPriceWithVat_PerCartArray[1].split("/");
		String ActualTotalPriceWithVat_PerCart_String=null;

		
		try {
			
			 ActualTotalPriceWithVat_PerCart_String=ActualTotalPriceWithVat_PerCartArray[1].concat(ActualTotalPriceWithVat_PerCartArray[2]);
			
			}
			catch(Exception e)
			{
				
				ActualTotalPriceWithVat_PerCart_String=ActualTotalPriceWithVat_PerCartArray[1];
				
//				Report.updateTestLog(Action, "ActualTotalProductPriceWithVat_String catch ::::::::::::;  "+ActualTotalPriceWithVat_PerCart_String, Status.PASS);
			}
		
		
		
		double ActualTotalPriceWithVat_PerCart_Double = Double.parseDouble(ActualTotalPriceWithVat_PerCart_String);
		Report.updateTestLog(Action," ActualTotalPriceWithVat_PerCart_Double:::: "+ActualTotalPriceWithVat_PerCart_Double, Status.DONE);
		if (ExpectedTotalPriceWithVat_PerCart==ActualTotalPriceWithVat_PerCart_Double) {
			Report.updateTestLog(Action, "Expected TotalPriceWithVat For Cart is "+ExpectedTotalPriceWithVat_PerCart+" And Actual TotalPriceWithVat For Cart is "+ActualTotalPriceWithVat_PerCart_Double, Status.PASS);
		}else {
			Report.updateTestLog(Action, "Expected TotalPriceWithVat For Cart is "+ExpectedTotalPriceWithVat_PerCart+" And Actual TotalPriceWithVat For Cart  is "+ActualTotalPriceWithVat_PerCart_Double, Status.FAIL);
		}
		
		
		

		
	
		// Verify Total Price for ALL Carts
	ExpectedTotalPriceWithVat_AllCart = Math.round((ExpectedTotalPriceWithVat_AllCart+ExpectedTotalPriceWithVat_PerCart) * 100.0) / 100.0;
	
		
		}catch (Exception e) {
			Report.updateTestLog(Action," Verify Total Price Per Cart  getting failed ", Status.FAIL);
		}
		
	try {	
		
		// Verify Total Price for ALL Carts
	String ActualTotalPriceWithVat_AllCart = Driver.findElement(By.xpath("//div[@class='row cart-bottom']//div[contains(@class,'checkSumFinalCostVal-print-CA gTotalAlgn-CA')]")).getText(); 

	ActualTotalPriceWithVat_AllCart = ActualTotalPriceWithVat_AllCart.replace(",", ".");
	
	String [] ActualTotalPriceWithVat_AllCartArray = ActualTotalPriceWithVat_AllCart.split(" ");
	//ActualTotalPriceWithVat_AllCartArray=ActualTotalPriceWithVat_AllCartArray[1].split("/");

	String ActualTotalPriceWithVat_AllCart_String=null;
	
	try {
		
		ActualTotalPriceWithVat_AllCart_String=ActualTotalPriceWithVat_AllCartArray[1].concat(ActualTotalPriceWithVat_AllCartArray[2]);
		
		}
		catch(Exception e)
		{
			
			ActualTotalPriceWithVat_AllCart_String=ActualTotalPriceWithVat_AllCartArray[1];
			
//			Report.updateTestLog(Action, "ActualTotalProductPriceWithVat_String catch ::::::::::::;  "+ActualTotalPriceWithVat_PerCart_String, Status.PASS);
		}

		

	double ActualTotalPriceWithVat_AllCart_Double = Double.parseDouble(ActualTotalPriceWithVat_AllCart_String);


	if (ExpectedTotalPriceWithVat_AllCart==ActualTotalPriceWithVat_AllCart_Double) {
		Report.updateTestLog(Action, "Expected TotalPriceWithVat_AllCart "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPriceWithVat_AllCart "+ActualTotalPriceWithVat_AllCart_Double, Status.PASS);
	}else {
		Report.updateTestLog(Action, "Expected TotalPriceWithVat_AllCart "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPriceWithVat_AllCart "+ActualTotalPriceWithVat_AllCart_Double, Status.FAIL);
	}

	
	}catch (Exception e) {
		Report.updateTestLog(Action," Verify Total Price for ALL Carts  getting failed ", Status.FAIL);
	}
	
try {
	WebElement Element = Driver.findElement(By.xpath("//span[@id='cartTotalZeroPrice']"));
	
	
	if (Element.getText().equals("(0)")) {
		
		Report.updateTestLog(Action, "Cart is null ", Status.PASS);
		
	}else {
		
		Report.updateTestLog(Action, "Cart is Not null "+ Element.getText(), Status.FAIL);
	}
	}catch (Exception e) {
		Report.updateTestLog(Action," Verify total Cart Price displayed at Cart Header  getting failed ", Status.FAIL);
	}

	
	
	
	
//Verify Orders on Order History Page
//Driver.findElement(By.xpath("//a[contains(text(),'PrzeglÄ…daj historiÄ™ zamÃ³wienia')]")).click();
Driver.findElement(By.xpath("//a[contains(text(),'Voir votre historique de commandes')]")).click();

WebDriverWait wait2 = new WebDriverWait(Driver,10);
wait2.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
		.executeScript("return document.readyState")));

for (int x=0;x<OrderNumberList.size();x++) {
	String OrderNumber1 = OrderNumberList.get(x);

	Driver.findElement(By.xpath("//input[@id='search_text_order']")).clear();
	Driver.findElement(By.xpath("//input[@id='search_text_order']")).sendKeys(OrderNumber1);

	Driver.findElement(By.xpath("//button[@id='searchtextBtn_order']")).click();
	
	Thread.sleep(5000);

	String SearchResultOrder = Driver.findElement(By.xpath("//div[@class='row']//div[contains(@class,'reservation-number')]//a")).getText();

	if(SearchResultOrder.equalsIgnoreCase(OrderNumber1)) {
		Report.updateTestLog(Action, "Order Number "+OrderNumber1+" is Present on Order History Page ", Status.PASS);
		
		String addfav8=userData.getData("RegressionData", "addfavorite");
		
		if(addfav8.equals("Yes")) {
			addAsFavorite_buttoncheck();
			
		}
		
		orderhistoryPage_OrderDetails(x);
		
		
		
	}else {
		Report.updateTestLog(Action, "Order Number "+OrderNumber1+" is NOT Present on Order History Page ", Status.FAIL);
	}
}

	
	
	
	
	
	
	
	
	
	
	
	}	catch(Exception e1) {
		Report.updateTestLog(Action,"Unable to click on the Addcart button "+e1, Status.FAIL);			
	}
	
	
	
	
	
}










}
	
	
