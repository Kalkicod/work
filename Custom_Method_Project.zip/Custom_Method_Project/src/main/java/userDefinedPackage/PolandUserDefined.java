package userDefinedPackage;


import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.X509TrustManager;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cognizant.cognizantits.engine.commands.General;
import com.cognizant.cognizantits.engine.core.CommandControl;
import com.cognizant.cognizantits.engine.support.Status;
import com.cognizant.cognizantits.engine.support.methodInf.Action;
import com.cognizant.cognizantits.engine.support.methodInf.InputType;
import com.cognizant.cognizantits.engine.support.methodInf.ObjectType;


public class PolandUserDefined extends General {


	public PolandUserDefined(CommandControl cc) {
		super(cc);
	}
	@Action(object = ObjectType.BROWSER, desc = "Values should be in 1000, 1second =1000 [<Data>]", input = InputType.YES)
	public void thread_Sleep() throws InterruptedException {

		int time = Integer.parseInt(Data);
		Thread.sleep(time);

	}



	@Action(object = ObjectType.BROWSER, desc = "Close Pending Req Popup", input = InputType.NO)
	public void pendingReqPopUpHandle_PL() {
		
		Driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		try {
			
			if (Driver.findElement(By.id("shiptoPendingOpen")).isDisplayed()) {
				
				Report.updateTestLog(Action, "Pending Ship-to Request For the Account is Present", Status.DONE);
				
				Driver.findElement(By.xpath("//button[contains(@onclick,'colorbox.close()')]")).click();
				Driver.findElement(By.id("cboxClose")).click();
				
				Report.updateTestLog(Action, "Closed Pending Shipto Popup", Status.PASS);
			} 
			
		} catch (Exception e) {
			
			System.out.println("PendingReqPopUp didn't display");
			Report.updateTestLog(Action, "No Pending Ship-to For the Account", Status.DONE);
		}		
	}


	@Action(object = ObjectType.BROWSER, desc = "Close Accept Cookies Popup", input = InputType.NO)
	public void acceptCookiesPopUpHandle_PL() {

		try {
			WebElement AcceptCookiesPopUp = Driver.findElement(By.id("privacy_prompt"));
			if (AcceptCookiesPopUp.isDisplayed()) {
				Driver.findElement(By.id("preferences_prompt_submit")).click();
			} else {
				System.out.println("AcceptCookiesPopUp didn't display");
			} 
		} catch (Exception e) {
			System.out.println("AcceptCookiesPopUp didn't display");
		}		
	}


	@Action(object = ObjectType.BROWSER, desc = "Enter ShipTo,Product ID,Quantity [<Data>]", input = InputType.YES)
	public void addProductToCart_PL() throws InterruptedException {
		
		
		String[] InputData = Data.split(",");
		String ShipTo = InputData[0]; //1200082978
		String Product = InputData[1]; //705809
		String Quantity = InputData[2]; //10
		
		//Click on Order able Page
		if(Driver.getTitle().contains("Zamów produkty")) {
			Report.updateTestLog(Action, "User is already in Zamów produkty Page", Status.DONE);
		} else {
			Driver.findElement(By.xpath("//a[@id='purchase-products-active']")).click();
			Thread.sleep(20000);
			Report.updateTestLog(Action, "User is navigated in Zamów produkty Page", Status.DONE);
		}
		

		try {
			
						

			WebElement ChangeShipToPopUp = Driver.findElement(By.id("cboxLoadedContent"));
			
			ChangeShipToPopUp.isDisplayed();

			
			System.out.println("Selecting the Ship to for the First Time");
			
			Driver.findElement(By.xpath("//span[contains(text(),'"+ShipTo+"')]")).click();
			
			Driver.findElement(By.xpath("//button[@id='orderForThisAddressBtn' and contains(text(),'Zamów dla odbiorcy')]")).click();
			
			Thread.sleep(2000);
			
				Driver.findElement(By.xpath("//input[@id='search_text_complexproducts_orderable']")).sendKeys(Product);
				Driver.findElement(By.xpath("//button[@id='searchtextBtn_complexproducts_orderable']")).click();


				Driver.findElement(By.xpath("//input[contains(@class,'QuantityText prodOrderListerQty')]")).sendKeys(Quantity);
				Driver.findElement(By.xpath("//span[@class='add-cart-PL' and contains(text(),'Dodaj do koszyka')]")).click();

				Driver.navigate().refresh();

				//Wait until page load is complete	
				WebDriverWait wait = new WebDriverWait(Driver,10);
				wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
						.executeScript("return document.readyState")));

				if (Driver.findElement(By.id("cartTotalNonZero")).isDisplayed()) {

					Report.updateTestLog(Action, Quantity + " Packs of " +Product+" Added To Cart for ShipTo "+ShipTo, Status.PASS);

				}else {
					Report.updateTestLog(Action, " No Product Added To Cart for ShipTo "+ShipTo, Status.FAIL);

				}

		} catch (Exception e) {
			
			System.out.println("Selecting a different Ship to");
			
			Driver.findElement(By.xpath("//a[@id='changeShipToLink']")).click();

			Thread.sleep(10000);
			
			Driver.findElement(By.xpath("//span[contains(text(),'"+ShipTo+"')]")).click();
			
			Driver.findElement(By.xpath("//button[@id='orderForThisAddressBtn' and contains(text(),'Zamów dla odbiorcy')]")).click();
			
			Thread.sleep(2000);

			Driver.findElement(By.xpath("//input[@id='search_text_complexproducts_orderable']")).sendKeys(Product);
			Driver.findElement(By.xpath("//button[@id='searchtextBtn_complexproducts_orderable']")).click();

			Driver.findElement(By.xpath("//input[contains(@class,'QuantityText prodOrderListerQty')]")).sendKeys(Quantity);
			Driver.findElement(By.xpath("//span[@class='add-cart-PL' and contains(text(),'Dodaj do koszyka')]")).click();


			Driver.navigate().refresh();

			//Wait until page load is complete	
			WebDriverWait wait = new WebDriverWait(Driver,10);
			wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
					.executeScript("return document.readyState")));

			if (Driver.findElement(By.id("cartTotalNonZero")).isDisplayed()) {

				Report.updateTestLog(Action, Quantity + " Packs of " +Product+" Added To Cart for ShipTo "+ShipTo, Status.PASS);

			}else {
				Report.updateTestLog(Action, " No Product Added To Cart for ShipTo "+ShipTo, Status.FAIL);

			}
		}		
	}



	@Action(object = ObjectType.BROWSER, desc = "Enter ProductCount,CartCount,ProductPerCart,ShipTo-BillTo [<Data>]", input = InputType.YES)
	public void verifyShoppingCartPage_PL() {


		try {

			String[] InputData = Data.split(",");

			String ProductCount = InputData[0];
			String CartCount = InputData[1];
			String ProductPerCart = InputData[2];

			HashMap<String,String> ShipToBillTo_Map = new HashMap<String,String>();

			for (int a=3;a<=InputData.length-1;a++) {

				String[] ShipToBillToArray = InputData[a].split("-");
				ShipToBillTo_Map.put(ShipToBillToArray[0], ShipToBillToArray[1]);

			}

			Driver.findElement(By.xpath("//a[contains(text(),'Koszyk')]")).click();

			//Wait until page load is complete	
			WebDriverWait wait = new WebDriverWait(Driver,10);
			wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
					.executeScript("return document.readyState")));

			String ActualProductCount = Driver.findElement(By.xpath("//span[@id='cartTotalNonZero']/span[contains(@class,'count')]")).getText();

			// Verify total Product Count displayed at Cart Header
			if(ActualProductCount.contains(ProductCount)) {
				Report.updateTestLog(Action, "Expected Total Product in Cart "+ProductCount+" And Actual Total Product in Cart "+ActualProductCount, Status.PASS);
			}else {
				Report.updateTestLog(Action, "Expected Total Product in Cart "+ProductCount+" And Actual Total Product in Cart "+ActualProductCount, Status.FAIL);
			}

			List<WebElement> Carts = Driver.findElements(By.xpath("//div[@class='row ship-to']"));

			// Verify Total Cart displayed
			if(Carts.size()==Integer.parseInt(CartCount)) {
				Report.updateTestLog(Action, "Expected Cart Count "+CartCount+" And Actual Cart Count "+Carts.size(), Status.PASS);
			}else {
				Report.updateTestLog(Action, "Expected Cart Count "+CartCount+" And Actual Cart Count "+Carts.size(), Status.FAIL);
			}

			// Verify Total "Nowy koszyk" section count
			if (ShipToBillTo_Map.size()>1) {
				List<WebElement> Nowy_koszyk = Driver.findElements(By.xpath("//div[contains(text(),'Nowy koszyk')]"));

				if(Nowy_koszyk.size()==ShipToBillTo_Map.size()-1) {
					Report.updateTestLog(Action, "Total Nowy_koszyk Section Count is "+Nowy_koszyk.size()+" Which is Expected", Status.PASS);
				}else {
					Report.updateTestLog(Action, "Total Nowy_koszyk Section Count is "+Nowy_koszyk.size()+" Which is NOT Expected", Status.FAIL);
				}
			}



			double ExpectedTotalPriceWithVat_AllCart = 0.00;

			for (int i=1;i<=Carts.size();i++) {
				// Verify ShipTo Row expanded by default
				WebElement ShipToToggle = Driver.findElement(By.xpath("//div[@class='row ship-to']["+i+"]//a"));

				if (ShipToToggle.getAttribute("class").equalsIgnoreCase("ship-to-toggle expanded")) {
					Report.updateTestLog(Action, "Cart "+i+ " Expanded By Default", Status.PASS);
				}else {
					Report.updateTestLog(Action, "Cart "+i+ " NOT Expanded By Default", Status.FAIL);
				}

				ShipToToggle.click();

				// Verify ShiTo Row Collapse
				if (ShipToToggle.getAttribute("class").equalsIgnoreCase("ship-to-toggle")) {

					Report.updateTestLog(Action, "Cart "+i+ " Toggle is Collapsed", Status.PASS);

					if (Driver.findElement(By.xpath("//div[@class='row ship-to']["+i+"]//div[@class='ship-to-full']")).isDisplayed()) {
						Report.updateTestLog(Action, "Cart "+i+ " is NOT Collapsed", Status.FAIL);
					}else {
						Report.updateTestLog(Action, "Cart "+i+ " is Collapsed", Status.PASS);

					}
				}else {
					Report.updateTestLog(Action, "Cart "+i+ " Toggle is NOT Collapsed", Status.FAIL);
				}



				ShipToToggle.click();

				// Verify ShiTo Row Expand
				if (ShipToToggle.getAttribute("class").equalsIgnoreCase("ship-to-toggle expanded")) {

					Report.updateTestLog(Action, "Cart "+i+ " Toggle is Expanded", Status.PASS);

					if (Driver.findElement(By.xpath("//div[@class='row ship-to']["+i+"]//div[@class='ship-to-full']")).isDisplayed()) {
						Report.updateTestLog(Action, "Cart "+i+ " is Expanded", Status.PASS);
					}else {
						Report.updateTestLog(Action, "Cart "+i+ " is NOT Expanded", Status.FAIL);
					}
				}else {
					Report.updateTestLog(Action, "Cart "+i+ " Toggle is NOT Expanded", Status.FAIL);
				}


				// Verify ShipTo and BillTo
				String ActualShipTo = Driver.findElement(By.xpath("//div[@class='row ship-to']["+i+"]//div[contains(@class,'cart-add-tlt-PL')]//span[contains(@class,'shpAddrAln')]")).getText();
				String ActualBillTo = Driver.findElement(By.xpath("//div[@class='row ship-to']["+i+"]//div[contains(@class,'po-cart')]//span[contains(@class,'shpAddrAln')]")).getText();

				for (String ExpectedShipTo : ShipToBillTo_Map.keySet()) {
					if(ActualShipTo.contains(ExpectedShipTo)) {
						String ExpectedBillTo = ShipToBillTo_Map.get(ExpectedShipTo);
						if (ActualBillTo.contains(ExpectedBillTo)) {
							Report.updateTestLog(Action, "Cart Created For "+ExpectedShipTo+" And Corresponding BillTo "+ExpectedBillTo, Status.PASS);
						}else {
							Report.updateTestLog(Action, "Cart is NOT Created For Provided ShipTo and BillTo", Status.FAIL);
						}

					}
				}


				List<WebElement> ProductRow = Driver.findElements(By.xpath("//div[@class='row ship-to']["+i+"]//div[contains(@class,'row product-item')]"));

				// Verify Total Product Per Cart displayed
				if(ProductRow.size()==Integer.parseInt(ProductPerCart)) {
					Report.updateTestLog(Action, "Expected Product Row Per Cart "+ProductPerCart+" And Actual Product Row Per Cart "+ProductRow.size(), Status.PASS);
				}else {
					Report.updateTestLog(Action, "Expected Product Row Per Cart "+ProductPerCart+" And Actual Product Row Per Cart "+ProductRow.size(), Status.FAIL);
				}

				double ExpectedTotalPriceWithVat_PerCart=0.00;

				// Verify each product row
				for (int j=1;j<=ProductRow.size();j++) {

					// Verify Product Name and PDP
					WebElement ProductNameLink = Driver.findElement(By.xpath("//div[@class='row ship-to']["+i+"]//div[contains(@class,'row product-item')]["+j+"]//a[@class='product-name']"));
					String ProductNameOnCartPage = ProductNameLink.getText();

					ProductNameLink.click();

					WebDriverWait wait1 = new WebDriverWait(Driver,10);
					wait1.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
							.executeScript("return document.readyState")));

					WebElement PDP = Driver.findElement(By.xpath("//span[contains(text(),'Dane produktu')]"));
					String ProductNameOnPDP = Driver.findElement(By.xpath("//h1[@id='productDetail-name']")).getText();

					if (PDP.isDisplayed() && ProductNameOnPDP.equalsIgnoreCase(ProductNameOnCartPage)) {
						Report.updateTestLog(Action, "PDP Opened For Product Name "+ProductNameOnCartPage, Status.PASS);
					}else {
						Report.updateTestLog(Action, "PDP NOT Opened For Product Name "+ProductNameOnCartPage, Status.FAIL);
					}


					Driver.navigate().back();

					WebDriverWait wait2 = new WebDriverWait(Driver,10);
					wait2.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
							.executeScript("return document.readyState")));

					// Verify "Usuń z koszyka" link under each product row
					String RemoveLink = Driver.findElement(By.xpath("//div[@class='row ship-to']["+i+"]//div[contains(@class,'row product-item')]["+j+"]//a[@id='removeCartLink']")).getText().trim();

					if (RemoveLink.equalsIgnoreCase("Usuń z koszyka")) {
						Report.updateTestLog(Action, "Remove Link Displayed for "+ProductNameOnCartPage, Status.PASS);
					}else {
						Report.updateTestLog(Action, "Remove Link NOT Displayed for "+ProductNameOnCartPage, Status.PASS);
					}


					// Verify Product Price With/WithOut VAT
					String PriceWithVat = Driver.findElement(By.xpath("//div[@class='row ship-to']["+i+"]//div[contains(@class,'row product-item')]["+j+"]//div[contains(@class,'pageConfWithVatVal')]")).getText();
					String ProductQuantity = Driver.findElement(By.xpath("//div[@class='row ship-to']["+i+"]//div[contains(@class,'row product-item')]["+j+"]//input[@id='quantity' and @type='number']")).getAttribute("value");
					String ActualTotalPriceWithVat_PerProduct = Driver.findElement(By.xpath("//div[@class='row ship-to']["+i+"]//div[contains(@class,'row product-item')]["+j+"]//div[contains(@class,'product-total')]")).getText();

					PriceWithVat = PriceWithVat.replace(",", ".");
					String [] PriceWithVatArray = PriceWithVat.split(" ");
					double PriceWithVat_Double = Double.parseDouble(PriceWithVatArray[0]);

					int ProductQuantity_Int = Integer.parseInt(ProductQuantity);

					double ExpectedTotalPriceWithVat_PerProduct =  Math.round((PriceWithVat_Double*ProductQuantity_Int) * 100.0) / 100.0;

					ActualTotalPriceWithVat_PerProduct = ActualTotalPriceWithVat_PerProduct.replace(",", ".");
					String [] ActualTotalPriceWithVat_PerProductArray = ActualTotalPriceWithVat_PerProduct.split(" ");

					String ActualTotalProductPriceWithVat_String="";

					for (int k=0;k<=ActualTotalPriceWithVat_PerProductArray.length-2;k++) {
						ActualTotalProductPriceWithVat_String = ActualTotalProductPriceWithVat_String+ActualTotalPriceWithVat_PerProductArray[k];
					}

					double ActualTotalPriceWithVat_PerProduct_Double = Double.parseDouble(ActualTotalProductPriceWithVat_String);

					if (ExpectedTotalPriceWithVat_PerProduct==ActualTotalPriceWithVat_PerProduct_Double) {
						Report.updateTestLog(Action, "Expected TotalPriceWithVat "+ExpectedTotalPriceWithVat_PerProduct+" And Actual TotalPriceWithVat "+ActualTotalPriceWithVat_PerProduct_Double, Status.PASS);
					}else {
						Report.updateTestLog(Action, "Expected TotalPriceWithVat "+ExpectedTotalPriceWithVat_PerProduct+" And Actual TotalPriceWithVat "+ActualTotalPriceWithVat_PerProduct_Double, Status.FAIL);
					}

					// Verify Total Price Per Cart
					ExpectedTotalPriceWithVat_PerCart = Math.round((ExpectedTotalPriceWithVat_PerCart+ExpectedTotalPriceWithVat_PerProduct) * 100.0) / 100.0;

				}

				// Verify Total Price Per Cart
				String ActualTotalPriceWithVat_PerCart = Driver.findElement(By.xpath("//div[@class='row ship-to']["+i+"]//div[contains(@class,'sumval-PL')]")).getText();

				ActualTotalPriceWithVat_PerCart = ActualTotalPriceWithVat_PerCart.replace(",", ".");
				String [] ActualTotalPriceWithVat_PerCartArray = ActualTotalPriceWithVat_PerCart.split(" ");

				String ActualTotalPriceWithVat_PerCart_String="";

				for (int l=0;l<=ActualTotalPriceWithVat_PerCartArray.length-2;l++) {
					ActualTotalPriceWithVat_PerCart_String = ActualTotalPriceWithVat_PerCart_String+ActualTotalPriceWithVat_PerCartArray[l];
				}

				double ActualTotalPriceWithVat_PerCart_Double = Double.parseDouble(ActualTotalPriceWithVat_PerCart_String);

				if (ExpectedTotalPriceWithVat_PerCart==ActualTotalPriceWithVat_PerCart_Double) {
					Report.updateTestLog(Action, "Expected TotalPriceWithVat For Cart "+i+" is "+ExpectedTotalPriceWithVat_PerCart+" And Actual TotalPriceWithVat For Cart "+i+" is "+ActualTotalPriceWithVat_PerCart_Double, Status.PASS);
				}else {
					Report.updateTestLog(Action, "Expected TotalPriceWithVat For Cart "+i+" is "+ExpectedTotalPriceWithVat_PerCart+" And Actual TotalPriceWithVat For Cart "+i+" is "+ActualTotalPriceWithVat_PerCart_Double, Status.FAIL);
				}

				// Verify Total Price for ALL Carts
				ExpectedTotalPriceWithVat_AllCart = Math.round((ExpectedTotalPriceWithVat_AllCart+ExpectedTotalPriceWithVat_PerCart) * 100.0) / 100.0;

			}

			// Verify Total Price for ALL Carts
			String ActualTotalPriceWithVat_AllCart = Driver.findElement(By.xpath("//div[@class='row cart-bottom']//div[contains(@class,'finalCostVal1-PL')]")).getText(); 

			ActualTotalPriceWithVat_AllCart = ActualTotalPriceWithVat_AllCart.replace(",", ".");
			String [] ActualTotalPriceWithVat_AllCartArray = ActualTotalPriceWithVat_AllCart.split(" ");

			String ActualTotalPriceWithVat_AllCart_String="";

			for (int m=0;m<=ActualTotalPriceWithVat_AllCartArray.length-2;m++) {
				ActualTotalPriceWithVat_AllCart_String = ActualTotalPriceWithVat_AllCart_String+ActualTotalPriceWithVat_AllCartArray[m];
			}

			double ActualTotalPriceWithVat_AllCart_Double = Double.parseDouble(ActualTotalPriceWithVat_AllCart_String);


			if (ExpectedTotalPriceWithVat_AllCart==ActualTotalPriceWithVat_AllCart_Double) {
				Report.updateTestLog(Action, "Expected TotalPriceWithVat_AllCart "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPriceWithVat_AllCart "+ActualTotalPriceWithVat_AllCart_Double, Status.PASS);
			}else {
				Report.updateTestLog(Action, "Expected TotalPriceWithVat_AllCart "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPriceWithVat_AllCart "+ActualTotalPriceWithVat_AllCart_Double, Status.FAIL);
			}

			// Verify total Cart Price displayed at Cart Header
			String ActualTotalPriceAtCartHeader = Driver.findElement(By.xpath("//span[@id='cartTotalNonZero']/span[contains(@class,'count')]/span[2]")).getText();

			ActualTotalPriceAtCartHeader = ActualTotalPriceAtCartHeader.replace(",", ".");
			String [] ActualTotalPriceAtCartHeaderArray = ActualTotalPriceAtCartHeader.split(" ");

			String ActualTotalPriceAtCartHeader_String="";

			for (int m=0;m<=ActualTotalPriceAtCartHeaderArray.length-2;m++) {
				ActualTotalPriceAtCartHeader_String = ActualTotalPriceAtCartHeader_String+ActualTotalPriceAtCartHeaderArray[m];
			}

			double ActualTotalPriceAtCartHeader_Double = Double.parseDouble(ActualTotalPriceAtCartHeader_String);

			if (ExpectedTotalPriceWithVat_AllCart==ActualTotalPriceAtCartHeader_Double) {
				Report.updateTestLog(Action, "Expected TotalPrice_At Cart Header "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPrice_At Cart Header "+ActualTotalPriceAtCartHeader_Double, Status.PASS);
			}else {
				Report.updateTestLog(Action, "Expected TotalPrice_At Cart Header "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPrice_At Cart Header "+ActualTotalPriceAtCartHeader_Double, Status.FAIL);
			}



		}catch(Exception e) {
			e.printStackTrace();			
		}


	}


	@Action(object = ObjectType.BROWSER, desc = "Enter ProductCount,CartCount,ProductPerCart,ShipTo-BillTo [<Data>]", input = InputType.YES)
	public void verifyConfirmOrderPage_PL() {
		
		
		String[] InputData = Data.split(",");

		String ProductCount = InputData[0];
		String CartCount = InputData[1];
		String ProductPerCart = InputData[2];

		HashMap<String,String> ShipToBillTo_Map = new HashMap<String,String>();

		for (int a=3;a<=InputData.length-1;a++) {

			String[] ShipToBillToArray = InputData[a].split("-");
			ShipToBillTo_Map.put(ShipToBillToArray[0], ShipToBillToArray[1]);

		}
		
		try {
			
			Driver.findElement(By.xpath("//button[@id='checkoutButton']")).click();
			Report.updateTestLog(Action, "Checkout Button is Clicked", Status.PASS);
			
		} catch(Exception f) {
			
			Report.updateTestLog(Action, "Checkout Button is not Clicked", Status.FAIL);
			
		}
		
		

		try{	
			
			Thread.sleep(10000);

			// Verify Header Text
						String ConfirmHeader = Driver.findElement(By.xpath("//div[contains(@class,'review-order')]/h3")).getText().trim();
						
						if (ConfirmHeader.equalsIgnoreCase("Potwierdź i złóż zamówienie")) {
							Report.updateTestLog(Action, "Potwierdź i złóż zamówienie Text Displayed at Header", Status.PASS);
						}else {
							Report.updateTestLog(Action, "Potwierdź i złóż zamówienie Text NOT Displayed at Header", Status.FAIL);
						}

						


			// Verify Navigate Back and Forward pages
			Driver.findElement(By.xpath("//button[contains(@class,'back-to-cart')]")).click();

			WebDriverWait wait1 = new WebDriverWait(Driver,10);
			wait1.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
					.executeScript("return document.readyState")));

			String CartPageTitle = Driver.getTitle();
			if(CartPageTitle.contains("Koszyk zakupów | gsk24.pl")) {
				Report.updateTestLog(Action, "User Navigate to Shopping Cart Page", Status.PASS);
			}else {
				Report.updateTestLog(Action, "User NOT Navigate to Shopping Cart Page", Status.FAIL);
			}

			Driver.findElement(By.xpath("//button[@id='checkoutButton']")).click();
			Thread.sleep(10000);

			String ConfirmOrderPageTitle = Driver.getTitle();
			if(ConfirmOrderPageTitle.contains("Podsumowanie zamówienia | gsk24.pl")) {
				Report.updateTestLog(Action, "User Navigate to ConfirmOrderPageTitle Page", Status.PASS);
			}else {
				Report.updateTestLog(Action, "User NOT Navigate to ConfirmOrderPageTitle Page", Status.FAIL);
			}
			
			
			try {
				
				WebElement SaleDocLink = Driver.findElement(By.xpath("//a[contains(@class,'termofsales')]"));

				SaleDocLink.isDisplayed();
				
				Report.updateTestLog(Action, "Sale Doc Link Displayed", Status.PASS);
				
				// Verify Sale Doc Link Opened
				
				SaleDocLink.click();
				Thread.sleep(5000);
				
				Set<String> Handles = Driver.getWindowHandles();
				Iterator<String> It = Handles.iterator();
				String ParentWindowID = It.next();
				String ChildWindowID = It.next();
				Driver.switchTo().window(ChildWindowID);
				String Url = Driver.getCurrentUrl();
				
				if (Url.contains("ROW-PL-Terms-of-Sale")){
					Report.updateTestLog(Action, "Sale Doc Page Displayed", Status.PASS);
					
				}else {
					Report.updateTestLog(Action, "Sale Doc Page NOT Displayed", Status.FAIL);
					
				}
				
				Driver.close();
				Driver.switchTo().window(ParentWindowID);

				
			} catch (Exception h) {
				Report.updateTestLog(Action, "Sale Doc Link NOT Displayed", Status.FAIL);
				
			}
			

			///////////////////////

			String ActualProductCount = Driver.findElement(By.xpath("//span[@id='cartTotalNonZero']/span[contains(@class,'count')]")).getText();

			// Verify total Product Count displayed at Cart Header
			if(ActualProductCount.contains(ProductCount)) {
				Report.updateTestLog(Action, "Expected Total Product in Cart "+ProductCount+" And Actual Total Product in Cart "+ActualProductCount, Status.PASS);
			}else {
				Report.updateTestLog(Action, "Expected Total Product in Cart "+ProductCount+" And Actual Total Product in Cart "+ActualProductCount, Status.FAIL);
			}

			List<WebElement> Carts = Driver.findElements(By.xpath("//div[@class='row ship-to']"));

			// Verify Total Cart displayed
			if(Carts.size()==Integer.parseInt(CartCount)) {
				Report.updateTestLog(Action, "Expected Cart Count "+CartCount+" And Actual Cart Count "+Carts.size(), Status.PASS);
			}else {
				Report.updateTestLog(Action, "Expected Cart Count "+CartCount+" And Actual Cart Count "+Carts.size(), Status.FAIL);
			}

			// Verify Total "Nowy koszyk" section count
			if (ShipToBillTo_Map.size()>1) {
				List<WebElement> Nowy_koszyk = Driver.findElements(By.xpath("//div[contains(text(),'Nowy koszyk')]"));

				if(Nowy_koszyk.size()==ShipToBillTo_Map.size()-1) {
					Report.updateTestLog(Action, "Total Nowy_koszyk Section Count is "+Nowy_koszyk.size()+" Which is Expected", Status.PASS);
				}else {
					Report.updateTestLog(Action, "Total Nowy_koszyk Section Count is "+Nowy_koszyk.size()+" Which is NOT Expected", Status.FAIL);
				}
			}



			double ExpectedTotalPriceWithVat_AllCart = 0.00;

			for (int i=1;i<=Carts.size();i++) {
				// Verify ShipTo Row expanded by default
				WebElement ShipToToggle = Driver.findElement(By.xpath("//div[@class='row ship-to']["+i+"]//a"));

				if (ShipToToggle.getAttribute("class").equalsIgnoreCase("ship-to-toggle expanded")) {
					Report.updateTestLog(Action, "Cart "+i+ " Expanded By Default", Status.PASS);
				}else {
					Report.updateTestLog(Action, "Cart "+i+ " NOT Expanded By Default", Status.FAIL);
				}

				ShipToToggle.click();

				// Verify ShiTo Row Collapse
				if (ShipToToggle.getAttribute("class").equalsIgnoreCase("ship-to-toggle")) {

					Report.updateTestLog(Action, "Cart "+i+ " Toggle is Collapsed", Status.PASS);

					if (Driver.findElement(By.xpath("//div[@class='row ship-to']["+i+"]//div[@class='ship-to-full']")).isDisplayed()) {
						Report.updateTestLog(Action, "Cart "+i+ " is NOT Collapsed", Status.FAIL);
					}else {
						Report.updateTestLog(Action, "Cart "+i+ " is Collapsed", Status.PASS);

					}
				}else {
					Report.updateTestLog(Action, "Cart "+i+ " Toggle is NOT Collapsed", Status.FAIL);
				}



				ShipToToggle.click();

				// Verify ShipTo Row Expand
				if (ShipToToggle.getAttribute("class").equalsIgnoreCase("ship-to-toggle expanded")) {

					Report.updateTestLog(Action, "Cart "+i+ " Toggle is Expanded", Status.PASS);

					if (Driver.findElement(By.xpath("//div[@class='row ship-to']["+i+"]//div[@class='ship-to-full']")).isDisplayed()) {
						Report.updateTestLog(Action, "Cart "+i+ " is Expanded", Status.PASS);
					}else {
						Report.updateTestLog(Action, "Cart "+i+ " is NOT Expanded", Status.FAIL);
					}
				}else {
					Report.updateTestLog(Action, "Cart "+i+ " Toggle is NOT Expanded", Status.FAIL);
				}


				// Verify ShipTo and BillTo
				String ActualShipTo = Driver.findElement(By.xpath("//div[@class='row ship-to']["+i+"]//div[contains(@class,'cart-add-tlt-PL')]//span[contains(@class,'shpAddrAln')]")).getText();
				String ActualBillTo = Driver.findElement(By.xpath("(//div[@class='row ship-to']["+i+"]//span[contains(@class,'shpAddrAln')])[2]")).getText();

				for (String ExpectedShipTo : ShipToBillTo_Map.keySet()) {
					if(ActualShipTo.contains(ExpectedShipTo)) {
						String ExpectedBillTo = ShipToBillTo_Map.get(ExpectedShipTo);
						if (ActualBillTo.contains(ExpectedBillTo)) {
							Report.updateTestLog(Action, "Cart Created For "+ExpectedShipTo+" And Corresponding BillTo "+ExpectedBillTo, Status.PASS);
						}else {
							Report.updateTestLog(Action, "Cart is NOT Created For Provided ShipTo and BillTo", Status.FAIL);
						}

					}
				}


				List<WebElement> ProductRow = Driver.findElements(By.xpath("//div[@class='row ship-to']["+i+"]//div[contains(@class,'row product-item')]"));

				// Verify Total Product Per Cart displayed
				if(ProductRow.size()==Integer.parseInt(ProductPerCart)) {
					Report.updateTestLog(Action, "Expected Product Row Per Cart "+ProductPerCart+" And Actual Product Row Per Cart "+ProductRow.size(), Status.PASS);
				}else {
					Report.updateTestLog(Action, "Expected Product Row Per Cart "+ProductPerCart+" And Actual Product Row Per Cart "+ProductRow.size(), Status.FAIL);
				}

				double ExpectedTotalPriceWithVat_PerCart=0.00;

				// Verify each product row
				for (int j=1;j<=ProductRow.size();j++) {

					// Verify Product Name and PDP
					WebElement ProductNameLink = Driver.findElement(By.xpath("//div[@class='row ship-to']["+i+"]//div[contains(@class,'row product-item')]["+j+"]//a[@class='product-name']"));
					String ProductNameOnCartPage = ProductNameLink.getText();

					ProductNameLink.click();

					WebDriverWait wait4 = new WebDriverWait(Driver,10);
					wait4.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
							.executeScript("return document.readyState")));

					WebElement PDP = Driver.findElement(By.xpath("//span[contains(text(),'Dane produktu')]"));
					String ProductNameOnPDP = Driver.findElement(By.xpath("//h1[@id='productDetail-name']")).getText();

					if (PDP.isDisplayed() && ProductNameOnPDP.equalsIgnoreCase(ProductNameOnCartPage)) {
						Report.updateTestLog(Action, "PDP Opened For Product Name "+ProductNameOnCartPage, Status.PASS);
					}else {
						Report.updateTestLog(Action, "PDP NOT Opened For Product Name "+ProductNameOnCartPage, Status.FAIL);
					}


					Driver.navigate().back();

					WebDriverWait wait5 = new WebDriverWait(Driver,10);
					wait5.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
							.executeScript("return document.readyState")));


					// Verify Product Price With/WithOut VAT
					String PriceWithVat = Driver.findElement(By.xpath("//div[@class='row ship-to']["+i+"]//div[contains(@class,'row product-item')]["+j+"]//div[contains(@class,'withoutvatcheckout-PL')]")).getText();
					String ProductQuantity = Driver.findElement(By.xpath("//div[@class='row ship-to']["+i+"]//div[contains(@class,'row product-item')]["+j+"]//div[contains(@class,'summary-qty-val-PL')]")).getText();
					String ActualTotalPriceWithVat_PerProduct = Driver.findElement(By.xpath("//div[@class='row ship-to']["+i+"]//div[contains(@class,'row product-item')]["+j+"]//div[contains(@class,'product-total')]")).getText();

					PriceWithVat = PriceWithVat.replace(",", ".");
					String [] PriceWithVatArray = PriceWithVat.split(" ");
					double PriceWithVat_Double = Double.parseDouble(PriceWithVatArray[0]);

					int ProductQuantity_Int = Integer.parseInt(ProductQuantity);

					double ExpectedTotalPriceWithVat_PerProduct =  Math.round((PriceWithVat_Double*ProductQuantity_Int) * 100.0) / 100.0;

					ActualTotalPriceWithVat_PerProduct = ActualTotalPriceWithVat_PerProduct.replace(",", ".");
					String [] ActualTotalPriceWithVat_PerProductArray = ActualTotalPriceWithVat_PerProduct.split(" ");

					String ActualTotalProductPriceWithVat_String="";

					for (int k=0;k<=ActualTotalPriceWithVat_PerProductArray.length-2;k++) {
						ActualTotalProductPriceWithVat_String = ActualTotalProductPriceWithVat_String+ActualTotalPriceWithVat_PerProductArray[k];
					}

					double ActualTotalPriceWithVat_PerProduct_Double = Double.parseDouble(ActualTotalProductPriceWithVat_String);

					if (ExpectedTotalPriceWithVat_PerProduct==ActualTotalPriceWithVat_PerProduct_Double) {
						Report.updateTestLog(Action, "Expected TotalPriceWithVat "+ExpectedTotalPriceWithVat_PerProduct+" And Actual TotalPriceWithVat "+ActualTotalPriceWithVat_PerProduct_Double, Status.PASS);
					}else {
						Report.updateTestLog(Action, "Expected TotalPriceWithVat "+ExpectedTotalPriceWithVat_PerProduct+" And Actual TotalPriceWithVat "+ActualTotalPriceWithVat_PerProduct_Double, Status.FAIL);
					}

					// Verify Total Price Per Cart
					ExpectedTotalPriceWithVat_PerCart = Math.round((ExpectedTotalPriceWithVat_PerCart+ExpectedTotalPriceWithVat_PerProduct) * 100.0) / 100.0;

				}

				// Verify Total Price Per Cart
				String ActualTotalPriceWithVat_PerCart = Driver.findElement(By.xpath("//div[@class='row ship-to']["+i+"]//div[contains(@class,'bottom-cost-val-PL')]")).getText();

				ActualTotalPriceWithVat_PerCart = ActualTotalPriceWithVat_PerCart.replace(",", ".");
				String [] ActualTotalPriceWithVat_PerCartArray = ActualTotalPriceWithVat_PerCart.split(" ");

				String ActualTotalPriceWithVat_PerCart_String="";

				for (int l=0;l<=ActualTotalPriceWithVat_PerCartArray.length-2;l++) {
					ActualTotalPriceWithVat_PerCart_String = ActualTotalPriceWithVat_PerCart_String+ActualTotalPriceWithVat_PerCartArray[l];
				}

				double ActualTotalPriceWithVat_PerCart_Double = Double.parseDouble(ActualTotalPriceWithVat_PerCart_String);

				if (ExpectedTotalPriceWithVat_PerCart==ActualTotalPriceWithVat_PerCart_Double) {
					Report.updateTestLog(Action, "Expected TotalPriceWithVat For Cart "+i+" is "+ExpectedTotalPriceWithVat_PerCart+" And Actual TotalPriceWithVat For Cart "+i+" is "+ActualTotalPriceWithVat_PerCart_Double, Status.PASS);
				}else {
					Report.updateTestLog(Action, "Expected TotalPriceWithVat For Cart "+i+" is "+ExpectedTotalPriceWithVat_PerCart+" And Actual TotalPriceWithVat For Cart "+i+" is "+ActualTotalPriceWithVat_PerCart_Double, Status.FAIL);
				}

				// Verify Total Price for ALL Carts
				ExpectedTotalPriceWithVat_AllCart = Math.round((ExpectedTotalPriceWithVat_AllCart+ExpectedTotalPriceWithVat_PerCart) * 100.0) / 100.0;

			}

			// Verify Total Price for ALL Carts
			String ActualTotalPriceWithVat_AllCart = Driver.findElement(By.xpath("//div[@class='row cart-bottom']//div[contains(@class,'finalCostVal-PL')]")).getText(); 

			ActualTotalPriceWithVat_AllCart = ActualTotalPriceWithVat_AllCart.replace(",", ".");
			String [] ActualTotalPriceWithVat_AllCartArray = ActualTotalPriceWithVat_AllCart.split(" ");

			String ActualTotalPriceWithVat_AllCart_String="";

			for (int m=0;m<=ActualTotalPriceWithVat_AllCartArray.length-2;m++) {
				ActualTotalPriceWithVat_AllCart_String = ActualTotalPriceWithVat_AllCart_String+ActualTotalPriceWithVat_AllCartArray[m];
			}

			double ActualTotalPriceWithVat_AllCart_Double = Double.parseDouble(ActualTotalPriceWithVat_AllCart_String);


			if (ExpectedTotalPriceWithVat_AllCart==ActualTotalPriceWithVat_AllCart_Double) {
				Report.updateTestLog(Action, "Expected TotalPriceWithVat_AllCart "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPriceWithVat_AllCart "+ActualTotalPriceWithVat_AllCart_Double, Status.PASS);
			}else {
				Report.updateTestLog(Action, "Expected TotalPriceWithVat_AllCart "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPriceWithVat_AllCart "+ActualTotalPriceWithVat_AllCart_Double, Status.FAIL);
			}

			// Verify total Cart Price displayed at Cart Header
			String ActualTotalPriceAtCartHeader = Driver.findElement(By.xpath("//span[@id='cartTotalNonZero']/span[contains(@class,'count')]/span[2]")).getText();

			ActualTotalPriceAtCartHeader = ActualTotalPriceAtCartHeader.replace(",", ".");
			String [] ActualTotalPriceAtCartHeaderArray = ActualTotalPriceAtCartHeader.split(" ");

			String ActualTotalPriceAtCartHeader_String="";

			for (int m=0;m<=ActualTotalPriceAtCartHeaderArray.length-2;m++) {
				ActualTotalPriceAtCartHeader_String = ActualTotalPriceAtCartHeader_String+ActualTotalPriceAtCartHeaderArray[m];
			}

			double ActualTotalPriceAtCartHeader_Double = Double.parseDouble(ActualTotalPriceAtCartHeader_String);

			if (ExpectedTotalPriceWithVat_AllCart==ActualTotalPriceAtCartHeader_Double) {
				Report.updateTestLog(Action, "Expected TotalPrice_At Cart Header "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPrice_At Cart Header "+ActualTotalPriceAtCartHeader_Double, Status.PASS);
			}else {
				Report.updateTestLog(Action, "Expected TotalPrice_At Cart Header "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPrice_At Cart Header "+ActualTotalPriceAtCartHeader_Double, Status.FAIL);
			}

			////////////////////////////



		}catch(Exception e) {
			e.printStackTrace();
		}


	}

	@Action(object = ObjectType.BROWSER, desc = "Enter OrderCount,CartCount,ProductPerCart,ShipTo-BillTo [<Data>]", input = InputType.YES)
	public void verifyOrderPage_PL() {
		
		String[] InputData = Data.split(",");

		String OrderCount = InputData[0];
		String CartCount = InputData[1];
		String ProductPerCart = InputData[2];

		HashMap<String,String> ShipToBillTo_Map = new HashMap<String,String>();

		for (int a=3;a<=InputData.length-1;a++) {

			String[] ShipToBillToArray = InputData[a].split("-");
			ShipToBillTo_Map.put(ShipToBillToArray[0], ShipToBillToArray[1]);

		}
		
        try {
			
        	Driver.findElement(By.xpath("//button[contains(@class,'place-order-pop')]")).click();
        	Thread.sleep(10000);
			Report.updateTestLog(Action, "Place Order Button is Clicked", Status.PASS);
			
		} catch(Exception f) {
			
			Report.updateTestLog(Action, "Place Order Button is not Clicked", Status.FAIL);
			
		}
		
		


		try{

			

			WebDriverWait wait = new WebDriverWait(Driver,10);
			wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
					.executeScript("return document.readyState")));

			// Verify Header Text, Order Confirmation No and Order Confirmation Date
			String ConfirmOrderHeader = Driver.findElement(By.xpath("//p[contains(@class,'order-confirm-head')]")).getText().trim();
			WebElement OrderConfirmationNumber = Driver.findElement(By.xpath("//p[@id='order-confirmation-number']"));
			WebElement OrderConfirmationDate = Driver.findElement(By.xpath("//p[@id='order-confirmation-date']"));

			String[] OrderConfirmationNumberArray = Driver.findElement(By.xpath("//p[@id='order-confirmation-number']/strong")).getText().trim().split(" ");
			String[] OrderConfirmationDateArray = OrderConfirmationDate.getText().trim().split(":");


			if (ConfirmOrderHeader.equalsIgnoreCase("Potwierdzenie zamówienia") && OrderConfirmationNumber.isDisplayed() && OrderConfirmationDate.isDisplayed()) {
				Report.updateTestLog(Action, "Order Placed Successfully. Order Confirmation No - "+OrderConfirmationNumberArray[2]+" | Order Confirmation Date - "+OrderConfirmationDateArray[1], Status.PASS);
			}else {
				Report.updateTestLog(Action, "Order Place is NOT Successful", Status.FAIL);
			}

			// Verify Drukuj button

			List<WebElement> DrukujButtons = Driver.findElements(By.xpath("//button[contains(text(),'Drukuj')]"));

			if (DrukujButtons.size()==2) {
				Report.updateTestLog(Action, "Total Drukuj button count: Expected is 2 And Actual is "+DrukujButtons.size(), Status.PASS);
			}else {
				Report.updateTestLog(Action, "Total Drukuj button count: Expected is 2 And Actual is "+DrukujButtons.size(), Status.FAIL);
			}
			
			


			/////////////////////

			List<WebElement> Carts = Driver.findElements(By.xpath("//div[@class='row ship-to newpage_eachOrder']"));

			// Verify Total Cart displayed
			if(Carts.size()==Integer.parseInt(CartCount)) {
				Report.updateTestLog(Action, "Expected Cart Count "+CartCount+" And Actual Cart Count "+Carts.size(), Status.PASS);
			}else {
				Report.updateTestLog(Action, "Expected Cart Count "+CartCount+" And Actual Cart Count "+Carts.size(), Status.FAIL);
			}

			// Verify Total "Nowy koszyk" section count
			if (ShipToBillTo_Map.size()>1) {
				List<WebElement> Nowy_koszyk = Driver.findElements(By.xpath("//div[contains(text(),'Nowy koszyk')]"));

				if(Nowy_koszyk.size()==Integer.parseInt(OrderCount)-1) {
					Report.updateTestLog(Action, "Total Nowy_koszyk Section Count is "+Nowy_koszyk.size()+" Which is Expected", Status.PASS);
				}else {
					Report.updateTestLog(Action, "Total Nowy_koszyk Section Count is "+Nowy_koszyk.size()+" Which is NOT Expected", Status.FAIL);
				}
			}



			double ExpectedTotalPriceWithVat_AllCart = 0.00;

			ArrayList<String> OrderNumberList = new ArrayList<String>();

			for (int i=1;i<=Carts.size();i++) {

				// Get Order Number
				WebElement OrderNumber = Driver.findElement(By.xpath("//div[@class='row ship-to newpage_eachOrder']["+i+"]//h2[contains(@class,'ship-to-title')]"));
				String OrderNumberString = OrderNumber.getText();
				String[] OrderNumberArray = OrderNumberString.split("\\s+");
				OrderNumberList.add(OrderNumberArray[1]);

				if(OrderNumber.isDisplayed()) {
					Report.updateTestLog(Action, "Order Number for Cart "+i+" is -->"+OrderNumberArray[1], Status.PASS);
				}else {
					Report.updateTestLog(Action, "Order Number for Cart "+i+" NOT Present", Status.FAIL);
				}



				// Verify ShipTo and BillTo
				String ActualShipTo = Driver.findElement(By.xpath("//div[@class='row ship-to newpage_eachOrder']["+i+"]//div[contains(@class,'cart-add-tlt-PL')]//span[contains(@class,'shpAddrAln')]")).getText();
				String ActualBillTo = Driver.findElement(By.xpath("(//div[@class='row ship-to newpage_eachOrder']["+i+"]//span[contains(@class,'shpAddrAln')])[2]")).getText();

				for (String ExpectedShipTo : ShipToBillTo_Map.keySet()) {
					if(ActualShipTo.contains(ExpectedShipTo)) {
						String ExpectedBillTo = ShipToBillTo_Map.get(ExpectedShipTo);
						if (ActualBillTo.contains(ExpectedBillTo)) {
							Report.updateTestLog(Action, "Cart Created For "+ExpectedShipTo+" And Corresponding BillTo "+ExpectedBillTo, Status.PASS);
						}else {
							Report.updateTestLog(Action, "Cart is NOT Created For Provided ShipTo and BillTo", Status.FAIL);
						}

					}
				}


				List<WebElement> ProductRow = Driver.findElements(By.xpath("//div[@class='row ship-to newpage_eachOrder']["+i+"]//div[contains(@class,'row product-item')]"));

				// Verify Total Product Per Cart displayed
				if(ProductRow.size()==Integer.parseInt(ProductPerCart)) {
					Report.updateTestLog(Action, "Expected Product Row Per Cart "+ProductPerCart+" And Actual Product Row Per Cart "+ProductRow.size(), Status.PASS);
				}else {
					Report.updateTestLog(Action, "Expected Product Row Per Cart "+ProductPerCart+" And Actual Product Row Per Cart "+ProductRow.size(), Status.FAIL);
				}

				double ExpectedTotalPriceWithVat_PerCart=0.00;

				// Verify each product row
				for (int j=1;j<=ProductRow.size();j++) {

					// Verify Product Name and PDP
					WebElement ProductNameLink = Driver.findElement(By.xpath("//div[@class='row ship-to newpage_eachOrder']["+i+"]//div[contains(@class,'row product-item')]["+j+"]//a[@class='product-name']"));
					String ProductNameOnCartPage = ProductNameLink.getText();

					ProductNameLink.click();

					WebDriverWait wait4 = new WebDriverWait(Driver,10);
					wait4.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
							.executeScript("return document.readyState")));

					WebElement PDP = Driver.findElement(By.xpath("//span[contains(text(),'Dane produktu')]"));
					String ProductNameOnPDP = Driver.findElement(By.xpath("//h1[@id='productDetail-name']")).getText();

					if (PDP.isDisplayed() && ProductNameOnPDP.equalsIgnoreCase(ProductNameOnCartPage)) {
						Report.updateTestLog(Action, "PDP Opened For Product Name "+ProductNameOnCartPage, Status.PASS);
					}else {
						Report.updateTestLog(Action, "PDP NOT Opened For Product Name "+ProductNameOnCartPage, Status.FAIL);
					}


					Driver.navigate().back();

					WebDriverWait wait1 = new WebDriverWait(Driver,10);
					wait1.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
							.executeScript("return document.readyState")));


					// Verify Product Price With/WithOut VAT
					String PriceWithVat = Driver.findElement(By.xpath("//div[@class='row ship-to newpage_eachOrder']["+i+"]//div[contains(@class,'row product-item')]["+j+"]//span[contains(@class,'cnd-price-print-PL')]")).getText();
					String ProductQuantity = Driver.findElement(By.xpath("//div[@class='row ship-to newpage_eachOrder']["+i+"]//div[contains(@class,'row product-item')]["+j+"]//div[contains(@class,'pack-quantity')]")).getText();
					String ActualTotalPriceWithVat_PerProduct = Driver.findElement(By.xpath("//div[@class='row ship-to newpage_eachOrder']["+i+"]//div[contains(@class,'row product-item')]["+j+"]//div[contains(@class,'totalhtvalprint-PL')]")).getText();

					PriceWithVat = PriceWithVat.replace(",", ".");
					String [] PriceWithVatArray = PriceWithVat.split(" ");
					double PriceWithVat_Double = Double.parseDouble(PriceWithVatArray[0]);

					int ProductQuantity_Int = Integer.parseInt(ProductQuantity);

					double ExpectedTotalPriceWithVat_PerProduct =  Math.round((PriceWithVat_Double*ProductQuantity_Int) * 100.0) / 100.0;

					ActualTotalPriceWithVat_PerProduct = ActualTotalPriceWithVat_PerProduct.replace(",", ".");
					String [] ActualTotalPriceWithVat_PerProductArray = ActualTotalPriceWithVat_PerProduct.split(" ");

					String ActualTotalProductPriceWithVat_String="";

					for (int k=0;k<=ActualTotalPriceWithVat_PerProductArray.length-2;k++) {
						ActualTotalProductPriceWithVat_String = ActualTotalProductPriceWithVat_String+ActualTotalPriceWithVat_PerProductArray[k];
					}

					double ActualTotalPriceWithVat_PerProduct_Double = Double.parseDouble(ActualTotalProductPriceWithVat_String);

					if (ExpectedTotalPriceWithVat_PerProduct==ActualTotalPriceWithVat_PerProduct_Double) {
						Report.updateTestLog(Action, "Expected TotalPriceWithVat "+ExpectedTotalPriceWithVat_PerProduct+" And Actual TotalPriceWithVat "+ActualTotalPriceWithVat_PerProduct_Double, Status.PASS);
					}else {
						Report.updateTestLog(Action, "Expected TotalPriceWithVat "+ExpectedTotalPriceWithVat_PerProduct+" And Actual TotalPriceWithVat "+ActualTotalPriceWithVat_PerProduct_Double, Status.FAIL);
					}

					// Verify Total Price Per Cart
					ExpectedTotalPriceWithVat_PerCart = Math.round((ExpectedTotalPriceWithVat_PerCart+ExpectedTotalPriceWithVat_PerProduct) * 100.0) / 100.0;

				}

				// Verify Total Price Per Cart
				String ActualTotalPriceWithVat_PerCart = Driver.findElement(By.xpath("//div[@class='row ship-to newpage_eachOrder']["+i+"]//div[contains(@class,'bottom-cost-val-PL')]")).getText();

				ActualTotalPriceWithVat_PerCart = ActualTotalPriceWithVat_PerCart.replace(",", ".");
				String [] ActualTotalPriceWithVat_PerCartArray = ActualTotalPriceWithVat_PerCart.split(" ");

				String ActualTotalPriceWithVat_PerCart_String="";

				for (int l=0;l<=ActualTotalPriceWithVat_PerCartArray.length-2;l++) {
					ActualTotalPriceWithVat_PerCart_String = ActualTotalPriceWithVat_PerCart_String+ActualTotalPriceWithVat_PerCartArray[l];
				}

				double ActualTotalPriceWithVat_PerCart_Double = Double.parseDouble(ActualTotalPriceWithVat_PerCart_String);

				if (ExpectedTotalPriceWithVat_PerCart==ActualTotalPriceWithVat_PerCart_Double) {
					Report.updateTestLog(Action, "Expected TotalPriceWithVat For Cart "+i+" is "+ExpectedTotalPriceWithVat_PerCart+" And Actual TotalPriceWithVat For Cart "+i+" is "+ActualTotalPriceWithVat_PerCart_Double, Status.PASS);
				}else {
					Report.updateTestLog(Action, "Expected TotalPriceWithVat For Cart "+i+" is "+ExpectedTotalPriceWithVat_PerCart+" And Actual TotalPriceWithVat For Cart "+i+" is "+ActualTotalPriceWithVat_PerCart_Double, Status.FAIL);
				}

				// Verify Total Price for ALL Carts
				ExpectedTotalPriceWithVat_AllCart = Math.round((ExpectedTotalPriceWithVat_AllCart+ExpectedTotalPriceWithVat_PerCart) * 100.0) / 100.0;

			}


			// Verify Total Price for ALL Carts
			String ActualTotalPriceWithVat_AllCart = Driver.findElement(By.xpath("//div[@class='row cart-bottom']//div[contains(@class,'checkSumFinalCostVal-PL')]")).getText(); 

			ActualTotalPriceWithVat_AllCart = ActualTotalPriceWithVat_AllCart.replace(",", ".");
			String [] ActualTotalPriceWithVat_AllCartArray = ActualTotalPriceWithVat_AllCart.split(" ");

			String ActualTotalPriceWithVat_AllCart_String="";

			for (int m=0;m<=ActualTotalPriceWithVat_AllCartArray.length-2;m++) {
				ActualTotalPriceWithVat_AllCart_String = ActualTotalPriceWithVat_AllCart_String+ActualTotalPriceWithVat_AllCartArray[m];
			}

			double ActualTotalPriceWithVat_AllCart_Double = Double.parseDouble(ActualTotalPriceWithVat_AllCart_String);


			if (ExpectedTotalPriceWithVat_AllCart==ActualTotalPriceWithVat_AllCart_Double) {
				Report.updateTestLog(Action, "Expected TotalPriceWithVat_AllCart "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPriceWithVat_AllCart "+ActualTotalPriceWithVat_AllCart_Double, Status.PASS);
			}else {
				Report.updateTestLog(Action, "Expected TotalPriceWithVat_AllCart "+ExpectedTotalPriceWithVat_AllCart+" And Actual TotalPriceWithVat_AllCart "+ActualTotalPriceWithVat_AllCart_Double, Status.FAIL);
			}


			////////////////////////////


			// Verify Orders on Order History Page
			//Driver.findElement(By.xpath("//a[contains(text(),'PrzeglÃ„â€¦daj historiÃ„â„¢ zamÃƒÂ³wienia')]")).click();
			Driver.findElement(By.xpath("//a[contains(@href,'orders') and not(@id='order-history-active')]")).click();

			WebDriverWait wait2 = new WebDriverWait(Driver,10);
			wait2.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
					.executeScript("return document.readyState")));

			for (int x=0;x<OrderNumberList.size();x++) {
				String OrderNumber = OrderNumberList.get(x);

				Driver.findElement(By.xpath("//input[@id='search_text_order']")).clear();
				Driver.findElement(By.xpath("//input[@id='search_text_order']")).sendKeys(OrderNumber);

				Driver.findElement(By.xpath("//button[@id='searchtextBtn_order']")).click();
				
				Thread.sleep(5000);

				String SearchResultOrder = Driver.findElement(By.xpath("//div[@class='row']//div[contains(@class,'reservation-number')]//a")).getText();

				if(SearchResultOrder.equalsIgnoreCase(OrderNumber)) {
					Report.updateTestLog(Action, "Order Number "+OrderNumber+" is Present on Order History Page ", Status.PASS);
				}else {
					Report.updateTestLog(Action, "Order Number "+OrderNumber+" is NOT Present on Order History Page ", Status.FAIL);
				}
			}

			// Back office Login
			Driver.get("https://global-uat1-backoffice.ecommerce.gsk.com/backoffice/login.zul");
			
			Thread.sleep(2000);					
			Driver.findElement(By.xpath("//input[@name='j_username']")).sendKeys("admin");
			Driver.findElement(By.xpath("//input[@name='j_password']")).sendKeys("nimda");
			
			Driver.findElement(By.xpath("//button[contains(text(),'Login')]")).click();
			
			Thread.sleep(5000);
			Report.updateTestLog(Action, "Backoffice Page  ", Status.DONE);
			Driver.findElement(By.xpath("//button[contains(text(),'PROCEED')]")).click();
			
			Thread.sleep(15000);
						
			WebElement Administration_Cockpit = Driver.findElement(By.xpath("//div[contains(text(),'Administration Cockpit')]"));	
			
			if(Administration_Cockpit.isDisplayed()) {
				Report.updateTestLog(Action, "Backoffice Login Successful ", Status.PASS);
			}else {
				Report.updateTestLog(Action, "Backoffice Login Fail ", Status.FAIL);
			}
				
			
			// Verify Orders in Backoffice
		Driver.findElement(By.xpath("//div[contains(@class, 'yw-perspective-container')]//input[@class='z-bandbox-input']")).sendKeys("Orders");
		Thread.sleep(2000);
		Driver.findElement(By.xpath("//span[text()='Orders']")).click();
		Report.updateTestLog(Action, "Clicked on Orders Link ", Status.DONE);
		Thread.sleep(6000);
		
		for (String Order : OrderNumberList ) {
			Driver.findElement(By.xpath("//input[@class='z-bandbox-input z-bandbox-rightedge']")).clear();
			Driver.findElement(By.xpath("//input[@class='z-bandbox-input z-bandbox-rightedge']")).sendKeys(Order);
			Driver.findElement(By.xpath("//div[contains(@class, 'yw-perspective-container')]//button[contains(text(),'Search')]")).click();
			Thread.sleep(3000);
			WebElement OrderSearchResult = Driver.findElement(By.xpath("//span[contains(text(),'"+Order+"')]"));
			if (OrderSearchResult.isDisplayed()) {
				Report.updateTestLog(Action, "Order -->"+Order+" Present in Backoffice", Status.PASS);
			}else {
				Report.updateTestLog(Action, "Order -->"+Order+" NOT Present in Backoffice", Status.PASS);
			}
					
			
		}
		
		
		}catch(Exception e) {
			e.printStackTrace();
		}


	}
	


	@Action(object = ObjectType.BROWSER, desc = "Edit shipto on Address Page", input = InputType.NO)
	public void editShipToAddressPage_PL() {
    String Account_status=null;
    
    By adress_count =  By.xpath("//span[@class='addresscount']");
    
    boolean Is_checked=true;
		try {

			Thread.sleep(10000);
			
			String name=Driver.findElement(adress_count).getText();
			
			Report.updateTestLog(Action, " Total number of shipto"+name, Status.PASS);
			
			
			

			// Making all the status check boxes unchecked
			for (int j =1;j<=4;j++) {
				
				
				Account_status=Driver.findElement(By.xpath("//div[@class='col-md-12 col-sm-12']/div["+j+"]/label")).getText();
				
				Is_checked=	Driver.findElement(By.xpath("//div[@class='col-md-12 col-sm-12']/div["+j+"]/input")).isSelected();
				
				if((Account_status.equalsIgnoreCase("Aktywny") && Is_checked==true)   )
					
				{
					Report.updateTestLog(Action, Account_status + " Selected ", Status.DONE);
					
					Driver.findElement(By.xpath("//div[@class='col-md-12 col-sm-12']/div["+j+"]/input")).click();
					
					Report.updateTestLog(Action, Driver.findElement(By.xpath("//div[@class='col-md-12 col-sm-12']/div["+j+"]/input")).isSelected() + " unselected ", Status.DONE);
					
					
				}else
			
				
             if(  (Account_status.equalsIgnoreCase("W OCZEKIWANIU") && Is_checked==true)    )
					
				{
					Report.updateTestLog(Action, Account_status + " Selected ", Status.DONE);
					
					Driver.findElement(By.xpath("//div[@class='col-md-12 col-sm-12']/div["+j+"]/input")).click();
					
					Report.updateTestLog(Action, Driver.findElement(By.xpath("//div[@class='col-md-12 col-sm-12']/div["+j+"]/input")).isSelected() + " unselected ", Status.DONE);
					
					
				}	else	
				
				
if((Account_status.equalsIgnoreCase("Nieaktywny") && Is_checked==true)||  (Account_status.equalsIgnoreCase("WNIOSEK") && Is_checked==true)    )
					
				{
					Report.updateTestLog(Action, Account_status + " Selected ", Status.DONE);
					
					Driver.findElement(By.xpath("//div[@class='col-md-12 col-sm-12']/div["+j+"]/input")).click();
					Report.updateTestLog(Action, Driver.findElement(By.xpath("//div[@class='col-md-12 col-sm-12']/div["+j+"]/input")).isSelected() + " unselected ", Status.DONE);
							
					
				} else
					
					if( (Account_status.equalsIgnoreCase("WNIOSEK") && Is_checked==true)   )
						
					{
						Report.updateTestLog(Action, Account_status + " Selected ", Status.DONE);
						
						Driver.findElement(By.xpath("//div[@class='col-md-12 col-sm-12']/div["+j+"]/input")).click();
						Report.updateTestLog(Action, Driver.findElement(By.xpath("//div[@class='col-md-12 col-sm-12']/div["+j+"]/input")).isSelected() + " unselected ", Status.DONE);
								
						
					}



//Checking all the status check boxes and the data dispalying acording to that
for (int k =1;k<=4;k++) {

	
	Driver.findElement(By.xpath("//div[@class='col-md-12 col-sm-12']/div["+k+"]/input")).click();
	try {
		
	
	Account_status=Driver.findElement(By.xpath("//div[@id='addressesList']/div[not(contains(@style, 'display: none;')) and @class='row addresslist-content accountManageAddressListTr']["+k+"]/div[11]")).getText();
	
	if((Account_status.equalsIgnoreCase("Aktywny")) )
			
			{
		
		// Get ship to count based of check box selection
		List<WebElement> rowcount = (Driver.findElements(By.xpath("//div[@id='addressesList']/div[not(contains(@style, 'display: none;')) and @class='row addresslist-content accountManageAddressListTr']")));
		int active_rowcount = rowcount.size();
		
		Report.updateTestLog(Action, Account_status + " :: Count ::  " +active_rowcount, Status.PASS);
		if(active_rowcount>0) {
			String shipToNumber = Driver.findElement(By.xpath("//div[@id='addressesList']/div[not(contains(@style, 'display: none;')) and @class='row addresslist-content accountManageAddressListTr'][1]/div[9]")).getText();

			Driver.findElement(By.xpath("//div[@class='col-md-12 col-sm-12']/div["+k+"]/input")).click();
			
			
			
			Report.updateTestLog(Action,  " shipToNumber  ::  " +shipToNumber, Status.DONE);
			
			
			Report.updateTestLog(Action, Driver.findElement(By.xpath("//div[@class='col-md-12 col-sm-12']/div["+k+"]/input")).isSelected() + " unselected ", Status.DONE);
			
		} else
		
  if((Account_status.equalsIgnoreCase("W OCZEKIWANIU")))
		{
	
	
		} else
			
			if(Account_status.equalsIgnoreCase("Nieaktywny"))
			{
				
			} else
				if (Account_status.equalsIgnoreCase("WNIOSEK"))
				{
					
				}
		else {
			
			Report.updateTestLog(Action, Account_status + " :: Count ::  " +active_rowcount, Status.FAIL);
		}
		
		
		
		
		
			}
	} catch (Exception e) {
		Report.updateTestLog(Action, Driver.findElement(By.xpath("//div[@class='col-md-12 col-sm-12']/div["+k+"]/label")).getText() +" :::: Failed ", Status.DONE);
	}
		
	
	
	
	
	
	
	
}




				
				
			}

				


		} catch (Exception e) {
			Report.updateTestLog(Action,  " Selection failed  " , Status.FAIL);
		}		
	}
	
	
	
	
	/* ************************************************ Activeshipto ***************************** */
	
	@Action(object = ObjectType.BROWSER, desc = "Get active shipTo from addresses tab", input = InputType.NO)
	public void getActiveShipToNumber_PL() throws InterruptedException {
		List<WebElement> findElements = Driver.findElements(By.xpath("//div[@id='addressesList']/div[contains(@class,'row addresslist-content')]")); 
		List<String> e1 = new ArrayList<String>();
		int i=1; 
		for (WebElement webElement:findElements){
		String b = "";
			//System.out.println(Driver.findElement(By.xpath("//tbody/tr[" + i + "]/td[6]")).getText());
			if (Driver.findElement(By.xpath("(//div[@id='addressesList']/div[contains(@class,'row addresslist-content')]/div[11])[" + i + "]")).getText().contains("AKTYWNY")) { 
																											 
				String text =
				Driver.findElement(By.xpath("(//div[@id='addressesList']/div[contains(@class,'row addresslist-content')]/div[9])[" + i + "]")).getText();
				b=text.toString();
				/*
				 * String[] split = text.split(" "); String a = split[3].toString(); String[]
				 * split2 = a.split("");
				 * 
				 * for (int j = 0; j < 10; j++) { b = b + split2[j].toString(); }
				 */
				System.out.println(b);
				e1.add(b);
			}
			i = i + 1;

		}
		Driver.findElement(By.id("purchase-products-active")).click(); 
		  Thread.sleep(10000);
		for (String string : e1) {
			System.out.println(string);

		  Thread.sleep(10000);
		 Driver.findElement(By.id("search-ship-to-field")).sendKeys(string);
		 
		// ((JavascriptExecutor) Driver).executeScript("arguments[0].scrollIntoView(true);",  Driver.findElement(By.xpath("//span[contains(text(),'1100551403')]")));
		 Driver.findElement(By.xpath("//span[contains(text(),'"+string+"')]")).click();
		 Driver.findElement(By.xpath("//button[@id='orderForThisAddressBtn']")).click();
		 
		 Thread.sleep(10000);
		 if(Driver.findElement(By.xpath("//*[@id='select-shipTo']/div/div[1]/div[2]")).getText().contains("Not valid") || Driver.findElement(By.xpath("//*[@id='select-shipTo']/div/div[1]/div[2]")).getText().contains("Due to expire on") || Driver.findElement(By.xpath("//*[@id='select-shipTo']/div/div[1]/div[2]")).getText().contains("Class of trade:FEDERAL")) {
			 
			 Driver.findElement(By.id("changeShipToLink")).click();
			 System.out.println("state licence not valid");
		 }else {
			 try {
				// userData.getData("Data", "Active ShipTo");
				 userData.putData("OrderPage", "ShipTo", string); 
				 Report.updateTestLog(Action, "Active Shipto : "+string, Status.PASS);
			} catch (Exception e) {
				
			}
			 
			
			break;
		 }
		}
	}
	

	
	@Action(object = ObjectType.BROWSER, desc = "click Custom element [<Data>]", input = InputType.YES)
	public void clickNDCInBackoffice_PL() throws InterruptedException {
		Thread.sleep(10000);
		WebElement findElement = Driver.findElement(By.xpath(Data));
		
	findElement.click();
	System.out.println(Data);
	}

	
	@Action(object = ObjectType.BROWSER, desc = "Removing DiscountProduct", input = InputType.NO)
	public void removeDiscountProduct_PL() throws InterruptedException {
		Thread.sleep(10000);
		List<WebElement> discount=null;
		try {
		 discount =Driver.findElements(By.xpath("//strong[contains(text(),'WYŚWIETL RABATY')]"));
		 Report.updateTestLog(Action,"1st No WYŚWIETL RABATY avialabe   "+discount.size(), Status.DONE);
		}catch (Exception e) {
			Report.updateTestLog(Action," No WYŚWIETL RABATY avialabe   ", Status.DONE);
			}
		try {
			if(discount.size()==0) {
				
				Report.updateTestLog(Action," No WYŚWIETL RABATY avialabe Size ZERO   ", Status.DONE);	
			}
		
		for(int i =discount.size(); i>=0;i--)
		{
			
			
			Driver.findElement(By.xpath("(//strong[contains(text(),'WYŚWIETL RABATY')])["+i+"]/parent::a/parent::div/following::div[8]/a")).click();
			
			WebDriverWait wait = new WebDriverWait(Driver, 600);
	        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//h3[contains(text(),'Usuwanie produktu')])[2]")));

	        Report.updateTestLog(Action,"WYŚWIETL RABATY Cancle button  "+i, Status.PASS);	
	        
	        Driver.findElement(By.xpath("(//*[@id='removeProduct-confirm'])[2]")).click();
				/*
				 * if(i==discount.size())
				 * {Report.updateTestLog(Action,"WYŚWIETL RABATY Cancle button  "+i,
				 * Status.PASS);
				 * 
				 * break; }
				 */
			
			Thread.sleep(5000);
			
		}
		}catch (Exception e) {
			Report.updateTestLog(Action," No WYŚWIETL RABATY avialabe   ", Status.DONE);
			}
		
	}


	
	@Action(object = ObjectType.BROWSER, desc = "Removing Products from Page", input = InputType.NO)
	public void removeProduct_PL() throws InterruptedException {
		
		List<WebElement> removeproduct=null;
		Thread.sleep(10000);
		
		try {
			removeproduct =Driver.findElements(By.xpath("//a[@id='removeCartLink']"));
		// Report.updateTestLog(Action,"1st No WYŚWIETL RABATY avialabe   "+removeproduct.size(), Status.DONE);
		}catch (Exception e) {
			Report.updateTestLog(Action," No Products avilable ", Status.DONE);
		}
		
		try {
			if(removeproduct.size()==0) {
				
				Report.updateTestLog(Action," No Products avilable in Page", Status.DONE);	
			}
		
		for(int i =removeproduct.size(); i>=0;i--)
		{
			
			
			Driver.findElement(By.xpath("(//a[@id='removeCartLink'])["+i+"]")).click();
			
			WebDriverWait wait = new WebDriverWait(Driver, 600);
	        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//h3[contains(text(),'Usuwanie produktu')])[2]")));

	        Report.updateTestLog(Action,"WYŚWIETL RABATY Cancle button  "+i, Status.PASS);	
	        
	        Driver.findElement(By.xpath("(//*[@id='removeProduct-confirm'])[2]")).click();
				/*
				 * if(i==discount.size())
				 * {Report.updateTestLog(Action,"WYŚWIETL RABATY Cancle button  "+i,
				 * Status.PASS);
				 * 
				 * break; }
				 */
			
			Thread.sleep(5000);
			
		}
		}catch (Exception e) {
			//Report.updateTestLog(Action," No WYŚWIETL RABATY avialabe   ", Status.DONE);
			}
		
		
	
	}

	
	
	
	@Action(object = ObjectType.BROWSER, desc = "Checking Element Not Present Page", input = InputType.YES)
	public void Element_NotPresent_check() throws InterruptedException {
		String s=null;
		try {
			
			 s=Driver.findElement(By.xpath(Data)).getText();
			 Report.updateTestLog(Action," Available text ::   " +s, Status.PASS);
			
		}catch (Exception e) {
			Report.updateTestLog(Action," Element or text not Present in the Page   ", Status.PASS);
			}
		
		
		
	}
	
	

	@Action(object = ObjectType.BROWSER, desc = "FlexibleSearch in HAC sendkeys", input = InputType.YES)
	public void hac_FlexibleSearch() throws InterruptedException {
		
		try {
			
			WebDriverWait wait = new WebDriverWait(Driver, 600);
	        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//legend[normalize-space()='FlexibleSearch query']")));
	        
	        Report.updateTestLog(Action," Query is ::    "+Data, Status.DONE);
	        
	        Driver.findElement(By.xpath("//*[@id='flexibleSearchQueryWrapper']")).sendKeys(Data);
			System.out.println("data entr");
			
		}catch (Exception e) {
			Report.updateTestLog(Action," Failed to enter data ", Status.FAIL);
			
			try {
				Driver.findElement(By.xpath("//div[@id='flexibleSearchQueryWrapper']/div[@class='CodeMirror cm-s-default CodeMirror-wrap']/div[@class='CodeMirror-scroll']/div[1]")).sendKeys(Data);
				
			}catch (Exception e1) {
				Report.updateTestLog(Action," Failed to enter data e1 ", Status.FAIL);
				
			}
			
			}
		
	}
	
	
	@Action(object = ObjectType.BROWSER,desc = "Upload File for New Ship to by Giving File Name",input = InputType.YES)
    public void uploadFile_NewShipto_PL() throws IOException, AWTException, InterruptedException {
		
		String projectPath = System.getProperty("user.dir"); 
		System.out.println("Project Location is: "+ projectPath);
        String path = projectPath + File.separator + "Global New Shipto Upload Files" + File.separator + Data;        
        System.out.println(path);      
        
		StringSelection copiedPath = new StringSelection(path);
		
           Robot robot = new Robot();
           
             Toolkit.getDefaultToolkit().getSystemClipboard().setContents(copiedPath, null);
             Thread.sleep(5000);
             robot.keyPress(KeyEvent.VK_CONTROL);
             robot.keyPress(KeyEvent.VK_V);
             robot.keyRelease(KeyEvent.VK_CONTROL); 
             robot.keyRelease(KeyEvent.VK_V);
             robot.keyRelease(KeyEvent.VK_CONTROL); 
             robot.keyPress(KeyEvent.VK_ENTER);
             robot.keyRelease(KeyEvent.VK_ENTER);
    }
	
	@Action(object = ObjectType.BROWSER,desc = "Variable %formattedStartDate% is created with Formatted Date value based input as <+or-Date> from Current Date",input = InputType.YES)
    public void createDateFormatforStartDate_PL() {
		Locale locale = new Locale("en", "US");
		Date date = new Date();
		int formatDateValue = Integer.parseInt(Data);
		DateFormat df = new SimpleDateFormat("MMM dd, yy, 12:00:00 a");
		df.setTimeZone(TimeZone.getTimeZone("Poland"));
		Calendar cell = Calendar.getInstance();
		cell.setTime(date);
		cell.add(Calendar.DATE, formatDateValue);
		cell.set(Calendar.AM_PM, Calendar.AM);
		String Date = df.format(cell.getTime());
		addVar("%formattedStartDate%",Date);
		
		Report.updateTestLog(Action,Date +" is updated in variable %formattedStartDate%", Status.DONE);
		
	}
	
	@Action(object = ObjectType.BROWSER,desc = "Variable %formattedEndDate% is created with Formatted Date value based input as <+or-Date> from Current Date",input = InputType.YES)
    public void createDateFormatforEndDate_PL() {
		Locale locale = new Locale("en", "US");
		Date date = new Date();
		int formatDateValue = Integer.parseInt(Data);
		DateFormat df = new SimpleDateFormat("MMM dd, yy, 11:59:59 a");
		df.setTimeZone(TimeZone.getTimeZone("Poland"));
		Calendar cell = Calendar.getInstance();
		cell.setTime(date);
		cell.add(Calendar.DATE, formatDateValue);
		cell.set(Calendar.AM_PM, Calendar.PM);
		String Date = df.format(cell.getTime());		
		addVar("%formattedEndDate%",Date);
		
		Report.updateTestLog(Action,Date +" is updated in variable %formattedEndDate%", Status.DONE);
		
	}
	
	
	@Action(object = ObjectType.BROWSER,desc = "Extracts the Price with VAT and change the Decimal Format store in Variable %pricewithVAT% ",input = InputType.YES)
    public void extractNconvertPriceWithVAT_PL() {
		
		String productID = Data;
		
		String pathForWithVAT = "(//input[@id='selectedAllocation"+productID+"']//following-sibling::div//div[@class='priceDisplayColumn']//span[@class='price-green'])[2]";
		String pathForWithOutVAT = "(//input[@id='selectedAllocation"+productID+"']//following-sibling::div//div[@class='priceDisplayColumn']//span[@class='price-green'])[1]";
		String withoutVAT  = Driver.findElement(By.xpath(pathForWithOutVAT)).getText().split(" ")[0];
		String withVAT  = Driver.findElement(By.xpath(pathForWithVAT)).getText().split(" ")[0];
		
		addVar("%NotCovertedwithoutVATPrice%",withoutVAT);
		addVar("%NotCovertedwithVATPrice%",withVAT);
		
		String convertedDecimalFormatWithVAT = withVAT.replace(",", ".");			
		
		addVar("%pricewithVAT%",convertedDecimalFormatWithVAT);
		
		Report.updateTestLog(Action," Price for the product "+Data+" is Extracted and updated in variable %NotCovertedwithoutVATPrice%, %NotCovertedwithVATPrice%, %pricewithVAT%", Status.DONE);
		
		
	}
	
	
	@Action(object = ObjectType.BROWSER,desc = "Calculates Discounted Price with and without VAT based on Flat Discount as Input and the store in Variable %discountedPriceWithVAT% and %discountedPriceWithoutVAT% ",input = InputType.YES)
    public void calculatedDiscountedPrice_PL() {
		
		int flatDiscount = Integer.parseInt(Data);
		DecimalFormat df = new DecimalFormat("#.00");
		
		
		//If VAT is 15% then VAT value = 1.15, here since its 8% its 1.08		
		double VAT = 1.08;
		
		double priceWithVAT = Double.parseDouble(getVar("%pricewithVAT%"));

		double calculatedPriceWithVAT = priceWithVAT - flatDiscount;
		String discountedPriceWithVAT = df.format(calculatedPriceWithVAT).replace(".", ",");
		
		
		double calcuatedPriceWithOutVAT = calculatedPriceWithVAT/VAT;		
		String discountedPriceWithoutVAT = df.format(calcuatedPriceWithOutVAT).replace(".", ",");
				
	
		addVar("%discountedPriceWithVAT%",discountedPriceWithVAT);
		addVar("%discountedPriceWithoutVAT%",discountedPriceWithoutVAT);
		
		Report.updateTestLog(Action,"Discounted price is calculated based on input "+Data+" and updated in Variable %discountedPriceWithVAT% and %discountedPriceWithoutVAT%", Status.DONE);
		
	}
	
	@Action(object = ObjectType.BROWSER,desc = "To Verfiy the Cart Total without Promotion Based on the Qty Input given ",input = InputType.NO)
    public void verfiyCartTotalwithoutPromotion_PL() {
		
		DecimalFormat df = new DecimalFormat("#.00");
		DecimalFormat decimalFormat = new DecimalFormat("#,###.##");	
        int qty;
		
        try {
			//x-path for Cart Page
		    qty = Integer.parseInt((Driver.findElement(By.xpath("//input[@id='quantity' and @type='number']")).getAttribute("value")));
		    Report.updateTestLog(Action,"Calculation Veriftion is taking place in Cart Page" , Status.PASS);
		} catch(Exception e) {
			try {
			    //x-path for Order Review Page
		        qty = Integer.parseInt(Driver.findElement(By.xpath("//div[contains(@class,'summary-qty-val-PL')]")).getText().trim());
		        Report.updateTestLog(Action,"Calculation Veriftion is taking place in Cart Review Page" , Status.PASS);
			} catch(Exception f) {
			    //x-path for Order Confirmation Page
				qty = Integer.parseInt(Driver.findElement(By.xpath("//div[contains(@class,'pack-quantity')]")).getText().trim());
				Report.updateTestLog(Action,"Calculation Veriftion is taking place in Order Confirmation Page" , Status.PASS);
			}
		}
		
		//If VAT is 15% then VAT value = 1.15 and calVATNum = 15 and calVATDnum = 115(i.e 100+15), here since its 8% its 1.08 and calVATNum = 08 and calVATDnum = 108	 	
		double VAT = 1.08;
		double calVATNum = 8;
		double calVATDnum = 108;
		double calVAT = calVATNum/calVATDnum;
		
		String price;
		
		try {
			//x-path for Cart Page
			price = Driver.findElement(By.xpath("//div[contains(@class,'pageConfWithVatVal-PL')]")).getText();
			
		} catch(Exception e) {
			try {
				//x-path for Order Review Page
				price = Driver.findElement(By.xpath("//div[contains(@class,'withoutvatcheckout-PL')]")).getText();
			} catch(Exception f) {
				//x-path for Order Confirmation Page
				price = Driver.findElement(By.xpath("//span[@class='cnd-price-print-PL']")).getText();
			}
						
		}
		
		String baseStringPrice = price.split(" ")[0].replace(",", ".");
		double basePricewithVAT = Double.parseDouble(baseStringPrice);
			
		
		double calculatedPricewithVAT = basePricewithVAT*qty;
		double calculatedPricewithoutVAT = calculatedPricewithVAT/VAT;
		calculatedPricewithoutVAT = Double.parseDouble(df.format(calculatedPricewithoutVAT));
		double calculatedVAT = calVAT * calculatedPricewithVAT;
		calculatedVAT = Double.parseDouble(df.format(calculatedVAT));
		
		String priceWithVATString = decimalFormat.format(calculatedPricewithVAT).trim();
		String priceWithOutVATString = decimalFormat.format(calculatedPricewithoutVAT).trim();
		String VATString = decimalFormat.format(calculatedVAT).trim();
		
		if(priceWithVATString.length()>6)
		{
			priceWithVATString = priceWithVATString.replace(",", " ");
			priceWithVATString = priceWithVATString.replace(".", ",");
		} else {
			priceWithVATString = priceWithVATString.replace(".", ",");
		}
		
		if(priceWithOutVATString.length()>6)
		{
			priceWithOutVATString = priceWithOutVATString.replace(",", " ");
			priceWithOutVATString = priceWithOutVATString.replace(".", ",");
		} else {
			priceWithOutVATString = priceWithOutVATString.replace(".", ",");
		}
		
		if(VATString.length()>6)
		{
			VATString = VATString.replace(",", " ");
			VATString = VATString.replace(".", ",");
		} else {
			VATString = VATString.replace(".", ",");
		}


		// Verify Product Total
		WebElement productTotal;
        try {
        	//x-path for Cart Page
        	productTotal = Driver.findElement(By.xpath("//div[contains(@class,'product-total-PL')]"));
			
		} catch(Exception e) {			
			try {
				//x-path for Order Review Page
				productTotal = Driver.findElement(By.xpath("//div[contains(@class,'pricevatval-PL')]"));
			} catch(Exception f) {
				//x-path for Order Confirmation Page
				productTotal = Driver.findElement(By.xpath("//div[contains(@class,'totalhtvalprint-PL')]"));
			}
			
		}

		String pT = productTotal.getText();
		if(pT.contains(priceWithVATString) && pT.contains("PLN"))
		{
			Report.updateTestLog(Action," The Calculated Product Total "+priceWithVATString+" Match's with Displayed Product Total "+productTotal.getText(), Status.PASS);
			addVar("%productTotal%",pT);
		}else {
			Report.updateTestLog(Action," The Calculated Product Total "+priceWithVATString+" is different from Displayed Product Total "+productTotal.getText(), Status.FAIL);
		}
		
		//Verify Cart Total without VAT		
		WebElement cartTotalWithOutVAT;
        try {
        	//x-path for Cart Page
        	cartTotalWithOutVAT = Driver.findElement(By.xpath("//div[contains(@class,'withoutvatval-PL')]"));
			
		} catch(Exception e) {
			try {
				//x-path for Order Review Page
				cartTotalWithOutVAT = Driver.findElement(By.xpath("(//div[contains(@class,'summaryTotalAlgn')])[1]"));
			} catch(Exception f) {
				//x-path for Order Confirmation Page
				cartTotalWithOutVAT = Driver.findElement(By.xpath("(//div[contains(@class,'cnfmTotalAlgn')])[1]"));
			}
						
		}
		
		String ctwov = cartTotalWithOutVAT.getText();
		if(ctwov.contains(priceWithOutVATString) && ctwov.contains("PLN"))
		{
			Report.updateTestLog(Action," The Calculated Cart Total Without VAT "+priceWithOutVATString+" Match's with Displayed Cart Total Without VAT "+cartTotalWithOutVAT.getText(), Status.PASS);
			addVar("%cartTotalWithOutVAT%",ctwov);
		}else {
			Report.updateTestLog(Action," The Calculated Cart Total Without VAT "+priceWithOutVATString+" is different from Displayed Cart Total Without VAT "+cartTotalWithOutVAT.getText(), Status.FAIL);
		}
		
		//Verify Cart Total with VAT
		WebElement cartTotalWithVAT;
        try {
        	//x-path for Cart Page
        	cartTotalWithVAT = Driver.findElement(By.xpath("//div[contains(@class,'sumval-PL')]"));
        	
		} catch(Exception e) {
			try {
				//x-path for Order Review Page
				cartTotalWithVAT = Driver.findElement(By.xpath("//div[contains(@class,'bottom-cost-val-PL')]"));
			} catch(Exception f) {
				//x-path for Order Confirmation Page
				cartTotalWithVAT = Driver.findElement(By.xpath("//div[contains(@class,'grand-total-print-PL')]"));
			}
			
		}
		
		String ctwv = cartTotalWithVAT.getText();
		if(ctwv.contains(priceWithVATString) && ctwv.contains("PLN"))
		{
			Report.updateTestLog(Action," The Calculated Cart Total With VAT "+priceWithVATString+" Match's with Displayed Cart Total With VAT "+cartTotalWithVAT.getText(), Status.PASS);
			addVar("%cartTotalWithVAT%",ctwv);
		}else {
			Report.updateTestLog(Action," The Calculated Cart Total With VAT "+priceWithVATString+" is different from Displayed Cart Total With VAT "+cartTotalWithVAT.getText(), Status.FAIL);
		}
		
		//Verify Cart VAT 
		WebElement cartVATValue;
        try {
        	//x-path for Cart Page
        	cartVATValue = Driver.findElement(By.xpath("//div[(contains(text(),'VAT') )and not(contains(text(),'Razem'))]//following-sibling::div[contains(@class,'vatval-PL')]"));
        			
		} catch(Exception e) {
			try {
				//x-path for Order Review Page
				cartVATValue = Driver.findElement(By.xpath("(//div[contains(@class,'summaryTotalAlgn')])[2]"));
			} catch(Exception f) {
				//x-path for Order Confirmation Page
				cartVATValue = Driver.findElement(By.xpath("(//div[contains(@class,'cnfmTotalAlgn')])[2]"));
			}
			
		}
		
		String cvv = cartVATValue.getText();
		if(cvv.contains(VATString) && cvv.contains("PLN"))
		{
			Report.updateTestLog(Action," The Calculated Cart VAT value "+VATString+" Match's with Displayed Cart VAT value "+cartVATValue.getText(), Status.PASS);
			addVar("%cartVATValue%",cvv);
		}else {
			Report.updateTestLog(Action," The Calculated Cart VAT value "+VATString+" is different from Displayed Cart VAT value "+cartVATValue.getText(), Status.FAIL);
		}
		
		
		//Verify Cart Final Total 
		WebElement finalCartTotal;
        try {
        	//x-path for Cart Page
        	finalCartTotal = Driver.findElement(By.xpath("//div[contains(@class,'finalCostVal1-PL')]"));
        	
		} catch(Exception e) {
			try {
				//x-path for Order Review Page
				finalCartTotal = Driver.findElement(By.xpath("//div[contains(@class,'finalCostVal-PL')]"));
			} catch(Exception f) {
				//x-path for Order Confirmation Page
				finalCartTotal = Driver.findElement(By.xpath("//div[contains(@class,'checkSumFinalCostVal-PL')]"));
			}
			
		}
		
		String fct = finalCartTotal.getText();
		if(fct.contains(priceWithVATString) && fct.contains("PLN"))
		{
			Report.updateTestLog(Action," The Calculated Cart Total With VAT "+priceWithVATString+" Match's with Displayed Cart Total With VAT "+finalCartTotal.getText(), Status.PASS);
			addVar("%finalCartTotal%",fct);
		}else {
			Report.updateTestLog(Action," The Calculated Cart Total With VAT "+priceWithVATString+" is different from Displayed Cart Total With VAT "+finalCartTotal.getText(), Status.FAIL);
		}
		
		
	}
	
	
	@Action(object = ObjectType.BROWSER,desc = "To Verfiy the Cart Total with Promotion Based on the Qty Input given ",input = InputType.NO)
    public void verfiyCartTotalwithPromotion_PL() {
		
		DecimalFormat df = new DecimalFormat("#.00");
		DecimalFormat decimalFormat = new DecimalFormat("#,###.##");	
		int qty;
		
		try {
			//x-path for Cart Page
		    qty = Integer.parseInt((Driver.findElement(By.xpath("//input[@id='quantity' and @type='number']")).getAttribute("value")));
		    Report.updateTestLog(Action,"Calculation Veriftion is taking place in Cart Page" , Status.PASS);
		} catch(Exception e) {
			try {
			    //x-path for Order Review Page
		        qty = Integer.parseInt(Driver.findElement(By.xpath("//div[contains(@class,'summary-qty-val-PL')]")).getText().trim());
		        Report.updateTestLog(Action,"Calculation Veriftion is taking place in Cart Review Page" , Status.PASS);
			} catch(Exception f) {
			    //x-path for Order Confirmation Page
				qty = Integer.parseInt(Driver.findElement(By.xpath("//div[contains(@class,'pack-quantity')]")).getText().trim());
				Report.updateTestLog(Action,"Calculation Veriftion is taking place in Order Confirmation Page" , Status.PASS);
			}
		}
		
		//If VAT is 15% then VAT value = 1.15 and calVATNum = 15 and calVATDnum = 115(i.e 100+15), here since its 8% its 1.08 and calVATNum = 08 and calVATDnum = 108	 		
		double VAT = 1.08;
		double calVATNum = 8;
		double calVATDnum = 108;
		double calVAT = calVATNum/calVATDnum;
		
		System.out.println("Cal VAT Base = "+calVAT);
	
		 
		String price;
		
		try {
			//x-path for Cart Page
			price = Driver.findElement(By.xpath("//div[contains(@class,'pageConfWithVatVal-PL')]")).getText();
			
		} catch(Exception e) {
			try {
				//x-path for Order Review Page
				price = Driver.findElement(By.xpath("//div[contains(@class,'withoutvatcheckout-PL')]")).getText();
			} catch(Exception f) {
				//x-path for Order Confirmation Page
				price = Driver.findElement(By.xpath("//span[@class='cnd-price-print-PL']")).getText();
			}
						
		}
		
		String baseStringPrice = price.split(" ")[0].replace(",", ".");
		double basePricewithVAT = Double.parseDouble(baseStringPrice);
				
		// To verify the Promotion Range Based on the Variable Create for Range
		
		String range1[] = getVar("%promotionPLname1%").split(" ");
		int range1Start = Integer.parseInt(range1[0].trim());
		int range1End = Integer.parseInt(range1[2].trim());
		
		String range2[] = getVar("%promotionPLname2%").split(" ");
		int range2Start = Integer.parseInt(range2[0].trim());
		int range2End = Integer.parseInt(range2[2].trim());
		
		String range3[] = getVar("%promotionPLname3%").split(" ");
		int range3Start = Integer.parseInt(range3[0].trim());
		
		double discountedVATPrice;
		double calculatedPricewithVAT;
		double calculatedPricewithoutVAT;
		double calculatedVAT;
		String promoMsg;
		String promoApplied;
		
		if(qty>=range1Start && qty<=range1End) {
			
			discountedVATPrice = Double.parseDouble(getVar("%range1DisPriceWithVAT%").replace(",", "."));

			calculatedPricewithVAT = discountedVATPrice*qty;
			calculatedPricewithoutVAT = calculatedPricewithVAT/VAT;
			calculatedPricewithoutVAT = Double.parseDouble(df.format(calculatedPricewithoutVAT));
			calculatedVAT = calVAT*calculatedPricewithVAT;
			calculatedVAT = Double.parseDouble(df.format(calculatedVAT));
			promoMsg = getVar("%promotionMessage1%");
			
			promoApplied = getVar("%promotion1code%");
			
			Report.updateTestLog(Action,"Promotion for Qty Range "+getVar("%promotionPLname1%")+" is applied" , Status.PASS);
			
		} else if(qty>=range2Start && qty<=range2End){
			
			discountedVATPrice = Double.parseDouble(getVar("%range2DisPriceWithVAT%").replace(",", "."));
			
			calculatedPricewithVAT = discountedVATPrice*qty;
			calculatedPricewithoutVAT = calculatedPricewithVAT/VAT;
			calculatedPricewithoutVAT = Double.parseDouble(df.format(calculatedPricewithoutVAT));
			calculatedVAT = calVAT*calculatedPricewithVAT;
			calculatedVAT = Double.parseDouble(df.format(calculatedVAT));
			promoMsg = getVar("%promotionMessage2%");
			
			promoApplied = getVar("%promotion2code%");
			
			Report.updateTestLog(Action,"Promotion for Qty Range "+getVar("%promotionPLname2%")+" is applied" , Status.PASS);
			
		} else if(qty>=range3Start){
			
			discountedVATPrice = Double.parseDouble(getVar("%range3DisPriceWithVAT%").replace(",", "."));
			
			calculatedPricewithVAT = discountedVATPrice*qty;
			calculatedPricewithoutVAT = calculatedPricewithVAT/VAT;
			calculatedPricewithoutVAT = Double.parseDouble(df.format(calculatedPricewithoutVAT));
			calculatedVAT = calVAT*calculatedPricewithVAT;
			calculatedVAT = Double.parseDouble(df.format(calculatedVAT));
			promoMsg = getVar("%promotionMessage3%");
			
			promoApplied = getVar("%promotion3code%");
			
			Report.updateTestLog(Action,"Promotion for Qty Range "+getVar("%promotionPLname3%")+" is applied" , Status.PASS);
			
		} else {
			
			
			discountedVATPrice = 0;
			calculatedPricewithVAT = basePricewithVAT*qty;
			calculatedPricewithoutVAT = calculatedPricewithVAT/VAT;
			calculatedPricewithoutVAT = Double.parseDouble(df.format(calculatedPricewithoutVAT));
			calculatedVAT = calVAT*calculatedPricewithVAT;
			calculatedVAT = Double.parseDouble(df.format(calculatedVAT));
			promoMsg = "No Promotion";
			
			promoApplied = null;
			
			Report.updateTestLog(Action,"Qty is not Eligible for Promotion", Status.FAIL);
		
		}
				
		
		String priceWithVATString = decimalFormat.format(calculatedPricewithVAT).trim();
		String priceWithOutVATString = decimalFormat.format(calculatedPricewithoutVAT).trim();
		String VATString = decimalFormat.format(calculatedVAT).trim();
		
		
		//Changing format for Calculated Value as per Store Front
		
		if(priceWithVATString.length()>6)
		{
			priceWithVATString = priceWithVATString.replace(",", " ");
			priceWithVATString = priceWithVATString.replace(".", ",");
		} else {
			priceWithVATString = priceWithVATString.replace(".", ",");
		}
		
		if(priceWithOutVATString.length()>6)
		{
			priceWithOutVATString = priceWithOutVATString.replace(",", " ");
			priceWithOutVATString = priceWithOutVATString.replace(".", ",");
		} else {
			priceWithOutVATString = priceWithOutVATString.replace(".", ",");
		}
		
		if(VATString.length()>6)
		{
			VATString = VATString.replace(",", " ");
			VATString = VATString.replace(".", ",");
		} else {
			VATString = VATString.replace(".", ",");
		}
		
		
		// Verify the Promotion Message
		String promoMsgDisplayed = Driver.findElement(By.xpath("//ul[@class='money-style']")).getText().trim();
		
		if(promoMsg.contentEquals(promoMsgDisplayed)) {
			Report.updateTestLog(Action, "The Promotion Message Displayed is "+promoMsgDisplayed, Status.PASS);
		} else {
		    Report.updateTestLog(Action, "The Promotion Message Displayed is not Correct "+promoMsgDisplayed, Status.FAIL);
		}
		
		// Verify Product Total
		WebElement productTotal;
        try {
        	//x-path for Cart Page
        	productTotal = Driver.findElement(By.xpath("//div[contains(@class,'product-total-PL')]"));
			
		} catch(Exception e) {			
			try {
				//x-path for Order Review Page
				productTotal = Driver.findElement(By.xpath("//div[contains(@class,'pricevatval-PL')]"));
			} catch(Exception f) {
				//x-path for Order Confirmation Page
				productTotal = Driver.findElement(By.xpath("//div[contains(@class,'totalhtvalprint-PL')]"));
			}
			
		}

		String pT = productTotal.getText();
		if(pT.contains(priceWithVATString) && pT.contains("PLN"))
		{
			Report.updateTestLog(Action," The Calculated Product Total "+priceWithVATString+" Match's with Displayed Product Total "+productTotal.getText(), Status.PASS);
			addVar("%productTotal%",pT);
		}else {
			Report.updateTestLog(Action," The Calculated Product Total "+priceWithVATString+" is different from Displayed Product Total "+productTotal.getText(), Status.FAIL);
		}
		
		//Verify Cart Total without VAT		
		WebElement cartTotalWithOutVAT;
        try {
        	//x-path for Cart Page
        	cartTotalWithOutVAT = Driver.findElement(By.xpath("//div[contains(@class,'withoutvatval-PL')]"));
			
		} catch(Exception e) {
			try {
				//x-path for Order Review Page
				cartTotalWithOutVAT = Driver.findElement(By.xpath("(//div[contains(@class,'summaryTotalAlgn')])[1]"));
			} catch(Exception f) {
				//x-path for Order Confirmation Page
				cartTotalWithOutVAT = Driver.findElement(By.xpath("(//div[contains(@class,'cnfmTotalAlgn')])[1]"));
			}
						
		}
		
		String ctwov = cartTotalWithOutVAT.getText();
		if(ctwov.contains(priceWithOutVATString) && ctwov.contains("PLN"))
		{
			Report.updateTestLog(Action," The Calculated Cart Total Without VAT "+priceWithOutVATString+" Match's with Displayed Cart Total Without VAT "+cartTotalWithOutVAT.getText(), Status.PASS);
			addVar("%cartTotalWithOutVAT%",ctwov);
		}else {
			Report.updateTestLog(Action," The Calculated Cart Total Without VAT "+priceWithOutVATString+" is different from Displayed Cart Total Without VAT "+cartTotalWithOutVAT.getText(), Status.FAIL);
		}
		
		//Verify Cart Total with VAT
		WebElement cartTotalWithVAT;
        try {
        	//x-path for Cart Page
        	cartTotalWithVAT = Driver.findElement(By.xpath("//div[contains(@class,'sumval-PL')]"));
        	
		} catch(Exception e) {
			try {
				//x-path for Order Review Page
				cartTotalWithVAT = Driver.findElement(By.xpath("//div[contains(@class,'bottom-cost-val-PL')]"));
			} catch(Exception f) {
				//x-path for Order Confirmation Page
				cartTotalWithVAT = Driver.findElement(By.xpath("//div[contains(@class,'grand-total-print-PL')]"));
			}
			
		}
		
		String ctwv = cartTotalWithVAT.getText();
		if(ctwv.contains(priceWithVATString) && ctwv.contains("PLN"))
		{
			Report.updateTestLog(Action," The Calculated Cart Total With VAT "+priceWithVATString+" Match's with Displayed Cart Total With VAT "+cartTotalWithVAT.getText(), Status.PASS);
			addVar("%cartTotalWithVAT%",ctwv);
		}else {
			Report.updateTestLog(Action," The Calculated Cart Total With VAT "+priceWithVATString+" is different from Displayed Cart Total With VAT "+cartTotalWithVAT.getText(), Status.FAIL);
		}
		
		//Verify Cart VAT 
		WebElement cartVATValue;
        try {
        	//x-path for Cart Page
        	cartVATValue = Driver.findElement(By.xpath("//div[(contains(text(),'VAT') )and not(contains(text(),'Razem'))]//following-sibling::div[contains(@class,'vatval-PL')]"));
        			
		} catch(Exception e) {
			try {
				//x-path for Order Review Page
				cartVATValue = Driver.findElement(By.xpath("(//div[contains(@class,'summaryTotalAlgn')])[2]"));
			} catch(Exception f) {
				//x-path for Order Confirmation Page
				cartVATValue = Driver.findElement(By.xpath("(//div[contains(@class,'cnfmTotalAlgn')])[2]"));
			}
			
		}
		
		String cvv = cartVATValue.getText();
		if(cvv.contains(VATString) && cvv.contains("PLN"))
		{
			Report.updateTestLog(Action," The Calculated Cart VAT value "+VATString+" Match's with Displayed Cart VAT value "+cartVATValue.getText(), Status.PASS);
			addVar("%cartVATValue%",cvv);
		}else {
			Report.updateTestLog(Action," The Calculated Cart VAT value "+VATString+" is different from Displayed Cart VAT value "+cartVATValue.getText(), Status.FAIL);
		}
		
		
		//Verify Cart Final Total 
		WebElement finalCartTotal;
        try {
        	//x-path for Cart Page
        	finalCartTotal = Driver.findElement(By.xpath("//div[contains(@class,'finalCostVal1-PL')]"));
        	
		} catch(Exception e) {
			try {
				//x-path for Order Review Page
				finalCartTotal = Driver.findElement(By.xpath("//div[contains(@class,'finalCostVal-PL')]"));
			} catch(Exception f) {
				//x-path for Order Confirmation Page
				finalCartTotal = Driver.findElement(By.xpath("//div[contains(@class,'checkSumFinalCostVal-PL')]"));
			}
			
		}
		
		String fct = finalCartTotal.getText();
		if(fct.contains(priceWithVATString) && fct.contains("PLN"))
		{
			Report.updateTestLog(Action," The Calculated Cart Total With VAT "+priceWithVATString+" Match's with Displayed Cart Total With VAT "+finalCartTotal.getText(), Status.PASS);
			addVar("%finalCartTotal%",fct);
		}else {
			Report.updateTestLog(Action," The Calculated Cart Total With VAT "+priceWithVATString+" is different from Displayed Cart Total With VAT "+finalCartTotal.getText(), Status.FAIL);
		}
		
		
		// Data Calculation and Variable created for Back Office Verification
				DecimalFormat df1 = new DecimalFormat("#.0");
				DecimalFormat df2 = new DecimalFormat("#.000");
				
				Double priceWithoutPromo = basePricewithVAT*qty;
				Double discount = priceWithoutPromo - calculatedPricewithVAT;
				
				String totalpricewithoutPromo = df.format(priceWithoutPromo).trim();
				String discountedProdPrice = df2.format(discountedVATPrice).trim();		
				String totalpricewithPromo = df.format(calculatedPricewithVAT).trim();
				String totaldiscountAmount = df1.format(discount).trim();
				
				addVar("%BOTotalPricewithoutPromo%", totalpricewithoutPromo);
				addVar("%BOTotalDiscount%", totaldiscountAmount);
				addVar("%BOTotalPricewithPromo%", totalpricewithPromo);
				addVar("%BOProdDiscountedPrice%", discountedProdPrice);
				addVar("%PromotionApplied%", promoApplied);
				
		
	}
	
	@Action(object = ObjectType.BROWSER,desc = "To update the Qty in the Cart Page Equal to the Input Qty",input = InputType.YES)
    public void updateQuantityinCart_PL() throws InterruptedException {
		
		String qty = Data;
		String command = "document.getElementById('quantity').setAttribute('value', "+qty+")" ;
		
		JavascriptExecutor js = (JavascriptExecutor) Driver;
		js.executeScript(command);
		
		//Click Inside the Quantity Box
		Driver.findElement(By.xpath("//input[@id='quantity' and @type='number']")).click();
		
		//Click Outside the Quantity Box
		Driver.findElement(By.xpath("//div[contains(@class,'listTotalWithVatTitle-PL')]")).click();
		
	
		Report.updateTestLog(Action,"The Quantity is updated as "+qty+" in the Cart",Status.PASS);
	
	}
	
	@Action(object = ObjectType.BROWSER,desc = "To Extract Order Confirmation Number and Store in Variable %OrderNumber%",input = InputType.NO)
    public void extractOrderNumber_PL(){
		String value = Driver.findElement(By.xpath("//h2[@class='ship-to-title']")).getText();
		String OrderNo = value.split(" ")[2].trim();
		addVar("%OrderNumber%",OrderNo);
	}
	
	@Action(object = ObjectType.BROWSER,desc = "To Verify if the Redirection Opens in New Tab and is correct",input = InputType.YES)
    public void verifyNewTabRedirection_PL(){
		
	String urlText = Data;
	
	 try {
		 
		Thread.sleep(15000);
		
		Set<String> Handles = Driver.getWindowHandles();
		Iterator<String> It = Handles.iterator();
		String ParentWindowID = It.next();
		String ChildWindowID = It.next();
		Driver.switchTo().window(ChildWindowID);
		String url = Driver.getCurrentUrl();
		
		

		if (url.contains(urlText)){
			Report.updateTestLog(Action, "The Page is displayed in New Tab is correct", Status.PASS);
		}else {
			Report.updateTestLog(Action, "The Page is displayed in New Tab is not correct", Status.FAIL);
		}

		Driver.close();
		Driver.switchTo().window(ParentWindowID);
		
	 } catch(Exception e) {
		 
		 Report.updateTestLog(Action, "The Page is not opened in new Tab", Status.FAIL);
	 }
	
	
	}
	
	
	@Action(object = ObjectType.BROWSER,desc = "Variable %currentDate% is created with Formatted Date for Current Time",input = InputType.NO)
    public void createDateFormatForCurrentTime_PL() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MMM dd, yy, hh:mm:ss a");
		LocalDateTime now = LocalDateTime.now();
		String curr_Date = dtf.format(now);
		
		addVar("%currentDate%",curr_Date);
		
		Report.updateTestLog(Action,curr_Date +" is updated in variable %currentDate%", Status.DONE);
		
	}
	
	@Action(object = ObjectType.BROWSER,desc = "When Navigated to General Tab Removes Soldto/Shipto from List Displayed based on the input as sd-/st- before Number and Save",input = InputType.YES)
    public void removeSoldtoOrShiptofromCustomersNode_PL() throws InterruptedException {
		
		String selectData ="//span[contains(text(),'"+Data+"')]//parent::div/parent::div";
		String removeData ="//table//span[contains(text(),'"+Data+"')]//following-sibling::div";
		
		Driver.findElement(By.xpath(selectData)).click();
		Driver.findElement(By.xpath(removeData)).click();
		
		Thread.sleep(2000);
		
		Driver.findElement(By.xpath("//button[text()='Save' and not(@disabled='disabled')]")).click();
		
		Report.updateTestLog(Action,"The Shipto / Soldto "+Data+" is removed from customer group list and changes are saved", Status.PASS);
		
		
	}
	
	
	@Action(object = ObjectType.BROWSER,desc = "Extract Shipto Linked to Soldto From Bill to Organizantion Tab and Store in Variable ",input = InputType.YES)
    public void extractShiptolinkedfromBillto_PL() throws InterruptedException {
		
		
		Driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		
		String soldTo = Data;
		
		String xpathLinked = "(//tbody//span[contains(text(),'"+soldTo+"') and contains(@class,'ye-default-reference-editor-selected-item-label')])[1]";
		
		Actions act = new Actions(Driver);
		
		WebElement linkedSoldto = Driver.findElement(By.xpath(xpathLinked));
		
		act.doubleClick(linkedSoldto).perform();
		
		
		Driver.findElement(By.xpath("//div[contains(@class,'yw-modal-collectionEditorAreaGroup')]//span[text()='Organization']")).click();
		
		
		Driver.findElement(By.xpath("//div[contains(@class,'yw-modal-collectionEditorAreaGroup')]//button[text()='Find Members of this UserGroup']")).click();
		
		
		Driver.findElement(By.xpath("//div[@title='Close']")).click();
		
		List<WebElement> listOfShipto = Driver.findElements(By.xpath("//span[contains(text(),'st-')]")); 
		
		String size = Integer.toString(listOfShipto.size());
		addVar("%NumberOfLinkedShipto%",size);
				
		for(int i=1; i<=listOfShipto.size(); i++) {
			
			String varName = "%ShipTo"+i+"%";
			
			String shipToNumber = listOfShipto.get(i-1).getText().split("-")[1];
			
			addVar(varName,shipToNumber);
		}
				
		
	}
	
	@Action(object = ObjectType.BROWSER,desc = "Verify if Shipto extracted from method extractShiptolinkedfromBillto_PL is present in the User Logged in",input = InputType.NO)
    public void verifyExtractShiptoForUser_PL() throws InterruptedException{
		
		Driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		
		int count = 0;
		int numberOfShipto = Integer.parseInt(getVar("%NumberOfLinkedShipto%"));
		
		for(int i=1; i<=numberOfShipto; i++) {
			
			String varName = "%ShipTo"+i+"%";		
			String path = "//div[contains(text(),'"+getVar(varName)+"')]";
			
			if(Driver.findElement(By.xpath(path)).isDisplayed()) {
				count++;
			} else {
				Report.updateTestLog(Action, "The Shipto "+getVar(varName)+"", Status.FAIL);
			}
		}
		
		if(count==numberOfShipto) {
			Report.updateTestLog(Action, "All Shipto linked to the Sold is Linked to User Registered as Admin", Status.PASS);
		} else {
			Report.updateTestLog(Action, "All Shipto linked to the Sold is not Linked to User Registered as Admin with List Displayed Above", Status.FAIL);
		}
		
	}
	
	@Action(object = ObjectType.BROWSER,desc = "Deactivate user after Navigating to User Management Page based on the input email",input = InputType.YES)
    public void deactivateUser_PL() throws InterruptedException {
		
		String path = "//a[text()='"+Data+"']//..//..//select";
		
		WebElement user = Driver.findElement(By.xpath(path));
		Select opt = new Select(user);
		
		opt.selectByValue("deactivateUser");
		
		Thread.sleep(1000);
		
		Driver.findElement(By.xpath("//div[@id='cboxWrapper']//input[contains(@onclick,'deactivateUser')]")).click();
		
		
	}
	
	
	@SuppressWarnings("unused")
	@Action(object = ObjectType.BROWSER, desc = "This Fuction is for Fluent wait for the Status of Process to Change to Finished Status", input = InputType.NO)
	public void fluentwaitforProcessess_PL() throws InterruptedException {
		
		Thread.sleep(5000);
		
		Wait<WebDriver> wait = new FluentWait<WebDriver>(Driver).withTimeout(Duration.ofSeconds(600))
				.pollingEvery(Duration.ofSeconds(3)).ignoring(NoSuchElementException.class);
		
		Driver.findElement(By.xpath("//a[@title='Processes']")).click();
		
		List<WebElement> processes = Driver.findElements(By.xpath("//span[contains(@class,'yw-processes-list-item-status-info')]"));

		
		String path1 = null;
		
		for(int i=1; i<=processes.size(); i++){
			
			String statusString = Driver.findElement(By.xpath("(//span[contains(@class,'yw-processes-list-item-status-info')])["+i+"]//preceding-sibling::span")).getText().trim();
			
			if(statusString.equalsIgnoreCase("finished")) {
				 
				Report.updateTestLog(Action, "The Process " +processes.get(i-1).getText()+ " is Finished", Status.PASS);
				path1 = null;
			}
			else {
				
				if(processes.get(i-1).getText().contains("Catalog Synchronization")) {
					path1 = "(//span[contains(@class,'yw-processes-list-item-status-info')])["+i+"]//preceding-sibling::span";
					
				} else {
					String inProcess = processes.get(i-1).getText().split(":")[1].split("-")[0];
					path1 = "//span[contains(text(),'"+inProcess+"')]//preceding-sibling::span";
				}
					
				break;
			}
		}

		String path = path1;
		 
		System.out.println(path);
		
		if(path!=null) {
			Boolean processName = wait.until(new Function<WebDriver, Boolean>() {

				@Override
				public Boolean apply(WebDriver Driver) {
					
					try {
						
					String processStatus = Driver.findElement(By.xpath(path)).getText();
					
					if(processStatus.equalsIgnoreCase("finished")) {
					
						Report.updateTestLog(Action, "The Status has Changed to Finished for "+processStatus, Status.PASS);
						return true;
					} else {
						return null;
					}
					
				} catch(Exception e) {
					
					System.out.println("The Process is Still In-Progress");
					return null;
				}
					
				}
			});
		}
		
		
		Driver.findElement(By.xpath("//a[contains(@class,'yw-processes-header-close-btn')]")).click();
		
	}

	
	
}
