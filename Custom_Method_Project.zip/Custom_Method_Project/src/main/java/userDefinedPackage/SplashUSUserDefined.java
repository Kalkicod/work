package userDefinedPackage;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.Random;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.net.URL;

import org.apache.commons.io.comparator.LastModifiedFileComparator;
import org.apache.commons.io.filefilter.WildcardFileFilter;
import org.apache.commons.lang3.time.StopWatch;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.hamcrest.core.IsEqual;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cognizant.cognizantits.engine.commands.General;
import com.cognizant.cognizantits.engine.core.CommandControl;
import com.cognizant.cognizantits.engine.execution.data.UserDataAccess;
import com.cognizant.cognizantits.engine.execution.exception.element.ElementException;
import com.cognizant.cognizantits.engine.execution.exception.element.ElementException.ExceptionType;
import com.cognizant.cognizantits.engine.support.Status;
import com.cognizant.cognizantits.engine.support.methodInf.Action;
import com.cognizant.cognizantits.engine.support.methodInf.InputType;
import com.cognizant.cognizantits.engine.support.methodInf.ObjectType;
import com.google.common.util.concurrent.Service.State;
import com.sun.jna.Function;
import com.testautomationguru.utility.PDFUtil;

import junit.framework.Assert;


public class SplashUSUserDefined extends General {

	public SplashUSUserDefined(CommandControl cc) {
		super(cc);
		// TODO Auto-generated constructor stub
	}
	@Action(object = ObjectType.BROWSER, desc = "Values should be in 1000, 1second =1000 [<Data>]", input = InputType.YES)
	public void thread_Sleep() throws InterruptedException {

		int time = Integer.parseInt(Data);
		Thread.sleep(time);

	}

	
	 @Action(object = ObjectType.BROWSER,desc = "To Accept and Close the Pop-up ",input = InputType.NO)
     public void acceptCookiePreferance() {
               Driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
               try {
                     Driver.findElement(By.xpath("//button[@id='gsk-consent-settings-button']")).click();                           
                     Driver.findElement(By.xpath("//button[@id='gsk-consent-confirm']")).click();
                     Report.updateTestLog(Action, "The Cookie Pop-up is closed", Status.PASS);
               }
               catch (Exception e) {
                     Report.updateTestLog(Action, "The Cookie Pop-up is not displayed", Status.PASS);
               }
               
        }
	 
	 
	 
	/*
	 * @Action(object = ObjectType.BROWSER, desc = "Shopping cart removal", input =
	 * InputType.NO) public void clearShoppingCart_splash() {
	 * 
	 * 
	 * WebElement Element = Driver.findElement(By.
	 * xpath("//*[@position='MiniCart']/..//span[@class='badge position-absolute']")
	 * );
	 * 
	 * String qtyarray = Element.getText(); WebDriverWait wait = new
	 * WebDriverWait(Driver, 600); int num = Integer.parseInt(qtyarray);
	 * System.out.println(qtyarray);
	 * 
	 * 
	 * try { if (!Element.getText().contains("0")) {
	 * Driver.findElement(By.xpath("(//*[contains(@class,'miniCart ')]//a)[1]")).
	 * click();
	 * 
	 * wait.until(ExpectedConditions.visibilityOf(Driver .findElement(By.
	 * xpath("//h3[contains(@class,'text-center')][text()='Order Summary']"))));
	 * 
	 * Report.updateTestLog(Action, "Clicked on Shipping Cart page ", Status.PASS);
	 * // expand_Product(); List<WebElement> buttons = Driver.findElements(By.xpath(
	 * "(//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])")); int
	 * btn=buttons.size();
	 * 
	 * try { for (int k = 0; k <= buttons.size()+1;k++) {
	 * 
	 * Report.updateTestLog(Action, "Button size    "+buttons.size(), Status.DONE);
	 * List<WebElement> remove=Driver.findElements(By.xpath(
	 * "(//div[@id='accordionUpdate']//div[contains(@id,'heading-0" +(k)
	 * +"')])/following-sibling::div//*[text()=' Remove Product ']")); for (int i
	 * =remove.size() ; i >=0; i--) { // Report.updateTestLog(Action,
	 * "remove link size    "+remove.size(), Status.DONE);
	 * 
	 * Driver.findElement(By.xpath(
	 * "((//div[@id='accordionUpdate']//div[contains(@id,'heading-0" +(k)
	 * +"')])/following-sibling::div//*[text()=' Remove Product '])["+i+"]")).click(
	 * );
	 * 
	 * wait.until(ExpectedConditions.visibilityOf(Driver .findElement(By.xpath(
	 * "((//div[@id='accordionUpdate']//div[contains(@id,'heading-0" +(k)
	 * +"')])/following-sibling::div//button[text()='Yes, Remove'])["+i+"]"))));
	 * 
	 * Driver.findElement(By.xpath(
	 * "((//div[@id='accordionUpdate']//div[contains(@id,'heading-0" +(k)
	 * +"')])/following-sibling::div//button[text()='Yes, Remove'])["+i+"]"))
	 * .click(); wait.until(
	 * ExpectedConditions.invisibilityOfElementLocated(By.xpath(
	 * "//div[contains(@class,'spinner-wrapper')]")));
	 * 
	 * 
	 * 
	 * // // // }
	 * 
	 * }
	 * 
	 * } catch (NoSuchElementException e) { //Handle the exception if the element is
	 * not found System.out.println("Element not found: " + e.getMessage());
	 * 
	 * } // // int size = remove.size(); // //Loop until the list is empty // while
	 * (size > 0) { // try { // //Click on the first element of the list //
	 * remove.get(0).click(); // //Wait for the element to be removed from the DOM
	 * // // wait.until(ExpectedConditions.visibilityOf(Driver //
	 * .findElement(By.xpath("(//button[text()='Yes, Remove'])[1]")))); // //
	 * Driver.findElement(By.xpath("(//button[text()='Yes, Remove'])[1]")) //
	 * .click(); // wait.until(
	 * ExpectedConditions.invisibilityOfElementLocated(By.xpath(
	 * "//div[contains(@class,'spinner-wrapper')]"))); // //Update the list and the
	 * size // remove =
	 * Driver.findElements(By.xpath("(//*[text()=' Remove Product '])")); // size =
	 * remove.size(); // } catch (NoSuchElementException e) { // //Handle the
	 * exception if the element is not found //
	 * System.out.println("Element not found: " + e.getMessage()); // break; // } //
	 * } // if (Element.getText().contains("0")) { Report.updateTestLog(Action,
	 * "Shipping Cart page Cleared Sucessfully  ", Status.PASS);
	 * Driver.findElement(By.xpath("(//img[@alt='GSKUS GSKDirect Logo'])[1]")).click
	 * ();
	 * 
	 * 
	 * } } else { Report.updateTestLog(Action, "Cart is null ", Status.PASS); }
	 * }catch(Exception e) { Report.updateTestLog(Action, "Cart is null ",
	 * Status.PASS);
	 * 
	 * 
	 * }
	 * 
	 * }
	 */
	 @Action(object = ObjectType.BROWSER, desc = "Shopping cart removal", input = InputType.NO)
		public void clearShoppingCart_splash() {

			WebElement Element = Driver.findElement(By.xpath("//*[@class='miniCart']/..//span[@class='badge position-absolute']"));

			System.out.println(Element);
			String qtyarray = Element.getText();
			WebDriverWait wait = new WebDriverWait(Driver, 600);
			int num = Integer.parseInt(qtyarray);
			System.out.println(qtyarray);
			spinnerLoad();
			try {
			if (!Element.getText().contains("0")) {
				Driver.findElement(By.xpath("//div[@class='miniCart']")).click();
				wait.until(ExpectedConditions.visibilityOf(Driver
						.findElement(By.xpath("//h3[contains(@class,'text-center')][text()='Order Summary']"))));
				Report.updateTestLog(Action, "Clicked on Shipping Cart page ", Status.PASS);
//				expand_Product();
				List<WebElement> buttons = Driver.findElements(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])"));
				int btn=buttons.size();
				try {
				for (int k = 0; k <= buttons.size()+1;k++) {
					Report.updateTestLog(Action, "Button size    "+buttons.size(), Status.DONE);
				List<WebElement> remove=Driver.findElements(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-0" +(k) +"')])/following-sibling::div//*[text()=' Remove Product ']"));
				for (int i =remove.size() ; i >=0; i--) {				
//					
					Report.updateTestLog(Action, "remove link size    "+remove.size(), Status.DONE);
					Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0" +(k) +"')])/following-sibling::div//*[text()=' Remove Product '])["+i+"]")).click();
					wait.until(ExpectedConditions.visibilityOf(Driver
							.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0" +(k) +"')])/following-sibling::div//button[text()='Yes, Remove'])["+i+"]"))));
					Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0" +(k) +"')])/following-sibling::div//button[text()='Yes, Remove'])["+i+"]"))	.click();
		    wait.until(	ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[contains(@class,'spinner-wrapper')]")));		


				}
			}
				} catch (NoSuchElementException e) {
				    //Handle the exception if the element is not found
				    System.out.println("Element not found: " + e.getMessage());
				  }
				if (Element.getText().contains("0")) {
					Report.updateTestLog(Action, "Shipping Cart page Cleared Sucessfully  ", Status.PASS);
					Driver.findElement(By.xpath("(//img[@alt='GSKUS GSKDirect Logo'])[1]")).click();

					
				}
			} else {
				Report.updateTestLog(Action, "Cart is null ", Status.PASS);
			}
			}catch(Exception e) {
				Report.updateTestLog(Action, "Cart is null ", Status.PASS);

			}

		}
	 
	 @Action(object = ObjectType.BROWSER, desc = "Shopping cart removal", input = InputType.NO)
		public void clearShoppingCart_splash1() {
		 
		
			WebElement Element = Driver.findElement(By.xpath("//*[@class='miniCart']/..//span[@class='badge position-absolute']"));

			String qtyarray = Element.getText();
			WebDriverWait wait = new WebDriverWait(Driver, 600);
			int num = Integer.parseInt(qtyarray);
			System.out.println(qtyarray);
			
			
			try {
			if (!Element.getText().contains("0")) {
				Driver.findElement(By.xpath("(//*[contains(@class,'miniCart ')]//a)[1]")).click();
				 wait.until(	ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[contains(@class,'spinner-wrapper')]")));
				wait.until(ExpectedConditions.visibilityOf(Driver
						.findElement(By.xpath("//h3[contains(@class,'text-center')][text()='Order Summary']"))));
				
				Report.updateTestLog(Action, "Clicked on Shipping Cart page ", Status.PASS);
//				expand_Product();
				

List<WebElement> remove = Driver.findElements(By.xpath("(//*[text()=' Remove Product '])"));

//Report.updateTestLog(Action, "remove  page "+remove.size(), Status.DONE);
// Loop through the list and click on each element
while (!remove.isEmpty()) {
  try {
//	  Report.updateTestLog(Action, "inside loop  page "+remove.size(), Status.DONE);
    // Click on the first element in the list
    remove.get(0).click();
    
    System.out.println("      remove  clik    "+remove.get(0).getSize());
    // Wait for the pop up to appear and click on the 'Yes, Remove' button
  
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//button[text()='Yes, Remove'])[1]")));
    Driver.findElement(By.xpath("(//button[text()='Yes, Remove'])[1]")).click();
    
    // Wait for the pop up to disappear
   
    wait.until(	ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[contains(@class,'spinner-wrapper')]")));
    // Update the list of elements with the text 'Remove Product'
    remove = Driver.findElements(By.xpath("(//*[text()=' Remove Product '])"));
    System.out.println("      remove      "+remove.size());
  } catch (NoSuchElementException e) {
    // Handle the exception when no link is available
    System.out.println("No link available to remove product");
    break;
  }
}
				
				
				
				
				
				
				
				
				if (Element.getText().contains("0")) {
					Report.updateTestLog(Action, "Shipping Cart page Cleared Sucessfully  ", Status.PASS);
					Driver.findElement(By.xpath("(//img[@alt='GSKUS GSKDirect Logo'])[1]")).click();

					
				}		
				
				
			} else {
				Report.updateTestLog(Action, "Cart is null ", Status.PASS);
			}
			}catch(Exception e) {
				Report.updateTestLog(Action, "Cart is null ", Status.PASS);
				
				
			}

		}
 
	 
	 
	public void expand_Product() {
		try
		{
		
		List<WebElement> expand = Driver.findElements(By.xpath("//*[contains(@data-target,'#collapse-0')]"));
		//Report.updateTestLog(Action, " expand :: " +expand.size(), Status.PASS);
		
		for (int i=0;i<expand.size()-1;i++) {
			
			
			String aa=Driver.findElement(By.xpath("//*[contains(@data-target,'#collapse-0"+i+"')]")).getAttribute("aria-expanded");
			System.out.println(aa);
//			Report.updateTestLog(Action, " expand :: " +aa, Status.DONE);
			
			if(aa.equals("false"))
				
			{
				Driver.findElement(By.xpath("//*[contains(@data-target,'#collapse-0"+i+"')]")).click();
				
			}
			
			
		}	
		}catch(Exception e) {
			Report.updateTestLog(Action, " expand Fail ", Status.FAIL);
			
			
		}

		
		
	}
	 
	 
		
	@Action(object = ObjectType.BROWSER, desc = "Validating FooterLinks of Splash Site", input = InputType.NO)
	public void footerLink_Validation() throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(Driver,10);

		try {
	List<WebElement> footerlinks=Driver.findElements(By.xpath("//ul[contains(@class,'childs')]//li/cx-generic-link/a"));
	
	int noOffooterlinks=footerlinks.size();
	
	if(noOffooterlinks==12) {
		
		for(int i =1;i<=6;i++) {
			
			
			String name=Driver.findElement(By.xpath("(//ul[contains(@class,'childs')]//li/cx-generic-link/a)["+i+"]")).getText();
			
			
			
			List<String> validStrings_Showpage = Arrays.asList("About GSK", "Terms of Use", "Terms of Sales","Legal Notices","Data Privacy","Sitemap");

        	if(validStrings_Showpage.contains(name))
        	{
        		Report.updateTestLog(Action, "Footerlink  ::  "+name , Status.PASS);
        		
        		Driver.findElement(By.xpath("(//ul[contains(@class,'childs')]//li/cx-generic-link/a)["+i+"]")).click();
        		
        		wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
						.executeScript("return document.readyState")));
        		
				 ArrayList<String> tabs = new ArrayList<String> (Driver.getWindowHandles());
				    Driver.switchTo().window(tabs.get(1));
				    
				    wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
							.executeScript("return document.readyState")));
					
				    System.out.println(Driver.getCurrentUrl());

			    	Report.updateTestLog(Action, "Sucessfully Click  "+Driver.getCurrentUrl() , Status.PASS);
			    
			    	
			    	
			    	 Driver.close();
					  Driver.switchTo().window(tabs.get(0));
					  wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
								.executeScript("return document.readyState")));
			
        		
        		
        	}
			
			
			
			
		}
		
		
		
	}else
    {
    	Report.updateTestLog(Action, "Link Verification Failed unable to click " , Status.FAIL);
    	
    }
		}catch (Exception e) {
			
		}

	}	
		
		
	 
	 @Action(object = ObjectType.BROWSER, desc = "Clicking on Login button", input = InputType.NO)
		public void login_Button() {
		 
		 
		 String xpaths = "//button[@type='submit'][contains(text(),'Login')]";

	        try {
	            List<WebElement> buttons = Driver.findElements(By.xpath(xpaths));

	            for (WebElement button : buttons) {
	                try {
	                    button.click();
	                    System.out.println("Clicked on button: " + button);
	                    break;  // If click is successful, break the loop
	                } catch (ElementNotInteractableException e) {
	                    System.out.println("Unable to interact with button: " + button);
	                    // Continue to the next iteration to try clicking the next button
	                }
	            }
	        } catch (NoSuchElementException e) {
	            System.out.println("No elements found with class name: " + xpaths);
	        } 
		 
		 
		 
	 }
		
		
		
	 @Action(object = ObjectType.BROWSER, desc = "Clicking on No thank you or closing flu reservation popup button", input = InputType.NO)
		public void  flureservation_popup() {
		 
			try {
//				 Alert alert =  Driver.switchTo().alert();
//				 String alertText = alert.getText();
//			        System.out.println("Popup text: " + alertText);
				WebDriverWait wait = new WebDriverWait(Driver,10);
	            

	        WebElement noThankYouButton = Driver.findElement(By.xpath("//button[text()='No, Thank you']"));
	        WebElement YesThankYouButton = Driver.findElement(By.xpath("//button[text()='Yes, Reserve Now']"));
	        
	        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()='No, Thank you']")));
	        JavascriptExecutor js = (JavascriptExecutor) Driver;
			 
	        
	        if (noThankYouButton != null) {
	        	WebElement element1 = Driver.findElement(By.xpath("//input[@id='dont-show-again']"));
				 js.executeScript("arguments[0].click();", element1);
	        	//Driver.findElement(By.xpath("//input[@id='dont-show-again']")).click();
	        	noThankYouButton.click();
	            
	        	Report.updateTestLog(Action, "Clicked on the 'No, Thank you' button of flu reservation popup  " , Status.PASS);
	            System.out.println("Clicked on the 'No, Thank you' button");
	        } else {
	        	
	            System.out.println("'No, Thank you' button not available on page");
	            Report.updateTestLog(Action, "Flu reservation popup Not dispaled  " , Status.PASS);
	        }
			}
			catch(Exception e){
				System.out.println("No Alert");
				Report.updateTestLog(Action, "Unable to click Flu reservation popup Not dispaled  " , Status.PASS);
				//count++;	
			}
		 
	 }
		
		
		
		
	 @Action(object = ObjectType.BROWSER, desc = "Clicking on Start a New Order button selecting shipto ", input = InputType.NO)
		public void  getActiveshipto() {
		 String id=Data;
		 String shiptoId=null;
//		 By newOrder=By.xpath("//a[normalize-space()='Start a New Order']");
		 By newOrder=By.xpath("//div[@class='home-banner-nav']//a[contains(text(),'Start a New Order')]");
		 By shippingAddress_title=By.xpath("//div[normalize-space()='Select Shipping Address for Your Order']");
		 By SelectnoShippingLocation=By.xpath("//a[@id='change_noShipping_location']");
		 By SelectShippingLocation =By.xpath("//a[@id='change_shipping_location']");
//		 By SelectShippingLocation =By.xpath("///a[@id='update_SLN']");
		 By continue_shopping=By.xpath("//div[@class='home-banner-nav']//a[contains(text(),'Continue Shopping')]");
		 
		 By Proddutsdrpdown=By.xpath("//button[contains(text(),'Products')]");
		 By Vaccines=By.xpath("//a[@id='Vaccines']");
		 String sln=null;
		 try {
			 
			 System.out.println("Id   ::"+id);	 
			 try {
			 Driver.findElement(SelectnoShippingLocation).click();
			 System.out.println("Try  SelectnoShippingLocation");
			 }
			 catch(Exception e){
			
				 Driver.findElement(SelectShippingLocation).click();
				 System.out.println("Catch SelectShippingLocation ");
			 }
			 WebDriverWait wait = new WebDriverWait(Driver,10);
			
//			 flureservation_popup();
		        try {
		        	
		            wait.until(ExpectedConditions.visibilityOfElementLocated(shippingAddress_title));
		            

//		            List<WebElement> activeElements = Driver.findElements(By.xpath("//span[@class='active cta cta-stroke-xs status-btn'][normalize-space()='Active']"));
		           
		            List<WebElement> activeElements = Driver.findElements(By.xpath("(//span[normalize-space()='Active']/../..//p/span[contains(text(),'HCPSL:')]/../span[2])"));
		            System.out.println("activeElements.size()   ::"+activeElements.size());	
		            for (int i = 1; i <= activeElements.size(); i++) {
		            		            	
//		            	shiptoId=Driver.findElement(By.xpath("(//span[normalize-space()='Active']/../../div//div[@class='not-card-view']//span[@class='label-value'])["+i+"]")).getText().toString();
	            
	            	 shiptoId=Driver.findElement(By.xpath("(//span[normalize-space()='Active']/../..//p/span[contains(text(),'HCPSL:')]/../span[2]/../../../../..//ancestor::div[@class='not-card-view']//span[@class='label-value'])["+i+"]")).getText().toString();
		 	            
	            	 sln=Driver.findElement(By.xpath("(//span[normalize-space()='Active']/../..//p/span[contains(text(),'HCPSL:')]/../span[2])["+i+"]")).getText().toString();
//			 	            
//			            	 
		            	 userData.putData("OrderDetails", "SLN1", sln);
		            	 
		            	 System.out.println("shiptoId   ::"+shiptoId);	

		            		
//		            		 WebElement selectAddressButton = Driver.findElement(By.xpath("(//span[normalize-space()='Active']/../..//button[normalize-space()='Select Address'])["+i+"]"));
		            		 WebElement selectAddressButton = Driver.findElement(By.xpath("(//span[normalize-space()='Active']/../..//p/span[contains(text(),'HCPSL:')]/../span[2]/../../../../..//ancestor::div[contains(@class,'fifth-box')]/button)["+i+"]"));
			            		 
		            		 
		 		            selectAddressButton.click();
		 		          
		 		            try {
		 		           wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class,'alert alert-danger ')]")));
		 		           
		 		            if(Driver.findElement(By.xpath("//div[contains(@class,'alert alert-danger ')]")).isDisplayed())
		 		            {
		 		            	
		 		          	 Driver.findElement(SelectShippingLocation).click();
		 		            	
		 		            	continue;
		 		            }
		 		            else
		 		            {
		 		            	
		 		            	
		 		            	
		 		            }
		 		            }
		 		           catch (Exception e) {
		 		        	   
//		 		  			Report.updateTestLog(Action, " Unable to Click on Click here link  ", Status.FAIL);
		 		        	  System.out.println("In else 403 ");
		 		            	 		  try
		 		            	 		  {
//		 		            	Driver.findElement(newOrder).click();
		 		            	 
		 		            Driver.findElement(Proddutsdrpdown).click();
		 		            
		 		            Thread.sleep(1000);
		 		            Driver.findElement(Vaccines).click();
		 		            	
		 		            	 wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
					 						.executeScript("return document.readyState")));
					 
					 Report.updateTestLog(Action, "Clicked on the 'Start a New Order' Link   " , Status.PASS); 
//					 System.out.println("In catch 396 ");
		 		            	 		  } catch(Exception e1) {
		 		            	 			Driver.findElement(continue_shopping).click();
		 			 		            	
		 			 		            	 wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
		 						 						.executeScript("return document.readyState")));
		 						 
		 						 Report.updateTestLog(Action, "Clicked on the 'Continue Shopping ' Link   " , Status.PASS); 
		 		            	 			
		 		            	 		  }
					  try {
						  System.out.println("In catch 401 ");
				String[]	  shiptoIdtext=Driver.findElement(By.xpath("//p[contains(@class,'shipto-label d-none')]")).getText().toString().split("#:");
				
				String[]	  billtoIdtext	=Driver.findElement(By.xpath("//span[text()='#: ']/../../p[1]")).getText().toString().split("#:");
				
//					  System.out.println(shiptoIdtext[0]+ "  ::  ");
					  
					 String a=shiptoIdtext[1].replaceAll("\\s+", "");
					  
					  Report.updateTestLog(Action, "Select the Shipto ::   "+a , Status.PASS);
//					  userData.getData("RegressionData", "Shipto1");
	 					userData.putData("OrderDetails", "Shipto1", a);
 		           
	 					  
						 String b=billtoIdtext[1].replaceAll("\\s+", "");
						  
						  Report.updateTestLog(Action, "Select the Billto ::   "+b , Status.PASS);
//						  userData.getData("RegressionData", "Shipto1");
		 					userData.putData("OrderDetails", "Billto1", b);
	 		                  
		 							 							 					
		 					  
					  }
					  catch(Exception e1)
					  {
						  Report.updateTestLog(Action, "Unable toSelect the Shipto "   , Status.FAIL);
					  }
		 					
					  break;
		 		            }
					  
//		            	}
		            	 

		            }
		            

		           
		        } catch (Exception e) {
		            System.out.println("'Shipping Address' text is not present on the page.");
		        } 
			 
			 
			 
			 
			 
		 }catch(Exception e){
				System.out.println("No Alert");
				//count++;	
			}
		 
		 
		 
		 
		 
	 }
	 
	 
		
	 @Action(object = ObjectType.BROWSER, desc = "Clicking on Start a New Order button selecting 2nd shipto ", input = InputType.NO)
		public void  getActiveshipto_2() {
		 String id=Data;
		 String shiptoId=null;
		 By newOrder=By.xpath("//a[normalize-space()='Start a New Order']");
		 By shippingAddress_title=By.xpath("//div[normalize-space()='Select Shipping Address for Your Order']");
		 By SelectnoShippingLocation=By.xpath("//a[@id='change_noShipping_location']");
		 By SelectShippingLocation =By.xpath("//a[@id='change_shipping_location']");
		 
		 try {
			 
			 System.out.println("Id   ::"+id);	 
			 try {
			 Driver.findElement(SelectnoShippingLocation).click();
			 System.out.println("Try  SelectnoShippingLocation");
			 }
			 catch(Exception e){
				 
				 Driver.findElement(SelectShippingLocation).click();
				 System.out.println("Catch SelectShippingLocation ");
			 }
			 WebDriverWait wait = new WebDriverWait(Driver,10);
			
//			 flureservation_popup();
		        try {
		        	
		            wait.until(ExpectedConditions.visibilityOfElementLocated(shippingAddress_title));
		            

		            List<WebElement> activeElements = Driver.findElements(By.xpath("//span[@class='active cta cta-stroke-xs status-btn'][normalize-space()='Active']"));
		            System.out.println("activeElements.size()   ::"+activeElements.size());	
		            
		            for (int i = 1; i <= activeElements.size(); i++) {
		            		            	
		            	 shiptoId=Driver.findElement(By.xpath("(//span[normalize-space()='Active']/../../div//div[@class='not-card-view']//span[@class='label-value'])["+i+"]")).getText().toString();
	            
		            	 System.out.println("shiptoId   ::"+shiptoId);	

		            		
		            		 WebElement selectAddressButton = Driver.findElement(By.xpath("(//span[normalize-space()='Active']/../..//span[normalize-space()='Select Address'])["+i+"]"));
		 		            selectAddressButton.click();
		 		          
		 		            try {
		 		           wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class,'alert alert-danger ')]")));
		 		            if(Driver.findElement(By.xpath("//div[contains(@class,'alert alert-danger ')]")).isDisplayed())
		 		            {
		 		            	
		 		          	 Driver.findElement(SelectShippingLocation).click();
		 		            	
		 		            	continue;
		 		            }
		 		            else
		 		            {
		 		            	System.out.println("In else 383 ");
		 		            }
		 		            }
		 		           catch (Exception e) {
		 		        	   
//		 		  			Report.updateTestLog(Action, " Unable to Click on Click here link  ", Status.FAIL);
		 		  		
		 		            	 		            	
		 		            	Driver.findElement(newOrder).click();
		 		            	
		 		            	 wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
					 						.executeScript("return document.readyState")));
					 
					 Report.updateTestLog(Action, "Clicked on the 'Start a New Order' Link   "+i , Status.PASS); 
//					 System.out.println("In catch 396 ");
					
//					  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[normalize-space()='Select Shipping Address for Your Order']")));
//					  System.out.println("In catch 399 ");
					  try {
						  System.out.println("In catch 401 ");
				String[]	  shiptoIdtext=Driver.findElement(By.xpath("//p[contains(@class,'shipto-label d-none')]")).getText().toString().split("#:");
//					  System.out.println(shiptoIdtext[0]+ "  ::  ");
					  
					 String a=shiptoIdtext[1].replaceAll("\\s+", "");
					  
					  Report.updateTestLog(Action, "Select the Shipto ::   "+a , Status.PASS);
//					  userData.getData("RegressionData", "Shipto1");
	 					userData.putData("RegressionData", "Shipto1", a);
//	 					
		 							 							 					
		 					  
					  }
					  catch(Exception e1)
					  {
						  Report.updateTestLog(Action, "Unable toSelect the Shipto "   , Status.FAIL);
					  }
		 					
					  break;
		 		            }
					  
//		            	}
		            	 

		            }
		            

		           
		        } catch (Exception e) {
		            System.out.println("'Shipping Address' text is not present on the page.");
		        } 
			 
			 
			 
			 
			 
		 }catch(Exception e){
				System.out.println("No Alert");
				//count++;	
			}
		 
		 
		 
		 
		 
	 }
	 
	 
	 
		
	 @Action(object = ObjectType.BROWSER, desc = "Selecting Prodcts  ", input = InputType.YES)
		public void  ProductSelection() {
		 
		 
		 String[] InputData = Data.split(",");
		 String ShipTo=userData.getData("RegressionData", "Shipto1");
			String Product = InputData[0]; // 705809
			String Quantity = InputData[1]; // 10
			
			System.out.println("  ::  "+Product+" ::  "+Quantity);
			 WebDriverWait wait = new WebDriverWait(Driver,10);
			 wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
			 						.executeScript("return document.readyState")));
			 
					            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[@class='shipto-label d-none d-md-block']//span[contains(text(),'Ship To #:')]")));	
			
			try
			{
				By qty=By.xpath("//*[@id='qty-"+Product+"']//input");
				By addtoCart=By.xpath("//div[@id='pid-"+Product+"']//button[contains(text(),'Add to Cart')]");
//				By Listprice=By.xpath("//*[@id='price-"+Product+"']//p");
				
//				System.out.println("  ::: ");
				
				JavascriptExecutor js = (JavascriptExecutor) Driver;
				
				WebElement element = Driver.findElement(qty);

		        // Delete the existing text in the text box
//				 js.executeScript("arguments[0].value = '';", element);
		        element.sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.DELETE));

		        // Enter the data into the text box
		        element.sendKeys(Quantity);
		        
//		        js.executeScript("arguments[0].value = '"+Quantity+"';", element);
		        
		        Thread.sleep(3000); 
		        Report.updateTestLog(Action,  " Packs :: "+Quantity  , Status.PASS);
				//Driver.findElement(qty)
		        
//		        Driver.findElement(By.xpath("//*[@id='qty-"+Product+"']")).click();
		        Thread.sleep(3000); 
//		        Report.updateTestLog(Action,  " Packs :: "+Quantity  , Status.PASS);
//		        System.out.println( "  after qty "+Quantity +Driver.findElement(addtoCart).getText());
//		        String price=Driver.findElement(Listprice).getText().toString();
		        try
		        { Driver.findElement(addtoCart).click();
		        
//		        	 WebElement element1 = Driver.findElement(addtoCart);
//					 js.executeScript("arguments[0].click();", element1);
		        Report.updateTestLog(Action,  " Clicked on addtoCart button :: "+Driver.findElement(addtoCart).getText()  , Status.PASS);
			 } catch (Exception e) {
//				 Driver.findElement(addtoCart).click();
				 WebElement element1 = Driver.findElement(addtoCart);
				 js.executeScript("arguments[0].click();", element1);
	        
				 Report.updateTestLog(Action,  " addtoCart button Clicked :: "+Driver.findElement(addtoCart).getText()  , Status.PASS);
			 }
				System.out.println( "  before refresh ");
				Driver.navigate().refresh();

				
				wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
						.executeScript("return document.readyState")));

				   System.out.println( "  cartTotal ");
				if (Driver.findElement(By.xpath("//div[contains(@class,'cartTotal')]")).isDisplayed()) {
					 userData.putData("RegressionData", "quantity", Quantity);
					 userData.putData("RegressionData", "Products", Product);
					 
//				        userData.putData("RegressionData", "List Price", splitss[0].toString());
					 System.out.println( "  inside ");
					flureservation_popup();
					Report.updateTestLog(Action, Quantity + " Packs of " +Product+" Added To Cart for ShipTo "+ShipTo, Status.PASS);
					
					

				}else {
					Report.updateTestLog(Action, " No Product Added To Cart for ShipTo "+ShipTo, Status.FAIL);

				}
				
				
			}catch(Exception e){
				System.out.println("No Alert");
				Report.updateTestLog(Action, " No Product Added To Cart for ShipTo ", Status.FAIL);
				//count++;	
			}
	 
		 
		 
	 }
	 
	 
	 
@Action(object = ObjectType.BROWSER, desc = "Clicking on Shipto Cart", input = InputType.NO)	 
public void ShiptocartClick() 

{	//Wait until page load is complete	
	
	spinnerLoad();
	WebDriverWait wait = new WebDriverWait(Driver,20);
		try {
			try {
			
		Driver.findElement(By.xpath("//*[@class='miniCart']//a")).click();
		}catch(Exception e){
			
			 JavascriptExecutor js = (JavascriptExecutor) Driver;
			 js.executeScript("arguments[0].click();", Driver.findElement(By.xpath("//*[@class='miniCart']//a")));
		}
			spinnerLoad();
		wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
				.executeScript("return document.readyState")));
		
		if (Driver.findElement(By.xpath("//a[normalize-space()='Shipping & Payment Information']")).isDisplayed()) {
			
//			flureservation_popup();
			Report.updateTestLog(Action, " Navigated to  Shipping & Payment Information Page  ", Status.PASS);
			
		 

		}else {
			Report.updateTestLog(Action, " Unable to Navigated to  Shipping & Payment Information Page  ", Status.FAIL);

		}
		
		
		}catch(Exception e){
			System.out.println("Shipto Click failed");
			//count++;	
		}
		
}
		
//@Action(object = ObjectType.BROWSER, desc = "Enter ProductCount,CartCount,ProductPerCart,ShipTo-BillTo [<Data>]", input = InputType.YES)
public void verifyShoppingCartPage_Needtowork() {
String paymenttype=null;

List<WebElement> Carts = Driver.findElements(By.xpath("//*[@class='card-header']"));


double ExpectedTotalPriceWithVat_AllCart = 0.00;

for (int i=1;i<=Carts.size();i++) {
	
	// Verify ShipTo Row expanded by default
	WebElement ShipToToggle = Driver.findElement(By.xpath("(//*[@class='card-header']//button)["+i+"]"));
//
//	if (ShipToToggle.getAttribute("aria-expanded").equalsIgnoreCase("true")) {
//		Report.updateTestLog(Action, "Cart "+i+ " Expanded By Default", Status.PASS);
//	}else {
//		Report.updateTestLog(Action, "Cart "+i+ " NOT Expanded By Default", Status.FAIL);
//	}
//
//	ShipToToggle.click();

	// Verify ShiTo Row Collapse
	if (ShipToToggle.getAttribute("aria-expanded").equalsIgnoreCase("false")) {

		Report.updateTestLog(Action, "Cart "+i+ " Toggle is Collapsed", Status.PASS);

		if (Driver.findElement(By.xpath("(//*[@class='card-header']//button)["+i+"]/..//div[@class='collapse show']")).isDisplayed()) {
			Report.updateTestLog(Action, "Cart "+i+ " is NOT Collapsed", Status.FAIL);
		}else {
			Report.updateTestLog(Action, "Cart "+i+ " is Collapsed", Status.PASS);

		}
	}else {
		Report.updateTestLog(Action, "Cart "+i+ " Toggle is NOT Collapsed", Status.FAIL);
	}



	ShipToToggle.click();

	// Verify ShiTo Row Expand
	if (ShipToToggle.getAttribute("class").equalsIgnoreCase("true")) {

		Report.updateTestLog(Action, "Cart "+i+ " Toggle is Expanded", Status.PASS);

		if (Driver.findElement(By.xpath("//div[@class='row ship-to']["+i+"]/..//div[@class='collapse show']")).isDisplayed()) {
			Report.updateTestLog(Action, "Cart "+i+ " is Expanded", Status.PASS);
		}else {
			Report.updateTestLog(Action, "Cart "+i+ " is NOT Expanded", Status.FAIL);
		}
	}else {
		Report.updateTestLog(Action, "Cart "+i+ " Toggle is NOT Expanded", Status.FAIL);
	}
	
	
	
	
	
	
	
	
}



}


@Action(object = ObjectType.BROWSER, desc = "Enter ProductCount,CartCount,ProductPerCart,ShipTo-BillTo [<Data>]", input = InputType.NO)
public void shippingcartPageValidation()

{
	
	try {
	
	
//	 List<WebElement> buttons = Driver.findElements(By.xpath("(//*[@class='card-header']//button)"));
	 List<WebElement> buttons = Driver.findElements(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])"));
	 
	 addVar("%buttonsize%",Integer.toString(buttons.size()));
	  System.out.println("buttons  " +buttons.size() );
     // Loop through the list of buttons
     for (int i = 1; i <= buttons.size(); i++) {
         // Get the current button
         WebElement button =  Driver.findElement(By.xpath("  (//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+i+"]//button"));
         System.out.println("buttons  791  " +button.getText() );
         // Get the value of the attribute "aria-expanded"
         
         Report.updateTestLog(Action, "Shipping & Payment Information Page  " , Status.PASS);
         
         String ariaExpanded = button.getAttribute("aria-expanded");
System.out.println(ariaExpanded);
         // Check if the value is "false"
         if (ariaExpanded.equals("false")) {
             // Click on the button
             button.click();
             
             Report.updateTestLog(Action, "Clicking on ship  " +i, Status.PASS);
             try {
             // Find the element that matches the xpath "(//*[@class='card-header']//button)["+i+"]/..//div[contains(@class,'noOfProds')]"
             WebElement div = Driver.findElement(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+i+"]/../../div/div[@class='collapse show']"));

             // Get the value of the attribute "class"
             String divClass = div.getAttribute("class");

             // Check if the value contains "collapse show"
             if (divClass.contains("collapse show")) {
                 // Print a message
                 System.out.println("The div element is expanded");
                 
                 Report.updateTestLog(Action, "collapse show is displayed Page  " , Status.PASS);
                 
                 payBy_Selection(i);

                 System.out.println("After payby selection  "+i);
                 
                 if((buttons.size()==1)) {
                 shippingPage_priceValidation(i);
                 }
                 
                 
                 
             }
             
            
             
             } catch (Exception e) {
                 // Catch any exception and print the error message
                 System.out.println("An error occurred: " + e.getMessage());
             }
         }
         
         
         else
         {
//        	 WebElement div = Driver.findElement(By.xpath("(//*[@class='card-header']//button)["+i+"]/../../div[@class='collapse show']"));
        	 WebElement div = Driver.findElement(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+i+"]/../../div/div[@class='collapse show']"));

             // Get the value of the attribute "class"
             String divClass = div.getAttribute("class");

             // Check if the value contains "collapse show"
             if (divClass.contains("collapse show")) {
                 // Print a message
                 System.out.println("The div element is expanded");
                 
                 Report.updateTestLog(Action, "Expanded Page displayed " , Status.PASS);
                 try
                 {
                	 
                	payBy_Selection(i);	 
                	 System.out.println("After payby selection  "+i);
                       	 
                 shippingPage_priceValidation(i);
                 
                 }catch (Exception e) {
                     // Catch any exception and print the error message
                     System.out.println("An error occurred: " + e.getMessage());
                 }
                 
                 
             }
        	 
         }
     }
     
     
     ordersummary_validation();
     
     
	} catch (Exception e) {
        // Catch any exception and print the error message
        System.out.println("An error occurred: " + e.getMessage());
    }
	
	
}

public void shippingCart_dataValidation(int i)
{
	String sln=null,cname=null,pdetails=null,rdd=null,Daddress=null;
	
	
	String Slndata = userData.getData("OrderDetails", "SLN"+i);
	String contract=getVar("%contractname"+i+"%");
	String ptype=userData.getData("OrderDetails", "CardDetails"+i);
	
	
	
	try {
		
		rdd=Driver.findElement(By.xpath("(//input[contains(@id,'deliveryDP')])["+i+"]")).getText();
		addVar("%rdd"+i+"%",contract);
		
		Driver.findElement(By.xpath("(//*[contains(@id,'specialDeliveryInstructions')])["+i+"]")).sendKeys();
		
		Driver.findElement(By.xpath("((//*[contains(@id,'poNumber')])["+i+"]")).sendKeys();
		
	} catch (Exception e) {
        // Catch any exception and print the error message
        System.out.println("An error occurred: " + e.getMessage());
    }
	
	
	
	
	
	
	
	
	
	
}

public static double convertStringToDouble(String s) {
	double d=0;
	String sWithoutComma =null;
	try {
		
		 sWithoutComma = s.replace("$", "");
		
		 sWithoutComma = sWithoutComma.replace(",", "");
		  // Parse the string without the comma as a double value
		  d = Double.parseDouble(sWithoutComma);
		  
		
				
		 
	}
	catch (Exception e) {
		System.out.println(e);
		sWithoutComma = sWithoutComma.replace(",", "");
		  // Parse the string without the comma as a double value
		  d = Double.parseDouble(sWithoutComma);
		
	}
	return d; 
	
	}


public static String removeSymbols(String input) {
	  // use replaceAll method with regex to remove $ and ,
	  return input.replaceAll("[$,]", "");
	}

public void shippingPage_priceValidation(int k)  {
	 DecimalFormat decimalFormat = new DecimalFormat("#,###.###");
	System.out.println(" shippingPage_priceValidation   k value "+k);
	JavascriptExecutor js = (JavascriptExecutor) Driver;
	Double cprice=null,lprice=null,cs=null,fet=null,ItemTotal=null;
	Double listprice=0.00,contractprice=0.00,ContractSaving=0.00,Fetdata=0.00,EST=0.00,ContractSaving_perpack=0.00, It1=0.00;
	Double ContractSaving_OS=0.00, subtotal_OS=0.00,Fet_OS=0.00, EST_OS=0.00,total_OS=0.00;	
	int pn1=0,pn2=0;
//	Double  = Double.valueOf(
	
	
	String Productname=null,NDC=null,quantity=null,contract=null;
	
	List<WebElement> p1 = Driver.findElements(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])/..//a[@class='productName']"));
	pn1=p1.size();
	String num=getVar("%buttonsize%");
	int btn=Integer.parseInt(num);
	
	String pname=null, product=null,qty=null;
	try {
	List<WebElement> products = Driver.findElements(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//a[@class='productName']"));
	System.out.println();
	//
	for (int h=1;h<=products.size();h++) {////
		//pn2=pn2+h;
		
		System.out.println("pn2=pn2+h   :: "+pn2);
if(btn<=1) {
	Report.updateTestLog(Action, " inside  btn<=1   is ::  " +btn  , Status.DONE);
		 product= (userData.getData("OrderDetails", "Product" + h));
		System.out.println("Product ::  "+product);
		 qty=(userData.getData("OrderDetails", "qty" + h));
		System.out.println("qty ::  "+qty);
		 listprice=Double.parseDouble((userData.getData("OrdersPriceValidation", "ListPrice" + h)));
		System.out.println("listprice ::  "+listprice);
		 contractprice=Double.parseDouble((userData.getData("OrdersPriceValidation", "ContractPrice" + h)));
		System.out.println("contractprice ::  "+contractprice);
		 ContractSaving=Double.parseDouble((userData.getData("OrdersPriceValidation", "Savings with promotion" + h)));
		System.out.println("ContractSaving ::  "+ContractSaving);
		 Fetdata=Double.parseDouble((userData.getData("OrdersPriceValidation", "Total Federal excise tax" + h)));
		 
		System.out.println("Fetdata ::  1025    "+Fetdata);
		 EST=Double.parseDouble((userData.getData("OrdersPriceValidation", "Total Estimated sales tax" + h)));
		 
		 ContractSaving_perpack=Double.parseDouble((userData.getData("OrdersPriceValidation", "Savings with promotion" + h)));
		 addVar("%feaa%",Double.toString(Fetdata));
		 
		  String oo=getVar("%feaa%");
		  System.out.println("oo ::  1032   ::    "+oo);
		  
		try {
		 It1=Double.parseDouble((userData.getData("OrdersPriceValidation", "Price for contract" +h)));
		
		} catch (Exception e) {
	       
			try {
			It1=convertStringToDouble(userData.getData("OrdersPriceValidation", "Price for contract" +h));	
			
			} catch (Exception e1) {
				
				System.out.println(e1);
				
				
				
			}
	    }
		try {
			String pn = "%prodname" + h + "%";
			Productname=getVar(pn);
			}
			catch (Exception e) {
				 System.out.println("catch    Productname  :: "); 
				
			}
		
		

		System.out.println("It1 ::  "+It1);
		Double subtot=convertStringToDouble(userData.getData("OrdersPriceValidation", "Subtotal before savings" +h));
		System.out.println("subtot ::  "+subtot);	
		
		System.out.println( " ContractSaving_OS  :"+ContractSaving);
		ContractSaving_OS=get2DecimalDoubleValue(ContractSaving_OS+ContractSaving);
		System.out.println(ContractSaving_OS+ " ContractSaving_OS  :"+ContractSaving);
		
		subtotal_OS=get2DecimalDoubleValue(subtotal_OS+subtot);
		Fet_OS=Fet_OS+Fetdata;
		EST_OS=EST_OS+EST;
		total_OS=total_OS+It1;
		System.out.println(subtotal_OS  +" ::   Fet_OS ::  "+Fet_OS+" ::   EST_OS :: "+EST_OS+" ::   total_OS  ::  "+total_OS);
		
		Report.updateTestLog(Action, subtotal_OS  +" ::  btn<=1  Fet_OS ::  "+Fet_OS+" ::   EST_OS :: "+EST_OS+" ::   total_OS  ::  "+total_OS , Status.DONE);
		
		
}


//Report.updateTestLog(Action, k+ "  Btn is  (btn>1) ::  " +btn+" h:: " +h , Status.DONE);
else if(btn>1) 
{
		Report.updateTestLog(Action, " inside    is ::  " +btn  +"  pn2=pn2+h   :: "+pn2 , Status.DONE);
	 product= (userData.getData("OrderDetails", "Product" +k ));
	System.out.println("Product ::  "+product);
	 qty=(userData.getData("OrderDetails", "qty" + k));
	System.out.println("qty ::  "+qty);
	 listprice=Double.parseDouble((userData.getData("OrdersPriceValidation", "ListPrice" + k)));
	System.out.println("listprice ::  "+listprice);
	 contractprice=Double.parseDouble((userData.getData("OrdersPriceValidation", "ContractPrice" + k)));
	System.out.println("contractprice ::  "+contractprice);
	 ContractSaving=Double.parseDouble((userData.getData("OrdersPriceValidation", "Savings with promotion" + k)));
	System.out.println("ContractSaving ::  "+ContractSaving);
	 Fetdata=Double.parseDouble((userData.getData("OrdersPriceValidation", "Total Federal excise tax" + k)));
		
	 
	 System.out.println("Fetdata ::  1091 ::   "+Fetdata);
	
	addVar("%feaa%",Double.toString(Fetdata));
	
	 EST=Double.parseDouble((userData.getData("OrdersPriceValidation", "Total Estimated sales tax" + k)));
	 ContractSaving_perpack=Double.parseDouble((userData.getData("OrdersPriceValidation", "Savings with promotion" + k)));
	
	try {
	 It1=Double.parseDouble((userData.getData("OrdersPriceValidation", "Price for contract" +k)));
	
	} catch (Exception e) {
      
		try {
		It1=convertStringToDouble(userData.getData("OrdersPriceValidation", "Price for contract" +k));	
		
		} catch (Exception e1) {
			
			System.out.println(e1);
			
			
			
		}
		
		
   }
	
	try {
		String pn = "%prodname" + k + "%";
		Productname=getVar(pn);
		}
		catch (Exception e) {
			 System.out.println("catch    Productname  :: "); 
			
		}
	
	
	
	System.out.println("It1 ::  "+It1);
	Double subtot=convertStringToDouble(userData.getData("OrdersPriceValidation", "Subtotal before savings" +h));
	System.out.println("subtot ::  "+subtot);	
	
	System.out.println( " ContractSaving_OS  :"+ContractSaving);
	ContractSaving_OS=get2DecimalDoubleValue(ContractSaving_OS+ContractSaving);
	System.out.println(ContractSaving_OS+ " ContractSaving_OS  :"+ContractSaving);
	
	subtotal_OS=get2DecimalDoubleValue(subtotal_OS+subtot);
	Fet_OS=Fet_OS+Fetdata;
	EST_OS=EST_OS+EST;
	total_OS=total_OS+It1;
//	System.out.println(subtotal_OS  +" ::   Fet_OS ::  "+Fet_OS+" ::   EST_OS :: "+EST_OS+" ::   total_OS  ::  "+total_OS);
	
	Report.updateTestLog(Action, subtotal_OS  +" ::   Fet_OS ::  "+Fet_OS+" ::   EST_OS :: "+EST_OS+" ::   total_OS  ::  "+total_OS , Status.DONE);
	

	
}
	
	

	
	
	try {
		
	pname	= Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//a[@class='productName'])["+h+"]")).getText();
//	NDC=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//a[@class='productName']/../../div/p/span)["+h+"]")).getText();
	NDC=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//a[@class='productName']//following-sibling::p//span)["+h+"]")).getText();
	
//	quantity=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//*[@class='productQtyBoxWrap']//input)["+h+"]")).getText();
	
	
	cprice=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//p[@class='contractPrice']//span)["+h+"]")).getText());
	System.out.println("cprice ::  "+cprice);	
	lprice=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//p[@class='listPrice']//span)["+h+"]")).getText());
	System.out.println("lprice ::  "+lprice);	
	
	cs=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//p[contains(@class,'contractSaving')]//span)["+h+"]")).getText());
	System.out.println("cs ::  "+cs);	
	fet=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//p[@class='fedtax']//span)["+h+"]")).getText());
	System.out.println("fet ::  "+fet);	
	
	ItemTotal=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//p[@class='itemTotal']//span)["+h+"]")).getText());
	
	System.out.println("ItemTotal ::  "+ItemTotal);	
	
	

String qtyy=null;
	try{
		qtyy=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//*[@class='productQtyBoxWrap']//label[@class='packqty text-center'])["+h+"]")).getText();
	
	}
	catch (Exception e) {
		 System.out.println("catch    qtyy  :: "); 
		 qtyy=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//div[contains(@class,'productQtyInfo')]//p)["+h+"]")).getText();
			
		
	}
	String[] split = qtyy.split("=");

	// get the first value from the array and trim any whitespace
	split = split[0].split("Packs");
	
	quantity=split[0].trim();
	 
	 System.out.println( "k :: "+ k+  "quantity    1073  :: "+quantity+ "   :: h  :: "+ h); 
	if(pname.equalsIgnoreCase(Productname))
		
	{
		Report.updateTestLog(Action, "Excepted Productname is ::  " +Productname  + " and Actual Productname is same::  " +pname , Status.PASS);
	}
	else
		
	{
		Report.updateTestLog(Action, "Excepted Productname is ::  " +Productname  + " and Actual Productname is  Not Matched ::  " +pname , Status.FAIL);
	}
	
	
	
if(NDC.equalsIgnoreCase(product))
		
	{
		Report.updateTestLog(Action, "Excepted Productname is ::  " +product  + " and Actual Productname is same::  " +NDC , Status.PASS);
	}
	else
		
	{
		Report.updateTestLog(Action, "Excepted Productname is ::  " +product  + " and Actual Productname is  Not Matched ::  " +NDC , Status.FAIL);
	}


if(qty.equalsIgnoreCase(quantity))
	
{
	Report.updateTestLog(Action, "Excepted quantity is ::  " +qty  + " and Actual quantity is same::  " +quantity , Status.PASS);
}
else
	
{
	Report.updateTestLog(Action, "Excepted quantity is ::  " +qty  + " and Actual quantity is  Not Matched ::  " +quantity , Status.FAIL);
}



	
	if(cprice.equals(contractprice))	
		
	{
		Report.updateTestLog(Action, "Excepted Contract price is ::  " +contractprice  + " and Actual Contract price is same::  " +cprice , Status.PASS);
	}
	else
		
	{
		Report.updateTestLog(Action, "Excepted Contract price is ::  " +contractprice  + " and Actual Contract price is  Not Matched ::  " +cprice , Status.FAIL);
	}
		
		
		if(lprice.equals(listprice))	
			
		{
			Report.updateTestLog(Action, "Excepted listprice is ::  " +listprice  + " and Actual listprice is same::  " +lprice , Status.PASS);
		}
		else
			
		{
			Report.updateTestLog(Action, "Excepted listprice is ::  " +listprice  + " and Actual listprice is  Not Matched ::  " +lprice , Status.FAIL);
		}
		
	if(cs.equals(ContractSaving_perpack))	
			
		{
			Report.updateTestLog(Action, "Excepted ContractSaving is ::  " +ContractSaving_perpack  + " and Actual ContractSaving is same::  " +cs , Status.PASS);
		}
		else
			
		{
			Report.updateTestLog(Action, "Excepted ContractSaving is ::  " +ContractSaving_perpack  + " and Actual ContractSaving  is  Not Matched ::  " +cs , Status.FAIL);
		}

	if(fet.equals(Fetdata))	
		
	{
		Report.updateTestLog(Action, "Excepted Federal Excise Tax is ::  " +Fetdata  + " and Actual Federal Excise Tax is same::  " +fet , Status.PASS);
	}
	else
		
	{
		Report.updateTestLog(Action, "Excepted Federal Excise Tax is ::  " +Fetdata  + " and Actual Federal Excise Tax is  Not Matched ::  " +fet , Status.FAIL);
	}

	if(ItemTotal.equals(It1))	
		
	{
		Report.updateTestLog(Action, "Excepted Item Total is ::  " +ItemTotal  + " and Actual Item Total is same::  " +It1 , Status.PASS);
	}
	else
		
	{
		Report.updateTestLog(Action, "Excepted Item Total is ::  " +ItemTotal  + " and Actual Item Total  is  Not Matched ::  " +It1 , Status.FAIL);
	}

	
	
//	pn2=pn2+1;	
//	
//	Report.updateTestLog(Action, "pn2=pn2+1;  1239 try  ::  " +pn2  , Status.DONE);
	}
catch (Exception e) {
	
	
        
	Report.updateTestLog(Action, "Excepted listprice is :: 1245   catch"  , Status.DONE);
	
	
	
	
	
	pname	= Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//a[@class='productName'])["+h+"]")).getText();
	NDC=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//a[@class='productName']//following-sibling::p//span)["+h+"]")).getText();
	
	
	lprice=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//p[@class='contractPrice']//span)["+h+"]")).getText());
	System.out.println("lprice ::  "+lprice);	
	
	cs=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//p[contains(@class,'contractSaving')]//span)["+h+"]")).getText());
	System.out.println("cs ::  "+cs);	
	fet=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//p[@class='fedtax']//span)["+h+"]")).getText());
	System.out.println("fet ::  "+fet);	
	
	ItemTotal=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//p[@class='itemTotal']//span)["+h+"]")).getText());
	
//	System.out.println("ItemTotal ::  "+ItemTotal);	
//	try {
//	String pn = "%prodname" + k + "%";
//	Productname=getVar(pn);
//	}
//	catch (Exception e1) {
//		 System.out.println("catch    Productname  :: "); 
//		
//	}
	
String qtyy=null;
	try{
		qtyy=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//*[@class='productQtyBoxWrap']//label[@class='packqty text-center'])["+h+"]")).getText();
	
	}
	catch (Exception e1) {
		 System.out.println("catch    qtyy  :: "); 
		 qtyy=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//div[contains(@class,'productQtyInfo')]//p)["+h+"]")).getText();
			
		
	}
	String[] split = qtyy.split("=");

	// get the first value from the array and trim any whitespace
	split = split[0].split("Packs");
	
	quantity=split[0].trim();
	 
	 System.out.println( "k :: "+ k+  "quantity  catch   1228  :: "+quantity+ "   :: h  :: "+ h); 
	if(pname.equalsIgnoreCase(Productname))
		
	{
		Report.updateTestLog(Action, "Excepted Productname is ::  " +Productname  + " and Actual Productname is same::  " +pname , Status.PASS);
	}
	else
		
	{
		Report.updateTestLog(Action, "Excepted Productname is ::  " +Productname  + " and Actual Productname is  Not Matched ::  " +pname , Status.FAIL);
	}
	
	
	
if(NDC.equalsIgnoreCase(product))
		
	{
		Report.updateTestLog(Action, "Excepted Productname is ::  " +product  + " and Actual Productname is same::  " +NDC , Status.PASS);
	}
	else
		
	{
		Report.updateTestLog(Action, "Excepted Productname is ::  " +product  + " and Actual Productname is  Not Matched ::  " +NDC , Status.FAIL);
	}


if(qty.equalsIgnoreCase(quantity))
	
{
	Report.updateTestLog(Action, "Excepted quantity is ::  " +qty  + " and Actual quantity is same::  " +quantity , Status.PASS);
}
else
	
{
	Report.updateTestLog(Action, "Excepted quantity is ::  " +qty  + " and Actual quantity is  Not Matched ::  " +quantity , Status.FAIL);
}



	
		
		
		if(lprice.equals(listprice))	
			
		{
			Report.updateTestLog(Action, "Excepted listprice is ::  " +listprice  + " and Actual listprice is same::  " +lprice , Status.PASS);
		}
		else
			
		{
			Report.updateTestLog(Action, "Excepted listprice is ::  " +listprice  + " and Actual listprice is  Not Matched ::  " +lprice , Status.FAIL);
		}
		
	if(cs.equals(ContractSaving_perpack))	
			
		{
			Report.updateTestLog(Action, "Excepted ContractSaving is ::  " +ContractSaving_perpack  + " and Actual ContractSaving is same::  " +cs , Status.PASS);
		}
		else
			
		{
			Report.updateTestLog(Action, "Excepted ContractSaving is ::  " +ContractSaving_perpack  + " and Actual ContractSaving  is  Not Matched ::  " +cs , Status.FAIL);
		}
if(fet.equals(Fetdata))	
		
	{
		Report.updateTestLog(Action, "Excepted Federal Excise Tax is ::  " +Fetdata  + " and Actual Federal Excise Tax is same::  " +fet , Status.PASS);
	}
	else
		
	{
		Report.updateTestLog(Action, "Excepted Federal Excise Tax is ::  " +Fetdata  + " and Actual Federal Excise Tax is  Not Matched ::  " +fet , Status.FAIL);
	}

	if(ItemTotal.equals(It1))	
		
	{
		Report.updateTestLog(Action, "Excepted Item Total is ::  " +ItemTotal  + " and Actual Item Total is same::  " +It1 , Status.PASS);
	}
	else
		
	{
		Report.updateTestLog(Action, "Excepted Item Total is ::  " +ItemTotal  + " and Actual Item Total  is  Not Matched ::  " +It1 , Status.FAIL);
	}
	
	
	pn2=pn2+1;	
	Report.updateTestLog(Action, "pn2=pn2+1;  1384 catch  ::  " +pn2  , Status.DONE);
		
	
}
	
	
	
	
	
	
	
	}
	
addVar("%ContractSaving_OS%",Double.toString(ContractSaving_OS));	
addVar("%subtotal_OS%",Double.toString(ContractSaving_OS));
addVar("%Fet_OS%",Double.toString(Fet_OS));
addVar("%EST_OS%",Double.toString(EST_OS));
addVar("%total_OS%",Double.toString(total_OS));
	
		}catch (Exception e) {
        // Catch any exception and print the error message
        System.out.println("An error occurred: " + e.getMessage());
    }
}

public void ordersummary_validation()
{
	
	String ContractSaving_OS= getVar("%ContractSaving_OS%");	
	String subtotal_OS= getVar("%subtotal_OS%");
	String Fet_OS=null;
	String EST_OS= getVar("%EST_OS%");
	String total_OS= getVar("%total_OS%");
	
	String fe=getVar("%feaa%");
	String res=null;
	Double fet=0.0,fe1=0.0,fe2=0.0;
//	//
	try {
		
		Fet_OS	= getVar("%Fet_OS%");
//		res=Driver.findElement(By.xpath("//span[normalize-space()='Reservation:']")).getText();
		
		if(res.contains("Reservation:"))
			
		{
			
			fet=Double.valueOf(Fet_OS);
			System.out.println("fet    1484 ::"+fet );
			fe1=Double.valueOf(fe);
			System.out.println("fe1    1486 ::"+fe1 );
		fe2=fet-fe1;
		
		Fet_OS=String.valueOf(fe2);
			
			
		}
		
		
	}catch (Exception e) {
        
		Fet_OS	= getVar("%Fet_OS%");
		
		System.out.println("Fet_OS    1500 ::"+Fet_OS );
    }
	
	Report.updateTestLog(Action, subtotal_OS  +" :: 1705 ::   Fet_OS ::  "+Fet_OS+" ::   EST_OS :: "+EST_OS+" ::   total_OS  ::  "+total_OS , Status.DONE);

try {
	
//	Double	ContractSavings_OS_actual=convertStringToDouble(Driver.findElement(By.xpath("(//div[@id='collapseOne']//p)[1]//span")).getText());
//	System.out.println("ContractSavings_OS_actual  :: "+ContractSavings_OS_actual);	
//	Double	subtotal_OS_actual=convertStringToDouble(Driver.findElement(By.xpath("(//div[@id='collapseOne']//p)[3]//span")).getText());
//	System.out.println("subtotal_OS_actual ::  "+subtotal_OS_actual);	
//	Double fet_OS=get2DecimalDoubleValue(convertStringToDouble(Driver.findElement(By.xpath("(//div[@id='collapseOne']//p)[4]//span")).getText()));
//	String fet_OS=(Driver.findElement(By.xpath("(//div[@id='collapseOne']//p)[4]//span")).getText());
//	System.out.println("fet_OS ::  "+fet_OS);	
//	
//
//	Double est_os=convertStringToDouble(Driver.findElement(By.xpath("(//div[@id='collapseOne']//p)[5]//span")).getText());
//	System.out.println("est_os ::  "+est_os);	
//	
//	Double	Totalamount=convertStringToDouble(Driver.findElement(By.xpath("//*[contains(text(),'Total Price')]//span")).getText());
//	
//	System.out.println("Totalamount ::  "+Totalamount);
	
	String	ContractSavings_OS_actual=Driver.findElement(By.xpath("(//div[@id='collapseOne']//p)[1]//span")).getText();
	System.out.println("ContractSavings_OS_actual  :: "+ContractSavings_OS_actual);	
	String	subtotal_OS_actual=removeSymbols(Driver.findElement(By.xpath("(//div[@id='collapseOne']//p)[3]//span")).getText());
	System.out.println("subtotal_OS_actual ::  "+subtotal_OS_actual);	
//	Double fet_OS=get2DecimalDoubleValue(convertStringToDouble(Driver.findElement(By.xpath("(//div[@id='collapseOne']//p)[4]//span")).getText()));
	String fet_OS=(Driver.findElement(By.xpath("(//div[@id='collapseOne']//p)[4]//span")).getText());
	System.out.println("fet_OS ::  "+fet_OS);	
//	

	String est_os=(Driver.findElement(By.xpath("(//div[@id='collapseOne']//p)[5]//span")).getText());
	System.out.println("est_os ::  "+est_os);	
	
	String	Totalamount=removeSymbols((Driver.findElement(By.xpath("//*[contains(text(),'Total Price')]//span")).getText()));
	
	System.out.println("Totalamount ::  "+Totalamount);

//	if(ContractSaving_OS.contains(ContractSavings_OS_actual))	
		if(ContractSavings_OS_actual.contains(ContractSaving_OS))	
				
	{
		
		Report.updateTestLog(Action, "Order Summary Excepted Contract Savings is ::  " +ContractSaving_OS  + " and Actual Contract Savings is same::  " +ContractSavings_OS_actual , Status.PASS);
	}
	else
		
	{
		
		Report.updateTestLog(Action, "Order Summary Excepted Contract Savings is ::  " +ContractSaving_OS  + " and Actual Contract Savings is  Not Matched ::  " +ContractSavings_OS_actual , Status.FAIL);
	}
	
//if(subtotal_OS.contains(subtotal_OS_actual))	
		
	if(subtotal_OS_actual.contains(subtotal_OS))	
	{
	
		Report.updateTestLog(Action, "Order Summary Excepted Subtotal is ::  " +subtotal_OS  + " and Actual Subtotal is same::  " +subtotal_OS_actual , Status.PASS);
	}
	else
		
	{
		Report.updateTestLog(Action, "Order Summary Excepted Subtotal is ::  " +subtotal_OS  + " and Actual Subtotal  is  Not Matched ::  " +subtotal_OS_actual , Status.FAIL);
	}
//DecimalFormat df = new DecimalFormat("0.00");
//
//
//String stringValue = String.valueOf(df.format(Fet_OS));
//
////add the $ symbol to the string value using concatenation
//String Fet_OS1 = "$" + stringValue;
//System.out.println(fet_OS+   "  ::   Fet_OS1   ::   "+Fet_OS1);

//if(Fet_OS1.contains(fet_OS))
	
	if(fet_OS.contains(Fet_OS))	
{
	Report.updateTestLog(Action, "Excepted Federal Excise Tax is ::  " +Fet_OS  + " and Actual Federal Excise Tax is same::  " +fet_OS , Status.PASS);
}
else
	
{
	Report.updateTestLog(Action, "Excepted Federal Excise Tax is ::  " +Fet_OS  + " and Actual Federal Excise Tax is  Not Matched ::  " +fet_OS , Status.FAIL);
}

//if(EST_OS.contains(est_os))	
	if(est_os.contains(EST_OS))	
{
	Report.updateTestLog(Action, "Excepted Estimated Sales Tax is ::  " +EST_OS  + " and Actual Estimated Sales Tax is same::  " +est_os , Status.PASS);
}
else
	
{
	Report.updateTestLog(Action, "Excepted Estimated Sales Tax is ::  " +EST_OS  + " and Actual Estimated Sales Tax  is  Not Matched ::  " +est_os , Status.FAIL);
}
	
	
if(Totalamount.contains(total_OS))	
//	if(total_OS.contains(Totalamount))	
	
{
	Report.updateTestLog(Action, "Excepted Total Price is ::  " +total_OS  + " and Actual Total Price is same::  " +Totalamount , Status.PASS);
}
else
	
{
	Report.updateTestLog(Action, "Excepted Total Price is ::  " +total_OS  + " and Actual Total Price  is  Not Matched ::  " +Totalamount , Status.FAIL);
}
		
	
	
	
	
}catch (Exception e1) {
    // Catch any exception and print the error message
    System.out.println("An error occurred: " + e1.getMessage());
}
	
	}	







@Action(object = ObjectType.BROWSER,desc = "This method Will take all the prices,Quantity,Product details and put data in CocPageDetails datasheet",input = InputType.NO)

public void price_Split() throws InterruptedException  {
	
	Thread.sleep(5000); 
    WebElement listPrice=null;
    DecimalFormat decimalFormat = new DecimalFormat("#,###.##");
    
    Double federalTax = Double.valueOf(userData.getData("RegressionData", "Federal excise tax"));
    String Product = userData.getData("RegressionData", "Products");
  // Double salesTax = Double.valueOf(userData.getData("RegressionData", "Estimated sales tax"));
    //List price
    String	 quantity = userData.getData("RegressionData", "quantity");
	By Listprice=By.xpath("//*[@id='price-"+Product+"']//p[1]");
	By Contractprice=By.xpath("//*[@id='price-"+Product+"']//p[2]");
	
    Double qty = Double.valueOf(quantity);
  
   
    try {
    	  System.out.println("Entering try  block");
    	listPrice = Driver.findElement(Listprice);
    	
    } catch (Exception e) {
    	  System.out.println("Entering catch block unable to get data");
    	
    }
      
    
   String text = listPrice.getText();
   System.out.println(text);
    
    
    String textStr[] = text.split("\\r\\n|\\n|\\r");
 	String a="";
   	for (String string : textStr) {
   
   		if(string.toString().contains("$")) {
   		a = string.toString().replace("$", ""); 
   		System.out.println( a+"  ::: ");
   		}
   		if (a.contains("List:")) {
			a= a.replaceAll("List:\\s+", "");
			System.out.println( "  ::: "+a);
		}
   	}
   	String[] splitss = a.split(" ");
   	
   	String valueOfa=	null;

   	//Double valueOf = Double.valueOf(splitss[0].toString());//
   	
   	if(splitss[0].toString().contains(","))
		
   	{
   		valueOfa= splitss[0].toString().replace(",", "");
   		
   	} else
   	{
   		valueOfa= splitss[0].toString();
   	}
    
    Double valueOf = Double.valueOf(valueOfa);
    Report.updateTestLog(Action, "List Price : "+valueOfa, Status.DONE);
   //Contract price 
    
   WebElement contractPrice=null;
    
        	try {
        	contractPrice = Driver.findElement(Contractprice);
        	}catch (Exception e1) {
        		Report.updateTestLog(Action, "No Contract associated to this Product", Status.DONE);
			}
        	  
   Double valueOf1 = null;
    if (contractPrice == null) {
    	Report.updateTestLog(Action, "No Contract associated to this Product", Status.DONE);
    	userData.putData("RegressionData", "Contract Price", "0.00");
	} else {
		 String text1 = contractPrice.getText();
		 
		 Report.updateTestLog(Action, Data+  " :::  contractPrice   ::  " +text1, Status.DONE);
 		String[] split = text1.split(":");
 		
 		for (String string2 : split) {
 			
			Report.updateTestLog(Action, " string2   ::  " +string2, Status.DONE);
 			if (string2.contains("$")) {
 				//contract price
 				System.out.println(string2.toString().replace("$", ""));
// 				 Report.updateTestLog(Action, " string2.toString().replace   ::  " +string2.toString().replace("$", ""), Status.DONE);
 				if (string2.contains(",")) {
 					String replaceAll = string2.replaceAll(",", "");
 					
 					valueOf1 = Double.valueOf(replaceAll.toString().replace("$", ""));
 					
// 					 Report.updateTestLog(Action, " valueOf1   ::  " +valueOf1, Status.DONE);
 	 				
 					
				} else {
					valueOf1 = Double.valueOf(string2.toString().replace("$", ""));
//					 Report.updateTestLog(Action, " valueOf1   ::  " +valueOf1, Status.DONE);
				}
 				
 				 
 			}
 		}
// 		Report.updateTestLog(Action, "Contract Price : "+valueOf1, Status.DONE);
 	    userData.putData("RegressionData", "Contract Price", String.valueOf(valueOf1));
	}
    	
	
		// TODO: handle exception
		
	
   
	//List price
	Report.updateTestLog(Action, "List Price : "+valueOf, Status.DONE);
	userData.putData("RegressionData", "List Price", String.valueOf(valueOf));
	//Contract Price
    
    //You saved price
	
	 if (contractPrice == null) {
		 Report.updateTestLog(Action, "You saved price : Contract Not associated", Status.DONE);
		 userData.putData("RegressionData", "You saved", "0.00");
			 }
	 else {
				 Report.updateTestLog(Action, "You saved : "+String.valueOf(decimalFormat.format(valueOf-valueOf1)), Status.DONE);
				 
				   userData.putData("RegressionData", "You saved", String.valueOf(decimalFormat.format(valueOf-valueOf1)));
		
	 }
    
    String percent = userData.getData("RegressionData", "Percentage");
    
    DecimalFormat decimalFormat1 = new DecimalFormat("#,###.##");
    DecimalFormat decimalFormat2 = new DecimalFormat("#,###.###");
    DecimalFormat decimalFormat3 = new DecimalFormat("#,###.####");
    String RegressionData_Dis1="";
    String RegressionData_Dis="";
	 if (contractPrice == null) {
		 RegressionData_Dis1 = decimalFormat3.format(valueOf/100*Double.valueOf(percent));
		 
		
		 if (RegressionData_Dis1.contains(",")) {
			 RegressionData_Dis = (String) RegressionData_Dis1;
			 
//			 if (RegressionData_Dis1.contains(".")) {
//			 String[] split = RegressionData_Dis1.split("[.]", 0);
//			 if (split[1].toString().length()>2) {
//				 RegressionData_Dis = (String) RegressionData_Dis1.subSequence(0, RegressionData_Dis1.length()-1);
//			}else {
//				RegressionData_Dis = (String) RegressionData_Dis1.subSequence(0, RegressionData_Dis1.length());
//			}
//			 }else {
//				 RegressionData_Dis = (String) RegressionData_Dis1;
//			 }
			 
		} else {
			 RegressionData_Dis1 = decimalFormat3.format(valueOf/100*Double.valueOf(percent));
			 
			 System.out.println(RegressionData_Dis1);
			 
	//	 Report.updateTestLog(Action, "RegressionData_Dis1   1 St else : "+RegressionData_Dis1, Status.PASS);
		 RegressionData_Dis = (String) RegressionData_Dis1;

		}	      
	 }
	 else {
     RegressionData_Dis1 = decimalFormat3.format(valueOf1/100.00*Double.valueOf(percent));
     
    // Report.updateTestLog(Action, "RegressionData_Dis1  2nd  else : "+RegressionData_Dis1, Status.PASS);
     
	 RegressionData_Dis = (String) RegressionData_Dis1;

     System.out.println(RegressionData_Dis); 
	 }
    
//	 Report.updateTestLog(Action, "RegressionData_Dis  3755 :: "+ RegressionData_Dis, Status.PASS);
	//System.out.println(subSequence);
	 String discount_Value =null;
	 if (RegressionData_Dis.contains(",")) {
		String replaceAll = RegressionData_Dis.replaceAll(",", "");
		discount_Value= decimalFormat.format(Double.valueOf(replaceAll)*qty);
		
		 Report.updateTestLog(Action, "discount_Value  if codition :: "+ discount_Value, Status.DONE);
	} else {
		    
		      	   
		   
		      discount_Value= decimalFormat3.format(Double.valueOf(RegressionData_Dis)*qty);
		  // Report.updateTestLog(Action, "discount_Value else codition :: "+ discount_Value, Status.PASS); 
		   
		   
	}
  
    Double saved=null;
    if (contractPrice == null) {
    	saved = 0.00;
    }else {
    	
    	saved	= valueOf*qty-valueOf1*qty;  
    	   
    	
   }
   Double savings =Double.valueOf(discount_Value)+saved;
   
   //savings=get2DecimalDoubleValue(savings);
  
   
   Report.updateTestLog(Action, "savings  :: "+ (savings), Status.DONE);
   
   //Discount value according to RegressionData
   userData.putData("RegressionData", "Product level discount", String.valueOf(get2DecimalDoubleValue(discount_Value)));
//   userData.putData("RegressionData", "Product level discount", String.valueOf((discount_Value)));
   Report.updateTestLog(Action, "Product level discount   :: "+ discount_Value, Status.DONE);
   Report.updateTestLog(Action, "Saved : "+ saved, Status.DONE);
   
   if (contractPrice == null) {
	   Report.updateTestLog(Action, "message discount :"+ decimalFormat1.format(valueOf*10.00/100.00), Status.DONE);
	    userData.putData("RegressionData", "Promotion discount", String.valueOf(decimalFormat2.format(valueOf*10.00/100.00)));   
   }else {
    Report.updateTestLog(Action, "Promotion message discount :"+ decimalFormat1.format(valueOf1*10.00/100.00), Status.DONE);
    userData.putData("RegressionData", "Promotion discount", String.valueOf(decimalFormat2.format(valueOf1*10.00/100.00)));
   }
    
    Report.updateTestLog(Action, "Savings  : "+decimalFormat1.format(savings), Status.DONE);
    userData.putData("RegressionData", "Savings", String.valueOf(decimalFormat2.format(saved)));
    
    userData.putData("RegressionData", "Savings with promotion", String.valueOf(decimalFormat1.format(savings)));
    Report.updateTestLog(Action, "Subtotal before savings: "+valueOf*qty, Status.DONE);
    if (contractPrice == null) {
        Report.updateTestLog(Action, "Subtotal before savings: "+valueOf*qty, Status.DONE);
        userData.putData("RegressionData", "Subtotal before savings", String.valueOf((decimalFormat2.format(valueOf*qty))));
        }
        
        else {
        	 Report.updateTestLog(Action, "Subtotal before savings: "+valueOf1*qty, Status.DONE);
        	    userData.putData("RegressionData", "Subtotal before savings", String.valueOf((decimalFormat2.format(valueOf1*qty))));
        	
        }
    Double salestax =null;
    Double salestax_Promotion = null;
    String state_Txt = userData.getData("RegressionData", "Sales Tax state");
    
    if (state_Txt.contains("Illinois") ||state_Txt.contains("Michigan") ||state_Txt.contains("Minnesota") ||state_Txt.contains("Hawaii")) {
    	  salestax = Double.valueOf(decimalFormat1.format((valueOf*qty-saved)/100.00));
    	  salestax_Promotion = Double.valueOf(decimalFormat1.format((valueOf*qty-savings)/100.00));
    	    
    	    Report.updateTestLog(Action, "salestax_RegressionData  "+salestax_Promotion, Status.DONE);
	}else {
		salestax = 0.00;
		salestax_Promotion = 0.00;
	}
  
    
   // userData.putData("RegressionData", "", String.valueOf(decimalFormat.format(valueOf*qty))); get2DecimalDoubleValue
    Report.updateTestLog(Action, "Federal excise tax : "+federalTax*qty, Status.DONE);
    userData.putData("RegressionData", "Total Federal excise tax", String.valueOf(decimalFormat3.format(federalTax*qty+0.00)));
    
    
    Report.updateTestLog(Action, "Estimated sales tax wo : "+salestax, Status.DONE);
    Report.updateTestLog(Action, "Estimated sales tax : "+salestax_Promotion, Status.DONE);
    
    userData.putData("RegressionData", "Total Estimated sales tax", String.valueOf(decimalFormat3.format(salestax+0.00)));
    userData.putData("RegressionData", "Total Estimated sales tax with Promotion", String.valueOf(decimalFormat3.format(salestax_Promotion)));
   
    Report.updateTestLog(Action, "Price for contract1: "+ String.valueOf(decimalFormat2.format((valueOf*qty-saved)+(federalTax*qty)+salestax)), Status.PASS);
    Report.updateTestLog(Action, "Price for contract1  : "+ (valueOf*qty-savings), Status.DONE);
     
    Report.updateTestLog(Action, "Price for contract  : "+ (federalTax*qty), Status.DONE);
    Report.updateTestLog(Action, "Price for contract  : "+ salestax_Promotion, Status.DONE);
    
    userData.putData("RegressionData", "Price for contract with promotion", String.valueOf((decimalFormat3.format((valueOf*qty-savings)+(federalTax*qty)+salestax_Promotion+0.00))));
    
    
    userData.putData("RegressionData", "Price for contract", String.valueOf((decimalFormat3.format((valueOf*qty-saved)+(federalTax*qty)+salestax))));
	}
	








@Action(object = ObjectType.BROWSER,desc = "This method Will take all the prices,Quantity,Product details and put data in CocPageDetails datasheet",input = InputType.NO)

public void price_Split2( ) {
	
	String num=getVar("%noofProducts%");
	  int numprd=Integer.parseInt(num);
	  
	  System.out.println("numprd  :: "+numprd);
	  
	try {
	 
	for(int i=1;i<=numprd;i++)
	{
		System.out.println("price split :: "+i);
		
    WebElement listPrice=null;
    DecimalFormat decimalFormat = new DecimalFormat("#,###.##");
    
    Double federalTax = Double.valueOf(userData.getData("OrdersPriceValidation", "Federal excise tax"+i));
    System.out.println("federalTax:: "+federalTax);
    String Product = userData.getData("OrderDetails", "Product"+i);
  // Double salesTax = Double.valueOf(userData.getData("RegressionData", "Estimated sales tax"));
    //List price
//    String	 quantity = userData.getData("RegressionData", "quantity");
//	By Listprice=By.xpath("//*[@id='price-"+Product+"']//p[1]");
//	By Contractprice=By.xpath("//*[@id='price-"+Product+"']//p[2]");
	
	Double qty=Double.valueOf(userData.getData("OrderDetails", "qty"+i));
	
        Double valueOf=Double.valueOf(userData.getData("OrdersPriceValidation", "ListPrice"+i));
        
   String contractPrice;
   
	  
Double valueOf1  =Double.valueOf(userData.getData("OrdersPriceValidation", "ContractPrice"+i));



if ((valueOf1 == 0)||(valueOf1 == 0.00) ) {
	Report.updateTestLog(Action, "No Contract associated to this Product", Status.DONE);
	//userData.putData("RegressionData", "Contract Price", "0.00");
	
	contractPrice=null;
} else {
	
	contractPrice =(userData.getData("OrdersPriceValidation", "ContractPrice"+i));
	
	
	
}
   
    
    //You saved price
	
	 if (contractPrice == null) {
		 Report.updateTestLog(Action, "You saved price : Contract Not associated", Status.DONE);
		 userData.putData("OrdersPriceValidation", "You saved"+i, "0.00");
			 }
	 else {
				 Report.updateTestLog(Action, "You saved : "+String.valueOf(decimalFormat.format(valueOf-valueOf1)), Status.DONE);
				 
				   userData.putData("OrdersPriceValidation", "You saved"+i, String.valueOf(decimalFormat.format(valueOf-valueOf1)));
		
	 }
    
    String percent = userData.getData("OrdersPriceValidation", "Percentage");
    
    DecimalFormat decimalFormat1 = new DecimalFormat("#,###.##");
    DecimalFormat decimalFormat2 = new DecimalFormat("#,###.###");
    DecimalFormat decimalFormat3 = new DecimalFormat("#,###.####");
    String RegressionData_Dis1="";
    String RegressionData_Dis="";
	 if (contractPrice == null) {
		 RegressionData_Dis1 = decimalFormat3.format(valueOf/100*Double.valueOf(percent));
		 
		
		 if (RegressionData_Dis1.contains(",")) {
			 RegressionData_Dis = (String) RegressionData_Dis1;
			 
	} else {
			 RegressionData_Dis1 = decimalFormat3.format(valueOf/100*Double.valueOf(percent));
			 
			 System.out.println(RegressionData_Dis1);
			 
	//	 Report.updateTestLog(Action, "RegressionData_Dis1   1 St else : "+RegressionData_Dis1, Status.PASS);
		 RegressionData_Dis = (String) RegressionData_Dis1;

		}	      
	 }
	 else {
     RegressionData_Dis1 = decimalFormat3.format(valueOf1/100.00*Double.valueOf(percent));
     
    // Report.updateTestLog(Action, "RegressionData_Dis1  2nd  else : "+RegressionData_Dis1, Status.PASS);
     
	 RegressionData_Dis = (String) RegressionData_Dis1;

     System.out.println(RegressionData_Dis); 
	 }
    
//	 Report.updateTestLog(Action, "RegressionData_Dis  3755 :: "+ RegressionData_Dis, Status.PASS);
	//System.out.println(subSequence);
	 String discount_Value =null;
	 if (RegressionData_Dis.contains(",")) {
		String replaceAll = RegressionData_Dis.replaceAll(",", "");
		discount_Value= decimalFormat.format(Double.valueOf(replaceAll)*qty);
		
		 Report.updateTestLog(Action, "discount_Value  if codition :: "+ discount_Value, Status.DONE);
	} else {
		    
		      	   
		   
		      discount_Value= decimalFormat3.format(Double.valueOf(RegressionData_Dis)*qty);
		  // Report.updateTestLog(Action, "discount_Value else codition :: "+ discount_Value, Status.PASS); 
		   
		   
	}
  
    Double saved=null;
    if (contractPrice == null) {
    	saved = 0.00;
    }else {
    	
    	saved	= valueOf*qty-valueOf1*qty;  
    	   
    	
   }
   Double savings =Double.valueOf(discount_Value)+saved*1.00;
   
   //savings=get2DecimalDoubleValue(savings);
  
   
   Report.updateTestLog(Action, "savings  :: "+ (savings), Status.DONE);
   
   //Discount value according to RegressionData
   userData.putData("OrdersPriceValidation", "Product level discount"+i, String.valueOf(get2DecimalDoubleValue(discount_Value)));
//   userData.putData("RegressionData", "Product level discount", String.valueOf((discount_Value)));
   Report.updateTestLog(Action, "Product level discount   :: "+ discount_Value, Status.DONE);
   Report.updateTestLog(Action, "Saved : "+ saved, Status.DONE);
   
   if (contractPrice == null) {
	   Report.updateTestLog(Action, "message discount :"+ decimalFormat1.format(valueOf*10.00/100.00), Status.DONE);
	    userData.putData("OrdersPriceValidation", "Promotion discount"+i, String.valueOf(decimalFormat2.format(valueOf*10.00/100.00)));   
   }else {
    Report.updateTestLog(Action, "Promotion message discount :"+ decimalFormat1.format(valueOf1*10.00/100.00), Status.DONE);
    userData.putData("OrdersPriceValidation", "Promotion discount"+i, String.valueOf(decimalFormat2.format(valueOf1*10.00/100.00)));
   }
    
    Report.updateTestLog(Action, "Savings  : "+decimalFormat1.format(savings), Status.DONE);
    userData.putData("OrdersPriceValidation", "Savings"+i, String.valueOf(decimalFormat2.format(saved*1.00)));
    
    userData.putData("OrdersPriceValidation", "Savings with promotion"+i, String.valueOf(decimalFormat1.format(savings*1.00)));
    
    if (contractPrice == null) {
    Report.updateTestLog(Action, "Subtotal before savings: "+valueOf*qty, Status.DONE);
    userData.putData("OrdersPriceValidation", "Subtotal before savings"+i, String.valueOf((decimalFormat2.format(valueOf*qty*1.00))));
    }
    
    else {
    	 Report.updateTestLog(Action, "Subtotal before savings: "+valueOf1*qty, Status.DONE);
    	    userData.putData("OrdersPriceValidation", "Subtotal before savings"+i, String.valueOf((decimalFormat2.format(valueOf1*qty*1.00))));
    	
    }
    
    
    Double salestax =null;
    Double salestax_Promotion = null;
    String state_Txt = userData.getData("OrdersPriceValidation", "Sales Tax state"+i);
    
    if (state_Txt.contains("Illinois") ||state_Txt.contains("Michigan") ||state_Txt.contains("Minnesota") ||state_Txt.contains("Hawaii")) {
    	  salestax = Double.valueOf(decimalFormat1.format((valueOf*qty-saved)/100.00));
    	  salestax_Promotion = Double.valueOf(decimalFormat1.format((valueOf*qty-savings)/100.00));
    	    
    	    Report.updateTestLog(Action, "salestax_RegressionData  "+salestax_Promotion, Status.DONE);
	}else {
		salestax = 0.00;
		salestax_Promotion = 0.00;
	}
  
    
   // userData.putData("RegressionData", "", String.valueOf(decimalFormat.format(valueOf*qty))); get2DecimalDoubleValue
    Report.updateTestLog(Action, "Federal excise tax : "+federalTax*qty, Status.DONE);
    userData.putData("OrdersPriceValidation", "Total Federal excise tax"+i, String.valueOf(decimalFormat3.format(federalTax*qty+0.00)));
    
    
    Report.updateTestLog(Action, "Estimated sales tax wo : "+salestax, Status.DONE);
    Report.updateTestLog(Action, "Estimated sales tax : "+salestax_Promotion, Status.DONE);
    
    userData.putData("OrdersPriceValidation", "Total Estimated sales tax"+i, String.valueOf(decimalFormat3.format(salestax+0.00)));
    userData.putData("OrdersPriceValidation", "Total Estimated sales tax with Promotion"+i, String.valueOf(decimalFormat3.format(salestax_Promotion)));
   
    Report.updateTestLog(Action, "Price for contract "+ String.valueOf(decimalFormat2.format((valueOf*qty-saved)+(federalTax*qty)+salestax)), Status.DONE);
    
    Report.updateTestLog(Action, "Price for contract1  : "+ (valueOf*qty-savings), Status.DONE);
     
    Report.updateTestLog(Action, "Price for contract  : "+ (federalTax*qty), Status.DONE);
    Report.updateTestLog(Action, "Price for contract  : "+ salestax_Promotion, Status.DONE);
    
    userData.putData("OrdersPriceValidation", "Price for contract with promotion"+i, String.valueOf((decimalFormat3.format((valueOf*qty-savings)+(federalTax*qty)+salestax_Promotion+0.00))));
    
    
    userData.putData("OrdersPriceValidation", "Price for contract"+i, String.valueOf((decimalFormat3.format((valueOf*qty-saved)+(federalTax*qty)+salestax))));
	}
	
	
	
	}catch (Exception e) {
		
		Report.updateTestLog(Action, "Data Not Present on the Page "+e, Status.FAIL);
	}
	
}
	











public static double get2DecimalDoubleValue(String discount_Value) {

	 double discount_Value1=Double.parseDouble(discount_Value);

   double final2DecimalDoubleValue = Math.round(discount_Value1 * Math.pow(10, 2))/ Math.pow(10, 2);
   return final2DecimalDoubleValue;
}
public static double get2DecimalDoubleValue(double discount_Value) {

	

  double final2DecimalDoubleValue = Math.round(discount_Value * Math.pow(10, 2))/ Math.pow(10, 2);
  return final2DecimalDoubleValue;
}


@Action(object = ObjectType.BROWSER, desc = "Waiting for elemnt to present", input = InputType.YES)
public void priceValidation() {
	
	
	
	
	
	
}

@Action(object = ObjectType.BROWSER, desc = "Waiting for elemnt to present", input = InputType.YES)
public void waiting_for_element() {
	
	try {
	WebDriverWait wait = new WebDriverWait(Driver, 600);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[contains(text(),'"+Data+"')])[1]")));
	
//	Driver.findElement(By.xpath("(//span[contains(text(),'"+Data+"')])[1]")).click();
	
	String s=Driver.findElement(By.xpath("(//span[contains(text(),'"+Data+"')])[1]")).getText();
	if(s.contains(Data)) {
		
		Report.updateTestLog(Action, s+" :: Data Present on the Page ", Status.PASS);
		
	}else
		
	{
		Report.updateTestLog(Action, "Data Not Present on the Page ", Status.FAIL);
	}
	
	}catch (Exception e) {
		
		
	}
	
}


@Action(object = ObjectType.BROWSER, desc = "Enter ProductCount,CartCount,ProductPerCart,ShipTo-BillTo [<Data>]", input = InputType.YES)
public void verifyShoppingCartPage() {
	
	
//	ShiptocartClick() ;
	
	
	By shipTo=By.xpath("(//div[@class='card shippinAddressCont']//div)[3]");
	By billTo=By.xpath("(//div[@class='card billingAddressCont']//div)");
	By sLn=By.xpath("//input[@id='stateLicenceNumber']");
	By paymentDetails=By.xpath("//input[contains(@name,'payment_type')]");
	By poNumber=By.xpath("//div[@class='form-group']//input[@id='poNumber']");
	By ndc=By.xpath("//div[contains(@class,'ProductDesc')]//p//span");
	By carttotal=By.xpath("//p[contains(text(),'Cart Total')]");
	
	By TermsOfSale_text=By.xpath("//div[contains(@class,'terms text-center')]");
	
	By TermsOfSale_Link=By.xpath("//div[contains(@class,'terms text-center')]//a");
	By Qty=By.xpath("(//div[@class='ProductQtyBoxWrap']//input)[1]");
	By ListPrice=By.xpath("(//div[@class='card contractList']//span)[1]");
	By contractSaving=By.xpath("//div[@class='card contractList']/..//p[@class='contractSaving']//span");
	By fedtax=By.xpath("(//div[@class='card contractList']/..//p[@class='fedtax']//span)[1]");
	
	By itemTotal=By.xpath("//div[contains(@class,'terms text-center')]");
	By ContractSavings_OS=By.xpath("(//div[contains(@id,'collapseOne')]//div//p[@class='pb-1']//span)[1]");
	
	By subTotal=By.xpath("(//div[contains(@class,'subTotal')]//p[1]//span)[1]");
	By Estimatedsalestax_OS=By.xpath("(//div[contains(@class,'subTotal')]//p[2]//span)[1]");
	By totalPrice=By.xpath("(//p[contains(@class,'totalPrice ')]//span)[1]");
	
	
	
	
	
	
}



@Action(object = ObjectType.BROWSER, desc = "Enter the value of xpath , Attribute , comparing Data ", input = InputType.YES)
public void getAttribute_Validation() {
	
	
	
	String[] InputData = Data.split(",");
	 
		String xpath = InputData[0]; // xpath
		String Attributevalue = InputData[1]; // Attributevalue
		String DataValidation= InputData[2]; 
	
	
	try {
	
	String ValidationData= Driver.findElement(By.xpath(xpath)).getAttribute(Attributevalue);
	
	
	if(ValidationData.contains(DataValidation))
	{
		
		Report.updateTestLog(Action, DataValidation + " :: Attribute value is Matcing with data ", Status.PASS);
		
	}
	else
	{
		Report.updateTestLog(Action, " Attribute value is Not Matcing with data  ", Status.FAIL);
	}
	
	
	} catch (Exception e) {
		Report.updateTestLog(Action, " Unable to get Attribute value  ", Status.FAIL);
	}
	
	
}


@Action(object = ObjectType.BROWSER, desc = "List Price and Contarct Price validation ", input = InputType.NO)
public void list_ContractPrice_Validation() {
	
//	String price=Data;
	 String ListPrice=userData.getData("RegressionData", "List Price");
	 String cprise=userData.getData("RegressionData", "Contract Price");
	
	
	try {
		
		String Lprice=Driver.findElement(By.xpath("//p[@class='listPrice']//span")).getText();
		if(Lprice.contains(ListPrice))
		{
			Report.updateTestLog(Action, Lprice+ " ::  List Price details from page  are matching with calucalted   :: "+ListPrice, Status.PASS);
//			Assert.assertEquals(Lprice, ListPrice);
			
		}
		
			
		
	} catch (Exception e) {
		
		String Lprice=Driver.findElement(By.xpath("//p[@class='contractPrice']//span")).getText();
		if(Lprice.contains(ListPrice))
		{
			Report.updateTestLog(Action, Lprice+ " ::  List Price details from page  are matching with calucalted   :: "+ListPrice, Status.PASS);
//			Assert.assertEquals(Lprice, ListPrice);
			
		}else {
		Report.updateTestLog(Action,  Lprice+ " ::  List Price details from page  are Not matching with calucalted   :: "+ListPrice, Status.FAIL);
		}
	}
	
	try
	{
		String Lprice=Driver.findElement(By.xpath("//p[@class='listPrice']//span")).getText();
String contractprice=Driver.findElement(By.xpath("//p[@class='contractPrice']//span")).getText();
		
		
		
		
		if(contractprice.contains(cprise))
			
		{
			
			Report.updateTestLog(Action, contractprice+" :: contractprice details from page  are matching with calucalted  ::  "+cprise, Status.PASS);
//			Assert.assertEquals(contractprice, cprise);
		} 
		else
		{
			
			Report.updateTestLog(Action, contractprice+" ::  Price Details are not Matching ::  "+cprise, Status.FAIL);
		}
		
	} catch (Exception e) 
	{
		
		
	}
	 
	
	
	
	
	
	

	
}




@Action(object = ObjectType.BROWSER, desc = "Selecting Prodcts  ", input = InputType.YES)
public void  ProductSelection_Complexcart() {
	
	 // Split the data by comma and get the length
    String[] Products = Data.split(",");
    int length = Products.length;
System.out.println("Length ::  "+length);
String pname=null,contract=null;
addVar("%noofProducts%",String.valueOf(length));
    // Loop through the Products array
    for (int i = 0; i < length; i++) {
        // Split each Product by hyphen and assign to variables
        String[] ProductDetails = Products[i].split("-");
        String Product = ProductDetails[0];
        String quantity = ProductDetails[1];
        
       
       
        // Locate the quantity element by xpath
        By qty = By.xpath("//*[@id='qty-"+Product+"']//input");

        // Locate the Add to Cart element by xpath
        By addtoCart = By.xpath("//div[@id='pid-"+Product+"']//button[contains(text(),'Add to Cart')]");

        By reservenow = By.xpath("//div[@id='pid-"+Product+"']//button[contains(text(),'Reserve now')]");
        // Create a JavascriptExecutor object
        JavascriptExecutor js = (JavascriptExecutor) Driver;

        // Try to perform the actions on the web elements
        try {
            // Find the quantity element
            WebElement element = Driver.findElement(qty);
Thread.sleep(2000);
            // Delete the existing text in the text box
//           element.sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.DELETE));
//           Thread.sleep(2000);
//           
//           Report.updateTestLog(Action, " quantity ::  "+quantity , Status.PASS);
           

           element.clear();
Thread.sleep(2000);
           
//           Report.updateTestLog(Action, " quantity 1::  "+quantity , Status.PASS);
            // Enter the data into the text box
            element.sendKeys(quantity);
            Thread.sleep(3000);
         
            try {
            // Click on the Add to Cart button
            Driver.findElement(addtoCart).click();
            }catch (Exception e) 
        	{
            	Driver.findElement(reservenow).click();
        	}
//            Thread.sleep(5000);
//            Driver.navigate().refresh();

            wait.until(	ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[contains(@class,'spinner-wrapper')]")));
			wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
					.executeScript("return document.readyState")));
//			pagereadycheck();
			
			   System.out.println( "  cartTotal ");
			   
			if (Driver.findElement(By.xpath("//div[contains(@class,'cartTotal')]")).isDisplayed()) {
				 

		        // Save the Product and quantity data in the data sheet
		         userData.putData("OrderDetails", "qty" + (i + 1), quantity);
		         userData.putData("OrderDetails", "Product" + (i + 1), Product);

				

		          Report.updateTestLog(Action, " Product  ::  "+Product +" and with quantity ::  "+quantity , Status.PASS);
				

			}else {
				Report.updateTestLog(Action, " No Product Added To Cart for ShipTo ", Status.FAIL);

			}
            //

          
            // Call the submethod to check the price of the Product
//            checkPrice(Product, i);
            By productname=By.xpath("//*[@id='pid-"+Product+"']//a//h4");
            
            pname=Driver.findElement(productname).getText();
            
            String aa="%prodname"+(i+1)+"%";
            addVar(aa,pname);
            
            try {
            	
            	contract=Driver.findElement(By.xpath("//*[@id='pid-"+Product+"']//*[@class='contractInfo']//p")).getText();
            	
            	addVar("%contractname"+(i+1)+"%",contract);
            	
            	
            }
            catch (Exception e) 
        	{
            	addVar("%contractname%",contract);
        		
        	} 
            Report.updateTestLog(Action, "Product name ::  "+pname+"  :: "  +quantity + " Packs of " +Product+" Added To Cart for ShipTo " , Status.PASS);  
            
            list_contract_Price_validation (Product, i);
           
        } catch (Exception e) {
            // Handle the exception
            System.out.println("An error occurred while adding the Product to the cart: " + e.getMessage());
        }
    }
}


// Create a submethod for checking the price of the Products
public void checkPrice(String Product, int i) {
    // Locate the list price element by xpath
    By listPrice = By.xpath("//*[@id='price-"+Product+"']//p[1]");
//
  
    // Declare variables for storing the prices
    double listPriceValue = 0.00;
    double contractPriceValue = 0.00;

    // Try to get the list price element
    try {
        // Find the list price element
        WebElement listPriceElement = Driver.findElement(listPrice);

        // Get the text of the list price element
        String listPriceText = listPriceElement.getText();

        // Split the text by line breaks
        String[] listPriceLines = listPriceText.split("\\r\\n|\\n|\\r");

        // Loop through the lines
        for (String line : listPriceLines) {
            // Check if the line contains a dollar sign
            if (line.contains("$")) {
                // Remove the dollar sign and the "List:" prefix
                line = line.replace("$", "").replace("List:", "").trim();

                // Check if the line contains a comma
                if (line.contains(",")) {
                    // Remove the comma
                    line = line.replace(",", "");
                }

                // Parse the line as a double value
                listPriceValue = Double.parseDouble(line);

                // Break the loop
                break;
            }
        }
        Report.updateTestLog(Action, " ListPriceValue of Product"+(i + 1)+"  ::  "+listPriceValue , Status.PASS);
    } catch (Exception e) {
        // Handle the exception
        System.out.println("An error occurred while getting the list price: " + e.getMessage());
    }

  
    System.out.println( "Product  :: "+  Product );
    // Locate the contract price element by xpath
    By contractPrice = By.xpath("//*[@id='price-"+Product+"']//p[2]");
// Try to get the contract price element
    try {
        // Find the contract price element
        WebElement contractPriceElement = Driver.findElement(contractPrice);

        // Get the text of the contract price element
        String contractPriceText = contractPriceElement.getText();
System.out.println( "contractPriceText  :: "+  contractPriceText   );
Report.updateTestLog(Action,  "contractPriceText  :: "+  contractPriceText  , Status.PASS);
        // Split the text by colon
//        String[] contractPriceParts = contractPriceText.split(":");
        String[] contractPriceParts = contractPriceText.split(":");
        // Loop through the parts
        for (String part : contractPriceParts) {
            // Check if the part contains a dollar sign
        	System.out.println( "  part  "+part);
            if (part.contains("$")) {
                // Remove the dollar sign
//                part = part.replace("$", "").trim();
                part = part.replace("$", "").replace("Contract:", "").trim();
                // Check if the part contains a comma
                if (part.contains(",")) {
                    // Remove the comma
                    part = part.replace(",", "");
                }

                // Parse the part as a double value
                contractPriceValue = Double.parseDouble(part);

                // Break the loop
                break;
            }
           
        }
        Report.updateTestLog(Action, " ContractPriceValue of Product"+(i + 1)+"  ::  "+contractPriceValue , Status.PASS);
    } catch (Exception e) {
        // Handle the exception
        System.out.println("An error occurred while getting the contract price: " + e.getMessage());
    }

    // Send the prices to the sheet
    
   
     userData.putData("OrdersPriceValidation", "ListPrice" + (i + 1), String.valueOf(listPriceValue));
     userData.putData("OrdersPriceValidation", "ContractPrice" + (i + 1), String.valueOf(contractPriceValue));
     
     try {
    	 
    	 String lprice = "%ListPrice"+(i + 1)+"%";
         String cprice = "%ContractPrice"+(i + 1)+"%";

    		addVar(lprice, String.valueOf(listPriceValue));
    		addVar(cprice, String.valueOf(contractPriceValue));
    		 
    		System.out.println(  " i value "+i);
//			price_Split2(i);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			  Report.updateTestLog(Action, " price_Split2((i + 1))  +" , Status.FAIL);
		}
     
    
		
		
	
		
		
}





WebDriverWait wait = new WebDriverWait(Driver, 600);
Actions actions = new Actions(Driver);
String payment = null, ctype = null, paytype = null ,cnew_existing=null;

@Action(object = ObjectType.BROWSER, desc = "PayBy Radio button selection ", input = InputType.NO)
public void payBy_Selection()

{

	List<WebElement> invoiceMe_radio = Driver
			.findElements(By.xpath("(//label[text()=' Invoice Me ']/parent::div/input)"));
	//Report.updateTestLog(Action, "List of elements       : " + invoiceMe_radio.size(), Status.DONE);
	try {
		for (int i = 1; i <= invoiceMe_radio.size(); i++) {
			//Report.updateTestLog(Action, "List of elements " + invoiceMe_radio.size(), Status.DONE);
			String ptype = userData.getData("OrderDetails", "PaymentType" + i);

			Report.updateTestLog(Action, "Payment type is   : " + ptype, Status.DONE);
			Thread.sleep(1000);

			String[] split = ptype.split(",");

			payment = split[0];
System.out.println("payment"+payment);
			if (payment.equalsIgnoreCase("Invoice me")) {

				//Report.updateTestLog(Action, " Entered to Invoice me loop  110 line ", Status.DONE);
				invoiceMe_Selection(i);

			} 
			
			
			if (payment.equalsIgnoreCase("Credit card")) {
				cnew_existing=split[1];
				ctype=split[2];
				paytype=split[3];
				

				Report.updateTestLog(Action, " cnew_existing  :  "+cnew_existing  +" ctype : "+ctype+"  paytype: "+paytype, Status.DONE);
				
				
				creditCard_Selection(i,cnew_existing,ctype,paytype);
				
			

			}

		}
	} catch (InterruptedException e) {

		e.printStackTrace();
	}

}

public void payBy_Selection(int i)

{

	List<WebElement> invoiceMe_radio = Driver
			.findElements(By.xpath("(//label[text()=' Invoice Me ']/parent::div/input)"));
	//Report.updateTestLog(Action, "List of elements       : " + invoiceMe_radio.size(), Status.DONE);
	try {
//		for (int i = 1; i <= invoiceMe_radio.size(); i++) {
			//Report.updateTestLog(Action, "List of elements " + invoiceMe_radio.size(), Status.DONE);
			String ptype = userData.getData("OrderDetails", "PaymentType" + i);

			Report.updateTestLog(Action, "Payment type is   : " + ptype, Status.DONE);
			Thread.sleep(1000);

			String[] split = ptype.split(",");

			payment = split[0];
System.out.println("payment"+payment);
			if (payment.equalsIgnoreCase("Invoice me")) {

				Report.updateTestLog(Action, " Entered to Invoice me loop  110 line "+i, Status.DONE);
				invoiceMe_Selection(i);

			} 
			
			
			if (payment.equalsIgnoreCase("Credit card")) {
				cnew_existing=split[1];
				ctype=split[2];
				paytype=split[3];
				

				Report.updateTestLog(Action, " cnew_existing  :  "+cnew_existing  +" ctype : "+ctype+"  paytype: "+paytype, Status.DONE);
				
				
				creditCard_Selection(i,cnew_existing,ctype,paytype);
				
				Report.updateTestLog(Action, " After  creditCard_Selection  2749 ", Status.DONE);

			}

//		}
	} catch (InterruptedException e) {

		e.printStackTrace();
	}

}



public void invoiceMe_Selection(int l) {
	int invoicesize = 0;

//	

	try {
		System.out.println("2325");
		JavascriptExecutor js = (JavascriptExecutor) Driver;

		
		wait.until(ExpectedConditions
				.presenceOfElementLocated(By.xpath("(//label[text()=' Invoice Me ']/parent::div/input)[" + l + "]")));
		System.out.println("2331");
		WebElement in_me = Driver
				.findElement(By.xpath("(//label[text()=' Invoice Me ']/parent::div/input)[" + l + "]"));
		System.out.println("2334");

		try {
		in_me.click();
		
		System.out.println("2339    tryy");
		
		}catch (Exception e) {
			System.out.println("2341    catch");
			
			actions.moveToElement(in_me).perform();

			 js.executeScript("arguments[0].click();", in_me);
			
			// TODO: handle exception
//			Report.updateTestLog(Action, "Invoice Me Radio button Selecting Issue ", Status.FAIL);
		}
		System.out.println("       text()=' Invoice Me '              :: "+Driver.findElement(By.xpath("(//label[text()=' Invoice Me ']/parent::div/input)/../label")).getText());

		Report.updateTestLog(Action, "Invoice Me Radio button Selected : " + l, Status.PASS);
		
		String card_details= Driver.findElement(By.xpath("(//label[text()=' Invoice Me '])[" + l + "]")).getText().toString().trim();
		userData.putData("OrderDetails", "CardDetails"+l, card_details);

	}

	catch (Exception e) {
		
		
		
		// TODO: handle exception
		Report.updateTestLog(Action, "Invoice Me Radio button Selecting Issue ", Status.FAIL);
	}



}


public void creditCard_Selection(int m,String new_old,String type1,String paytype1) {
//
			try {
//				(i,cnew_existing,ctype,paytype);
			
				Report.updateTestLog(Action, "creditCard_Selection  ::: " +m  +"  "+new_old+"  "+type1 , Status.PASS);
				
				
//				wait.until(ExpectedConditions.presenceOfElementLocated(
//						By.xpath("(//label[contains(text(),'Credit Card')]/parent::div/input)[" + m + "]")));
//				
				wait.until(ExpectedConditions.presenceOfElementLocated(
						By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-" +(m-1) + "0')])/following-sibling::div//div[@class='row shiptoRow']//input[@name='payment_type']")));
				JavascriptExecutor js = (JavascriptExecutor) Driver;

				
			
				WebElement in_me = Driver
						.findElement(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-" +(m-1) +"0')])/following-sibling::div//div[@class='row shiptoRow']//input[@name='payment_type']"));

				

//				actions.moveToElement(in_me).perform();
				try {
				 js.executeScript("arguments[0].click();", in_me);
				 
				 Report.updateTestLog(Action, "Credit card Radio button Selected  ", Status.PASS);
				 
				}catch (Exception e) {
					// TODO: handle exception
					
					in_me.click();

					Report.updateTestLog(Action, "Credit card Radio button Selecting Issue ", Status.FAIL);
				}
				
//				Report.updateTestLog(Action, "Credit card Radio button Selected : " + m, Status.PASS);
				
			
		
			
				
				if(new_old.equalsIgnoreCase("new"))
				
				{
					Report.updateTestLog(Action, "New card inside  " , Status.PASS);
			WebElement link_newCard = Driver.findElement(By.xpath("(//label[text()=' Credit Card ']/parent::div/following-sibling::div/button[contains(text(),'Add New Card')])["+m+"]"));
//					WebElement link_newCard = Driver.findElement(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-0" +(m-1) +"')])/following-sibling::div//button[contains(text(),'Add New Card')])"));

				//Report.updateTestLog(Action, "New Credit card Link link_newCard.getLocation() : "+link_newCard.getLocation() , Status.DONE);
				link_newCard.click();
				Report.updateTestLog(Action, "New Credit card Link Selected : " , Status.PASS);
				spinnerLoad();
//				new_Payment(type1);
				new_Payment1(type1,m);
				Report.updateTestLog(Action, " Completed  to new_Payment   ", Status.PASS);
				
				
				spinnerLoad();

						creditCard_payNow_Paylater(type1,paytype1 ,m);
				} 
				
				
				
//				Report.updateTestLog(Action, " try old  "+new_old, Status.PASS);
				
				if(new_old.equalsIgnoreCase("old"))
					{
					
					
			String cardendnum=userData.getData("OrderDetails", "CardDetails"+m);
			
			String cardname=null;
					try {
						Report.updateTestLog(Action, " Completed  to new_Payment  try old  "+cardendnum, Status.PASS);
						
						List<WebElement>  card1st=				Driver.findElements(By.xpath("(//div[@aria-expanded='true']/..//div[contains(@class,'dropdown-menu')]//p/span)"));
						
						System.out.println(" c 3024 ard1st.size() ::: "+ card1st.size());
						for(int t=1;t<=card1st.size();t++)
						{
							
							cardname=	Driver.findElement(By.xpath("(//div[@aria-expanded='true']/..//div[contains(@class,'dropdown-menu')]//p/span)[" + t + "]")).getText().toString();
							System.out.println(" cardname   3029  ::: "+ cardname);
							
							
							if(cardname.contains(cardendnum))
							{
								Report.updateTestLog(Action, " Inside   ::  "+cardendnum, Status.PASS);
						WebElement c1=		Driver.findElement(By.xpath("(//div[@aria-expanded='true']/..//div[contains(@class,'dropdown-menu')]//p/span)[" + t + "]"));
						
//						Driver.findElement(By.xpath("(//div[@aria-expanded='true']/..//div[contains(@class,'dropdown-menu')]//p/span)[" + t + "]"))
						 js.executeScript("arguments[0].click();", c1);	
						 
						 creditCard_payNow_Paylater(type1,paytype1 ,m);
						 break;
		
							}
							
						}
			
	
	
	
					}
					catch (Exception e) {
						// TODO: handle exception
						Report.updateTestLog(Action, " Completed  to new_Payment  catch old  ", Status.PASS);
						Driver.findElement(By.xpath("(//div[@aria-expanded='true']/..//div[contains(@class,'dropdown-menu')]//p)[1]")).click();
					}
	creditCard_payNow_Paylater(type1,paytype1 ,m);
					//Report.updateTestLog(Action, " Completed to creditCard_payNow_Paylater(paytype);  213 line ",Status.PASS);
					
					
				}
				
			
			}

			catch (Exception e) {
				// TODO: handle exception
				Report.updateTestLog(Action, "Credit card Radio button Selecting Issue "+e, Status.FAIL);
			}

		}

		public void new_Payment(String ctype) {
			wait.until(	ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[contains(@class,'spinner-wrapper')]")));
			wait.until(ExpectedConditions					.presenceOfElementLocated(By.xpath("//*[contains(text(),'New Credit Card Details')]")));

			if (ctype.equalsIgnoreCase("Visa")) {

				Driver.findElement(By.xpath("//input[@value='Visa']")).click();

				new_Creditcard_DataFill(ctype);
			} else if (ctype.equalsIgnoreCase("MasterCard")) {

				Driver.findElement(By.xpath("//input[@value='MasterCard']")).click();
				new_Creditcard_DataFill(ctype);

			} else if (ctype.equalsIgnoreCase("AmericanExpress")) {

				Driver.findElement(By.xpath("//input[@value='AmericanExpress']")).click();
				new_Creditcard_DataFill(ctype);

			}

		}
		

		By name_cad = By.xpath("//input[@id='name']");
		By ccard = By.xpath("//input[@id='cardNumber']");
		By adress1 = By.xpath("//input[@id='address1']");
		By adress2 = By.xpath("//input[@id='address2']");
		By city = By.xpath("//input[@id='addrCity']");
		By state = By.xpath("//select[@id='addrState']");

		By zipcode = By.xpath("//input[@id='addrZip']");

		By confirm_btn = By.xpath("//button[@id='ccSubmit'][text()='Save']");

		public void new_Creditcard_DataFill(String ctype) {
			try {
				String name = userData.getData("CreditCard Data", "Name");
				
				String visa_cardnum = userData.getData("CreditCard Data", "Visa");
				
				String Master_cardnum = userData.getData("CreditCard Data", "MasterCard");
				String AmericanExpress_cardnum = userData.getData("CreditCard Data", "AmericanExpress");

				String ccmonth = userData.getData("CreditCard Data", "Exp Month");
				String ccyear = userData.getData("CreditCard Data", "Exp Year");
				String ccAddress1 = userData.getData("CreditCard Data", "Address 1");
				String ccAddress2 = userData.getData("CreditCard Data", "Address 2");

				String ccCity = userData.getData("CreditCard Data", "City");
				String ccState = userData.getData("CreditCard Data", "State");
				String ccPcode = userData.getData("CreditCard Data", "Postal Code");
				
				
				
				
				if (ctype.equalsIgnoreCase("Visa")) {

					Driver.findElement(name_cad).sendKeys("VISA card");
					Report.updateTestLog(Action, " Name on Credit Card :  " + ctype, Status.DONE);

					Driver.findElement(ccard).sendKeys(visa_cardnum);
					Report.updateTestLog(Action, "Credit Card Number   :  " + visa_cardnum, Status.DONE);
					
					
					try {
						
//						creditcardnumberLastFourDigit_COC(ctype);
						}
						catch (Exception e) {
							Report.updateTestLog(Action, "  CreditCard Last four num data  Failed ", Status.FAIL);
						}
					
				} else if (ctype.equalsIgnoreCase("MasterCard")) {

					Driver.findElement(name_cad).sendKeys("MasterCard");
					Report.updateTestLog(Action, " Name on Credit Card :  " + ctype, Status.DONE);

					Driver.findElement(ccard).sendKeys(Master_cardnum);
					Report.updateTestLog(Action, "Credit Card Number   :  " + Master_cardnum, Status.DONE);
					
	try {
						
//						creditcardnumberLastFourDigit_COC(ctype);
						}
						catch (Exception e) {
							Report.updateTestLog(Action, "  CreditCard Last four num data  Failed ", Status.FAIL);
						}

				} else if (ctype.equalsIgnoreCase("AmericanExpress")) {

					Driver.findElement(name_cad).sendKeys("AmericanExpress");
					Report.updateTestLog(Action, " Name on Credit Card :  " + ctype, Status.DONE);

					Driver.findElement(ccard).sendKeys(AmericanExpress_cardnum);
					Report.updateTestLog(Action, "Credit Card Number   :  " + AmericanExpress_cardnum, Status.DONE);
					
	try {
						
						//creditcardnumberLastFourDigit_COC(ctype);
						}
						catch (Exception e) {
							Report.updateTestLog(Action, "  CreditCard Last four num data  Failed ", Status.FAIL);
						}

				}
				
				Driver.findElement(By.xpath("//select[@id='expMonth']")).click();
				//org.openqa.selenium.support.ui.Select objMonth = new org.openqa.selenium.support.ui.Select(Driver.findElement(By.xpath("//select[@id='CreditCard_ExpirationMonth']")));

			//	objMonth.selectByVisibleText(ccmonth);

				Driver.findElement(By.xpath("//option[text()='Month']/following-sibling::option[contains(text(),'"+ccmonth+"')]")).click();			
				Driver.findElement(By.xpath("//select[@id='expYear']")).click();
				System.out.println(ccmonth);
				System.out.println(ccyear);
			//	org.openqa.selenium.support.ui.Select objyear = new org.openqa.selenium.support.ui.Select(Driver.findElement(By.xpath("//select[@id='CreditCard_ExpirationYear']")));
				Driver.findElement(By.xpath("//option[text()='Year']/following-sibling::option[contains(text(),'"+ccyear+"')]")).click();
			//	objyear.selectByVisibleText(ccyear);

				Report.updateTestLog(Action,
						" Expiration Month of Card  :  " + ccmonth + " Expiration Year of Card  :  " + ccyear, Status.PASS);

				Driver.findElement(adress1).sendKeys(ccAddress1);
				System.out.println(ccAddress1);
				System.out.println(ccAddress2);
				
				Driver.findElement(adress2).sendKeys(ccAddress2);

				Driver.findElement(city).sendKeys(ccCity);
				Driver.findElement(state).click();

			//			
				Thread.sleep(2000);


				Driver.findElement(By.xpath(
						"//select[@id='addrState']//option[text()='" + ccState + "']"))
						.click();

				Driver.findElement(zipcode).sendKeys(ccPcode);

				Report.updateTestLog(Action, "Address of Card  : " + ccAddress1 + " , " + ccAddress2 + " , " + ccCity
						+ " , " + ccState + " , " + ccPcode, Status.PASS);

				wait.until(ExpectedConditions.visibilityOfElementLocated(confirm_btn));

				Driver.findElement(confirm_btn).click();

//				Thread.sleep(15000);
				wait.until(	ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[contains(@class,'spinner-wrapper')]")));
//				try {
//					wait.until(ExpectedConditions
//							.presenceOfElementLocated(By.xpath("(//button[@id='message-info-close'][text()='Close'])[2]")));
//
//					Driver.findElement(By.xpath("(//button[@id='message-info-close'][text()='Close'])[2]")).click();
//					Thread.sleep(10000);
//					
//					
//
//				} catch (Exception e) {
//					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@id='cboxClose']")));
//
//					Driver.findElement(By.xpath("//button[@id='cboxClose']")).click();
//					Thread.sleep(10000);
//
//				}

			} catch (Exception e) {
				Report.updateTestLog(Action, "   Fill CreditCard data  ", Status.FAIL);

			}

		}
		
		
		public void new_Payment1(String ctype,int l) {
			 System.out.println("  New payment  ");
			 WebElement iframeElement=null;
			wait.until(	ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[contains(@class,'spinner-wrapper')]")));
			String s=Driver.findElement(By.xpath("//*[contains(text(),'New Credit Card Details')]")).getText().toString();
	        System.out.println("  ::  "+s);
	        
			wait.until(ExpectedConditions					.presenceOfElementLocated(By.xpath("//*[contains(text(),'New Credit Card Details')]")));
	String name = userData.getData("CreditCard Data", "Name");
			
			String visa_cardnum = userData.getData("CreditCard Data", "Visa");
			
			String Master_cardnum = userData.getData("CreditCard Data", "MasterCard");
			String AmericanExpress_cardnum = userData.getData("CreditCard Data", "AmericanExpress");

			String ccmonth = userData.getData("CreditCard Data", "Exp Month");
			String ccyear = userData.getData("CreditCard Data", "Exp Year");
			String ccAddress1 = userData.getData("CreditCard Data", "Address 1");
			
			String ccPcode = userData.getData("CreditCard Data", "Postal Code");
			
			System.out.println("visa_cardnum  :: "+visa_cardnum  + "" +Master_cardnum+"  "+AmericanExpress_cardnum);
//			JavascriptExecutor js = (JavascriptExecutor) Driver;
			try {
			 iframeElement = Driver.findElement(By.xpath("//*[@position='GSKUSAddCardFlexSlotName']//iframe[contains(@SRC,'GSKIFRAME')]"));
	        Driver.switchTo().frame(iframeElement);
	        
	        System.out.println("try payment :  ");
	        
	        Driver.findElement(By.xpath("//input[@id='CCNAME']")).click();
	        System.out.println("After click :  ");
			}
			catch (Exception e) {
				Report.updateTestLog(Action, "  CreditCard Frame seting issue ", Status.FAIL);
			}
			By name_cad = By.xpath("//input[@id='CCNAME']");
			By ccard = By.xpath("//input[@id='REPACCOUNTNUMBER1']");
			By cardicon = By.xpath("//span[@class='ttdetectedIcon']//span[contains(@class,'tticon')]");
			By SecurityCode = By.xpath("//input[@id='CCCVV']");
			
			By zipcode = By.xpath("//input[@id='REPACCOUNTAVS']");

			By confirm_btn1 = By.xpath("//button[@id='ccSubmit'][text()='Save']");
			
		
		System.out.println( "  3295");	
			
			String cardlogo=null;
			
			if (ctype.equalsIgnoreCase("Visa")) {

				Driver.findElement(name_cad).sendKeys("VISA card Test");
				Report.updateTestLog(Action, " Name on Credit Card :  VISA card Test " , Status.DONE);

				Driver.findElement(ccard).sendKeys(visa_cardnum);
				Report.updateTestLog(Action, "Credit Card Number   :  " + visa_cardnum, Status.DONE);
				
				
				try {
					creditcardnumberLastFourDigit_COC(ctype,l);
					wait.until(ExpectedConditions.presenceOfElementLocated(cardicon));
					
					 WebElement cardlogo1 =  Driver.findElement(cardicon);
					cardlogo=	cardlogo1.getAttribute("class").toString();
					Report.updateTestLog(Action, cardlogo+ "  :: "+ctype , Status.DONE);
					if(cardlogo.contains("visa"))
					{
						
						Report.updateTestLog(Action, " VISA Logo displyed in Card Session " , Status.PASS);
					}
					else
					{
						
						Report.updateTestLog(Action, " VISA Logo Not displyed in Card Session " , Status.FAIL);
					}
					
					
					
					
					}
					catch (Exception e) {
						Report.updateTestLog(Action, "  CreditCard Last four num data  Failed ", Status.FAIL);
					}
				
			} else if (ctype.equalsIgnoreCase("MasterCard")) {
				
//				js.executeScript("document.getElementById('element id').value = 'xyz';");

				Driver.findElement(name_cad).sendKeys("MasterCard");
				Report.updateTestLog(Action, " Name on Credit Card :  " + ctype, Status.DONE);

				Driver.findElement(ccard).sendKeys(Master_cardnum);
				Report.updateTestLog(Action, "Credit Card Number   :  " + Master_cardnum, Status.DONE);
				
try {
					
	creditcardnumberLastFourDigit_COC(ctype,l);
	wait.until(ExpectedConditions.presenceOfElementLocated(cardicon));
	
	 WebElement cardlogo1 =  Driver.findElement(cardicon);
	cardlogo=	cardlogo1.getAttribute("class").toString();
	Report.updateTestLog(Action, cardlogo+ "  :: "+ctype , Status.DONE);	
	if(cardlogo.contains("mastercard"))
	{
		
		Report.updateTestLog(Action, " MasterCard Logo displyed in Card Session " , Status.PASS);
	}
	else
	{
		
		Report.updateTestLog(Action, " MasterCard Logo Not displyed in Card Session " , Status.FAIL);
	}
					}
					catch (Exception e) {
						Report.updateTestLog(Action, "  CreditCard Last four num data  Failed ", Status.FAIL);
					}

			} else if (ctype.equalsIgnoreCase("AmericanExpress")) {

				Driver.findElement(name_cad).sendKeys("AmericanExpress");
				Report.updateTestLog(Action, " Name on Credit Card :  " + ctype, Status.DONE);

				Driver.findElement(ccard).sendKeys(AmericanExpress_cardnum);
				Report.updateTestLog(Action, "Credit Card Number   :  " + AmericanExpress_cardnum, Status.DONE);
				
try {
					
					creditcardnumberLastFourDigit_COC(ctype,l);
					
					wait.until(ExpectedConditions.presenceOfElementLocated(cardicon));
					
					 WebElement cardlogo1 =  Driver.findElement(cardicon);
					cardlogo=	cardlogo1.getAttribute("class").toString();
					Report.updateTestLog(Action, cardlogo+ "  :: "+ctype , Status.DONE);
					if(cardlogo.contains("amex"))
					{
						
						Report.updateTestLog(Action, " AmericanExpress Logo displyed in Card Session " , Status.PASS);
					}
					else
					{
						
						Report.updateTestLog(Action, " AmericanExpress Logo Not displyed in Card Session " , Status.FAIL);
					}
					
					
					}
					catch (Exception e) {
						Report.updateTestLog(Action, "  CreditCard Last four num data  Failed ", Status.FAIL);
					}

			}
			
			
			
			
			
			Driver.findElement(By.xpath("//select[@id='EXPMO']")).click();
			
			Driver.findElement(By.xpath("//option[text()='Month']/following-sibling::option[contains(@value,'"+ccmonth+"')]")).click();	
			
			
			Driver.findElement(By.xpath("//select[@id='EXPYR']")).click();
			Driver.findElement(By.xpath("//option[text()='Year']/following-sibling::option[contains(@value,'"+ccyear+"')]")).click();
			
			Driver.findElement(SecurityCode).sendKeys(ccAddress1);
			System.out.println(ccAddress1);
						
			Driver.findElement(zipcode).sendKeys(ccPcode);
			
			

			wait.until(ExpectedConditions.visibilityOfElementLocated(confirm_btn1));

			Driver.findElement(confirm_btn1).click();
			
			
			Driver.switchTo().defaultContent();
			wait.until(	ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[contains(@class,'spinner-wrapper')]")));
			try {
				wait.until(ExpectedConditions
						.presenceOfElementLocated(By.xpath("//*[contains(text(),'Save this card for future payments')]")));

				Driver.findElement(By.xpath("//button[normalize-space()='No']")).click();
//				Thread.sleep(10000);
				wait.until(	ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[contains(@class,'spinner-wrapper')]")));
				
//
			} catch (Exception e) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@id='cboxClose']")));
//
				Driver.findElement(By.xpath("//button[@class='cta cta-stroke-sm'][text()='No']")).click();
				wait.until(	ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[contains(@class,'spinner-wrapper')]")));
//
			}
		}

		public void creditcardnumberLastFourDigit_COC(String type1,int l) {
			if (ctype.equalsIgnoreCase("Visa")) {
			String number = userData.getData("CreditCard Data", "Visa");
			String[] split = number.split("");
			String VisaLastFourNumber = split[split.length - 4] + split[(split.length) - 3] + split[(split.length) - 2]
					+ split[(split.length) - 1];
			
			userData.putData("OrderDetails", "CardDetails"+l, VisaLastFourNumber);
//			userData.putData("CreditCard Data", "last four number", VisaLastFourNumber);
			}
			
			if (ctype.equalsIgnoreCase("MasterCard")) {

			String number1 = userData.getData("CreditCard Data", "MasterCard");
			String[] split1 = number1.split("");
			String MasterLastFourNumber = split1[split1.length - 4] + split1[(split1.length) - 3]
					+ split1[(split1.length) - 2] + split1[(split1.length) - 1];
			
			
//			userData.putData("CreditCard Data", "MasterCardLast4num", MasterLastFourNumber);
			userData.putData("OrderDetails", "CardDetails"+l, MasterLastFourNumber);
			}
			
			if (ctype.equalsIgnoreCase("AmericanExpress")) {

			String number2 = userData.getData("CreditCard Data", "AmericanExpress");
			String[] split2 = number2.split("");
			String AmericanLastFourNumber = split2[split2.length - 4] + split2[(split2.length) - 3]
					+ split2[(split2.length) - 2] + split2[(split2.length) - 1];
			
			
//			userData.putData("CreditCard Data", "AmericanExpressLast4num", AmericanLastFourNumber);
			userData.putData("OrderDetails", "CardDetails"+l, AmericanLastFourNumber);
			}
			
			
			
			
		}

		public void creditCard_payNow_Paylater(String type1,String pnow_later, int o) {
			try {JavascriptExecutor js = (JavascriptExecutor) Driver;

			 
			
				//Driver.switchTo().activeElement();
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//div[@aria-labelledby='selectCardModal']//*[@class='modal-content'])[" + o + "]")));

				WebElement text = Driver.findElement(By.xpath("(//div[@aria-labelledby='selectCardModal']//*[@class='modal-content'])[" + o + "]"));
				//Report.updateTestLog(Action, " Paynow Popup ::: " + text.getText()   +"  -----------"+pnow_later, Status.DONE);
				

				if (pnow_later.contains("PayNow")) {
					
//					WebElement PayNow=Driver.findElement(By.xpath("//input[@id='pay-now']"));

					WebElement PayNow=Driver.findElement(By.xpath("(//div[@aria-labelledby='selectCardModal']//*[@class='modal-content'])[" + o + "]//input[contains(@id,'pay-now')]"));	
					js.executeScript("arguments[0].click();", PayNow);

					//Driver.findElement(By.xpath("//input[@id='pay-now']")).click();

					Report.updateTestLog(Action, "Selected CreditCard Paynow Radio Button  ", Status.PASS);

					
//					WebElement Continue=Driver.findElement(By.xpath("//input[@id='pay-now']/../../following-sibling::div//button[normalize-space()='Continue']"));
//					WebElement Continue=Driver.findElement(By.xpath("//input[contains(@id,'pay-now')]/../../following-sibling::div//button[normalize-space()='Continue']"));
					WebElement Continue=Driver.findElement(By.xpath("(//div[@aria-labelledby='selectCardModal']//*[@class='modal-content'])[" + o + "]//button[normalize-space()='Continue']"));

					js.executeScript("arguments[0].click();", Continue);
					spinnerLoad();
					
					try {
						wait.until(
								ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[contains(@class,'spinner-wrapper')]")));
						
//						String card_details= Driver.findElement(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-" +(o-1) + "0')])/following-sibling::div//div[@class='row shiptoRow']//label[@for='Credit_card_dd']")).getText().toString().trim();
//						userData.putData("OrderDetails", "CardDetails"+o, card_details);
						System.out.println(o+  "  ::   pnow_string :: (o-1)  "+(o-1));
						String pnow_string = Driver.findElement(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-" +(o-1) +"0')])/following-sibling::div//div[@class='row shiptoRow']//div[normalize-space()='Pay Now']")).getText();
//						pagereadycheck();
						System.out.println("pnow_string ::  "+pnow_string);
						if (pnow_string.equalsIgnoreCase("Pay Now")) {

							Report.updateTestLog(Action, " Paynow Text is displayed under Credit card   ", Status.PASS);
							
//							Thread.sleep(10000);
							
							
							
						} else {
							Report.updateTestLog(Action, " Paynow Text is Not displayed under Credit card   ", Status.FAIL);
						}

					} catch (Exception e) {
						Report.updateTestLog(Action, " Paynow Text Fetching Failed  ", Status.FAIL);

					}
				}

				

				if (pnow_later.contains("Payatinvoice")) {

					//Driver.findElement(By.xpath("(//*[@id='cboxLoadedContent']//input[@type='radio'])[2]")).click();
					
//					WebElement paynow=Driver.findElement(By.xpath("//input[@id='pay-later']"));
					WebElement paynow=Driver.findElement(By.xpath("(//div[@aria-labelledby='selectCardModal']//*[@class='modal-content'])[" + o + "]//input[contains(@id,'pay-later')]"));

					js.executeScript("arguments[0].click();", paynow);
					Thread.sleep(2000);
//					Driver.findElement(By.xpath("//input[@id='pay-later']")).click();

					
					
					Report.updateTestLog(Action, "Selected CrediCard Pay at invoice due date Radio Button  ", Status.PASS);

//					Thread.sleep(5000);
								
//					Report.updateTestLog(Action,
//							"Continue button :::::; " + Driver.findElement(By.xpath("//input[contains(@id,'pay-later')]/../../following-sibling::div//button[normalize-space()='Continue']")).getText(),
//							Status.PASS);
					try {
						
						
						//reselect_payatin(type1,o);

						WebElement Continue=Driver.findElement(By.xpath("(//div[@aria-labelledby='selectCardModal']//*[@class='modal-content'])[" + o + "]//button[normalize-space()='Continue']"));

						js.executeScript("arguments[0].click();", Continue);
						Report.updateTestLog(Action, "Continue button  ", Status.DONE);
						spinnerLoad();
//						pagereadycheck();
			
					}catch (Exception e) {
						
						
					
//					Driver.findElement(By.xpath("//input[@id='pay-now']/../../following-sibling::div//button[normalize-space()='Continue']")).click();
					Driver.findElement(By.xpath("//input[contains(@id,'pay-later')]/../../following-sibling::div//button[normalize-space()='Continue']")).click();	
					Thread.sleep(2000);
					System.out.println("try");
					
					String card_details= Driver.findElement(By.xpath("(//label[@for='Credit_card_dd'])[" + o + "]")).getText().toString().trim();
//					userData.putData("OrderDetails", "CardDetails"+o, card_details);
				
					}
					
					wait.until(	ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[contains(@class,'spinner-wrapper')]")));	
					
					try {
						String card_details= Driver.findElement(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-" +(o-1) + "0')])/following-sibling::div//div[@class='row shiptoRow']//label[@for='Credit_card_dd']")).getText().toString().trim();
//						userData.putData("OrderDetails", "CardDetails"+o, card_details);
						
						String pnow_string = Driver.findElement(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-" +(o-1) +"0')])/following-sibling::div//div[@class='row shiptoRow']//div[normalize-space()='Pay at invoice due date']")).getText();

						
						if (pnow_string.equalsIgnoreCase("Pay at invoice due date")) {

							Report.updateTestLog(Action, pnow_string + "  is displayed under Credit card   ", Status.PASS);
						} else {
							Report.updateTestLog(Action,
									" Pay at invoice due date Text is Not displayed under Credit card   ", Status.FAIL);
						}

					} catch (Exception e) {
						Report.updateTestLog(Action, " Pay at invoice due date Text Fetching Failed  ", Status.FAIL);

					}	
					
				}
				
				System.out.println("3284");

				// }

				// }
			} catch (Exception e) {
				Report.updateTestLog(Action, " CreditCard Paynow later radio button selection failed   ", Status.FAIL);

			}

		}

		
		
@Action(object = ObjectType.BROWSER, desc = "Validatating Payment details   ", input = InputType.NO)
		
		public void  Validating_Paymenttype() {
	
	pagereadycheck();
	List<WebElement> pd=Driver.findElements(By.xpath("//*[contains(text(),'Payment Details:')]"));
	
	String paymenttype=null;
	for(int i=1;i<=pd.size();i++)
		
	{
		
		
		String ptype=userData.getData("OrderDetails", "PaymentType"+i);
	String [] split=ptype.split(",");
	
	payment = split[0];

	
	try {
	if (payment.equalsIgnoreCase("Invoice me")) {
		try
		{

		paymenttype=Driver.findElement(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-" +(i-1) +"')])/following-sibling::div//*[contains(text(),'Payment Details:')]/../h5/following-sibling::strong")).getText().trim();
		}
		catch (Exception e) {
			paymenttype=Driver.findElement(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-')])/following-sibling::div//*[contains(text(),'Payment Details:')]/../h5/following-sibling::strong")).getText().trim();
			
		}
		if(paymenttype.equalsIgnoreCase("Invoice Me"))
		{
			Report.updateTestLog(Action, "  Invoice me Details avavilable ", Status.PASS);
			
		}
		else
		{
			Report.updateTestLog(Action, "  Invoice me Details not avavilable ", Status.FAIL);
			
		}
		
		

	} 
	}catch (Exception e) {
		
		try {

			
			try {
paymenttype=Driver.findElement(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-" +(i-1) +"')])/following-sibling::div//*[contains(text(),'Payment Details')]/../div//input/following-sibling::label")).getText().trim();
			}catch (Exception e1) {
				
				paymenttype=Driver.findElement(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-" +(i-1) +"')])/following-sibling::div//*[contains(text(),'Payment Details:')]/../h5/following-sibling::p")).getText().trim();	
			}
		if(paymenttype.equalsIgnoreCase("Invoice Me"))
		{
			Report.updateTestLog(Action, "  Invoice me Details avavilable ", Status.PASS);
			
		}
		else
		{
			Report.updateTestLog(Action, "  Invoice me Details not avavilable ", Status.FAIL);
			
		}
		}catch (Exception e1) {
			
			
			
			
			Report.updateTestLog(Action, "  Invoice me Element not found "+e1, Status.FAIL);	
			
			
			
		}
		

	}
	try {
	
	if (payment.equalsIgnoreCase("Credit card")) {
		String details=null;
		try {
				
		paymenttype=Driver.findElement(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-" +(i-1) + "')])/following-sibling::div//*[contains(text(),'Payment Details:')]/../div")).getText();
		 details=Driver.findElement(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-" +(i-1) +"')])/following-sibling::div//*[contains(text(),'Payment Details:')]/../h5/following-sibling::strong")).getText();
		}catch (Exception e) {
			
			paymenttype=Driver.findElement(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-0" +(i-1) + "')])/following-sibling::div//*[contains(text(),'Payment Details:')]/../div")).getText();
			 details=Driver.findElement(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-0" +(i-1) +"')])/following-sibling::div//*[contains(text(),'Payment Details:')]/../h5/following-sibling::strong")).getText();
					
		}
		String CardDetails=userData.getData("OrderDetails", "CardDetails"+i);
		
//	Report.updateTestLog(Action, "Credit card is selected  and "+paymenttype  + "  with  "+ details + "  Option  "+ CardDetails , Status.DONE);
		System.out.println(paymenttype); 	System.out.println(details); 
		
		
		if((details.equalsIgnoreCase("Pay At Invoice Due Date")) &&   (paymenttype.equalsIgnoreCase(CardDetails)) )
		{
			Report.updateTestLog(Action, "Credit card is selected  and "+paymenttype  + "  with  "+ details + "  Option  " , Status.PASS);
			
		} else if((details.equalsIgnoreCase("Pay Now")) &&   (paymenttype.contains(CardDetails)) )
		{
			Report.updateTestLog(Action, "Credit card is selected  and "+paymenttype  + "  with  "+ details + "  Option  " , Status.PASS);
			
		}
		else
		{
			Report.updateTestLog(Action, "Credit card Details In Correct  "+paymenttype  +"  ::  "+details, Status.FAIL);
			
		}
				
	

	}
	
	
	}catch (Exception e) {
		
		Report.updateTestLog(Action, "  Invoice me Element not found "+e, Status.FAIL);
	}

	}
	
	
}

		@Action(object = ObjectType.BROWSER, desc = "Validationg text from page give Xpath , Text  ", input = InputType.YES)
		
		public void  Assertingtext_Validation() {
			
			String [] input=Data.split("---");
			
			// Define the expected text
						String expectedText = input[0];
						String xpath=input[1];
			// Define the expected text
//			String expectedText = "By placing this order, you agree to the Terms of Sale for purchases on this website.";

			// Find the element by xpath and get its text
			WebElement element = Driver.findElement(By.xpath(xpath));
			String actualText = element.getText();

			// Remove the space and new line from the actual text
			actualText = actualText.replace("\n", "");

			// Use if else condition with equalignorecase to compare the actual text and the expected text
			if (actualText.equalsIgnoreCase(expectedText)) {
			    // Do something if the texts match
			    System.out.println("The text matches");
			} else {
			    // Do something if the texts do not match
			    System.out.println("The text does not match");
			}
			
			Assert.assertEquals(actualText, expectedText, "The text does not match");

			
			
		}
		
		
public void list_contract_Price_validation(String Product ,int i )
{
	
	spinnerLoad();
    WebElement listPrice=null;
    
	By Listprice=By.xpath("//*[@id='price-"+Product+"']//p[1]");
	By Contractprice=By.xpath("//*[@id='price-"+Product+"']//p[2]");
	
    
   
    try {
    	  System.out.println("Entering try  block");
    	listPrice = Driver.findElement(Listprice);
    	
    } catch (Exception e) {
    	
    	  System.out.println("Entering catch block unable to get data");
    	
    }
      
    
   String text = listPrice.getText();
   System.out.println(text);
    
    
    String textStr[] = text.split("\\r\\n|\\n|\\r");
 	String a="";
   	for (String string : textStr) {
   
   		if(string.toString().contains("$")) {
   		a = string.toString().replace("$", ""); 
   		System.out.println( a+"  ::: ");
   		}
   		if (a.contains("List:")) {
			a= a.replaceAll("List:\\s+", "");
			System.out.println( "  ::: "+a);
		}
   	}
   	String[] splitss = a.split(" ");
   	
   	String valueOfa=	null;

   	//Double valueOf = Double.valueOf(splitss[0].toString());//
   	
   	if(splitss[0].toString().contains(","))
		
   	{
   		valueOfa= splitss[0].toString().replace(",", "");
   		
   	} else
   	{
   		valueOfa= splitss[0].toString();
   	}
    
    Double valueOf = Double.valueOf(valueOfa);
    Report.updateTestLog(Action, "List Price : "+valueOfa, Status.DONE);
    userData.putData("OrdersPriceValidation", "ListPrice"+(i+1), String.valueOf(valueOf));
   //Contract price 
    
   WebElement contractPrice=null;
    System.out.println("  contractPrice  ::   "+contractPrice);
        	try {
        	contractPrice = Driver.findElement(Contractprice);
        	System.out.println("  contractPrice  :: try      "+contractPrice);
        	}catch (Exception e1) {
//        		Report.updateTestLog(Action, "No Contract associated to this Product", Status.DONE);
        		contractPrice=null;
        		userData.putData("OrdersPriceValidation", "ContractPrice"+(i+1), "0.00");
        		System.out.println("  contractPrice  ::  3519 catch  "+contractPrice);
			}
        	  
   Double valueOf1 = null;
   
    if (contractPrice == null) {
    	
//    	System.out.println("  contractPrice  ::  if loop 3525 "+contractPrice);
   	Report.updateTestLog(Action, "No Contract associated to this Product", Status.DONE);
   	userData.putData("OrdersPriceValidation", "ContractPrice"+(i+1), "0.00");
    	
	} else {
		 String text1 = contractPrice.getText();
		 
//		 Report.updateTestLog(Action, Data+  " :::  contractPrice   ::  " +text1, Status.DONE);
 		String[] split = text1.split(":");
 		
 		for (String string2 : split) {
 			
//			Report.updateTestLog(Action, " string2   ::  " +string2, Status.DONE);
 			if (string2.contains("$")) {
 				//contract price
 				System.out.println(string2.toString().replace("$", ""));
// 				 Report.updateTestLog(Action, " string2.toString().replace   ::  " +string2.toString().replace("$", ""), Status.DONE);
 				if (string2.contains(",")) {
 					String replaceAll = string2.replaceAll(",", "");
 					
 					valueOf1 = Double.valueOf(replaceAll.toString().replace("$", ""));
 					
// 					 Report.updateTestLog(Action, " valueOf1   ::  " +valueOf1, Status.DONE);
 	 				
 					
				} else {
					valueOf1 = Double.valueOf(string2.toString().replace("$", ""));
//					 Report.updateTestLog(Action, " valueOf1   ::  " +valueOf1, Status.DONE);
				}
 				
 				 
 			}
 		}
// 		Report.updateTestLog(Action, "Contract Price : "+valueOf1, Status.DONE);
 	    userData.putData("OrdersPriceValidation", "ContractPrice"+(i+1), String.valueOf(valueOf1));
	}
    	
	
	
}
		

@Action(object = ObjectType.BROWSER, desc = "Enter ProductCount,CartCount,ProductPerCart,ShipTo-BillTo [<Data>]", input = InputType.NO)
public void OrderreviewPageValidation_cc()

{
	
	try {
	
	
//	 List<WebElement> buttons = Driver.findElements(By.xpath("(//*[@class='card-header']//button)"));
	 List<WebElement> buttons = Driver.findElements(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])"));
	 
	  System.out.println("buttons  " +buttons.size() );
     // Loop through the list of buttons
     for (int i = 1; i <= buttons.size(); i++) {
         // Get the current button
         WebElement button =  Driver.findElement(By.xpath("  (//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+i+"]//button"));
         System.out.println("buttons  791  " +button.getText() );
         // Get the value of the attribute "aria-expanded"
         
//         Report.updateTestLog(Action, "Shipping & Payment Information Page  " , Status.PASS);
         
         String ariaExpanded = button.getAttribute("aria-expanded");
System.out.println(ariaExpanded);
         // Check if the value is "false"
         if (ariaExpanded.equals("false")) {
             // Click on the button
             button.click();
             
             Report.updateTestLog(Action, "Clicking on ship  " +i, Status.PASS);
             try {
             // Find the element that matches the xpath "(//*[@class='card-header']//button)["+i+"]/..//div[contains(@class,'noOfProds')]"
             WebElement div = Driver.findElement(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+i+"]/../../div/div[@class='collapse show']"));

             // Get the value of the attribute "class"
             String divClass = div.getAttribute("class");

             // Check if the value contains "collapse show"
             if (divClass.contains("collapse show")) {
                 // Print a message
                 System.out.println("The div element is expanded");
                 
                 Report.updateTestLog(Action, "collapse show is displayed Page  " , Status.PASS);
                 
//                 payBy_Selection();

                 
                 Validating_Paymenttype_orderpaage(i) ;
                 shippingPage_priceValidation(i);
                 
             }
             
             } catch (Exception e) {
                 // Catch any exception and print the error message
                 System.out.println("An error occurred: " + e.getMessage());
             }
         }
         
         
         else
         {
//        	 WebElement div = Driver.findElement(By.xpath("(//*[@class='card-header']//button)["+i+"]/../../div[@class='collapse show']"));
        	 WebElement div = Driver.findElement(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+i+"]/../../div/div[@class='collapse show']"));

             // Get the value of the attribute "class"
             String divClass = div.getAttribute("class");

             // Check if the value contains "collapse show"
             if (divClass.contains("collapse show")) {
                 // Print a message
                 System.out.println("The div element is expanded");
                 
                 Report.updateTestLog(Action, "Expanded Page displayed " , Status.PASS);
                 try
                 {
                	 
//                	payBy_Selection();	 
                	 Validating_Paymenttype_orderpaage(i) ;
                 shippingPage_priceValidation(i);
                 
                 }catch (Exception e) {
                     // Catch any exception and print the error message
                     System.out.println("An error occurred: " + e.getMessage());
                 }
                 
                 
             }
        	 
         }
     }
	} catch (Exception e) {
        // Catch any exception and print the error message
        System.out.println("An error occurred: " + e.getMessage());
    }
	
	
}



@Action(object = ObjectType.BROWSER, desc = "Enter ProductCount,CartCount,ProductPerCart,ShipTo-BillTo [<Data>]", input = InputType.NO)
public void OrderCompletedPageValidation_cc()

{
	
	try {
	
	
//	 List<WebElement> buttons = Driver.findElements(By.xpath("(//*[@class='card-header']//button)"));
	 List<WebElement> buttons = Driver.findElements(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])"));
	 
	  System.out.println("buttons  " +buttons.size() );
     // Loop through the list of buttons
     for (int i = 1; i <= buttons.size(); i++) {
         // Get the current button
         WebElement button =  Driver.findElement(By.xpath("  (//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+i+"]//button"));
         System.out.println("buttons  791  " +button.getText() );
         // Get the value of the attribute "aria-expanded"
         
//         Report.updateTestLog(Action, "Shipping & Payment Information Page  " , Status.PASS);
         
         String ariaExpanded = button.getAttribute("aria-expanded");
System.out.println(ariaExpanded);
         // Check if the value is "false"
         if (ariaExpanded.equals("false")) {
             // Click on the button
             button.click();
             
             Report.updateTestLog(Action, "Clicking on ship  " +i, Status.PASS);
             try {
             // Find the element that matches the xpath "(//*[@class='card-header']//button)["+i+"]/..//div[contains(@class,'noOfProds')]"
             WebElement div = Driver.findElement(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+i+"]/../../div/div[@class='collapse show']"));

             // Get the value of the attribute "class"
             String divClass = div.getAttribute("class");

             // Check if the value contains "collapse show"
             if (divClass.contains("collapse show")) {
                 // Print a message
                 System.out.println("The div element is expanded");
                 
                 Report.updateTestLog(Action, "collapse show is displayed Page  " , Status.PASS);
                 
//                 payBy_Selection();
//
                 orderConfirmation();
                 Validating_Paymenttype_orderpaage(i) ;
                 shippingPage_priceValidation(i);
                 
             }
             
             } catch (Exception e) {
                 // Catch any exception and print the error message
                 System.out.println("An error occurred: " + e.getMessage());
             }
         }
         
         
         else
         {
//        	 WebElement div = Driver.findElement(By.xpath("(//*[@class='card-header']//button)["+i+"]/../../div[@class='collapse show']"));
        	 WebElement div = Driver.findElement(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+i+"]/../../div/div[@class='collapse show']"));

             // Get the value of the attribute "class"
             String divClass = div.getAttribute("class");

             // Check if the value contains "collapse show"
             if (divClass.contains("collapse show")) {
                 // Print a message
                 System.out.println("The div element is expanded");
                 
                 Report.updateTestLog(Action, "Expanded Page displayed " , Status.PASS);
                 try
                 {
                	 
//                	payBy_Selection();	
                	 orderConfirmation();
                	 Validating_Paymenttype_orderpaage(i) ;
                 shippingPage_priceValidation(i);
                 
                 
                 
                 }catch (Exception e) {
                     // Catch any exception and print the error message
                     System.out.println("An error occurred: " + e.getMessage());
                 }
                 
                 
             }
        	 
         }
     }
	} catch (Exception e) {
        // Catch any exception and print the error message
        System.out.println("An error occurred: " + e.getMessage());
    }
	
	
}


public void orderConfirmation() {
	
	String thanku=null,Orderdate_time=null,Confirmationnum=null,Confirmationsent=null,Ordernum=null;
	try {
		
		thanku=Driver.findElement(By.xpath("//*[@class='my-2']")).getText();
		Orderdate_time=Driver.findElement(By.xpath("(//*[contains(@class,'thankYouSection')]//p//span)[1]")).getText();
		Confirmationnum=Driver.findElement(By.xpath("(//*[contains(@class,'thankYouSection')]//p//span)[2]")).getText();
		Confirmationsent=Driver.findElement(By.xpath("(//*[contains(@class,'thankYouSection')]//p//span)[3]")).getText();
		
		
		
		if(thanku.equalsIgnoreCase("Thank you! Your order has been successfully placed."))
		{
			
			  Report.updateTestLog(Action, "Thank you! Your order has been successfully placed is  displayed " , Status.PASS);	
		}
		else
		{
			
			  Report.updateTestLog(Action, "Thank you! Your order has been successfully placed Not displayed " , Status.FAIL);
			  
		}
		
		
		addVar("%Orderdate_time%",Orderdate_time);
		addVar("%Confirmationnum%",Confirmationnum);
		addVar("%Confirmationsent%",Confirmationsent);
		
		Report.updateTestLog(Action, "Order Date/Time:   "+Orderdate_time  +"    ::  Confirmation Number:   "+Confirmationnum+ "    ::  Confirmation Sent to:   "+Confirmationsent , Status.PASS);
		List<WebElement> OrderNum = Driver.findElements(By.xpath("(//*[contains(@class,'thankYouSection')]//p//a)"));
		addVar("%OrderNumsize%",Integer.toString(OrderNum.size()));
		for(int l=1;l<=OrderNum.size();l++)
			
		{
			
			Ordernum=Driver.findElement(By.xpath("(//*[contains(@class,'thankYouSection')]//p//a)["+l+"]")).getText();
			 String on="%OrderNumber"+l+"%";
			 
			 addVar(on,Ordernum);
			 
			 Report.updateTestLog(Action, "Order Number displayed ::  "+Ordernum , Status.PASS); 
			
		}
		
		
	}
	
	catch (Exception e) {
        // Catch any exception and print the error message
        System.out.println("An error occurred: " + e.getMessage());
    }
	
	
}

@Action(object = ObjectType.BROWSER, desc = "Clicking On Order Number and Validating Order History page Validation", input = InputType.NO)
public void orderHistoryvalidation() {
	
	WebDriverWait wait = new WebDriverWait(Driver,10);
	
	String Ordernum=null,res=null;
	String ordernum_history=null,ConNumber=null,Odt=null,CustomerType=null;
	String ShipTo=null,BillTo=null,DeliveryAddress=null,Rdd=null,Sln=null,contract=null,ponum=null,ptype=null;
	List<WebElement> OrderNum = Driver.findElements(By.xpath("(//*[contains(@class,'thankYouSection')]//p//a)"));
	
//	addVar("%OrderNumsize%",Integer.toString(OrderNum.size()));
	
	
	String Orderdate_time=null,Confirmationnum=null,Confirmationsent=null,ordernum_Oh=null;
	for(int l=1;l<=OrderNum.size();l++)
		
	{
		
		Ordernum=Driver.findElement(By.xpath("(//*[contains(@class,'thankYouSection')]//p//a)["+l+"]")).getText();
		
		 
		 Report.updateTestLog(Action, "Order Number"+l+" displayed ::  "+Ordernum , Status.PASS); 
		 
		 Driver.findElement(By.xpath("(//*[contains(@class,'thankYouSection')]//p//a)["+l+"]")).click();
		 spinnerLoad();
//		 wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
//					.executeScript("return document.readyState")));
		 spinnerLoad();
		 try {
			 
			  res= Driver.findElement(By.xpath("//span[normalize-space()='Reservation:']")).getText();
			  System.out.println(" res  3815 "+res);
		 }
		 catch(Exception e1)
		 
		 {
			 
			 
			 res=null;
			  System.out.println(" res  catch  4208 "+res);
		 }
		 
		 try {
			 
//		 wait.until(ExpectedConditions.visibilityOf(Driver.findElement(By.xpath("//div[contains(text(),'Order Details')]"))));
//		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Print')]")));
	 Orderdate_time=	 getVar("%Orderdate_time%");
	 Confirmationnum=	getVar("%Confirmationnum%");
	 Confirmationsent=getVar("%Confirmationsent%");
		 
	System.out.println("Orderdate_time  ::  "+Orderdate_time + " ::  Confirmationnum  ::  " +Confirmationnum+" :: Confirmationsent  ::  "+Confirmationsent );
	
	  ordernum_Oh=getVar("%OrderNumber"+l+"%");
	 
		 
		
			 wait.until(ExpectedConditions.visibilityOf(Driver.findElement(By.xpath("//div[contains(text(),'Order Details')]"))));
			 Thread.sleep(5000);
			 
			 ordernum_history=Driver.findElement(By.xpath("//span[@class='title-sm'][contains(text(),'Order #:')]//following-sibling::span")).getText();
			 ConNumber=Driver.findElement(By.xpath("//span[@class='title-sm'][contains(text(),'Confirmation Number:')]//following-sibling::span")).getText();
			 Odt=Driver.findElement(By.xpath("//span[@class='title-sm'][contains(text(),'Order Date/Time:')]//following-sibling::span")).getText();
//			 CustomerType=Driver.findElement(By.xpath("//span[@class='title-sm'][contains(text(),'Order #:')]//following-sibling::span")).getText();
			
//			 ordernum_history=Driver.findElement(By.xpath("//span[@class='title-sm'][contains(text(),'Order #:')]//following-sibling::span")).getText();
			 
			 
			 
			 if(ordernum_history.contains(ordernum_Oh))
					
				{
					Report.updateTestLog(Action, "Excepted Ordernumber in Order History ::  " +ordernum_Oh  + " and Actual Ordernumber is same::  " +ordernum_history , Status.PASS);
				}
				else
					
				{
					Report.updateTestLog(Action, "Excepted Ordernumber in Order History ::  " +ordernum_Oh  + " and Actual Ordernumber is same::  " +ordernum_history , Status.FAIL);
				}
				
				
				
			if(ConNumber.contains(Confirmationnum))
					
			{
				Report.updateTestLog(Action, "Excepted Confirmation Number in Order History ::  " +Confirmationnum  + " and Confirmation Number is same::  " +ConNumber , Status.PASS);
			}
			else
				
			{
				Report.updateTestLog(Action, "Excepted Confirmation Number in Order History ::  " +Confirmationnum  + " and Confirmation Number is  Not Matched ::  " +ConNumber , Status.FAIL);
			}

			if(Odt.contains(Orderdate_time))
				
			{
				Report.updateTestLog(Action, "Excepted Order Date/Time in Order History ::  " +Orderdate_time  + " and Order Date/Time:  is same::  " +Odt , Status.PASS);
			}
			else
				
			{
				Report.updateTestLog(Action, "Excepted Order Date/Time: in Order History ::  " +Orderdate_time  + " andOrder Date/Time: is Not Matched ::  " +Odt , Status.FAIL);
			}



						 
			 try {
			 
				 System.out.println(" aa:  "+res);
				 if((res.contains(null))||(res==("null"))||(res.equals("null")))
					{
						 Report.updateTestLog(Action, "res==null ;  ", Status.DONE);
						 OrderSummary_History(l);	 
						
					}
				 else if(res.contains("Reservation:"))
				{
				 Report.updateTestLog(Action, "OrderSummary_History(l);  4286 ", Status.DONE);
				 System.out.println(" OrderSummary_History(l);  4286  ");
				 OrderSummary_History(l);
//				 order_items_Oh_Validation(l);
				 
				}
				 
				else {
					Report.updateTestLog(Action, "OrderSummary_History(l); catch 39  ", Status.DONE);
				}
			 }
			 catch (Exception e1) {
				 
				 System.out.println("inside catch  4292");
				 OrderSummary_History(l);
				 System.out.println(e1);
//				 order_items_Oh_Validation(l);
			 Report.updateTestLog(Action, "OrderSummary_History(l); catch 3886  ", Status.DONE);
			
			 }
			 Driver.navigate().back();
			 
			 spinnerLoad();
			 wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
						.executeScript("return document.readyState")));
			  
			 
		 }
		 catch (Exception e) {
			 
			 try {
				 
				 wait.until(ExpectedConditions.visibilityOf(Driver.findElement(By.xpath("//span[contains(@class,'reservationDetailsTitle')][contains(text(),'Reservation Details')]"))));
					
			 Orderdate_time=	 getVar("%Orderdate_time%");
			 Confirmationnum=	getVar("%Confirmationnum%");
			 Confirmationsent=getVar("%Confirmationsent%");
				 
			System.out.println("Orderdate_time  ::  "+Orderdate_time + " ::  Confirmationnum  ::  " +Confirmationnum+" :: Confirmationsent  ::  "+Confirmationsent );
			
			  ordernum_Oh=getVar("%OrderNumber"+l+"%");
			 
			 
			 // Thread.sleep(5000);
			 
			 ordernum_history=Driver.findElement(By.xpath("//*[contains(@class,'card-title')]//span")).getText();
			 ConNumber=Driver.findElement(By.xpath("//span[contains(text(),'Confirmation Number:')]/../../p")).getText();
			 Odt=Driver.findElement(By.xpath("//span[contains(text(),'Order Date/Time: ')]/../../p")).getText();
//			 CustomerType=Driver.findElement(By.xpath("//span[@class='title-sm'][contains(text(),'Order #:')]//following-sibling::span")).getText();
			
//			 ordernum_history=Driver.findElement(By.xpath("//span[@class='title-sm'][contains(text(),'Order #:')]//following-sibling::span")).getText();
			 
			 
			 
			 if(ordernum_history.contains(ordernum_Oh))
					
				{
					Report.updateTestLog(Action, "Excepted Ordernumber in Order History ::  " +ordernum_Oh  + " and Actual Ordernumber is same::  " +ordernum_history , Status.PASS);
				}
				else
					
				{
					Report.updateTestLog(Action, "Excepted Ordernumber in Order History ::  " +ordernum_Oh  + " and Actual Ordernumber is same::  " +ordernum_history , Status.FAIL);
				}
				
				
				
			if(ConNumber.contains(Confirmationnum))
					
			{
				Report.updateTestLog(Action, "Excepted Confirmation Number in Order History ::  " +Confirmationnum  + " and Confirmation Number is same::  " +ConNumber , Status.PASS);
			}
			else
				
			{
				Report.updateTestLog(Action, "Excepted Confirmation Number in Order History ::  " +Confirmationnum  + " and Confirmation Number is  Not Matched ::  " +ConNumber , Status.FAIL);
			}

			if(Odt.contains(Orderdate_time))
				
			{
				Report.updateTestLog(Action, "Excepted Order Date/Time in Order History ::  " +Orderdate_time  + " and Order Date/Time:  is same::  " +Odt , Status.PASS);
			}
			else
				
			{
				Report.updateTestLog(Action, "Excepted Order Date/Time: in Order History ::  " +Orderdate_time  + " andOrder Date/Time: is Not Matched ::  " +Odt , Status.FAIL);
			}


 
			 
			Report.updateTestLog(Action, "reservation_items_Oh_alidation  :: before  ", Status.PASS);
			reservation_items_Oh_Validation(l); 
			 }
			 catch (Exception e1) {
				 
				 Report.updateTestLog(Action, "reservation details FAiled  ", Status.FAIL);
			 }
			 
			 Driver.navigate().back();
			 
			 spinnerLoad();
			 wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
						.executeScript("return document.readyState")));
			 
		    }
			
		
		 
		
	}
	
	
	
	
}


public void OrderSummary_History()

{
	String 	cs_os = null,subt_os=null,fex_os=null,est_os=null,total_os1=null;
	String ContractSaving_OS=null,subtotal_OS=null,Fet_OS1=null,EST_OS1=null,total_OS=null;


	
	
	try {
	Thread.sleep(5000);
	 	cs_os=Driver.findElement(By.xpath("//span[@class='title-lg'][contains(text(),'Contract Savings')]//following-sibling::span")).getText();
	 	subt_os=removeSymbols(Driver.findElement(By.xpath("//span[@class='title-sm'][contains(text(),'Subtotal')]//following-sibling::span")).getText());
	 	fex_os=Driver.findElement(By.xpath("//*[@class='od-os-content']//span[@class='title-sm'][contains(text(),'Federal Excise Tax')]//following-sibling::span")).getText();
	 	est_os=Driver.findElement(By.xpath("//*[@class='od-os-content']//span[@class='title-sm'][contains(text(),'Estimated Sales Tax')]//following-sibling::span")).getText();
	 	total_os1=removeSymbols(Driver.findElement(By.xpath("//*[@class='od-os-content']//span[@class='title-lg'][contains(text(),'Total Price')]//following-sibling::span")).getText());
	
	Report.updateTestLog(Action, "try  1::  cs_os  in Order History ::  " +cs_os  + "subt_os  in Order History ::  " +subt_os  +"fex_os  in Order History ::  " +fex_os  +
			"est_os  in Order History ::  " +est_os  +"total_os1  in Order History ::  " +total_os1  , Status.DONE);	
	
//
	 
	}

	 catch (Exception e) {
		 
		 try {
			 
			 cs_os=Driver.findElement(By.xpath("//p[contains(text(),'Contract Savings')]//span")).getText();
			 	subt_os=removeSymbols(Driver.findElement(By.xpath("//span[@class='title-sm'][contains(text(),'Subtotal')]//following-sibling::span")).getText());
			 	fex_os=Driver.findElement(By.xpath("//*[@class='od-os-content']//span[@class='title-sm'][contains(text(),'Federal Excise Tax')]//following-sibling::span")).getText();
			 	est_os=Driver.findElement(By.xpath("//*[@class='od-os-content']//span[@class='title-sm'][contains(text(),'Estimated Sales Tax')]//following-sibling::span")).getText();
			 	total_os1=removeSymbols(Driver.findElement(By.xpath("//*[@class='od-os-content']//span[@class='title-lg'][contains(text(),'Total Price')]//following-sibling::span")).getText());
			
			Report.updateTestLog(Action, "cs_os  in Order History ::  " +cs_os  + "subt_os  in Order History ::  " +subt_os  +"fex_os  in Order History ::  " +fex_os  +
					"est_os  in Order History ::  " +est_os  +"total_os1  in Order History ::  " +total_os1  , Status.DONE);	
			
		//
	       
		 } catch (Exception e1) {
			 // Catch any exception and print the error message
		        System.out.println("An error occurred: " + e.getMessage());
		         
			 
		 }
	    }
		

	
	

	 ContractSaving_OS=getVar("%ContractSaving_OS%");
	 subtotal_OS= getVar("%subtotal_OS%");
	 Fet_OS1=getVar("%Fet_OS%");
	 EST_OS1= getVar("%EST_OS%");
	 total_OS= getVar("%total_OS%");
	
	Report.updateTestLog(Action, "ContractSaving_OS  in Order History ::  " +ContractSaving_OS  + "subtotal_OS  in Order History ::  " +subtotal_OS  +"Fet_OS1  in Order History ::  " +Fet_OS1  +
			"EST_OS1  in Order History ::  " +EST_OS1  +"total_OS  in Order History ::  " +total_OS  , Status.DONE);	
			
	
	
if(cs_os.contains(ContractSaving_OS))
		
	{
		Report.updateTestLog(Action, "Excepted Contract Savings in Order Summary in Order History ::  " +ContractSaving_OS  + " and Actual Contract Savings is same::  " +cs_os , Status.PASS);
	}
	else
		
	{
		Report.updateTestLog(Action, "Excepted Contract Savings  in Order Summary in Order History ::  " +ContractSaving_OS  + " and Actual Contract Savings is  Not Matched ::  " +cs_os , Status.FAIL);
	}
	
	
	
if(subt_os.contains(subtotal_OS))
		
{
	Report.updateTestLog(Action, "Excepted Subtotal in Order Summary in Order History ::  " +subtotal_OS  + " and Actual Subtotal is same::  " +subt_os , Status.PASS);
}
else
	
{
	Report.updateTestLog(Action, "Excepted Subtotal in Order Summary in Order History ::  " +subtotal_OS  + " and Actual Subtotal is  Not Matched ::  " +subt_os , Status.FAIL);
}

if(fex_os.contains(Fet_OS1))
	
{
	Report.updateTestLog(Action, "Excepted Federal Excise Tax in Order Summary  in Order History ::  " +fex_os  + " and Federal Excise Tax is same::  " +Fet_OS1 , Status.PASS);
}
else
	
{
	Report.updateTestLog(Action, "Excepted Federal Excise Tax in Order Summary in Order History ::  " +fex_os  + " and Federal Excise Tax is Not Matched ::  " +Fet_OS1 , Status.FAIL);
}



	
	if(est_os.contains(EST_OS1))	
		
	{
		Report.updateTestLog(Action, "Excepted Estimated Sales Tax in Order History  ::  " +EST_OS1  + " and Actual Estimated Sales Tax  is same::  " +est_os , Status.PASS);
	}
	else
		
	{
		Report.updateTestLog(Action, "Excepted Estimated Sales Tax in Order History  ::  " +EST_OS1  + " and Actual Estimated Sales Tax is Not Matched ::  " +est_os , Status.FAIL);
	}
		
		
		if(total_os1.contains(total_OS))	
			
		{
			Report.updateTestLog(Action, "Excepted Total Price Tax in Order History  ::  " +total_OS  + " and Actual Total Price is same::  " +total_os1 , Status.PASS);
		}
		else
			
		{
			Report.updateTestLog(Action, "Excepted Total Price Tax in Order History  ::  " +total_OS  + " and Actual Total Price is Not Matched ::  " +total_os1 , Status.FAIL);
		}
		
		
	
	
}



public void OrderSummary_History(int k)

{
	String 	cs_os = null,subt_os=null,fex_os=null,est_os=null,total_os1=null;
	String ContractSaving_OS=null,subtotal_OS=null,Fet_OS1=null,EST_OS1=null,total_OS=null;


	
	
	try {
	Thread.sleep(5000);
	 	cs_os=Driver.findElement(By.xpath("//span[@class='title-lg'][contains(text(),'Contract Savings')]//following-sibling::span")).getText();
	 	subt_os=removeSymbols(Driver.findElement(By.xpath("//span[@class='title-sm'][contains(text(),'Subtotal')]//following-sibling::span")).getText());
	 	fex_os=Driver.findElement(By.xpath("//*[@class='od-os-content']//span[@class='title-sm'][contains(text(),'Federal Excise Tax')]//following-sibling::span")).getText();
	 	est_os=Driver.findElement(By.xpath("//*[@class='od-os-content']//span[@class='title-sm'][contains(text(),'Estimated Sales Tax')]//following-sibling::span")).getText();
	 	total_os1=removeSymbols(Driver.findElement(By.xpath("//*[@class='od-os-content']//span[@class='title-lg'][contains(text(),'Total Price')]//following-sibling::span")).getText());
	
	Report.updateTestLog(Action, "try  2::  cs_os  in Order History ::  " +cs_os  + "subt_os  in Order History ::  " +subt_os  +"fex_os  in Order History ::  " +fex_os  +
			"est_os  in Order History ::  " +est_os  +"total_os1  in Order History ::  " +total_os1  , Status.DONE);	
	
//
	 
	}

	 catch (Exception e) {
		 
		 try {
			 
			 cs_os=Driver.findElement(By.xpath("//p[contains(text(),'Contract Savings')]//span")).getText();
			 	subt_os=removeSymbols(Driver.findElement(By.xpath("//span[@class='title-sm'][contains(text(),'Subtotal')]//following-sibling::span")).getText());
			 	fex_os=Driver.findElement(By.xpath("//*[@class='od-os-content']//span[@class='title-sm'][contains(text(),'Federal Excise Tax')]//following-sibling::span")).getText();
			 	est_os=Driver.findElement(By.xpath("//*[@class='od-os-content']//span[@class='title-sm'][contains(text(),'Estimated Sales Tax')]//following-sibling::span")).getText();
			 	total_os1=removeSymbols(Driver.findElement(By.xpath("//*[@class='od-os-content']//span[@class='title-lg'][contains(text(),'Total Price')]//following-sibling::span")).getText());
			
			Report.updateTestLog(Action, "cs_os  in Order History ::  " +cs_os  + "subt_os  in Order History ::  " +subt_os  +"fex_os  in Order History ::  " +fex_os  +
					"est_os  in Order History ::  " +est_os  +"total_os1  in Order History ::  " +total_os1  , Status.DONE);	
			
		//
	       
		 } catch (Exception e1) {
			 // Catch any exception and print the error message
		        System.out.println("An error occurred: " + e.getMessage());
		         
			 
		 }
	    }
		

	
	

	 ContractSaving_OS=removeSymbols(userData.getData("OrdersPriceValidation", "Savings with promotion"+k));
	 subtotal_OS= removeSymbols(userData.getData("OrdersPriceValidation", "Subtotal before savings" + k));
	 Fet_OS1=userData.getData("OrdersPriceValidation", "Total Federal excise tax" + k);
	 EST_OS1=userData.getData("OrdersPriceValidation", "Total Estimated sales tax" + k);
	 total_OS= removeSymbols(userData.getData("OrdersPriceValidation", "Price for contract" +k));
	
	Report.updateTestLog(Action, "ContractSaving_OS 2 : sheet data  in Order History ::  " +ContractSaving_OS  + "subtotal_OS  in Order History ::  " +subtotal_OS  +"Fet_OS1  in Order History ::  " +Fet_OS1  +
			"EST_OS1  in Order History ::  " +EST_OS1  +"total_OS  in Order History ::  " +total_OS  , Status.DONE);	
			
	
	
if(cs_os.contains(ContractSaving_OS))
		
	{
		Report.updateTestLog(Action, "Excepted Contract Savings in Order Summary in Order History ::  " +ContractSaving_OS  + " and Actual Contract Savings is same::  " +cs_os , Status.PASS);
	}
	else
		
	{
		Report.updateTestLog(Action, "Excepted Contract Savings  in Order Summary in Order History ::  " +ContractSaving_OS  + " and Actual Contract Savings is  Not Matched ::  " +cs_os , Status.FAIL);
	}
	
	
	
if(subt_os.contains(subtotal_OS))
		
{
	Report.updateTestLog(Action, "Excepted Subtotal in Order Summary in Order History ::  " +subtotal_OS  + " and Actual Subtotal is same::  " +subt_os , Status.PASS);
}
else
	
{
	Report.updateTestLog(Action, "Excepted Subtotal in Order Summary in Order History ::  " +subtotal_OS  + " and Actual Subtotal is  Not Matched ::  " +subt_os , Status.FAIL);
}

if(fex_os.contains(Fet_OS1))
	
{
	Report.updateTestLog(Action, "Excepted Federal Excise Tax in Order Summary  in Order History ::  " +fex_os  + " and Federal Excise Tax is same::  " +Fet_OS1 , Status.PASS);
}
else
	
{
	Report.updateTestLog(Action, "Excepted Federal Excise Tax in Order Summary in Order History ::  " +fex_os  + " and Federal Excise Tax is Not Matched ::  " +Fet_OS1 , Status.FAIL);
}



	
	if(est_os.contains(EST_OS1))	
		
	{
		Report.updateTestLog(Action, "Excepted Estimated Sales Tax in Order History  ::  " +EST_OS1  + " and Actual Estimated Sales Tax  is same::  " +est_os , Status.PASS);
	}
	else
		
	{
		Report.updateTestLog(Action, "Excepted Estimated Sales Tax in Order History  ::  " +EST_OS1  + " and Actual Estimated Sales Tax is Not Matched ::  " +est_os , Status.FAIL);
	}
		
		
		if(total_os1.contains(total_OS))	
			
		{
			Report.updateTestLog(Action, "Excepted Total Price Tax in Order History  ::  " +total_OS  + " and Actual Total Price is same::  " +total_os1 , Status.PASS);
		}
		else
			
		{
			Report.updateTestLog(Action, "Excepted Total Price Tax in Order History  ::  " +total_OS  + " and Actual Total Price is Not Matched ::  " +total_os1 , Status.FAIL);
		}
		
		
//		 order_items_Oh_Validation(k);
	
}



public void  order_items_Oh_Validation(int i) {
	
	int count=0;
	String pname=null,Ndc=null,qty=null,contract1=null,lprice1=null,cs=null,fet1=null,it1=null;
	String prodname=null,Ndcdetails=null,quantity=null,contract=null,lprice=null,contractsavings=null,fet=null,it=null;
	
	List<WebElement> oh=Driver.findElements(By.xpath("//div[@class='oi-od-desc']"));
	
//	for(int i=1;i<=oh.size();i++) {
		
try {
		  String aa="%prodname"+i+"%";
		  prodname=getVar(aa);
}catch(Exception e1) 
{
	System.out.println(e1);
}
		  Ndcdetails=userData.getData("OrderDetails", "Product"+i);
		quantity=userData.getData("OrderDetails", "qty"+i);
		lprice= userData.getData("OrdersPriceValidation", "ListPrice"+i);
		contractsavings=userData.getData("OrdersPriceValidation", "Savings with promotion" + i);
		fet=userData.getData("OrdersPriceValidation", "Total Federal excise tax" + i);
		it=	userData.getData("OrdersPriceValidation", "Price for contract" +i);
		
		
		
		
		try {
			contract=userData.getData("OrdersPriceValidation", "ContractPrice"+i);
		contract1=Driver.findElement(By.xpath("(//span[contains(text(),'Contract:')]/following-sibling::span)["+i+"]")).getText();
		pname=	Driver.findElement(By.xpath("(//div[@class='oi-od-desc']//span[@class='title-xl'])["+i+"]")).getText();
		Ndc=Driver.findElement(By.xpath("(//div[@class='oi-od-desc']//span[contains(text(),'NDC:')]/following-sibling::span)["+i+"]")).getText();
		qty=Driver.findElement(By.xpath("(//div[@class='od-od-tot-pack']//span[contains(text(),'Total Packs:')]/following-sibling::span)["+i+"]")).getText();
		
		lprice1	=Driver.findElement(By.xpath("(//span[contains(text(),'List:')]/following-sibling::span)["+i+"]")).getText();
		cs=Driver.findElement(By.xpath("(//span[contains(text(),'Contract Savings:')]/following-sibling::span)["+i+"]")).getText();
		fet1=Driver.findElement(By.xpath("(//span[contains(text(),'Federal Excise Tax:')]/following-sibling::span)["+i+"]")).getText();
		it1=Driver.findElement(By.xpath("(//span[contains(text(),'Item Total')]/following-sibling::span)["+i+"]")).getText();



if(pname.contains(prodname))
	
{
	Report.updateTestLog(Action, "Excepted Product Name in Order History ::  " +prodname  + " and Actual Product Name is same::  " +pname , Status.PASS);
}
else
	
{
	Report.updateTestLog(Action, "Excepted Product Name in Order History ::  " +prodname  + " and Actual Product Name is  Not Matched ::  " +pname , Status.FAIL);
}



if(Ndc.contains(Ndcdetails))
	
{
Report.updateTestLog(Action, "Excepted NDC in Order History ::  " +Ndc  + " and Actual NDC is same::  " +Ndcdetails , Status.PASS);
}
else

{
Report.updateTestLog(Action, "Excepted NDC in Order History ::  " +Ndc  + " and Actual NDC is  Not Matched ::  " +Ndcdetails , Status.FAIL);
}		


if(qty.contains(quantity))
	
{
	Report.updateTestLog(Action, "Excepted Quantity in Order History ::  " +quantity  + " and Actual Quantity is same::  " +qty , Status.PASS);
}
else
	
{
	Report.updateTestLog(Action, "Excepted Quantity in Order History ::  " +quantity  + " and Actual Quantity is Not Matched ::  " +qty , Status.FAIL);
}		

if(contract1.contains(contract))

{
Report.updateTestLog(Action, "Excepted Contract Savings in Order Summary in Order History ::  " +contract  + " and Actual Contract Savings is same::  " +contract1 , Status.PASS);
}
else

{
Report.updateTestLog(Action, "Excepted Contract Savings  in Order Summary in Order History ::  " +contract  + " and Actual Contract Savings is  Not Matched ::  " +contract1 , Status.FAIL);
}


if(lprice1.contains(lprice))
	
{
Report.updateTestLog(Action, "Excepted ListPrice in Order History ::  " +lprice  + " and Actual ListPrice is same::  " +lprice1 , Status.PASS);
}
else

{
Report.updateTestLog(Action, "Excepted ListPrice in Order History ::  " +lprice  + " and Actual ListPrice is  Not Matched ::  " +lprice1 , Status.FAIL);
}

if(cs.contains(contractsavings))

{
Report.updateTestLog(Action, "Excepted contractsavings in Order History ::  " +contractsavings  + " and Actual contractsavings is same::  " +cs , Status.PASS);
}
else

{
Report.updateTestLog(Action, "Excepted contractsavings in Order History ::  " +contractsavings  + " and Actual contractsavings is  Not Matched ::  " +cs , Status.FAIL);
}

if(fet1.contains(fet))

{
Report.updateTestLog(Action, "Excepted Federal Excise Tax in Order Summary  in Order History ::  " +fet  + " and Federal Excise Tax is same::  " +fet1 , Status.PASS);
}
else

{
Report.updateTestLog(Action, "Excepted Federal Excise Tax in Order Summary in Order History ::  " +fet  + " and Federal Excise Tax is Not Matched ::  " +fet1 , Status.FAIL);
}



	
	if(it1.contains(it))	
		
	{
		Report.updateTestLog(Action, "Excepted Item Total in Order History  ::  " +it  + " and Actual Item Total is same::  " +it1 , Status.PASS);
	}
	else
		
	{
		Report.updateTestLog(Action, "Excepted Item Total in Order History  ::  " +it  + " and Actual Item Total is Not Matched ::  " +it1 , Status.FAIL);
	}
								  
     
		
	count++;	
		}catch (Exception e) {
			
			pname=	Driver.findElement(By.xpath("(//div[@class='oi-od-desc']//span[@class='title-xl'])["+i+"]")).getText();
			Ndc=Driver.findElement(By.xpath("(//div[@class='oi-od-desc']//span[contains(text(),'NDC:')]/following-sibling::span)["+i+"]")).getText();
			qty=Driver.findElement(By.xpath("(//div[@class='od-od-tot-pack']//span[contains(text(),'Total Packs:')]/following-sibling::span)["+i+"]")).getText();
			lprice1	=Driver.findElement(By.xpath("(//span[contains(text(),'List:')]/following-sibling::span)["+i+"]")).getText();
			cs=Driver.findElement(By.xpath("(//span[contains(text(),'Contract Savings:')]/following-sibling::span)["+i+"]")).getText();
			fet1=Driver.findElement(By.xpath("(//span[contains(text(),'Federal Excise Tax:')]/following-sibling::span)["+i+"]")).getText();
			it1=Driver.findElement(By.xpath("(//span[contains(text(),'Item Total')]/following-sibling::span)["+i+"]")).getText();
				
			

			
			if(pname.contains(prodname))
				
			{
				Report.updateTestLog(Action, "Excepted Product Name in Order History ::  " +prodname  + " and Actual Product Name is same::  " +pname , Status.PASS);
			}
			else
				
			{
				Report.updateTestLog(Action, "Excepted Product Name in Order History ::  " +prodname  + " and Actual Product Name is  Not Matched ::  " +pname , Status.FAIL);
			}
			
			
			
			if(Ndc.contains(Ndcdetails))
				
		{
			Report.updateTestLog(Action, "Excepted NDC in Order History ::  " +Ndc  + " and Actual NDC is same::  " +Ndcdetails , Status.PASS);
		}
		else
			
		{
			Report.updateTestLog(Action, "Excepted NDC in Order History ::  " +Ndc  + " and Actual NDC is  Not Matched ::  " +Ndcdetails , Status.FAIL);
		}		
			
			
			if(qty.contains(quantity))
				
			{
				Report.updateTestLog(Action, "Excepted Quantity in Order History ::  " +quantity  + " and Actual Quantity is same::  " +qty , Status.PASS);
			}
			else
				
			{
				Report.updateTestLog(Action, "Excepted Quantity in Order History ::  " +quantity  + " and Actual Quantity is Not Matched ::  " +qty , Status.FAIL);
			}		
			
		if(lprice1.contains(lprice))
				
		{
			Report.updateTestLog(Action, "Excepted ListPrice in Order History ::  " +lprice  + " and Actual ListPrice is same::  " +lprice1 , Status.PASS);
		}
		else
			
		{
			Report.updateTestLog(Action, "Excepted ListPrice in Order History ::  " +lprice  + " and Actual ListPrice is  Not Matched ::  " +lprice1 , Status.FAIL);
		}
		
		if(cs.contains(contractsavings))
			
		{
			Report.updateTestLog(Action, "Excepted contractsavings in Order History ::  " +contractsavings  + " and Actual contractsavings is same::  " +cs , Status.PASS);
		}
		else
			
		{
			Report.updateTestLog(Action, "Excepted contractsavings in Order History ::  " +contractsavings  + " and Actual contractsavings is  Not Matched ::  " +cs , Status.FAIL);
		}

		if(fet1.contains(fet))
			
		{
			Report.updateTestLog(Action, "Excepted Federal Excise Tax in Order Summary  in Order History ::  " +fet  + " and Federal Excise Tax is same::  " +fet1 , Status.PASS);
		}
		else
			
		{
			Report.updateTestLog(Action, "Excepted Federal Excise Tax in Order Summary in Order History ::  " +fet  + " and Federal Excise Tax is Not Matched ::  " +fet1 , Status.FAIL);
		}


		
				
				if(it1.contains(it))	
					
				{
					Report.updateTestLog(Action, "Excepted Item Total in Order History  ::  " +it  + " and Actual Item Total is same::  " +it1 , Status.PASS);
				}
				else
					
				{
					Report.updateTestLog(Action, "Excepted Item Total in Order History  ::  " +it  + " and Actual Item Total is Not Matched ::  " +it1 , Status.FAIL);
				}
					
				
				count++;	
		
		}
		
										
				  
				  
				  
				 
							
							
							
			
			
		
		
//	}
	
	
	System.out.println(  "  count ::: "+count);
	
	
	
	
	
}






public void  reservation_items_Oh_Validation(int k) {
	
	int count=0;
	String pname=null,Ndc=null,qty=null,contract1=null,lprice1=null,cs=null,fet1=null,it1=null;
	String prodname=null,Ndcdetails=null,quantity=null,contract=null,lprice=null,contractsavings=null,fet=null,it=null;
	
	List<WebElement> oh=Driver.findElements(By.xpath("//div[contains(@class,'card checkoutProduct')]//div[@class='card-body']/div[@class='row']"));
	Report.updateTestLog(Action, "reservation_items_Oh_Validation  :: Inside  "+oh.size(), Status.PASS);
	for(int i=1;i<=oh.size();i++) {
		//

		  String aa="%prodname"+k+"%";
		  prodname=getVar(aa);
		  Ndcdetails=userData.getData("OrderDetails", "Product"+k);
		quantity=userData.getData("OrderDetails", "qty"+k);
		lprice= userData.getData("OrdersPriceValidation", "ListPrice"+k);
		contractsavings=userData.getData("OrdersPriceValidation", "ContractPrice" + k);
		fet=userData.getData("OrdersPriceValidation", "Total Federal excise tax" + k);
		it=	userData.getData("OrdersPriceValidation", "Price for contract" +k);
		
		Report.updateTestLog(Action, "prodname  ::   "+prodname +"  :: Ndcdetails  ::   "+Ndcdetails +"  :: quantity  ::   "+quantity+"  :: lprice  ::   "+lprice+
				"  :: contractsavings  ::   "+contractsavings+"  :: fet  ::   "+fet+"  :: it  ::   "+it, Status.PASS);	
		
		
		try {
			contract=userData.getData("OrdersPriceValidation", "ContractPrice"+i);
		contract1=Driver.findElement(By.xpath("(//p[contains(text(),'Contract:')]/span)["+i+"]")).getText();
		pname=	Driver.findElement(By.xpath("(//div[contains(@class,'productDesc')]//h4)["+i+"]")).getText();
		Ndc=Driver.findElement(By.xpath("(//div[contains(@class,'productDesc')]//p/span)["+i+"]")).getText();
		qty=Driver.findElement(By.xpath("(//span[contains(text(),'Quantity ')]/../../h4/following-sibling::p)["+i+"]")).getText();
		
		lprice1	=Driver.findElement(By.xpath("(//p[contains(text(),'List:')]/span)["+i+"]")).getText();
		cs=Driver.findElement(By.xpath("(//p[contains(text(),' Contract Savings: ')]/span)["+i+"]")).getText();
		fet1=Driver.findElement(By.xpath("(//p[contains(text(),'Federal Excise Tax')]/span)["+i+"]")).getText();
		it1=Driver.findElement(By.xpath("(//p[contains(text(),'Item Total:')]/span)["+i+"]")).getText();



if(pname.contains(prodname))
	
{
	Report.updateTestLog(Action, "Excepted Product Name in Order History ::  " +prodname  + " and Actual Product Name is same::  " +pname , Status.PASS);
}
else
	
{
	Report.updateTestLog(Action, "Excepted Product Name in Order History ::  " +prodname  + " and Actual Product Name is  Not Matched ::  " +pname , Status.FAIL);
}



if(Ndc.contains(Ndcdetails))
	
{
Report.updateTestLog(Action, "Excepted NDC in Order History ::  " +Ndc  + " and Actual NDC is same::  " +Ndcdetails , Status.PASS);
}
else

{
Report.updateTestLog(Action, "Excepted NDC in Order History ::  " +Ndc  + " and Actual NDC is  Not Matched ::  " +Ndcdetails , Status.FAIL);
}		


if(qty.contains(quantity))
	
{
	Report.updateTestLog(Action, "Excepted Quantity in Order History ::  " +quantity  + " and Actual Quantity is same::  " +qty , Status.PASS);
}
else
	
{
	Report.updateTestLog(Action, "Excepted Quantity in Order History ::  " +quantity  + " and Actual Quantity is Not Matched ::  " +qty , Status.FAIL);
}		

if(contract1.contains(contract))

{
Report.updateTestLog(Action, "Excepted Contract Savings in Order Summary in Order History ::  " +contract  + " and Actual Contract Savings is same::  " +contract1 , Status.PASS);
}
else

{
Report.updateTestLog(Action, "Excepted Contract Savings  in Order Summary in Order History ::  " +contract  + " and Actual Contract Savings is  Not Matched ::  " +contract1 , Status.FAIL);
}


if(lprice1.contains(lprice))
	
{
Report.updateTestLog(Action, "Excepted ListPrice in Order History ::  " +lprice  + " and Actual ListPrice is same::  " +lprice1 , Status.PASS);
}
else

{
Report.updateTestLog(Action, "Excepted ListPrice in Order History ::  " +lprice  + " and Actual ListPrice is  Not Matched ::  " +lprice1 , Status.FAIL);
}

if(cs.contains(contractsavings))

{
Report.updateTestLog(Action, "Excepted contractsavings in Order History ::  " +contractsavings  + " and Actual contractsavings is same::  " +cs , Status.PASS);
}
else

{
Report.updateTestLog(Action, "Excepted contractsavings in Order History ::  " +contractsavings  + " and Actual contractsavings is  Not Matched ::  " +cs , Status.FAIL);
}

if(fet1.contains(fet))

{
Report.updateTestLog(Action, "Excepted Federal Excise Tax in Order Summary  in Order History ::  " +fet  + " and Federal Excise Tax is same::  " +fet1 , Status.PASS);
}
else

{
Report.updateTestLog(Action, "Excepted Federal Excise Tax in Order Summary in Order History ::  " +fet  + " and Federal Excise Tax is Not Matched ::  " +fet1 , Status.FAIL);
}



	
	if(it1.contains(it))	
		
	{
		Report.updateTestLog(Action, "Excepted Item Total in Order History  ::  " +it  + " and Actual Item Total is same::  " +it1 , Status.PASS);
	}
	else
		
	{
		Report.updateTestLog(Action, "Excepted Item Total in Order History  ::  " +it  + " and Actual Item Total is Not Matched ::  " +it1 , Status.FAIL);
	}
								  
     
		
	count++;	
		}catch (Exception e) {
			
			
			pname=	Driver.findElement(By.xpath("(//div[contains(@class,'productDesc')]//h4)["+i+"]")).getText();
			Ndc=Driver.findElement(By.xpath("(//div[contains(@class,'productDesc')]//p/span)["+i+"]")).getText();
			qty=Driver.findElement(By.xpath("(//span[contains(text(),'Quantity ')]/../../h4/following-sibling::p)["+i+"]")).getText();
			lprice1	=Driver.findElement(By.xpath("(//p[contains(text(),'List:')]/span)["+i+"]")).getText();
			cs=Driver.findElement(By.xpath("(//p[contains(text(),' Contract Savings: ')]/span)["+i+"]")).getText();
			fet1=Driver.findElement(By.xpath("(//p[contains(text(),'Federal Excise Tax')]/span)["+i+"]")).getText();
			it1=Driver.findElement(By.xpath("(//p[contains(text(),'Item Total:')]/span)["+i+"]")).getText();

			

			
			if(pname.contains(prodname))
				
			{
				Report.updateTestLog(Action, "Excepted Product Name in Order History ::  " +prodname  + " and Actual Product Name is same::  " +pname , Status.PASS);
			}
			else
				
			{
				Report.updateTestLog(Action, "Excepted Product Name in Order History ::  " +prodname  + " and Actual Product Name is  Not Matched ::  " +pname , Status.FAIL);
			}
			
			
			
			if(Ndc.contains(Ndcdetails))
				
		{
			Report.updateTestLog(Action, "Excepted NDC in Order History ::  " +Ndc  + " and Actual NDC is same::  " +Ndcdetails , Status.PASS);
		}
		else
			
		{
			Report.updateTestLog(Action, "Excepted NDC in Order History ::  " +Ndc  + " and Actual NDC is  Not Matched ::  " +Ndcdetails , Status.FAIL);
		}		
			
			
			if(qty.contains(quantity))
				
			{
				Report.updateTestLog(Action, "Excepted Quantity in Order History ::  " +quantity  + " and Actual Quantity is same::  " +qty , Status.PASS);
			}
			else
				
			{
				Report.updateTestLog(Action, "Excepted Quantity in Order History ::  " +quantity  + " and Actual Quantity is Not Matched ::  " +qty , Status.FAIL);
			}		
			
		if(lprice1.contains(lprice))
				
		{
			Report.updateTestLog(Action, "Excepted ListPrice in Order History ::  " +lprice  + " and Actual ListPrice is same::  " +lprice1 , Status.PASS);
		}
		else
			
		{
			Report.updateTestLog(Action, "Excepted ListPrice in Order History ::  " +lprice  + " and Actual ListPrice is  Not Matched ::  " +lprice1 , Status.FAIL);
		}
		
		if(cs.contains(contractsavings))
			
		{
			Report.updateTestLog(Action, "Excepted contractsavings in Order History ::  " +contractsavings  + " and Actual contractsavings is same::  " +cs , Status.PASS);
		}
		else
			
		{
			Report.updateTestLog(Action, "Excepted contractsavings in Order History ::  " +contractsavings  + " and Actual contractsavings is  Not Matched ::  " +cs , Status.FAIL);
		}

		if(fet1.contains(fet))
			
		{
			Report.updateTestLog(Action, "Excepted Federal Excise Tax in Order Summary  in Order History ::  " +fet  + " and Federal Excise Tax is same::  " +fet1 , Status.PASS);
		}
		else
			
		{
			Report.updateTestLog(Action, "Excepted Federal Excise Tax in Order Summary in Order History ::  " +fet  + " and Federal Excise Tax is Not Matched ::  " +fet1 , Status.FAIL);
		}


		
				
				if(it1.contains(it))	
					
				{
					Report.updateTestLog(Action, "Excepted Item Total in Order History  ::  " +it  + " and Actual Item Total is same::  " +it1 , Status.PASS);
				}
				else
					
				{
					Report.updateTestLog(Action, "Excepted Item Total in Order History  ::  " +it  + " and Actual Item Total is Not Matched ::  " +it1 , Status.FAIL);
				}
					
				
				count++;	
		
		}
		
										
				  
			
			
		
		
	}
	
	
	System.out.println(  "  count ::: "+count);
	
	
	
	
	
}




@Action(object = ObjectType.BROWSER, desc = "Validatating Payment details   ", input = InputType.NO)

public void  Validating_Paymenttype_orderpaage(int i) {
	spinnerLoad();
	String paymenttype=null;
	JavascriptExecutor js = (JavascriptExecutor) Driver;
	WebDriverWait wait = new WebDriverWait(Driver, 10);

	
System.out.println(" i::    "+i );

String ptype=userData.getData("OrderDetails", "PaymentType"+i);
String [] split=ptype.split(",");

payment = split[0];



if (payment.equalsIgnoreCase("Invoice me")) {
	
	try {
	String xpath = "(//*[contains(text(),'Payment Details:')]/../h5/following-sibling::strong)["+i+"]";
	// Wait until an element with id="foo" is present on the page
		WebElement element = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpath)));
System.out.println(i+"payemt type ::  try  "+paymenttype);


paymenttype=Driver.findElement(By.xpath("(//*[contains(text(),'Payment Details:')]/../h5/following-sibling::p)")).getText().trim();
System.out.println(i+"payemt type ::  try  "+paymenttype);
if(paymenttype.equalsIgnoreCase("Invoice Me"))
{
	Report.updateTestLog(Action, "  Invoice me Details avavilable ", Status.PASS);
	
}
else
{
	Report.updateTestLog(Action, "  Invoice me Details not avavilable ", Status.FAIL);
	
}




}catch (Exception e) {
	System.out.println("payemt type ::  catch   "+paymenttype);
try {

	try {
paymenttype=Driver.findElement(By.xpath("(//*[contains(text(),'Payment Details')]/../div//input/following-sibling::label)["+i+"]")).getText().trim();
System.out.println("paymenttype   5216 :: "+paymenttype);
	}catch (Exception e1) {
		
		try {
		paymenttype=Driver.findElement(By.xpath("(//*[contains(text(),'Payment Details:')]/../h5/following-sibling::p)["+i+"]")).getText().trim();	
		System.out.println("paymenttype   5220 :: "+paymenttype);
		}catch (Exception e3) {
			paymenttype=Driver.findElement(By.xpath("(//*[contains(text(),'Payment Details:')]/../h5/following-sibling::strong)["+i+"]")).getText().trim();
//			paymenttype=Driver.findElement(By.xpath("(//*[contains(text(),'Payment Details:')]/../h5/following-sibling::p)")).getText().trim();
			System.out.println("paymenttype   5224 :: "+paymenttype);
		}
	}

//String xpath = "(//*[contains(text(),'Payment Details:')]/../h5/following-sibling::p)["+i+"]";
//paymenttype = (String) js.executeScript("return document.evaluate(arguments[0], document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.textContent", xpath);


System.out.println(i+"payemt type ::  try  "+paymenttype);
if(paymenttype.equalsIgnoreCase("Invoice Me"))
{
	Report.updateTestLog(Action, "  Invoice me Details avavilable ", Status.PASS);
	
}
else
{
	Report.updateTestLog(Action, "  Invoice me Details not avavilable ", Status.FAIL);
	
}
}catch (Exception e1) {
	
	
	
	
	Report.updateTestLog(Action, "  Invoice me Element not found "+e1, Status.FAIL);	
	
	
	
}


}

}
try {

if (payment.equalsIgnoreCase("Credit card")) {
System.out.println("    Inside Credit Card  ");
	
	String details=null;
	
	try {
		System.out.println("    Inside try 1 5267 Card  ");
paymenttype=Driver.findElement(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(i-1)+"0')])/..//img/following-sibling::span")).getText();
details=Driver.findElement(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(i-1)+"0')])/..//strong")).getText();

System.out.println("  paymenttype   Inside try 1 5046 Card     "  +paymenttype );
	}catch (Exception e1) {
		
		try {
			System.out.println("    Inside try2 5275 Card  ");
		paymenttype=Driver.findElement(By.xpath("(//*[contains(text(),'Payment Details:')]/../div)["+i+"]")).getText();
		details=Driver.findElement(By.xpath("(//*[contains(text(),'Payment Details:')]/../h5/following-sibling::strong)["+i+"]")).getText();
		System.out.println(details  +"   ::  paymenttype   Inside try 2 5046 Card     "  +paymenttype );
		
	}catch (Exception e) {
		
		try {
			
			System.out.println("    Inside try3 5284 Card  ");
			paymenttype=Driver.findElement(By.xpath("(//*[contains(text(),'Payment Details:')]/../div)")).getText();
			details=Driver.findElement(By.xpath("(//*[contains(text(),'Payment Details:')]/../h5/following-sibling::strong)")).getText();
			System.out.println(details  +"   ::  paymenttype   Inside try 2 5046 Card     "  +paymenttype );
		}catch (Exception e2) {
			Report.updateTestLog(Action, "  Credit card payment paymenttype not found "+e2, Status.DONE);	
			
		}
			
		
	}
		
	}
String CardDetails=userData.getData("OrderDetails", "CardDetails"+i);

//Report.updateTestLog(Action, "Credit card is selected  and "+paymenttype  + "  with  "+ details + "  Option  "+ CardDetails , Status.DONE);
System.out.println("CardDetails     "+CardDetails); 	


if((details.equalsIgnoreCase("Pay At Invoice Due Date")) &&   (paymenttype.contains(CardDetails)) )
{
	Report.updateTestLog(Action, "Credit card is selected  and "+paymenttype  + "  with  "+ details + "  Option  " , Status.PASS);
	
} else if((details.equalsIgnoreCase("Pay Now")) &&   (paymenttype.contains(CardDetails)) )
{
	Report.updateTestLog(Action, "Credit card is selected  and "+paymenttype  + "  with  "+ details + "  Option  " , Status.PASS);
	
}
else
{
	Report.updateTestLog(Action, "Credit card Details In Correct  "+paymenttype  +"  ::  "+details, Status.FAIL);
	
}
		


}


}catch (Exception e) {

Report.updateTestLog(Action, "  Credit card Issue "+e, Status.FAIL);
}




}






@Action(object = ObjectType.BROWSER, desc = "Enter ProductCount,CartCount,ProductPerCart,ShipTo-BillTo [<Data>]", input = InputType.NO)
public void shippingcartPageValidation_complexCart()

{
	int pn1=0,pn2=0;
	String pname=null, product=null,qty=null;
	JavascriptExecutor js = (JavascriptExecutor) Driver;
	Double cprice=null,lprice=null,cs=null,fet=null,ItemTotal=null;
	Double listprice=0.00,contractprice=0.00,ContractSaving=0.00,Fetdata=0.00,EST=0.00,ContractSaving_perpack=0.00, It1=0.00;
	Double ContractSaving_OS=0.00, subtotal_OS=0.00,Fet_OS=0.00, EST_OS=0.00,total_OS=0.00;	
	String Productname=null,NDC=null,quantity=null,contract=null;
	
	spinnerLoad();
//	pagereadycheck();
	try {
		
		List<WebElement> buttons = Driver.findElements(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-')])"));
		int btn=buttons.size();
		Report.updateTestLog(Action, "Expanded Page :: "+btn , Status.DONE);
		
		for (int k = 1; k <= buttons.size();k++) {
			
			
			WebElement div = Driver.findElement(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-')])["+k+"]/../../div/div[@class='collapse show']"));
	// Get the value of the attribute "class"
            String divClass = div.getAttribute("class");

            // Check if the value contains "collapse show"
            if (divClass.contains("collapse show")) {
                // Print a message
                System.out.println("The div element is expanded");
                
//                Report.updateTestLog(Action, "Expanded Page displayed " , Status.PASS);
                try
                {
               	 
                	try {
                		Thread.sleep(5000);//
//                		Driver.findElement(By.xpath("(//input[contains(@value,'Invoice Me')])[1]")).click();
               	payBy_Selection(k);	 
               	Report.updateTestLog(Action, " payBy_Selection  :: 5000 try  "  , Status.DONE);
               	
               	
                	}catch(Exception e1)
                	{
                	 	Report.updateTestLog(Action, " payBy_Selection  :: catch  5003 "+e1  , Status.DONE);
                		  Validating_Paymenttype_orderpaage(k) ;
                	//	
                	}
               	try {
               		List<WebElement> products = Driver.findElements(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-')])["+k+"]/..//a[@class='productName']"));
               		System.out.println();
               		
               		
               		for (int h=1;h<=products.size();h++) {////
               			
               			
//               			System.out.println("pn2=pn2+h   :: "+pn2);
               	if(buttons.size()<=1) {
//               		Report.updateTestLog(Action, " inside  buttons.size()<=1   is ::  " +buttons.size()  , Status.DONE);
               			 product= (userData.getData("OrderDetails", "Product" + h));
               			System.out.println("Product ::  "+product);
               			 qty=(userData.getData("OrderDetails", "qty" + h));
               			System.out.println("qty ::  "+qty);
               			 listprice=Double.parseDouble((userData.getData("OrdersPriceValidation", "ListPrice" + h)));
               			System.out.println("listprice ::  "+listprice);
               			 contractprice=Double.parseDouble((userData.getData("OrdersPriceValidation", "ContractPrice" + h)));
               			System.out.println("contractprice ::  "+contractprice);
               			 ContractSaving=Double.parseDouble((userData.getData("OrdersPriceValidation", "Savings with promotion" + h)));
               			System.out.println("ContractSaving ::  "+ContractSaving);
               			 Fetdata=Double.parseDouble((userData.getData("OrdersPriceValidation", "Total Federal excise tax" + h)));
               			System.out.println("Fetdata :: 4950  "+Fetdata);
               			addVar("%feaa%",Double.toString(Fetdata));
               			 EST=Double.parseDouble((userData.getData("OrdersPriceValidation", "Total Estimated sales tax" + h)));
               			 ContractSaving_perpack=Double.parseDouble((userData.getData("OrdersPriceValidation", "Savings with promotion" + h)));
               			
               			try {
               			 It1=Double.parseDouble((userData.getData("OrdersPriceValidation", "Price for contract" +h)));
               			
               			} catch (Exception e) {
               		       
               				try {
               				It1=convertStringToDouble(userData.getData("OrdersPriceValidation", "Price for contract" +h));	
               				
               				} catch (Exception e1) {
               					
               					System.out.println(e1);
               					
               					
               					
               				}
               		    }
               			try {
               				String pn = "%prodname" + h + "%";
               				Productname=getVar(pn);
               				}
               				catch (Exception e) {
               					 System.out.println("catch    Productname  :: "); 
               					
               				}
               			
               			

               			System.out.println("It1 ::  "+It1);
               			Double subtot=convertStringToDouble(userData.getData("OrdersPriceValidation", "Subtotal before savings" +h));
               			System.out.println("subtot ::  "+subtot);	
               			
               			System.out.println( " ContractSaving_OS  :"+ContractSaving);
               			ContractSaving_OS=get2DecimalDoubleValue(ContractSaving_OS+ContractSaving);
               			System.out.println(ContractSaving_OS+ " ContractSaving_OS  :"+ContractSaving);
               			
               			subtotal_OS=get2DecimalDoubleValue(subtotal_OS+subtot);
               			Fet_OS=Fet_OS+Fetdata;
               			EST_OS=EST_OS+EST;
               			total_OS=total_OS+It1;
               			System.out.println(subtotal_OS  +" ::   Fet_OS ::  "+Fet_OS+" ::   EST_OS :: "+EST_OS+" ::   total_OS  ::  "+total_OS);
               			
//               			Report.updateTestLog(Action, subtotal_OS  +" ::   Fet_OS ::  "+Fet_OS+" ::   EST_OS :: "+EST_OS+" ::   total_OS  ::  "+total_OS , Status.DONE);
               			
               			
               	}


               	//Report.updateTestLog(Action, k+ "  buttons.size() is  (buttons.size()>1) ::  " +buttons.size()+" h:: " +h , Status.DONE);
               	else if(buttons.size()>1) 
               	{
//               			Report.updateTestLog(Action, " inside    is ::  " +buttons.size()  +"  pn2=pn2+h   :: "+pn2 , Status.DONE);
//               		Driver.navigate().refresh();
//               		Driver.findElement(By.xpath("//button[@data-target='#collapse-00']")).click();
               		
               		
               		wait.until(	ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[contains(@class,'spinner-wrapper')]")));
               		 product= (userData.getData("OrderDetails", "Product" +k ));
               		System.out.println("Product ::  "+product);
               		 qty=(userData.getData("OrderDetails", "qty" + k));
               		System.out.println("qty ::  "+qty);
               		 listprice=Double.parseDouble((userData.getData("OrdersPriceValidation", "ListPrice" + k)));
               		System.out.println("listprice ::  "+listprice);
               		 contractprice=Double.parseDouble((userData.getData("OrdersPriceValidation", "ContractPrice" + k)));
               		System.out.println("contractprice ::  "+contractprice);
               		 ContractSaving=Double.parseDouble((userData.getData("OrdersPriceValidation", "Savings with promotion" + k)));
               		System.out.println("ContractSaving ::  "+ContractSaving);
               		 Fetdata=Double.parseDouble((userData.getData("OrdersPriceValidation", "Total Federal excise tax" + k)));
               		System.out.println("Fetdata :: 5019 "+Fetdata);
               		 EST=Double.parseDouble((userData.getData("OrdersPriceValidation", "Total Estimated sales tax" + k)));
               		 ContractSaving_perpack=Double.parseDouble((userData.getData("OrdersPriceValidation", "Savings with promotion" + k)));
               		 addVar("%feaa%",Double.toString(Fetdata));
               		try {
               		 It1=Double.parseDouble((userData.getData("OrdersPriceValidation", "Price for contract" +k)));
               		
               		} catch (Exception e) {
               	      
               			try {
               			It1=convertStringToDouble(userData.getData("OrdersPriceValidation", "Price for contract" +k));	
               			
               			} catch (Exception e1) {
               				
               				System.out.println(e1);
               				
               				
               				
               			}
               			
               			
               	   }
               		
               		try {
               			String pn = "%prodname" + k + "%";
               			
               			Productname=getVar(pn);
               			}
               			catch (Exception e) {
               				 System.out.println("catch    Productname  :: "); 
               				
               			}
               		
               		
               		
               		System.out.println("It1 ::  "+It1);
               		Double subtot=convertStringToDouble(userData.getData("OrdersPriceValidation", "Subtotal before savings" +k));
               		System.out.println("subtot ::   "+k  + "  ::  "+subtot);	
               		Report.updateTestLog(Action, "subtot ::   "+k  + "  ::  "+subtot   , Status.DONE);
               		System.out.println( " ContractSaving_OS  :"+ContractSaving);
               		ContractSaving_OS=get2DecimalDoubleValue(ContractSaving_OS+ContractSaving);
               		System.out.println(ContractSaving_OS+ " ContractSaving_OS  :"+ContractSaving);
               		
               		subtotal_OS=get2DecimalDoubleValue(subtotal_OS+subtot);
               		Fet_OS=Fet_OS+Fetdata;
               		EST_OS=EST_OS+EST;
               		total_OS=total_OS+It1;
//               		System.out.println(subtotal_OS  +" ::   Fet_OS ::  "+Fet_OS+" ::   EST_OS :: "+EST_OS+" ::   total_OS  ::  "+total_OS);
               		
//               		Report.updateTestLog(Action, subtotal_OS  +" ::   Fet_OS ::  "+Fet_OS+" ::   EST_OS :: "+EST_OS+" ::   total_OS  ::  "+total_OS , Status.DONE);
               		

               		
               	}
               		
               		

//               	Driver.findElement(By.xpath("//button[@data-target='#collapse-00']")).click();
           		
               		
               		try {
               			
               			
               			lprice=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//p[@class='listPrice']//span)["+h+"]")).getText());
                   		System.out.println("lprice ::  "+lprice);		
               		pname	= Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//a[@class='productName'])["+h+"]")).getText();
//               		NDC=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//a[@class='productName']/../../div/p/span)["+h+"]")).getText();
               		NDC=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//a[@class='productName']//following-sibling::p//span)["+h+"]")).getText();
               		
//               		quantity=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//*[@class='productQtyBoxWrap']//input)["+h+"]")).getText();
               		
               		
               		cprice=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//p[@class='contractPrice']//span)["+h+"]")).getText());
               		System.out.println("cprice ::  "+cprice);	
               		
               		
               		cs=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//p[contains(@class,'contractSaving')]//span)["+h+"]")).getText());
               		System.out.println("cs ::  "+cs);	
               		fet=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//p[@class='fedtax']//span)["+h+"]")).getText());
               		System.out.println("fet ::  "+fet);	
               		
               		ItemTotal=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//p[@class='itemTotal']//span)["+h+"]")).getText());
               		
               		System.out.println("ItemTotal ::  "+ItemTotal);	
               		
               		

               	String qtyy=null;
               		try{
               			qtyy=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//*[@class='productQtyBoxWrap']//label[@class='packqty text-center'])["+h+"]")).getText();
               		
               		}
               		catch (Exception e) {
               			 System.out.println("catch    qtyy  :: "); 
               			 qtyy=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//div[contains(@class,'productQtyInfo')]//p)["+h+"]")).getText();
               				
               			
               		}
               		String[] split = qtyy.split("=");

               		// get the first value from the array and trim any whitespace
               		split = split[0].split("Packs");
               		
               		quantity=split[0].trim();
               		 
               		 System.out.println( "k :: "+ k+  "quantity    1073  :: "+quantity+ "   :: h  :: "+ h); 
               		if(pname.equalsIgnoreCase(Productname))
               			
               		{
               			Report.updateTestLog(Action, "Excepted Productname is ::  " +Productname  + " and Actual Productname is same::  " +pname , Status.PASS);
               		}
               		else
               			
               		{
               			Report.updateTestLog(Action, "Excepted Productname is ::  " +Productname  + " and Actual Productname is  Not Matched ::  " +pname , Status.FAIL);
               		}
               		
               		
               		
               	if(NDC.equalsIgnoreCase(product))
               			
               		{
               			Report.updateTestLog(Action, "Excepted Productname is ::  " +product  + " and Actual Productname is same::  " +NDC , Status.PASS);
               		}
               		else
               			
               		{
               			Report.updateTestLog(Action, "Excepted Productname is ::  " +product  + " and Actual Productname is  Not Matched ::  " +NDC , Status.FAIL);
               		}


               	if(qty.equalsIgnoreCase(quantity))
               		
               	{
               		Report.updateTestLog(Action, "Excepted quantity is ::  " +qty  + " and Actual quantity is same::  " +quantity , Status.PASS);
               	}
               	else
               		
               	{
               		Report.updateTestLog(Action, "Excepted quantity is ::  " +qty  + " and Actual quantity is  Not Matched ::  " +quantity , Status.FAIL);
               	}



               		
               		if(cprice.equals(contractprice))	
               			
               		{
               			Report.updateTestLog(Action, "Excepted Contract price is ::  " +contractprice  + " and Actual Contract price is same::  " +cprice , Status.PASS);
               		}
               		else
               			
               		{
               			Report.updateTestLog(Action, "Excepted Contract price is ::  " +contractprice  + " and Actual Contract price is  Not Matched ::  " +cprice , Status.FAIL);
               		}
               			
               			
               			if(lprice.equals(listprice))	
               				
               			{
               				Report.updateTestLog(Action, "Excepted listprice is ::  " +listprice  + " and Actual listprice is same::  " +lprice , Status.PASS);
               			}
               			else
               				
               			{
               				Report.updateTestLog(Action, "Excepted listprice is ::  " +listprice  + " and Actual listprice is  Not Matched ::  " +lprice , Status.FAIL);
               			}
               			
               		if(cs.equals(ContractSaving_perpack))	
               				
               			{
               				Report.updateTestLog(Action, "Excepted ContractSaving is ::  " +ContractSaving_perpack  + " and Actual ContractSaving is same::  " +cs , Status.PASS);
               			}
               			else
               				
               			{
               				Report.updateTestLog(Action, "Excepted ContractSaving is ::  " +ContractSaving_perpack  + " and Actual ContractSaving  is  Not Matched ::  " +cs , Status.FAIL);
               			}

               		if(fet.equals(Fetdata))	
               			
               		{
               			Report.updateTestLog(Action, "Excepted Federal Excise Tax is ::  " +Fetdata  + " and Actual Federal Excise Tax is same::  " +fet , Status.PASS);
               		}
               		else
               			
               		{
               			Report.updateTestLog(Action, "Excepted Federal Excise Tax is ::  " +Fetdata  + " and Actual Federal Excise Tax is  Not Matched ::  " +fet , Status.FAIL);
               		}

               		if(ItemTotal.equals(It1))	
               			
               		{
               			Report.updateTestLog(Action, "Excepted Item Total is ::  " +ItemTotal  + " and Actual Item Total is same::  " +It1 , Status.PASS);
               		}
               		else
               			
               		{
               			Report.updateTestLog(Action, "Excepted Item Total is ::  " +ItemTotal  + " and Actual Item Total  is  Not Matched ::  " +It1 , Status.FAIL);
               		}

               		
               		
//               		pn2=pn2+1;	
               	//	
//               		Report.updateTestLog(Action, "pn2=pn2+1;  1239 try  ::  " +pn2  , Status.DONE);
               		}
               	catch (Exception e) {
               		
               		
               	        
               		Report.updateTestLog(Action, "Excepted listprice is :: 1245   catch"  , Status.DONE);
               		
               		
               		Driver.navigate().refresh();
               		wait.until(	ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[contains(@class,'spinner-wrapper')]")));
               		
               		
               		pname	= Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//a[@class='productName'])["+h+"]")).getText();
               		NDC=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//a[@class='productName']//following-sibling::p//span)["+h+"]")).getText();
               		
               		
               		lprice=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//p[@class='contractPrice']//span)["+h+"]")).getText());
               		System.out.println("lprice ::  "+lprice);	
               		
               		cs=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//p[contains(@class,'contractSaving')]//span)["+h+"]")).getText());
               		System.out.println("cs ::  "+cs);	
               		fet=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//p[@class='fedtax']//span)["+h+"]")).getText());
               		System.out.println("fet ::  "+fet);	
               		
               		ItemTotal=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//p[@class='itemTotal']//span)["+h+"]")).getText());
               		
               		System.out.println("ItemTotal ::  "+ItemTotal);	
//               		try {
//               		String pn = "%prodname" + k + "%";
//               		Productname=getVar(pn);
//               		}
//               		catch (Exception e1) {
//               			 System.out.println("catch    Productname  :: "); 
//               			
//               		}
               		
               	String qtyy=null;
               		try{
               			qtyy=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//*[@class='productQtyBoxWrap']//label[@class='packqty text-center'])["+h+"]")).getText();
               		
               		}
               		catch (Exception e1) {
               			 System.out.println("catch    qtyy  :: "); 
               			 qtyy=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//div[contains(@class,'productQtyInfo')]//p)["+h+"]")).getText();
               				
               			
               		}
               		String[] split = qtyy.split("=");

               		// get the first value from the array and trim any whitespace
               		split = split[0].split("Packs");
               		
               		quantity=split[0].trim();
               		 
               		 System.out.println( "k :: "+ k+  "quantity  catch   1228  :: "+quantity+ "   :: h  :: "+ h); 
               		if(pname.equalsIgnoreCase(Productname))
               			
               		{
               			Report.updateTestLog(Action, "Excepted Productname is ::  " +Productname  + " and Actual Productname is same::  " +pname , Status.PASS);
               		}
               		else
               			
               		{
               			Report.updateTestLog(Action, "Excepted Productname is ::  " +Productname  + " and Actual Productname is  Not Matched ::  " +pname , Status.FAIL);
               		}
               		
               		
               		
               	if(NDC.equalsIgnoreCase(product))
               			
               		{
               			Report.updateTestLog(Action, "Excepted Productname is ::  " +product  + " and Actual Productname is same::  " +NDC , Status.PASS);
               		}
               		else
               			
               		{
               			Report.updateTestLog(Action, "Excepted Productname is ::  " +product  + " and Actual Productname is  Not Matched ::  " +NDC , Status.FAIL);
               		}


               	if(qty.equalsIgnoreCase(quantity))
               		
               	{
               		Report.updateTestLog(Action, "Excepted quantity is ::  " +qty  + " and Actual quantity is same::  " +quantity , Status.PASS);
               	}
               	else
               		
               	{
               		Report.updateTestLog(Action, "Excepted quantity is ::  " +qty  + " and Actual quantity is  Not Matched ::  " +quantity , Status.FAIL);
               	}



               		
               			
               			
               			if(lprice.equals(listprice))	
               				
               			{
               				Report.updateTestLog(Action, "Excepted listprice is ::  " +listprice  + " and Actual listprice is same::  " +lprice , Status.PASS);
               			}
               			else
               				
               			{
               				Report.updateTestLog(Action, "Excepted listprice is ::  " +listprice  + " and Actual listprice is  Not Matched ::  " +lprice , Status.FAIL);
               			}
               			
               		if(cs.equals(ContractSaving_perpack))	
               				
               			{
               				Report.updateTestLog(Action, "Excepted ContractSaving is ::  " +ContractSaving_perpack  + " and Actual ContractSaving is same::  " +cs , Status.PASS);
               			}
               			else
               				
               			{
               				Report.updateTestLog(Action, "Excepted ContractSaving is ::  " +ContractSaving_perpack  + " and Actual ContractSaving  is  Not Matched ::  " +cs , Status.FAIL);
               			}
               	if(fet.equals(Fetdata))	
               			
               		{
               			Report.updateTestLog(Action, "Excepted Federal Excise Tax is ::  " +Fetdata  + " and Actual Federal Excise Tax is same::  " +fet , Status.PASS);
               		}
               		else
               			
               		{
               			Report.updateTestLog(Action, "Excepted Federal Excise Tax is ::  " +Fetdata  + " and Actual Federal Excise Tax is  Not Matched ::  " +fet , Status.FAIL);
               		}

               		if(ItemTotal.equals(It1))	
               			
               		{
               			Report.updateTestLog(Action, "Excepted Item Total is ::  " +ItemTotal  + " and Actual Item Total is same::  " +It1 , Status.PASS);
               		}
               		else
               			
               		{
               			Report.updateTestLog(Action, "Excepted Item Total is ::  " +ItemTotal  + " and Actual Item Total  is  Not Matched ::  " +It1 , Status.FAIL);
               		}
               		
               		
//               		pn2=pn2+1;	
               		Report.updateTestLog(Action, "pn2=pn2+1;  1384 catch  ::  " +pn2  , Status.DONE);
               			
               		
               	}
               		
               		
               		
               		
               		
               		
               		
               		}
               		
               	addVar("%ContractSaving_OS%",Double.toString(ContractSaving_OS));	
               	addVar("%subtotal_OS%",Double.toString(subtotal_OS));
               	addVar("%Fet_OS%",Double.toString(Fet_OS));
               	addVar("%EST_OS%",Double.toString(EST_OS));
               	addVar("%total_OS%",Double.toString(total_OS));
               		
               			}catch (Exception e) {
               	        // Catch any exception and print the error message
               	        System.out.println("An error occurred: " + e.getMessage());
               	    }
               	
                
                }catch (Exception e) {
                    // Catch any exception and print the error message
                    System.out.println("An error occurred: " + e.getMessage());
                }
                
                
            }
			
			
			
			
			
		}
		
		 ordersummary_validation();
		 
		
		
	} catch (Exception e) {
        // Catch any exception and print the error message
        System.out.println("An error occurred: " + e.getMessage());
    }
	
	
}






@Action(object = ObjectType.BROWSER, desc = "Enter ProductCount,CartCount,ProductPerCart,ShipTo-BillTo [<Data>]", input = InputType.NO)
public void orderCompletedValidation_complexCart()

{
	int pn1=0,pn2=0;
	String pname=null, product=null,qty=null;
	JavascriptExecutor js = (JavascriptExecutor) Driver;
	Double cprice=null,lprice=null,cs=null,fet=null,ItemTotal=null;
	Double listprice=0.00,contractprice=0.00,ContractSaving=0.00,Fetdata=0.00,EST=0.00,ContractSaving_perpack=0.00, It1=0.00;
	Double ContractSaving_OS=0.00, subtotal_OS=0.00,Fet_OS=0.00, EST_OS=0.00,total_OS=0.00;	
	String Productname=null,NDC=null,quantity=null,contract=null;
	
	try {
		
		List<WebElement> buttons = Driver.findElements(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-')])"));
		int btn=buttons.size();
		orderConfirmation();
       
		for (int k = 1; k <= buttons.size();k++) {
			
			
			WebElement div = Driver.findElement(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-')])["+k+"]/../../div/div[@class='collapse show']"));
	// Get the value of the attribute "class"
            String divClass = div.getAttribute("class");

            // Check if the value contains "collapse show"
            if (divClass.contains("collapse show")) {
                // Print a message
                System.out.println("The div element is expanded");
                
                Report.updateTestLog(Action, "Expanded Page displayed " , Status.PASS);
                try
                {
               	 
                	
                	
                		  Validating_Paymenttype_orderpaage(k) ;
                		
                	
               	try {
               		List<WebElement> products = Driver.findElements(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-')])["+k+"]/..//a[@class='productName']"));
               		System.out.println();
               		//
               		for (int h=1;h<=products.size();h++) {////
               			pn2=pn2+h;
               			
               			System.out.println("pn2=pn2+h   :: "+pn2);
               	if(buttons.size()<=1) {
//               		Report.updateTestLog(Action, " inside  buttons.size()<=1   is ::  " +buttons.size()  , Status.DONE);
               			 product= (userData.getData("OrderDetails", "Product" + h));
               			System.out.println("Product ::  "+product);
               			 qty=(userData.getData("OrderDetails", "qty" + h));
               			System.out.println("qty ::  "+qty);
               			 listprice=Double.parseDouble((userData.getData("OrdersPriceValidation", "ListPrice" + h)));
               			System.out.println("listprice ::  "+listprice);
               			 contractprice=Double.parseDouble((userData.getData("OrdersPriceValidation", "ContractPrice" + h)));
               			System.out.println("contractprice ::  "+contractprice);
               			 ContractSaving=Double.parseDouble((userData.getData("OrdersPriceValidation", "Savings with promotion" + h)));
               			System.out.println("ContractSaving ::  "+ContractSaving);
               			 Fetdata=Double.parseDouble((userData.getData("OrdersPriceValidation", "Total Federal excise tax" + h)));
               			System.out.println("Fetdata ::  "+Fetdata);
               			 EST=Double.parseDouble((userData.getData("OrdersPriceValidation", "Total Estimated sales tax" + h)));
               			 ContractSaving_perpack=Double.parseDouble((userData.getData("OrdersPriceValidation", "Savings with promotion" + h)));
               			
               			try {
               			 It1=Double.parseDouble((userData.getData("OrdersPriceValidation", "Price for contract" +h)));
               			
               			} catch (Exception e) {
               		       
               				try {
               				It1=convertStringToDouble(userData.getData("OrdersPriceValidation", "Price for contract" +h));	
               				
               				} catch (Exception e1) {
               					
               					System.out.println(e1);
               					
               					
               					
               				}
               		    }
               			try {
               				String pn = "%prodname" + h + "%";
               				Productname=getVar(pn);
               				}
               				catch (Exception e) {
               					 System.out.println("catch    Productname  :: "); 
               					
               				}
               			
               			

               			System.out.println("It1 ::  "+It1);
               			Double subtot=convertStringToDouble(userData.getData("OrdersPriceValidation", "Subtotal before savings" +h));
               			System.out.println("subtot ::  "+subtot);	
               			
               			System.out.println( " ContractSaving_OS  :"+ContractSaving);
               			ContractSaving_OS=get2DecimalDoubleValue(ContractSaving_OS+ContractSaving);
               			System.out.println(ContractSaving_OS+ " ContractSaving_OS  :"+ContractSaving);
               			
               			subtotal_OS=get2DecimalDoubleValue(subtotal_OS+subtot);
               			Fet_OS=Fet_OS+Fetdata;
               			EST_OS=EST_OS+EST;
               			total_OS=total_OS+It1;
               			System.out.println(subtotal_OS  +" ::   Fet_OS ::  "+Fet_OS+" ::   EST_OS :: "+EST_OS+" ::   total_OS  ::  "+total_OS);
               			
               			Report.updateTestLog(Action, subtotal_OS  +" ::   Fet_OS ::  "+Fet_OS+" ::   EST_OS :: "+EST_OS+" ::   total_OS  ::  "+total_OS , Status.DONE);
               			
               			
               	}


               	//Report.updateTestLog(Action, k+ "  buttons.size() is  (buttons.size()>1) ::  " +buttons.size()+" h:: " +h , Status.DONE);
               	else if(buttons.size()>1) 
               	{
               			Report.updateTestLog(Action, " inside    is ::  " +buttons.size()  +"  pn2=pn2+h   :: "+pn2 , Status.DONE);
               			
               		 product= (userData.getData("OrderDetails", "Product" +k ));
               		System.out.println("Product ::  "+product);
               		 qty=(userData.getData("OrderDetails", "qty" + k));
               		System.out.println("qty ::  "+qty);
               		 listprice=Double.parseDouble((userData.getData("OrdersPriceValidation", "ListPrice" + k)));
               		System.out.println("listprice ::  "+listprice);
               		 contractprice=Double.parseDouble((userData.getData("OrdersPriceValidation", "ContractPrice" + k)));
               		System.out.println("contractprice ::  "+contractprice);
               		 ContractSaving=Double.parseDouble((userData.getData("OrdersPriceValidation", "Savings with promotion" + k)));
               		System.out.println("ContractSaving ::  "+ContractSaving);
               		 Fetdata=Double.parseDouble((userData.getData("OrdersPriceValidation", "Total Federal excise tax" + k)));
               		System.out.println("Fetdata ::  "+Fetdata);
               		 EST=Double.parseDouble((userData.getData("OrdersPriceValidation", "Total Estimated sales tax" + k)));
               		 ContractSaving_perpack=Double.parseDouble((userData.getData("OrdersPriceValidation", "Savings with promotion" + k)));
               		
               		try {
               		 It1=Double.parseDouble((userData.getData("OrdersPriceValidation", "Price for contract" +k)));
               		
               		} catch (Exception e) {
               	      
               			try {
               			It1=convertStringToDouble(userData.getData("OrdersPriceValidation", "Price for contract" +k));	
               			
               			} catch (Exception e1) {
               				
               				System.out.println(e1);
               				
               				
               				
               			}
               			
               			
               	   }
               		
               		try {
               			String pn = "%prodname" + k + "%";
               			Productname=getVar(pn);
               			}
               			catch (Exception e) {
               				 System.out.println("catch    Productname  :: "); 
               				
               			}
               		
               		
               		
               		System.out.println("It1 ::  "+It1);
               		Double subtot=convertStringToDouble(userData.getData("OrdersPriceValidation", "Subtotal before savings" +k));
               		System.out.println("subtot ::   "+k  + "  ::  "+subtot);	
               		Report.updateTestLog(Action, "subtot ::   "+k  + "  ::  "+subtot   , Status.DONE);
               		System.out.println( " ContractSaving_OS  :"+ContractSaving);
               		ContractSaving_OS=get2DecimalDoubleValue(ContractSaving_OS+ContractSaving);
               		System.out.println(ContractSaving_OS+ " ContractSaving_OS  :"+ContractSaving);
               		
               		subtotal_OS=get2DecimalDoubleValue(subtotal_OS+subtot);
               		Fet_OS=Fet_OS+Fetdata;
               		EST_OS=EST_OS+EST;
               		total_OS=total_OS+It1;
//               		System.out.println(subtotal_OS  +" ::   Fet_OS ::  "+Fet_OS+" ::   EST_OS :: "+EST_OS+" ::   total_OS  ::  "+total_OS);
               		
               		Report.updateTestLog(Action, subtotal_OS  +" ::   Fet_OS ::  "+Fet_OS+" ::   EST_OS :: "+EST_OS+" ::   total_OS  ::  "+total_OS , Status.DONE);
               		

               		
               	}
               		
               		

               		
               		
               		try {
               			
               		pname	= Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//a[@class='productName'])["+h+"]")).getText();
//               		NDC=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//a[@class='productName']/../../div/p/span)["+h+"]")).getText();
               		NDC=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//a[@class='productName']//following-sibling::p//span)["+h+"]")).getText();
               		
//               		quantity=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//*[@class='productQtyBoxWrap']//input)["+h+"]")).getText();
               		
               		
               		cprice=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//p[@class='contractPrice']//span)["+h+"]")).getText());
               		System.out.println("cprice ::  "+cprice);	
               		lprice=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//p[@class='listPrice']//span)["+h+"]")).getText());
               		System.out.println("lprice ::  "+lprice);	
               		
               		cs=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//p[contains(@class,'contractSaving')]//span)["+h+"]")).getText());
               		System.out.println("cs ::  "+cs);	
               		fet=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//p[@class='fedtax']//span)["+h+"]")).getText());
               		System.out.println("fet ::  "+fet);	
               		
               		ItemTotal=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//p[@class='itemTotal']//span)["+h+"]")).getText());
               		
               		System.out.println("ItemTotal ::  "+ItemTotal);	
               		
               		

               	String qtyy=null;
               		try{
               			qtyy=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//*[@class='productQtyBoxWrap']//label[@class='packqty text-center'])["+h+"]")).getText();
               		
               		}
               		catch (Exception e) {
               			 System.out.println("catch    qtyy  :: "); 
               			 qtyy=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//div[contains(@class,'productQtyInfo')]//p)["+h+"]")).getText();
               				
               			
               		}
               		String[] split = qtyy.split("=");

               		// get the first value from the array and trim any whitespace
               		split = split[0].split("Packs");
               		
               		quantity=split[0].trim();
               		 
               		 System.out.println( "k :: "+ k+  "quantity    1073  :: "+quantity+ "   :: h  :: "+ h); 
               		if(pname.equalsIgnoreCase(Productname))
               			
               		{
               			Report.updateTestLog(Action, "Excepted Productname is ::  " +Productname  + " and Actual Productname is same::  " +pname , Status.PASS);
               		}
               		else
               			
               		{
               			Report.updateTestLog(Action, "Excepted Productname is ::  " +Productname  + " and Actual Productname is  Not Matched ::  " +pname , Status.FAIL);
               		}
               		
               		
               		
               	if(NDC.equalsIgnoreCase(product))
               			
               		{
               			Report.updateTestLog(Action, "Excepted Productname is ::  " +product  + " and Actual Productname is same::  " +NDC , Status.PASS);
               		}
               		else
               			
               		{
               			Report.updateTestLog(Action, "Excepted Productname is ::  " +product  + " and Actual Productname is  Not Matched ::  " +NDC , Status.FAIL);
               		}


               	if(qty.equalsIgnoreCase(quantity))
               		
               	{
               		Report.updateTestLog(Action, "Excepted quantity is ::  " +qty  + " and Actual quantity is same::  " +quantity , Status.PASS);
               	}
               	else
               		
               	{
               		Report.updateTestLog(Action, "Excepted quantity is ::  " +qty  + " and Actual quantity is  Not Matched ::  " +quantity , Status.FAIL);
               	}



               		
               		if(cprice.equals(contractprice))	
               			
               		{
               			Report.updateTestLog(Action, "Excepted Contract price is ::  " +contractprice  + " and Actual Contract price is same::  " +cprice , Status.PASS);
               		}
               		else
               			
               		{
               			Report.updateTestLog(Action, "Excepted Contract price is ::  " +contractprice  + " and Actual Contract price is  Not Matched ::  " +cprice , Status.FAIL);
               		}
               			
               			
               			if(lprice.equals(listprice))	
               				
               			{
               				Report.updateTestLog(Action, "Excepted listprice is ::  " +listprice  + " and Actual listprice is same::  " +lprice , Status.PASS);
               			}
               			else
               				
               			{
               				Report.updateTestLog(Action, "Excepted listprice is ::  " +listprice  + " and Actual listprice is  Not Matched ::  " +lprice , Status.FAIL);
               			}
               			
               		if(cs.equals(ContractSaving_perpack))	
               				
               			{
               				Report.updateTestLog(Action, "Excepted ContractSaving is ::  " +ContractSaving_perpack  + " and Actual ContractSaving is same::  " +cs , Status.PASS);
               			}
               			else
               				
               			{
               				Report.updateTestLog(Action, "Excepted ContractSaving is ::  " +ContractSaving_perpack  + " and Actual ContractSaving  is  Not Matched ::  " +cs , Status.FAIL);
               			}

               		if(fet.equals(Fetdata))	
               			
               		{
               			Report.updateTestLog(Action, "Excepted Federal Excise Tax is ::  " +Fetdata  + " and Actual Federal Excise Tax is same::  " +fet , Status.PASS);
               		}
               		else
               			
               		{
               			Report.updateTestLog(Action, "Excepted Federal Excise Tax is ::  " +Fetdata  + " and Actual Federal Excise Tax is  Not Matched ::  " +fet , Status.FAIL);
               		}

               		if(ItemTotal.equals(It1))	
               			
               		{
               			Report.updateTestLog(Action, "Excepted Item Total is ::  " +ItemTotal  + " and Actual Item Total is same::  " +It1 , Status.PASS);
               		}
               		else
               			
               		{
               			Report.updateTestLog(Action, "Excepted Item Total is ::  " +ItemTotal  + " and Actual Item Total  is  Not Matched ::  " +It1 , Status.FAIL);
               		}

               		
               		
//               		pn2=pn2+1;	
               	//	
//               		Report.updateTestLog(Action, "pn2=pn2+1;  1239 try  ::  " +pn2  , Status.DONE);
               		}
               	catch (Exception e) {
               		
               		
               	        
               		Report.updateTestLog(Action, "Excepted listprice is :: 1245   catch"  , Status.DONE);
               		
               		
               		
               		
               		
               		pname	= Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//a[@class='productName'])["+h+"]")).getText();
               		NDC=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//a[@class='productName']//following-sibling::p//span)["+h+"]")).getText();
               		
               		
               		lprice=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//p[@class='contractPrice']//span)["+h+"]")).getText());
               		System.out.println("lprice ::  "+lprice);	
               		
               		cs=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//p[contains(@class,'contractSaving')]//span)["+h+"]")).getText());
               		System.out.println("cs ::  "+cs);	
               		fet=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//p[@class='fedtax']//span)["+h+"]")).getText());
               		System.out.println("fet ::  "+fet);	
               		
               		ItemTotal=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//p[@class='itemTotal']//span)["+h+"]")).getText());
               		
               		System.out.println("ItemTotal ::  "+ItemTotal);	
               		try {
               		String pn = "%prodname" + k + "%";
               		Productname=getVar(pn);
               		}
               		catch (Exception e1) {
               			 System.out.println("catch    Productname  :: "); 
               			
               		}
               		
               	String qtyy=null;
               		try{
               			qtyy=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//*[@class='productQtyBoxWrap']//label[@class='packqty text-center'])["+h+"]")).getText();
               		
               		}
               		catch (Exception e1) {
               			 System.out.println("catch    qtyy  :: "); 
               			 qtyy=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//div[contains(@class,'productQtyInfo')]//p)["+h+"]")).getText();
               				
               			
               		}
               		String[] split = qtyy.split("=");

               		// get the first value from the array and trim any whitespace
               		split = split[0].split("Packs");
               		
               		quantity=split[0].trim();
               		 
               		 System.out.println( "k :: "+ k+  "quantity  catch   1228  :: "+quantity+ "   :: h  :: "+ h); 
               		if(pname.equalsIgnoreCase(Productname))
               			
               		{
               			Report.updateTestLog(Action, "Excepted Productname is ::  " +Productname  + " and Actual Productname is same::  " +pname , Status.PASS);
               		}
               		else
               			
               		{
               			Report.updateTestLog(Action, "Excepted Productname is ::  " +Productname  + " and Actual Productname is  Not Matched ::  " +pname , Status.FAIL);
               		}
               		
               		
               		
               	if(NDC.equalsIgnoreCase(product))
               			
               		{
               			Report.updateTestLog(Action, "Excepted Productname is ::  " +product  + " and Actual Productname is same::  " +NDC , Status.PASS);
               		}
               		else
               			
               		{
               			Report.updateTestLog(Action, "Excepted Productname is ::  " +product  + " and Actual Productname is  Not Matched ::  " +NDC , Status.FAIL);
               		}


               	if(qty.equalsIgnoreCase(quantity))
               		
               	{
               		Report.updateTestLog(Action, "Excepted quantity is ::  " +qty  + " and Actual quantity is same::  " +quantity , Status.PASS);
               	}
               	else
               		
               	{
               		Report.updateTestLog(Action, "Excepted quantity is ::  " +qty  + " and Actual quantity is  Not Matched ::  " +quantity , Status.FAIL);
               	}



               		
               			
               			
               			if(lprice.equals(listprice))	
               				
               			{
               				Report.updateTestLog(Action, "Excepted listprice is ::  " +listprice  + " and Actual listprice is same::  " +lprice , Status.PASS);
               			}
               			else
               				
               			{
               				Report.updateTestLog(Action, "Excepted listprice is ::  " +listprice  + " and Actual listprice is  Not Matched ::  " +lprice , Status.FAIL);
               			}
               			
               		if(cs.equals(ContractSaving_perpack))	
               				
               			{
               				Report.updateTestLog(Action, "Excepted ContractSaving is ::  " +ContractSaving_perpack  + " and Actual ContractSaving is same::  " +cs , Status.PASS);
               			}
               			else
               				
               			{
               				Report.updateTestLog(Action, "Excepted ContractSaving is ::  " +ContractSaving_perpack  + " and Actual ContractSaving  is  Not Matched ::  " +cs , Status.FAIL);
               			}
               	if(fet.equals(Fetdata))	
               			
               		{
               			Report.updateTestLog(Action, "Excepted Federal Excise Tax is ::  " +Fetdata  + " and Actual Federal Excise Tax is same::  " +fet , Status.PASS);
               		}
               		else
               			
               		{
               			Report.updateTestLog(Action, "Excepted Federal Excise Tax is ::  " +Fetdata  + " and Actual Federal Excise Tax is  Not Matched ::  " +fet , Status.FAIL);
               		}

               		if(ItemTotal.equals(It1))	
               			
               		{
               			Report.updateTestLog(Action, "Excepted Item Total is ::  " +ItemTotal  + " and Actual Item Total is same::  " +It1 , Status.PASS);
               		}
               		else
               			
               		{
               			Report.updateTestLog(Action, "Excepted Item Total is ::  " +ItemTotal  + " and Actual Item Total  is  Not Matched ::  " +It1 , Status.FAIL);
               		}
               		
               		
               		pn2=pn2+1;	
               		Report.updateTestLog(Action, "pn2=pn2+1;  1384 catch  ::  " +pn2  , Status.DONE);
               			
               		
               	}
               		
               		
               		
               		
               		
               		
               		
               		}
               		
               	addVar("%ContractSaving_OS%",Double.toString(ContractSaving_OS));	
               	addVar("%subtotal_OS%",Double.toString(subtotal_OS));
               	addVar("%Fet_OS%",Double.toString(Fet_OS));
               	addVar("%EST_OS%",Double.toString(EST_OS));
               	addVar("%total_OS%",Double.toString(total_OS));
               		
               			}catch (Exception e) {
               	        // Catch any exception and print the error message
               	        System.out.println("An error occurred: " + e.getMessage());
               	    }
               	
                
                }catch (Exception e) {
                    // Catch any exception and print the error message
                    System.out.println("An error occurred: " + e.getMessage());
                }
                
                
            }
			
			
			
			
			
		}
		 ordersummary_validation();
		
	//	
	} catch (Exception e) {
        // Catch any exception and print the error message
        System.out.println("An error occurred: " + e.getMessage());
    }
	
	
}




@Action(object = ObjectType.BROWSER, desc = "Enter ProductCount,CartCount,ProductPerCart,ShipTo-BillTo [<Data>]", input = InputType.NO)
public void orderreviewPageValidation_complexCart()

{
	int pn1=0,pn2=0;
	String pname=null, product=null,qty=null;
	JavascriptExecutor js = (JavascriptExecutor) Driver;
	Double cprice=null,lprice=null,cs=null,fet=null,ItemTotal=null;
	Double listprice=0.00,contractprice=0.00,ContractSaving=0.00,Fetdata=0.00,EST=0.00,ContractSaving_perpack=0.00, It1=0.00;
	Double ContractSaving_OS=0.00, subtotal_OS=0.00,Fet_OS=0.00, EST_OS=0.00,total_OS=0.00;	
	String Productname=null,NDC=null,quantity=null,contract=null;
	
	try {
		
		List<WebElement> buttons = Driver.findElements(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-')])"));
		int btn=buttons.size();
		for (int k = 1; k <= buttons.size();k++) {
			
			
			WebElement div = Driver.findElement(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-')])["+k+"]/../../div/div[@class='collapse show']"));
	// Get the value of the attribute "class"
            String divClass = div.getAttribute("class");

            // Check if the value contains "collapse show"
            if (divClass.contains("collapse show")) {
                // Print a message
                System.out.println("The div element is expanded");
                
                Report.updateTestLog(Action, "Expanded Page displayed " , Status.PASS);
                try
                {
               	 
                	try {
                		Driver.findElement(By.xpath("(//input[contains(@value,'Invoice Me')])[1]")).click();
               	payBy_Selection(k);	 
               	
                	}catch(Exception e1)
                	{
                	
                		  Validating_Paymenttype_orderpaage(k) ;
                		
                	}
               	try {
               		List<WebElement> products = Driver.findElements(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-')])["+k+"]/..//a[@class='productName']"));
               		System.out.println();
               		//
               		for (int h=1;h<=products.size();h++) {////
               			pn2=pn2+h;
               			
               			System.out.println("pn2=pn2+h   :: "+pn2);
               	if(buttons.size()<=1) {
               		Report.updateTestLog(Action, " inside  buttons.size()<=1   is ::  " +buttons.size()  , Status.DONE);
               			 product= (userData.getData("OrderDetails", "Product" + h));
               			System.out.println("Product ::  "+product);
               			 qty=(userData.getData("OrderDetails", "qty" + h));
               			System.out.println("qty ::  "+qty);
               			 listprice=Double.parseDouble((userData.getData("OrdersPriceValidation", "ListPrice" + h)));
               			System.out.println("listprice ::  "+listprice);
               			 contractprice=Double.parseDouble((userData.getData("OrdersPriceValidation", "ContractPrice" + h)));
               			System.out.println("contractprice ::  "+contractprice);
               			 ContractSaving=Double.parseDouble((userData.getData("OrdersPriceValidation", "Savings with promotion" + h)));
               			System.out.println("ContractSaving ::  "+ContractSaving);
               			 Fetdata=Double.parseDouble((userData.getData("OrdersPriceValidation", "Total Federal excise tax" + h)));
               			System.out.println("Fetdata ::  "+Fetdata);
               			 EST=Double.parseDouble((userData.getData("OrdersPriceValidation", "Total Estimated sales tax" + h)));
               			 ContractSaving_perpack=Double.parseDouble((userData.getData("OrdersPriceValidation", "Savings with promotion" + h)));
               			
               			try {
               			 It1=Double.parseDouble((userData.getData("OrdersPriceValidation", "Price for contract" +h)));
               			
               			} catch (Exception e) {
               		       
               				try {
               				It1=convertStringToDouble(userData.getData("OrdersPriceValidation", "Price for contract" +h));	
               				
               				} catch (Exception e1) {
               					
               					System.out.println(e1);
               					
               					
               					
               				}
               		    }
               			try {
               				String pn = "%prodname" + h + "%";
               				Productname=getVar(pn);
               				}
               				catch (Exception e) {
               					 System.out.println("catch    Productname  :: "); 
               					
               				}
               			
               			

               			System.out.println("It1 ::  "+It1);
               			Double subtot=convertStringToDouble(userData.getData("OrdersPriceValidation", "Subtotal before savings" +h));
               			System.out.println("subtot ::  "+subtot);	
               			
               			System.out.println( " ContractSaving_OS  :"+ContractSaving);
               			ContractSaving_OS=get2DecimalDoubleValue(ContractSaving_OS+ContractSaving);
               			System.out.println(ContractSaving_OS+ " ContractSaving_OS  :"+ContractSaving);
               			
               			subtotal_OS=get2DecimalDoubleValue(subtotal_OS+subtot);
               			Fet_OS=Fet_OS+Fetdata;
               			EST_OS=EST_OS+EST;
               			total_OS=total_OS+It1;
               			System.out.println(subtotal_OS  +" ::   Fet_OS ::  "+Fet_OS+" ::   EST_OS :: "+EST_OS+" ::   total_OS  ::  "+total_OS);
               			
//               			Report.updateTestLog(Action, subtotal_OS  +" ::   Fet_OS ::  "+Fet_OS+" ::   EST_OS :: "+EST_OS+" ::   total_OS  ::  "+total_OS , Status.DONE);
               			
               			
               	}


               	//Report.updateTestLog(Action, k+ "  buttons.size() is  (buttons.size()>1) ::  " +buttons.size()+" h:: " +h , Status.DONE);
               	else if(buttons.size()>1) 
               	{
//               			Report.updateTestLog(Action, " inside    is ::  " +buttons.size()  +"  pn2=pn2+h   :: "+pn2 , Status.DONE);
               			
               		 product= (userData.getData("OrderDetails", "Product" +k ));
               		System.out.println("Product ::  "+product);
               		 qty=(userData.getData("OrderDetails", "qty" + k));
               		System.out.println("qty ::  "+qty);
               		 listprice=Double.parseDouble((userData.getData("OrdersPriceValidation", "ListPrice" + k)));
               		System.out.println("listprice ::  "+listprice);
               		 contractprice=Double.parseDouble((userData.getData("OrdersPriceValidation", "ContractPrice" + k)));
               		System.out.println("contractprice ::  "+contractprice);
               		 ContractSaving=Double.parseDouble((userData.getData("OrdersPriceValidation", "Savings with promotion" + k)));
               		System.out.println("ContractSaving ::  "+ContractSaving);
               		 Fetdata=Double.parseDouble((userData.getData("OrdersPriceValidation", "Total Federal excise tax" + k)));
               		System.out.println("Fetdata ::  "+Fetdata);
               		 EST=Double.parseDouble((userData.getData("OrdersPriceValidation", "Total Estimated sales tax" + k)));
               		 ContractSaving_perpack=Double.parseDouble((userData.getData("OrdersPriceValidation", "Savings with promotion" + k)));
               		
               		try {
               		 It1=Double.parseDouble((userData.getData("OrdersPriceValidation", "Price for contract" +k)));
               		
               		} catch (Exception e) {
               	      
               			try {
               			It1=convertStringToDouble(userData.getData("OrdersPriceValidation", "Price for contract" +k));	
               			
               			} catch (Exception e1) {
               				
               				System.out.println(e1);
               				
               				
               				
               			}
               			
               			
               	   }
               		
               		try {
               			String pn = "%prodname" + k + "%";
               			Productname=getVar(pn);
               			}
               			catch (Exception e) {
               				 System.out.println("catch    Productname  :: "); 
               				
               			}
               		
               		
               		
               		System.out.println("It1 ::  "+It1);
               		Double subtot=convertStringToDouble(userData.getData("OrdersPriceValidation", "Subtotal before savings" +k));
               		System.out.println("subtot ::   "+k  + "  ::  "+subtot);	
               		Report.updateTestLog(Action, "subtot ::   "+k  + "  ::  "+subtot   , Status.DONE);
               		System.out.println( " ContractSaving_OS  :"+ContractSaving);
               		ContractSaving_OS=get2DecimalDoubleValue(ContractSaving_OS+ContractSaving);
               		System.out.println(ContractSaving_OS+ " ContractSaving_OS  :"+ContractSaving);
               		
               		subtotal_OS=get2DecimalDoubleValue(subtotal_OS+subtot);
               		Fet_OS=Fet_OS+Fetdata;
               		EST_OS=EST_OS+EST;
               		total_OS=total_OS+It1;
//               		System.out.println(subtotal_OS  +" ::   Fet_OS ::  "+Fet_OS+" ::   EST_OS :: "+EST_OS+" ::   total_OS  ::  "+total_OS);
               		
//               		Report.updateTestLog(Action, subtotal_OS  +" ::   Fet_OS ::  "+Fet_OS+" ::   EST_OS :: "+EST_OS+" ::   total_OS  ::  "+total_OS , Status.DONE);
               		

               		
               	}
               		
               		

               		
               		
               		try {
               			
               		pname	= Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//a[@class='productName'])["+h+"]")).getText();
//               		NDC=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//a[@class='productName']/../../div/p/span)["+h+"]")).getText();
               		NDC=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//a[@class='productName']//following-sibling::p//span)["+h+"]")).getText();
               		
//               		quantity=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//*[@class='productQtyBoxWrap']//input)["+h+"]")).getText();
               		
               		
               		cprice=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//p[@class='contractPrice']//span)["+h+"]")).getText());
               		System.out.println("cprice ::  "+cprice);	
               		lprice=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//p[@class='listPrice']//span)["+h+"]")).getText());
               		System.out.println("lprice ::  "+lprice);	
               		
               		cs=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//p[contains(@class,'contractSaving')]//span)["+h+"]")).getText());
               		System.out.println("cs ::  "+cs);	
               		fet=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//p[@class='fedtax']//span)["+h+"]")).getText());
               		System.out.println("fet ::  "+fet);	
               		
               		ItemTotal=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//p[@class='itemTotal']//span)["+h+"]")).getText());
               		
               		System.out.println("ItemTotal ::  "+ItemTotal);	
               		
               		

               	String qtyy=null;
               		try{
               			qtyy=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//*[@class='productQtyBoxWrap']//label[@class='packqty text-center'])["+h+"]")).getText();
               		
               		}
               		catch (Exception e) {
               			 System.out.println("catch    qtyy  :: "); 
               			 qtyy=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//div[contains(@class,'productQtyInfo')]//p)["+h+"]")).getText();
               				
               			
               		}
               		String[] split = qtyy.split("=");

               		// get the first value from the array and trim any whitespace
               		split = split[0].split("Packs");
               		
               		quantity=split[0].trim();
               		 
               		 System.out.println( "k :: "+ k+  "quantity    1073  :: "+quantity+ "   :: h  :: "+ h); 
               		if(pname.equalsIgnoreCase(Productname))
               			
               		{
               			Report.updateTestLog(Action, "Excepted Productname is ::  " +Productname  + " and Actual Productname is same::  " +pname , Status.PASS);
               		}
               		else
               			
               		{
               			Report.updateTestLog(Action, "Excepted Productname is ::  " +Productname  + " and Actual Productname is  Not Matched ::  " +pname , Status.FAIL);
               		}
               		
               		
               		
               	if(NDC.equalsIgnoreCase(product))
               			
               		{
               			Report.updateTestLog(Action, "Excepted Productname is ::  " +product  + " and Actual Productname is same::  " +NDC , Status.PASS);
               		}
               		else
               			
               		{
               			Report.updateTestLog(Action, "Excepted Productname is ::  " +product  + " and Actual Productname is  Not Matched ::  " +NDC , Status.FAIL);
               		}


               	if(qty.equalsIgnoreCase(quantity))
               		
               	{
               		Report.updateTestLog(Action, "Excepted quantity is ::  " +qty  + " and Actual quantity is same::  " +quantity , Status.PASS);
               	}
               	else
               		
               	{
               		Report.updateTestLog(Action, "Excepted quantity is ::  " +qty  + " and Actual quantity is  Not Matched ::  " +quantity , Status.FAIL);
               	}



               		
               		if(cprice.equals(contractprice))	
               			
               		{
               			Report.updateTestLog(Action, "Excepted Contract price is ::  " +contractprice  + " and Actual Contract price is same::  " +cprice , Status.PASS);
               		}
               		else
               			
               		{
               			Report.updateTestLog(Action, "Excepted Contract price is ::  " +contractprice  + " and Actual Contract price is  Not Matched ::  " +cprice , Status.FAIL);
               		}
               			
               			
               			if(lprice.equals(listprice))	
               				
               			{
               				Report.updateTestLog(Action, "Excepted listprice is ::  " +listprice  + " and Actual listprice is same::  " +lprice , Status.PASS);
               			}
               			else
               				
               			{
               				Report.updateTestLog(Action, "Excepted listprice is ::  " +listprice  + " and Actual listprice is  Not Matched ::  " +lprice , Status.FAIL);
               			}
               			
               		if(cs.equals(ContractSaving_perpack))	
               				
               			{
               				Report.updateTestLog(Action, "Excepted ContractSaving is ::  " +ContractSaving_perpack  + " and Actual ContractSaving is same::  " +cs , Status.PASS);
               			}
               			else
               				
               			{
               				Report.updateTestLog(Action, "Excepted ContractSaving is ::  " +ContractSaving_perpack  + " and Actual ContractSaving  is  Not Matched ::  " +cs , Status.FAIL);
               			}

               		if(fet.equals(Fetdata))	
               			
               		{
               			Report.updateTestLog(Action, "Excepted Federal Excise Tax is ::  " +Fetdata  + " and Actual Federal Excise Tax is same::  " +fet , Status.PASS);
               		}
               		else
               			
               		{
               			Report.updateTestLog(Action, "Excepted Federal Excise Tax is ::  " +Fetdata  + " and Actual Federal Excise Tax is  Not Matched ::  " +fet , Status.FAIL);
               		}

               		if(ItemTotal.equals(It1))	
               			
               		{
               			Report.updateTestLog(Action, "Excepted Item Total is ::  " +ItemTotal  + " and Actual Item Total is same::  " +It1 , Status.PASS);
               		}
               		else
               			
               		{
               			Report.updateTestLog(Action, "Excepted Item Total is ::  " +ItemTotal  + " and Actual Item Total  is  Not Matched ::  " +It1 , Status.FAIL);
               		}

               		
               		
//               		pn2=pn2+1;	
               	//	
//               		Report.updateTestLog(Action, "pn2=pn2+1;  1239 try  ::  " +pn2  , Status.DONE);
               		}
               	catch (Exception e) {
               		
               		
               	        
               		Report.updateTestLog(Action, "Excepted listprice is :: 1245   catch"  , Status.DONE);
               		
               		
               		
               		
               		
               		pname	= Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//a[@class='productName'])["+h+"]")).getText();
               		NDC=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//a[@class='productName']//following-sibling::p//span)["+h+"]")).getText();
               		
               		
               		lprice=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//p[@class='contractPrice']//span)["+h+"]")).getText());
               		System.out.println("lprice ::  "+lprice);	
               		
               		cs=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//p[contains(@class,'contractSaving')]//span)["+h+"]")).getText());
               		System.out.println("cs ::  "+cs);	
               		fet=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//p[@class='fedtax']//span)["+h+"]")).getText());
               		System.out.println("fet ::  "+fet);	
               		
               		ItemTotal=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//p[@class='itemTotal']//span)["+h+"]")).getText());
               		
               		System.out.println("ItemTotal ::  "+ItemTotal);	
               		try {
               		String pn = "%prodname" + k + "%";
               		Productname=getVar(pn);
               		}
               		catch (Exception e1) {
               			 System.out.println("catch    Productname  :: "); 
               			
               		}
               		
               	String qtyy=null;
               		try{
               			qtyy=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//*[@class='productQtyBoxWrap']//label[@class='packqty text-center'])["+h+"]")).getText();
               		
               		}
               		catch (Exception e1) {
               			 System.out.println("catch    qtyy  :: "); 
               			 qtyy=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-0')])["+k+"]/..//div[contains(@class,'productQtyInfo')]//p)["+h+"]")).getText();
               				
               			
               		}
               		String[] split = qtyy.split("=");

               		// get the first value from the array and trim any whitespace
               		split = split[0].split("Packs");
               		
               		quantity=split[0].trim();
               		 
               		 System.out.println( "k :: "+ k+  "quantity  catch   1228  :: "+quantity+ "   :: h  :: "+ h); 
               		if(pname.equalsIgnoreCase(Productname))
               			
               		{
               			Report.updateTestLog(Action, "Excepted Productname is ::  " +Productname  + " and Actual Productname is same::  " +pname , Status.PASS);
               		}
               		else
               			
               		{
               			Report.updateTestLog(Action, "Excepted Productname is ::  " +Productname  + " and Actual Productname is  Not Matched ::  " +pname , Status.FAIL);
               		}
               		
               		
               		
               	if(NDC.equalsIgnoreCase(product))
               			
               		{
               			Report.updateTestLog(Action, "Excepted Productname is ::  " +product  + " and Actual Productname is same::  " +NDC , Status.PASS);
               		}
               		else
               			
               		{
               			Report.updateTestLog(Action, "Excepted Productname is ::  " +product  + " and Actual Productname is  Not Matched ::  " +NDC , Status.FAIL);
               		}


               	if(qty.equalsIgnoreCase(quantity))
               		
               	{
               		Report.updateTestLog(Action, "Excepted quantity is ::  " +qty  + " and Actual quantity is same::  " +quantity , Status.PASS);
               	}
               	else
               		
               	{
               		Report.updateTestLog(Action, "Excepted quantity is ::  " +qty  + " and Actual quantity is  Not Matched ::  " +quantity , Status.FAIL);
               	}



               		
               			
               			
               			if(lprice.equals(listprice))	
               				
               			{
               				Report.updateTestLog(Action, "Excepted listprice is ::  " +listprice  + " and Actual listprice is same::  " +lprice , Status.PASS);
               			}
               			else
               				
               			{
               				Report.updateTestLog(Action, "Excepted listprice is ::  " +listprice  + " and Actual listprice is  Not Matched ::  " +lprice , Status.FAIL);
               			}
               			
               		if(cs.equals(ContractSaving_perpack))	
               				
               			{
               				Report.updateTestLog(Action, "Excepted ContractSaving is ::  " +ContractSaving_perpack  + " and Actual ContractSaving is same::  " +cs , Status.PASS);
               			}
               			else
               				
               			{
               				Report.updateTestLog(Action, "Excepted ContractSaving is ::  " +ContractSaving_perpack  + " and Actual ContractSaving  is  Not Matched ::  " +cs , Status.FAIL);
               			}
               	if(fet.equals(Fetdata))	
               			
               		{
               			Report.updateTestLog(Action, "Excepted Federal Excise Tax is ::  " +Fetdata  + " and Actual Federal Excise Tax is same::  " +fet , Status.PASS);
               		}
               		else
               			
               		{
               			Report.updateTestLog(Action, "Excepted Federal Excise Tax is ::  " +Fetdata  + " and Actual Federal Excise Tax is  Not Matched ::  " +fet , Status.FAIL);
               		}

               		if(ItemTotal.equals(It1))	
               			
               		{
               			Report.updateTestLog(Action, "Excepted Item Total is ::  " +ItemTotal  + " and Actual Item Total is same::  " +It1 , Status.PASS);
               		}
               		else
               			
               		{
               			Report.updateTestLog(Action, "Excepted Item Total is ::  " +ItemTotal  + " and Actual Item Total  is  Not Matched ::  " +It1 , Status.FAIL);
               		}
               		
               		
//               		pn2=pn2+1;	
//               		Report.updateTestLog(Action, "pn2=pn2+1;  1384 catch  ::  " +pn2  , Status.DONE);
               			
               		
               	}
               		
               		
               		
               		
               		
               		
               		
               		}
               		
               	addVar("%ContractSaving_OS%",Double.toString(ContractSaving_OS));	
               	addVar("%subtotal_OS%",Double.toString(subtotal_OS));
               	addVar("%Fet_OS%",Double.toString(Fet_OS));
               	addVar("%EST_OS%",Double.toString(EST_OS));
               	addVar("%total_OS%",Double.toString(total_OS));
               		
               			}catch (Exception e) {
               	        // Catch any exception and print the error message
               	        System.out.println("An error occurred: " + e.getMessage());
               	    }
               	
                
                }catch (Exception e) {
                    // Catch any exception and print the error message
                    System.out.println("An error occurred: " + e.getMessage());
                }
                
                
            }
			
			
			
			
			
		}
		 ordersummary_validation();
		
		
	} catch (Exception e) {
        // Catch any exception and print the error message
        System.out.println("An error occurred: " + e.getMessage());
    }
	
	
}








public void pagereadycheck()

{
	
	int maxWaitTime = 30;
    WebDriverWait wait = new WebDriverWait(Driver, maxWaitTime);

    // Wait until the page is completely loaded using a while loop
    while (!isPageLoaded(Driver)) {
        // Wait for a short interval before checking again
        try {
            Thread.sleep(1000); // 1 second
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    // Wait until the page is completely loaded
    wait.until(ExpectedConditions.jsReturnsValue("return document.readyState === 'complete';"));
}



private static boolean isPageLoaded(WebDriver Driver) {
    return (Boolean) ((JavascriptExecutor) Driver).executeScript("return document.readyState === 'complete';");
}






@Action(object = ObjectType.BROWSER, desc = "Clicking on Start a New Order button selecting shipto ", input = InputType.NO)
	public void  selectShipTo() {
	 String id=Data;
	 String shiptoId=null;
//	 By newOrder=By.xpath("//a[normalize-space()='Start a New Order']");
	 By newOrder=By.xpath("//div[@class='home-banner-nav']//a[contains(text(),'Start a New Order')]");
	 By shippingAddress_title=By.xpath("//div[normalize-space()='Select Shipping Address for Your Order']");
	 By SelectnoShippingLocation=By.xpath("//a[@id='change_noShipping_location']");
	 By SelectShippingLocation =By.xpath("//a[@id='change_shipping_location']");
	 By searchbox =By.xpath("//input[@id='searchBox']");
	 By continue_shopping=By.xpath("//div[@class='home-banner-nav']//a[contains(text(),'Continue Shopping')]");
	 By Proddutsdrpdown=By.xpath("//button[contains(text(),'Products')]");
	 By Vaccines=By.xpath("//a[@id='Vaccines']");
	 
	 String sln=null;
	 try {
		 
		 
		 
		 Driver.findElement(Proddutsdrpdown).click();
          
		    Thread.sleep(1000);
		     Driver.findElement(Vaccines).click();
		 WebDriverWait wait = new WebDriverWait(Driver,10);
		
		  wait.until(ExpectedConditions.visibilityOfElementLocated(shippingAddress_title));
          
		  
		   shiptoId=userData.getData("OrderDetails", "Shipto1");
		  
		   
		  Driver.findElement(searchbox).sendKeys(shiptoId);
		  
		  Thread.sleep(3000);
		  sln=Driver.findElement(By.xpath("(//span[normalize-space()='Active']/../..//p/span[contains(text(),'HCPSL:')]/../span[2])[1]")).getText().toString();
//           
//      	 
		  System.out.println("SLN   ::"  +  sln);
  	 userData.putData("OrderDetails", "SLN1", sln);
  	 
  	 System.out.println("shiptoId   ::"+shiptoId  +  sln);	
  
  		
//  		 WebElement selectAddressButton = Driver.findElement(By.xpath("(//span[normalize-space()='Active']/../..//button[normalize-space()='Select Address'])["+i+"]"));
  		 WebElement selectAddressButton = Driver.findElement(By.xpath("(//span[normalize-space()='Active']/../..//p/span[contains(text(),'HCPSL:')]/../span[2]/../../../../..//ancestor::div[contains(@class,'fifth-box')]/button)[1]"));
      		 
  		 
           selectAddressButton.click();	 
		  
           wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
   				.executeScript("return document.readyState")));
           System.out.println("In catch 6592 ");
           spinnerLoad();
           
	 }
	 catch(Exception e){
			
//		 Driver.findElement(SelectShippingLocation).click();
		 System.out.println("6598 "+e);
		 JavascriptExecutor js = (JavascriptExecutor) Driver;
		 Report.updateTestLog(Action, "Unable toSelect the  6598 " +e  , Status.DONE);
		 WebElement selectAddressButton = Driver.findElement(By.xpath("(//span[normalize-space()='Active']/../..//button[normalize-space()='Select Address'])[1]"));
		 js.executeScript("arguments[0].click();", selectAddressButton);
	 }

try {
//System.out.println("In catch 401 ");
String[]	  shiptoIdtext=Driver.findElement(By.xpath("//p[contains(@class,'shipto-label d-none')]")).getText().toString().split("#:");

String[]	  billtoIdtext	=Driver.findElement(By.xpath("//span[text()='#: ']/../../p[1]")).getText().toString().split("#:");

//System.out.println(shiptoIdtext[0]+ "  ::  ");

String a=shiptoIdtext[1].replaceAll("\\s+", "");

Report.updateTestLog(Action, "Select the Shipto ::   "+a , Status.PASS);
//userData.getData("RegressionData", "Shipto1");
userData.putData("OrderDetails", "Shipto1", a);


String b=billtoIdtext[1].replaceAll("\\s+", "");

Report.updateTestLog(Action, "Select the Billto ::   "+b , Status.PASS);
//userData.getData("RegressionData", "Shipto1");
userData.putData("OrderDetails", "Billto1", b);

		 							 					

}
catch(Exception e1)
{
Report.updateTestLog(Action, "Unable toSelect the Shipto " +e1  , Status.FAIL);
}
	  
}	  
		  
    
@Action(object = ObjectType.BROWSER, desc = "Clicking on Start a New Order button selecting shipto ", input = InputType.NO)
public void  selectShipTo2() {
 String id=Data;
 String shiptoId=null;
// By newOrder=By.xpath("//a[normalize-space()='Start a New Order']");
 By newOrder=By.xpath("//div[@class='home-banner-nav']//a[contains(text(),'Start a New Order')]");
 By shippingAddress_title=By.xpath("//div[normalize-space()='Select Shipping Address for Your Order']");
 By SelectnoShippingLocation=By.xpath("//a[@id='change_noShipping_location']");
 By SelectShippingLocation =By.xpath("//a[@id='change_shipping_location']");
 By searchbox =By.xpath("//input[@id='searchBox']");
 By continue_shopping=By.xpath("//div[@class='home-banner-nav']//a[contains(text(),'Continue Shopping')]");
 By addanother=By.xpath("//span[contains(text(),'Add Product to Another Shipping Address')]");
 String sln=null;
 try {
	 
	 System.out.println("Id   ::"+id);	 
	 Driver.findElement(addanother).click();
	 
	 wait.until(	ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[contains(@class,'spinner-wrapper')]")));

	  
	  
	   shiptoId=userData.getData("OrderDetails", "Shipto2");
	  
	   
	  Driver.findElement(searchbox).sendKeys(shiptoId);
	  
	  Thread.sleep(3000);
	  sln=Driver.findElement(By.xpath("(//span[normalize-space()='Active']/../..//p/span[contains(text(),'HCPSL:')]/../span[2])[1]")).getText().toString();
//       
//  	 
	  System.out.println("SLN   ::"  +  sln);
	 userData.putData("OrderDetails", "SLN2", sln);
	 
	 System.out.println("shiptoId 2  ::"+shiptoId  +  sln);	
	
		
//		 WebElement selectAddressButton = Driver.findElement(By.xpath("(//span[normalize-space()='Active']/../..//button[normalize-space()='Select Address'])["+i+"]"));
		 WebElement selectAddressButton = Driver.findElement(By.xpath("(//span[normalize-space()='Active']/../..//p/span[contains(text(),'HCPSL:')]/../span[2]/../../../../..//ancestor::div[contains(@class,'fifth-box')]/button)[1]"));
  		 
		 
       selectAddressButton.click();	 

	  
       wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
				.executeScript("return document.readyState")));
       System.out.println("In catch 6753 ");
       
       
 }
 catch(Exception e){
		
//	 Driver.findElement(SelectShippingLocation).click();
	 System.out.println("6598 "+e);
	 JavascriptExecutor js = (JavascriptExecutor) Driver;
	 Report.updateTestLog(Action, "Unable toSelect the  6598 " +e  , Status.DONE);
	 WebElement selectAddressButton = Driver.findElement(By.xpath("(//span[normalize-space()='Active']/../..//button[normalize-space()='Select Address'])[1]"));
	 js.executeScript("arguments[0].click();", selectAddressButton);
 }
try {
//System.out.println("In catch 401 ");
	wait.until(	ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[contains(@class,'spinner-wrapper')]")));
	
String[]	  shiptoIdtext=Driver.findElement(By.xpath("//p[contains(@class,'shipto-label d-none')]")).getText().toString().split("#:");

String[]	  billtoIdtext	=Driver.findElement(By.xpath("//span[text()='#: ']/../../p[1]")).getText().toString().split("#:");

//System.out.println(shiptoIdtext[0]+ "  ::  ");

String a=shiptoIdtext[1].replaceAll("\\s+", "");

Report.updateTestLog(Action, "Select the Shipto ::   "+a , Status.PASS);
//userData.getData("RegressionData", "Shipto1");
userData.putData("OrderDetails", "Shipto2", a);


String b=billtoIdtext[1].replaceAll("\\s+", "");

Report.updateTestLog(Action, "Select the Billto ::   "+b , Status.PASS);
//userData.getData("RegressionData", "Shipto1");
userData.putData("OrderDetails", "Billto2", b);

	 							 					

}
catch(Exception e1)
{
Report.updateTestLog(Action, "Unable toSelect the Shipto " +e1  , Status.FAIL);
}
  
	  
	  
		 
		 
	 
}





@Action(object = ObjectType.BROWSER, desc = "Selecting Prodcts  ", input = InputType.YES)
public void  ProductSelection1() {
//	pagereadycheck();
	 // Split the data by comma and get the length
    String[] Products = Data.split(",");
    int length = Products.length;
System.out.println("Length ::  "+length);
String pname=null,contract=null;

addVar("%noofProducts%",String.valueOf(length));

    // Loop through the Products array
    for (int i = 0; i < length; i++) {
        // Split each Product by hyphen and assign to variables
        String[] ProductDetails = Products[i].split("-");
        String Product = ProductDetails[0];
        String quantity = ProductDetails[1];
        
       
        By productname=By.xpath("//*[@id='pid-"+Product+"']//a//h4");
        
        pname=Driver.findElement(productname).getText();
        System.out.println(" pname :: (i+1)   "  + pname );
        String aa="%prodname"+(i+1)+"%";
        addVar(aa,pname);
         
       
        // Locate the quantity element by xpath
        By qty = By.xpath("//*[@id='qty-"+Product+"']//input");

        // Locate the Add to Cart element by xpath
        By addtoCart = By.xpath("//div[@id='pid-"+Product+"']//button[contains(text(),'Add to Cart')]");

        By reservenow = By.xpath("//div[@id='pid-"+Product+"']//button[contains(text(),'Reserve now')]");
        // Create a JavascriptExecutor object
        JavascriptExecutor js = (JavascriptExecutor) Driver;

        // Try to perform the actions on the web elements
        try {
            // Find the quantity element
            WebElement element = Driver.findElement(qty);
Thread.sleep(2000);
            // Delete the existing text in the text box
//           element.sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.DELETE));
//           Thread.sleep(2000);
//           
//           Report.updateTestLog(Action, " quantity ::  "+quantity , Status.PASS);
           

           element.clear();
Thread.sleep(2000);
           
//           Report.updateTestLog(Action, " quantity 1::  "+quantity , Status.PASS);
            // Enter the data into the text box
            element.sendKeys(quantity);
            Thread.sleep(3000);
         
            try {
            // Click on the Add to Cart button
            Driver.findElement(addtoCart).click();
            }catch (Exception e) 
        	{
            	Driver.findElement(reservenow).click();
        	}
//            Thread.sleep(5000);
//            Driver.navigate().refresh();

            wait.until(	ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[contains(@class,'spinner-wrapper')]")));
			wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
					.executeScript("return document.readyState")));
//			pagereadycheck();
			
			   System.out.println( "  cartTotal ");
			   
			if (Driver.findElement(By.xpath("//div[contains(@class,'cartTotal')]")).isDisplayed()) {
				 

		        // Save the Product and quantity data in the data sheet
		         userData.putData("OrderDetails", "qty" + (i + 1), quantity);
		         userData.putData("OrderDetails", "Product" + (i + 1), Product);

				

		          Report.updateTestLog(Action, " Product NDC  ::  "+Product +" and with quantity ::  "+quantity , Status.PASS);
				

			}else {
				Report.updateTestLog(Action, " No Product Added To Cart for ShipTo ", Status.FAIL);

			}
            //

          spinnerLoad();
            // Call the submethod to check the price of the Product
//            checkPrice(Product, i);
            By productname1=By.xpath("//*[@id='pid-"+Product+"']//a//h4");
            
            pname=Driver.findElement(productname1).getText();
            System.out.println(" pname :: (i+1)   "  + pname );
            String aa1="%prodname"+(i+1)+"%";
            addVar(aa1,pname);
            
            try {
            	
            	contract=Driver.findElement(By.xpath("//*[@id='pid-"+Product+"']//*[@class='contractInfo']//p")).getText();
            	 System.out.println(" contractname :: (i+1)   "  + contract );
            	addVar("%contractname"+(i+1)+"%",contract);
            	
            	
            }
            catch (Exception e) 
        	{
            	addVar("%contractname"+(i+1)+"%",contract);
        		
        	} 
            Report.updateTestLog(Action, "Product name ::  "+pname+"  :: "  +quantity + " Packs of " +Product+" Added To Cart for ShipTo " , Status.PASS);  
            
            list_contract_Price_validation (Product, i);
           
        } catch (Exception e) {
            // Handle the exception
            System.out.println("An error occurred while adding the Product to the cart: " + e.getMessage());
        }
    }
}

@Action(object = ObjectType.BROWSER, desc = "PageLoading spinner  ", input = InputType.NO)
public void spinnerLoad()

{
	
	wait.until(	ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[contains(@class,'spinner-wrapper')]")));
}

@Action(object = ObjectType.BROWSER, desc = "Selecting Prodcts  ", input = InputType.YES)
public void  ProductSelection2() {
//	pagereadycheck();
	wait.until(	ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[contains(@class,'spinner-wrapper')]")));
	 // Split the data by comma and get the length
	
	
	  
    String[] Products = Data.split(",");
    int length = Products.length;
System.out.println("Length ::  "+length);
String pname=null,contract=null;
String fludata=null;

    // Loop through the Products array
    for (int i = 0; i < length; i++) {
        // Split each Product by hyphen and assign to variables
        String[] ProductDetails = Products[i].split("-");
        String Product = ProductDetails[0];
        String quantity = ProductDetails[1];
        try {
         fludata=ProductDetails[2];
        }catch (Exception e) 
    	{
    	
    	}
       
       
        // Locate the quantity element by xpath
        By qty = By.xpath("//*[@id='qty-"+Product+"']//input");

        // Locate the Add to Cart element by xpath
        By addtoCart = By.xpath("//div[@id='pid-"+Product+"']//button[contains(text(),'Add to Cart')]");

        By reservenow = By.xpath("//div[@id='pid-"+Product+"']//button[contains(text(),'Reserve now')]");
        // Create a JavascriptExecutor object
        JavascriptExecutor js = (JavascriptExecutor) Driver;

        // Try to perform the actions on the web elements
        try {
            // Find the quantity element
            WebElement element = Driver.findElement(qty);
Thread.sleep(2000);
            // Delete the existing text in the text box
//           element.sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.DELETE));
//           Thread.sleep(2000);
//           
//           Report.updateTestLog(Action, " quantity ::  "+quantity , Status.PASS);
           

           element.clear();
Thread.sleep(2000);
           
//           Report.updateTestLog(Action, " quantity 1::  "+quantity , Status.PASS);
            // Enter the data into the text box
            element.sendKeys(quantity);
            Thread.sleep(3000);
         
            try {
            // Click on the Add to Cart button
            Driver.findElement(addtoCart).click();
            }catch (Exception e) 
        	{
            	Driver.findElement(reservenow).click();
            	
            	if(fludata.equals("flu"))
            	{
            		flu_Availabledoses();
            		
            	}
            	
        	}
//            Thread.sleep(5000);
//            Driver.navigate().refresh();

            wait.until(	ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[contains(@class,'spinner-wrapper')]")));
			wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
					.executeScript("return document.readyState")));
//			pagereadycheck();
			
			   System.out.println( "  cartTotal ");
			   
			if (Driver.findElement(By.xpath("//div[contains(@class,'cartTotal')]")).isDisplayed()) {
				 

		        // Save the Product and quantity data in the data sheet
		         userData.putData("OrderDetails", "qty" + (i + 2), quantity);
		         userData.putData("OrderDetails", "Product" + (i + 2), Product);

				

		          Report.updateTestLog(Action, " Product  ::  "+Product +" and with quantity ::  "+quantity , Status.PASS);
				

			}else {
				Report.updateTestLog(Action, " No Product Added To Cart for ShipTo ", Status.FAIL);

			}
            //

          
            // Call the submethod to check the price of the Product
//            checkPrice(Product, i);
            By productname=By.xpath("//*[@id='pid-"+Product+"']//a//h4");
            
            pname=Driver.findElement(productname).getText();
            System.out.println("pname2  " +pname  );
            String aa="%prodname"+(i+2)+"%";
            addVar(aa,pname);
            
            try {
            	
            	contract=Driver.findElement(By.xpath("//*[@id='pid-"+Product+"']//*[@class='contractInfo']//p")).getText();
            	
            	addVar("%contractname"+(i+2)+"%",contract);
            	
            	
            }
            catch (Exception e) 
        	{
            	addVar("%contractname"+(i+2)+"%",contract);
        		
        	} 
            Report.updateTestLog(Action, "Product name ::  "+pname+"  :: "  +quantity + " Packs of " +Product+" Added To Cart for ShipTo " , Status.DONE);  
            
            list_contract_Price_validation (Product, (i+1));
           
        } catch (Exception e) {
            // Handle the exception
            System.out.println("An error occurred while adding the Product to the cart: " + e.getMessage());
        }
        
       
        
    }
    
    String num=getVar("%noofProducts%");
	  int numprd=Integer.parseInt(num);  
      
  int     leng = Products.length+numprd;
      System.out.println("Length ::  "+length);
    
      addVar("%noofProducts%",String.valueOf(leng));    
    
    
    
    
    
    
    
    
    
}




public void flu_Availabledoses() 
{
	try {
		Thread.sleep(10000);
		String flu_popup_text=null;
		
		String flu_popup=Driver.findElement(By.xpath("//p[contains(text(),'Available Flu Doses')]")).getText();
		
		
		if(flu_popup.contains("Available Flu Doses"))
		{
			System.out.println("Available Flu Doses");
			Report.updateTestLog(Action, flu_popup + " :: Flu Doses PopUp displayed", Status.PASS);
			
			List<WebElement> flu_radio  = Driver.findElements(By.xpath("//input[@name='reservation']"));
			
			try {
				for (int i = 1; i <= flu_radio.size(); i++) {
					
					
	flu_popup_text=Driver.findElement(By.xpath("(//input[@name='reservation']/following-sibling::label//p[1])["+i+"]")).getText();
			
	Report.updateTestLog(Action, flu_popup_text + "   ", Status.PASS);
	if(!(flu_popup_text.contains("Create a New Reservation")))
		
	{
		System.out.println("Enter Create a new reservation loop");
		Driver.findElement(By.xpath("(//input[@name='reservation'])["+i+"]")).click();
		Thread.sleep(2000);
		
		Report.updateTestLog(Action," Reservation Radio button selected", Status.PASS);
		
		System.out.println("Enter Create a new reservation loop");
		
		JavascriptExecutor js = (JavascriptExecutor) Driver;
		WebElement element1 = Driver.findElement(By.xpath("//div[contains(@class,'justify-content-cente')]//button[contains(text(),'Continue')][@class='cta cta-primary-sm']"));
						 js.executeScript("arguments[0].click();", element1);
//		Driver.findElement(By.xpath("//div[contains(@class,'justify-content-cente')]//button[contains(text(),'Continue')][@class='cta cta-primary-sm']")).click();
		
		Thread.sleep(6000);
		
		break;
		
	}
				
	
	
				}
					
					
			}catch (Exception e) {
				Report.updateTestLog(Action," Available Flu Doses Not Displayed ", Status.FAIL);
				}
			
			spinnerLoad();
			
		}
		
	} catch (Exception e) {	
		
		Report.updateTestLog(Action," Available Flu Doses Not Displayed ", Status.FAIL);
	}
	






}	






@Action(object = ObjectType.BROWSER, desc = "Enter ProductCount,CartCount,ProductPerCart,ShipTo-BillTo [<Data>]", input = InputType.NO)
public void shippingcartPageValidation_complexCart1()

{
	int pn1=0,pn2=0;
	String pname=null, product=null,qty=null;
	JavascriptExecutor js = (JavascriptExecutor) Driver;
	Double cprice=null,lprice=null,cs=null,fet=null,ItemTotal=null;
	Double listprice=0.00,contractprice=0.00,ContractSaving=0.00,Fetdata=0.00,EST=0.00,ContractSaving_perpack=0.00, It1=0.00;
	Double ContractSaving_OS=0.00, subtotal_OS=0.00,Fet_OS=0.00, EST_OS=0.00,total_OS=0.00;	
	String Productname=null,NDC=null,quantity=null,contract=null;
	
	spinnerLoad();

	try {
		
		List<WebElement> buttons = Driver.findElements(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-')])"));
		int btn=buttons.size();
		Report.updateTestLog(Action, "Expanded Page :: "+btn , Status.DONE);
		
		for (int k = 1; k <=buttons.size();k++) {
			
			try {
//            		Thread.sleep(5000);
           	payBy_Selection(k);	 
           	Report.updateTestLog(Action, " payBy_Selection  :: 5000 try  "  , Status.DONE);
           	
           	
            	}catch(Exception e1)
            	{
            	 	Report.updateTestLog(Action, " payBy_Selection  :: catch  5003 "+e1  , Status.DONE);
            		  Validating_Paymenttype_orderpaage(k) ;
            	//	
            	}
            	
			
			
			
           	try {
           		List<WebElement> products = Driver.findElements(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"0')])/..//a[@class='productName']"));
           		
           		for (int h=1;h<=products.size();h++) {
           			
           			
           			wait.until(	ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[contains(@class,'spinner-wrapper')]")));
              		 product= (userData.getData("OrderDetails", "Product" +k ));
              		System.out.println("Product ::  "+product);
              		 qty=(userData.getData("OrderDetails", "qty" + k));
              		System.out.println("qty ::  "+qty);
              		 listprice=Double.parseDouble((userData.getData("OrdersPriceValidation", "ListPrice" + k)));
              		System.out.println("listprice ::  "+listprice);
              		 contractprice=Double.parseDouble((userData.getData("OrdersPriceValidation", "ContractPrice" + k)));
              		System.out.println("contractprice ::  "+contractprice);
              		 ContractSaving=Double.parseDouble((userData.getData("OrdersPriceValidation", "Savings with promotion" + k)));
              		System.out.println("ContractSaving ::  "+ContractSaving);
              		 Fetdata=Double.parseDouble((userData.getData("OrdersPriceValidation", "Total Federal excise tax" + k)));
              		System.out.println("Fetdata :: 5019 "+Fetdata);
              		 EST=Double.parseDouble((userData.getData("OrdersPriceValidation", "Total Estimated sales tax" + k)));
              		 ContractSaving_perpack=Double.parseDouble((userData.getData("OrdersPriceValidation", "Savings with promotion" + k)));
              		 addVar("%feaa%",Double.toString(Fetdata));//
              		try {
              		 It1=Double.parseDouble((userData.getData("OrdersPriceValidation", "Price for contract" +k)));
              		
              		} catch (Exception e) {
              	      
              			try {
              			It1=convertStringToDouble(userData.getData("OrdersPriceValidation", "Price for contract" +k));	
              			
              			} catch (Exception e1) {
              				
              				System.out.println(e1);
              				
              				
              				
              			}
              			
              			
              	   }
              		
              		try {
              			String pn = "%prodname" + k + "%";
              			Productname=getVar(pn);
              			}
              			catch (Exception e) {
              				 System.out.println("catch    Productname  :: "); 
              				
              			}
              		
              		
              		
              		System.out.println("It1 ::  "+It1);
              		Double subtot=convertStringToDouble(userData.getData("OrdersPriceValidation", "Subtotal before savings" +k));
              		System.out.println("subtot ::   "+k  + "  ::  "+subtot);	
              		Report.updateTestLog(Action, "subtot ::   "+k  + "  ::  "+subtot   , Status.DONE);
              		System.out.println( " ContractSaving_OS  :"+ContractSaving);
              		ContractSaving_OS=get2DecimalDoubleValue(ContractSaving_OS+ContractSaving);
              		System.out.println(ContractSaving_OS+ " ContractSaving_OS  :"+ContractSaving);
              		
              		subtotal_OS=get2DecimalDoubleValue(subtotal_OS+subtot);
              		Fet_OS=Fet_OS+Fetdata;
              		EST_OS=EST_OS+EST;
              		total_OS=total_OS+It1;
              		System.out.println(subtotal_OS  +" ::   Fet_OS ::  "+Fet_OS+" ::   EST_OS :: "+EST_OS+" ::   total_OS  ::  "+total_OS);
              		
//              		Report.updateTestLog(Action, subtotal_OS  +" ::   Fet_OS ::  "+Fet_OS+" ::   EST_OS :: "+EST_OS+" ::   total_OS  ::  "+total_OS , Status.DONE);
              			
           			
           			
try {
               			
               			
               			lprice=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"0')])/..//p[@class='listPrice']//span)["+h+"]")).getText());
                   		System.out.println("lprice ::  "+lprice);		
               		pname	= Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"0')])/..//a[@class='productName'])["+h+"]")).getText();
//               		NDC=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"0')])/..//a[@class='productName']/../../div/p/span)["+h+"]")).getText();
               		NDC=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"0')])/..//a[@class='productName']//following-sibling::p//span)["+h+"]")).getText();
               		
//               		quantity=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"0')])/..//*[@class='productQtyBoxWrap']//input)["+h+"]")).getText();
               		
               		
               		cprice=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"0')])/..//p[@class='contractPrice']//span)["+h+"]")).getText());
               		System.out.println("cprice ::  "+cprice);	
               		
               		
               		cs=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"0')])/..//p[contains(@class,'contractSaving')]//span)["+h+"]")).getText());
               		System.out.println("cs ::  "+cs);	
               		fet=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"0')])/..//p[@class='fedtax']//span)["+h+"]")).getText());
               		System.out.println("fet ::  "+fet);	
               		
               		ItemTotal=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"0')])/..//p[@class='itemTotal']//span)["+h+"]")).getText());
               		
               		System.out.println("ItemTotal ::  "+ItemTotal);	
               		
               		

               	String qtyy=null;
               		try{
               			qtyy=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"0')])/..//*[@class='productQtyBoxWrap']//label[@class='packqty text-center'])["+h+"]")).getText();
               		
               		}
               		catch (Exception e) {
               			 System.out.println("catch    qtyy  :: "); 
               			 qtyy=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"0')])/..//div[contains(@class,'productQtyInfo')]//p)["+h+"]")).getText();
               				
               			
               		}
               		String[] split = qtyy.split("=");

               		// get the first value from the array and trim any whitespace
               		split = split[0].split("Packs");
               		
               		quantity=split[0].trim();
               		 
               		 System.out.println( "k :: "+ k+  "quantity    1073  :: "+quantity+ "   :: h  :: "+ h); 
               		if(pname.equalsIgnoreCase(Productname))
               			
               		{
               			Report.updateTestLog(Action, "Excepted Productname is ::  " +Productname  + " and Actual Productname is same::  " +pname , Status.PASS);
               		}
               		else
               			
               		{
               			Report.updateTestLog(Action, "Excepted Productname is ::  " +Productname  + " and Actual Productname is  Not Matched ::  " +pname , Status.FAIL);
               		}
               		
               		
               		
               	if(NDC.equalsIgnoreCase(product))
               			
               		{
               			Report.updateTestLog(Action, "Excepted Productname is ::  " +product  + " and Actual Productname is same::  " +NDC , Status.PASS);
               		}
               		else
               			
               		{
               			Report.updateTestLog(Action, "Excepted Productname is ::  " +product  + " and Actual Productname is  Not Matched ::  " +NDC , Status.FAIL);
               		}


               	if(qty.equalsIgnoreCase(quantity))
               		
               	{
               		Report.updateTestLog(Action, "Excepted quantity is ::  " +qty  + " and Actual quantity is same::  " +quantity , Status.PASS);
               	}
               	else
               		
               	{
               		Report.updateTestLog(Action, "Excepted quantity is ::  " +qty  + " and Actual quantity is  Not Matched ::  " +quantity , Status.FAIL);
               	}



               		
               		if(cprice.equals(contractprice))	
               			
               		{
               			Report.updateTestLog(Action, "Excepted Contract price is ::  " +contractprice  + " and Actual Contract price is same::  " +cprice , Status.PASS);
               		}
               		else
               			
               		{
               			Report.updateTestLog(Action, "Excepted Contract price is ::  " +contractprice  + " and Actual Contract price is  Not Matched ::  " +cprice , Status.FAIL);
               		}
               			
               			
               			if(lprice.equals(listprice))	
               				
               			{
               				Report.updateTestLog(Action, "Excepted listprice is ::  " +listprice  + " and Actual listprice is same::  " +lprice , Status.PASS);
               			}
               			else
               				
               			{
               				Report.updateTestLog(Action, "Excepted listprice is ::  " +listprice  + " and Actual listprice is  Not Matched ::  " +lprice , Status.FAIL);
               			}
               			
               		if(cs.equals(ContractSaving_perpack))	
               				
               			{
               				Report.updateTestLog(Action, "Excepted ContractSaving is ::  " +ContractSaving_perpack  + " and Actual ContractSaving is same::  " +cs , Status.PASS);
               			}
               			else
               				
               			{
               				Report.updateTestLog(Action, "Excepted ContractSaving is ::  " +ContractSaving_perpack  + " and Actual ContractSaving  is  Not Matched ::  " +cs , Status.FAIL);
               			}

               		if(fet.equals(Fetdata))	
               			
               		{
               			Report.updateTestLog(Action, "Excepted Federal Excise Tax is ::  " +Fetdata  + " and Actual Federal Excise Tax is same::  " +fet , Status.PASS);
               		}
               		else
               			
               		{
               			Report.updateTestLog(Action, "Excepted Federal Excise Tax is ::  " +Fetdata  + " and Actual Federal Excise Tax is  Not Matched ::  " +fet , Status.FAIL);
               		}

               		if(ItemTotal.equals(It1))	
               			
               		{
               			Report.updateTestLog(Action, "Excepted Item Total is ::  " +ItemTotal  + " and Actual Item Total is same::  " +It1 , Status.PASS);
               		}
               		else
               			
               		{
               			Report.updateTestLog(Action, "Excepted Item Total is ::  " +ItemTotal  + " and Actual Item Total  is  Not Matched ::  " +It1 , Status.FAIL);
               		}

               		
               		
//               		pn2=pn2+1;	
               	//	
//               		Report.updateTestLog(Action, "pn2=pn2+1;  1239 try  ::  " +pn2  , Status.DONE);
               		}

catch (Exception e) {
		
		
       
		Report.updateTestLog(Action, "Excepted listprice is :: 1245   catch"  , Status.DONE);
		
		
		Driver.navigate().refresh();
		wait.until(	ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[contains(@class,'spinner-wrapper')]")));
		
		
		pname	= Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"0')])/..//a[@class='productName'])["+h+"]")).getText();
		NDC=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"0')])/..//a[@class='productName']//following-sibling::p//span)["+h+"]")).getText();
		
		
		lprice=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"0')])/..//p[@class='contractPrice']//span)["+h+"]")).getText());
		System.out.println("lprice ::  "+lprice);	
		
		cs=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"0')])/..//p[contains(@class,'contractSaving')]//span)["+h+"]")).getText());
		System.out.println("cs ::  "+cs);	
		fet=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"0')])/..//p[@class='fedtax']//span)["+h+"]")).getText());
		System.out.println("fet ::  "+fet);	
		
		ItemTotal=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"0')])/..//p[@class='itemTotal']//span)["+h+"]")).getText());
		
		System.out.println("ItemTotal ::  "+ItemTotal);	
		try {
		String pn = "%prodname" + h + "%";
		Productname=getVar(pn);
		}
		catch (Exception e1) {
			 System.out.println("catch    Productname  :: "); 
			
		}
		
	String qtyy=null;
		try{
			qtyy=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"0')])/..//*[@class='productQtyBoxWrap']//label[@class='packqty text-center'])["+h+"]")).getText();
		
		}
		catch (Exception e1) {
			 System.out.println("catch    qtyy  :: "); 
			 qtyy=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"0')])/..//div[contains(@class,'productQtyInfo')]//p)["+h+"]")).getText();
				
			
		}
		String[] split = qtyy.split("=");

		// get the first value from the array and trim any whitespace
		split = split[0].split("Packs");
		
		quantity=split[0].trim();
		 
		 System.out.println( "k :: "+ k+  "quantity  catch   1228  :: "+quantity+ "   :: h  :: "+ h); 
		if(pname.equalsIgnoreCase(Productname))
			
		{
			Report.updateTestLog(Action, "Excepted Productname is ::  " +Productname  + " and Actual Productname is same::  " +pname , Status.PASS);
		}
		else
			
		{
			Report.updateTestLog(Action, "Excepted Productname is ::  " +Productname  + " and Actual Productname is  Not Matched ::  " +pname , Status.FAIL);
		}
		
		
		
	if(NDC.equalsIgnoreCase(product))
			
		{
			Report.updateTestLog(Action, "Excepted Productname is ::  " +product  + " and Actual Productname is same::  " +NDC , Status.PASS);
		}
		else
			
		{
			Report.updateTestLog(Action, "Excepted Productname is ::  " +product  + " and Actual Productname is  Not Matched ::  " +NDC , Status.FAIL);
		}


	if(qty.equalsIgnoreCase(quantity))
		
	{
		Report.updateTestLog(Action, "Excepted quantity is ::  " +qty  + " and Actual quantity is same::  " +quantity , Status.PASS);
	}
	else
		
	{
		Report.updateTestLog(Action, "Excepted quantity is ::  " +qty  + " and Actual quantity is  Not Matched ::  " +quantity , Status.FAIL);
	}



		
			
			
			if(lprice.equals(listprice))	
				
			{
				Report.updateTestLog(Action, "Excepted listprice is ::  " +listprice  + " and Actual listprice is same::  " +lprice , Status.PASS);
			}
			else
				
			{
				Report.updateTestLog(Action, "Excepted listprice is ::  " +listprice  + " and Actual listprice is  Not Matched ::  " +lprice , Status.FAIL);
			}
			
		if(cs.equals(ContractSaving_perpack))	
				
			{
				Report.updateTestLog(Action, "Excepted ContractSaving is ::  " +ContractSaving_perpack  + " and Actual ContractSaving is same::  " +cs , Status.PASS);
			}
			else
				
			{
				Report.updateTestLog(Action, "Excepted ContractSaving is ::  " +ContractSaving_perpack  + " and Actual ContractSaving  is  Not Matched ::  " +cs , Status.FAIL);
			}
	if(fet.equals(Fetdata))	
			
		{
			Report.updateTestLog(Action, "Excepted Federal Excise Tax is ::  " +Fetdata  + " and Actual Federal Excise Tax is same::  " +fet , Status.PASS);
		}
		else
			
		{
			Report.updateTestLog(Action, "Excepted Federal Excise Tax is ::  " +Fetdata  + " and Actual Federal Excise Tax is  Not Matched ::  " +fet , Status.FAIL);
		}

		if(ItemTotal.equals(It1))	
			
		{
			Report.updateTestLog(Action, "Excepted Item Total is ::  " +ItemTotal  + " and Actual Item Total is same::  " +It1 , Status.PASS);
		}
		else
			
		{
			Report.updateTestLog(Action, "Excepted Item Total is ::  " +ItemTotal  + " and Actual Item Total  is  Not Matched ::  " +It1 , Status.FAIL);
		}
		
		
//		pn2=pn2+1;	
		Report.updateTestLog(Action, "pn2=pn2+1;  1384 catch  ::  " +pn2  , Status.DONE);
			
		
	}

           			
           		}
           		
           		
           		
               	addVar("%ContractSaving_OS%",Double.toString(ContractSaving_OS));	
               	addVar("%subtotal_OS%",Double.toString(subtotal_OS));
               	addVar("%Fet_OS%",Double.toString(Fet_OS));
               	addVar("%EST_OS%",Double.toString(EST_OS));
               	addVar("%total_OS%",Double.toString(total_OS));
           		
           		
           	}
           	
           	catch(Exception e1)
        	{
        	 	Report.updateTestLog(Action, " payBy_Selection  :: catch  5003 "+e1  , Status.DONE);
        		 
        	
        	}
			
			
			
			
			
			
			
			
			
			
			
		}
		
		 ordersummary_validation();
		 
		
		
	} catch (Exception e) {
        // Catch any exception and print the error message
        System.out.println("An error occurred: " + e.getMessage());
    }
	
	
}


@Action(object = ObjectType.BROWSER, desc = "Enter ProductCount,CartCount,ProductPerCart,ShipTo-BillTo [<Data>]", input = InputType.NO)
public void orderreviewPageValidation_complexCart1()

{
	int pn1=0,pn2=0;
	String pname=null, product=null,qty=null;
	JavascriptExecutor js = (JavascriptExecutor) Driver;
	Double cprice=null,lprice=null,cs=null,fet=null,ItemTotal=null;
	Double listprice=0.00,contractprice=0.00,ContractSaving=0.00,Fetdata=0.00,EST=0.00,ContractSaving_perpack=0.00, It1=0.00;
	Double ContractSaving_OS=0.00, subtotal_OS=0.00,Fet_OS=0.00, EST_OS=0.00,total_OS=0.00;	
	String Productname=null,NDC=null,quantity=null,contract=null;
	
	spinnerLoad();
try {
		
		List<WebElement> buttons = Driver.findElements(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-')])"));
		int btn=buttons.size();
		Report.updateTestLog(Action, "Expanded Page :: "+btn , Status.DONE);
		
		for (int k = 1; k <= buttons.size();k++) {
			
			try {
//            		Thread.sleep(5000);
				Validating_Paymenttype_orderpaage(k) ; 
           	Report.updateTestLog(Action, " Validating payment Done   "  , Status.DONE);
           	
           	
            	}catch(Exception e1)
            	{
            	 	Report.updateTestLog(Action, " Validating Payment fail "+e1  , Status.FAIL);
            		  
            	//	
            	}
            	
			
			
			
           	try {
           		List<WebElement> products = Driver.findElements(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"0')])/..//a[@class='productName']"));
           		
           		for (int h=1;h<=products.size();h++) {
           			
           			
           			wait.until(	ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[contains(@class,'spinner-wrapper')]")));
              		 product= (userData.getData("OrderDetails", "Product" +k ));
              		System.out.println("Product ::  "+product);
              		 qty=(userData.getData("OrderDetails", "qty" + k));
              		System.out.println("qty ::  "+qty);
              		 listprice=Double.parseDouble((userData.getData("OrdersPriceValidation", "ListPrice" + k)));
              		System.out.println("listprice ::  "+listprice);
              		 contractprice=Double.parseDouble((userData.getData("OrdersPriceValidation", "ContractPrice" + k)));
              		System.out.println("contractprice ::  "+contractprice);
              		 ContractSaving=Double.parseDouble((userData.getData("OrdersPriceValidation", "Savings with promotion" + k)));
              		System.out.println("ContractSaving ::  "+ContractSaving);
              		 Fetdata=Double.parseDouble((userData.getData("OrdersPriceValidation", "Total Federal excise tax" + k)));
              		System.out.println("Fetdata :: 5019 "+Fetdata);
              		 EST=Double.parseDouble((userData.getData("OrdersPriceValidation", "Total Estimated sales tax" + k)));
              		 ContractSaving_perpack=Double.parseDouble((userData.getData("OrdersPriceValidation", "Savings with promotion" + k)));
              		 addVar("%feaa%",Double.toString(Fetdata));
              		try {
              		 It1=Double.parseDouble((userData.getData("OrdersPriceValidation", "Price for contract" +k)));
              		
              		} catch (Exception e) {
              	      
              			try {
              			It1=convertStringToDouble(userData.getData("OrdersPriceValidation", "Price for contract" +k));	
              			
              			} catch (Exception e1) {
              				
              				System.out.println(e1);
              				
              				
              				
              			}
              			
              			
              	   }
              		
              		try {
              			String pn = "%prodname" + k + "%";
              			Productname=getVar(pn);
              			}
              			catch (Exception e) {
              				 System.out.println("catch    Productname  :: "); 
              				
              			}
              		
              		
              		
              		System.out.println("It1 ::  "+It1);
              		Double subtot=convertStringToDouble(userData.getData("OrdersPriceValidation", "Subtotal before savings" +k));
              		System.out.println("subtot ::   "+k  + "  ::  "+subtot);	
              		Report.updateTestLog(Action, "subtot ::   "+k  + "  ::  "+subtot   , Status.DONE);
              		System.out.println( " ContractSaving_OS  :"+ContractSaving);
              		ContractSaving_OS=get2DecimalDoubleValue(ContractSaving_OS+ContractSaving);
              		System.out.println(ContractSaving_OS+ " ContractSaving_OS  :"+ContractSaving);
              		
              		subtotal_OS=get2DecimalDoubleValue(subtotal_OS+subtot);
              		Fet_OS=Fet_OS+Fetdata;
              		EST_OS=EST_OS+EST;
              		total_OS=total_OS+It1;
//              		System.out.println(subtotal_OS  +" ::   Fet_OS ::  "+Fet_OS+" ::   EST_OS :: "+EST_OS+" ::   total_OS  ::  "+total_OS);
              		
//              		Report.updateTestLog(Action, subtotal_OS  +" ::   Fet_OS ::  "+Fet_OS+" ::   EST_OS :: "+EST_OS+" ::   total_OS  ::  "+total_OS , Status.DONE);
              			
           			
           			
try {
               			
               			
               			lprice=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"0')])/..//p[@class='listPrice']//span)["+h+"]")).getText());
                   		System.out.println("lprice ::  "+lprice);		
               		pname	= Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"0')])/..//a[@class='productName'])["+h+"]")).getText();
//               		NDC=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"0')])/..//a[@class='productName']/../../div/p/span)["+h+"]")).getText();
               		NDC=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"0')])/..//a[@class='productName']//following-sibling::p//span)["+h+"]")).getText();
               		
//               		quantity=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"0')])/..//*[@class='productQtyBoxWrap']//input)["+h+"]")).getText();
               		
               		
               		cprice=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"0')])/..//p[@class='contractPrice']//span)["+h+"]")).getText());
               		System.out.println("cprice ::  "+cprice);	
               		
               		
               		cs=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"0')])/..//p[contains(@class,'contractSaving')]//span)["+h+"]")).getText());
               		System.out.println("cs ::  "+cs);	
               		fet=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"0')])/..//p[@class='fedtax']//span)["+h+"]")).getText());
               		System.out.println("fet ::  "+fet);	
               		
               		ItemTotal=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"0')])/..//p[@class='itemTotal']//span)["+h+"]")).getText());
               		
               		System.out.println("ItemTotal ::  "+ItemTotal);	
               		
               		

               	String qtyy=null;
               		try{
               			qtyy=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"0')])/..//*[@class='productQtyBoxWrap']//label[@class='packqty text-center'])["+h+"]")).getText();
               		
               		}
               		catch (Exception e) {
               			 System.out.println("catch    qtyy  :: "); 
               			 qtyy=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"0')])/..//div[contains(@class,'productQtyInfo')]//p)["+h+"]")).getText();
               				
               			
               		}
               		String[] split = qtyy.split("=");

               		// get the first value from the array and trim any whitespace
               		split = split[0].split("Packs");
               		
               		quantity=split[0].trim();
               		 
               		 System.out.println( "k :: "+ k+  "quantity    1073  :: "+quantity+ "   :: h  :: "+ h); 
               		if(pname.equalsIgnoreCase(Productname))
               			
               		{
               			Report.updateTestLog(Action, "Excepted Productname is ::  " +Productname  + " and Actual Productname is same::  " +pname , Status.PASS);
               		}
               		else
               			
               		{
               			Report.updateTestLog(Action, "Excepted Productname is ::  " +Productname  + " and Actual Productname is  Not Matched ::  " +pname , Status.FAIL);
               		}
               		
               		
               		
               	if(NDC.equalsIgnoreCase(product))
               			
               		{
               			Report.updateTestLog(Action, "Excepted Productname is ::  " +product  + " and Actual Productname is same::  " +NDC , Status.PASS);
               		}
               		else
               			
               		{
               			Report.updateTestLog(Action, "Excepted Productname is ::  " +product  + " and Actual Productname is  Not Matched ::  " +NDC , Status.FAIL);
               		}


               	if(qty.equalsIgnoreCase(quantity))
               		
               	{
               		Report.updateTestLog(Action, "Excepted quantity is ::  " +qty  + " and Actual quantity is same::  " +quantity , Status.PASS);
               	}
               	else
               		
               	{
               		Report.updateTestLog(Action, "Excepted quantity is ::  " +qty  + " and Actual quantity is  Not Matched ::  " +quantity , Status.FAIL);
               	}



               		
               		if(cprice.equals(contractprice))	
               			
               		{
               			Report.updateTestLog(Action, "Excepted Contract price is ::  " +contractprice  + " and Actual Contract price is same::  " +cprice , Status.PASS);
               		}
               		else
               			
               		{
               			Report.updateTestLog(Action, "Excepted Contract price is ::  " +contractprice  + " and Actual Contract price is  Not Matched ::  " +cprice , Status.FAIL);
               		}
               			
               			
               			if(lprice.equals(listprice))	
               				
               			{
               				Report.updateTestLog(Action, "Excepted listprice is ::  " +listprice  + " and Actual listprice is same::  " +lprice , Status.PASS);
               			}
               			else
               				
               			{
               				Report.updateTestLog(Action, "Excepted listprice is ::  " +listprice  + " and Actual listprice is  Not Matched ::  " +lprice , Status.FAIL);
               			}
               			
               		if(cs.equals(ContractSaving_perpack))	
               				
               			{
               				Report.updateTestLog(Action, "Excepted ContractSaving is ::  " +ContractSaving_perpack  + " and Actual ContractSaving is same::  " +cs , Status.PASS);
               			}
               			else
               				
               			{
               				Report.updateTestLog(Action, "Excepted ContractSaving is ::  " +ContractSaving_perpack  + " and Actual ContractSaving  is  Not Matched ::  " +cs , Status.FAIL);
               			}

               		if(fet.equals(Fetdata))	
               			
               		{
               			Report.updateTestLog(Action, "Excepted Federal Excise Tax is ::  " +Fetdata  + " and Actual Federal Excise Tax is same::  " +fet , Status.PASS);
               		}
               		else
               			
               		{
               			Report.updateTestLog(Action, "Excepted Federal Excise Tax is ::  " +Fetdata  + " and Actual Federal Excise Tax is  Not Matched ::  " +fet , Status.FAIL);
               		}

               		if(ItemTotal.equals(It1))	
               			
               		{
               			Report.updateTestLog(Action, "Excepted Item Total is ::  " +ItemTotal  + " and Actual Item Total is same::  " +It1 , Status.PASS);
               		}
               		else
               			
               		{
               			Report.updateTestLog(Action, "Excepted Item Total is ::  " +ItemTotal  + " and Actual Item Total  is  Not Matched ::  " +It1 , Status.FAIL);
               		}

               		
               		
//               		pn2=pn2+1;	
               	//	
//               		Report.updateTestLog(Action, "pn2=pn2+1;  1239 try  ::  " +pn2  , Status.DONE);
               		}

catch (Exception e) {
		
		
       
		Report.updateTestLog(Action, "Excepted listprice is :: 1245   catch"  , Status.DONE);
		
		
		Driver.navigate().refresh();
		wait.until(	ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[contains(@class,'spinner-wrapper')]")));
		
		
		pname	= Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"0')])/..//a[@class='productName'])["+h+"]")).getText();
		NDC=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"0')])/..//a[@class='productName']//following-sibling::p//span)["+h+"]")).getText();
		
		
		lprice=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"0')])/..//p[@class='contractPrice']//span)["+h+"]")).getText());
		System.out.println("lprice ::  "+lprice);	
		
		cs=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"0')])/..//p[contains(@class,'contractSaving')]//span)["+h+"]")).getText());
		System.out.println("cs ::  "+cs);	
		fet=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"0')])/..//p[@class='fedtax']//span)["+h+"]")).getText());
		System.out.println("fet ::  "+fet);	
		
		ItemTotal=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"0')])/..//p[@class='itemTotal']//span)["+h+"]")).getText());
		
		System.out.println("ItemTotal ::  "+ItemTotal);	
		try {
		String pn = "%prodname" + h + "%";
		Productname=getVar(pn);
		}
		catch (Exception e1) {
			 System.out.println("catch    Productname  :: "); 
			
		}
		
	String qtyy=null;
		try{
			qtyy=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"0')])/..//*[@class='productQtyBoxWrap']//label[@class='packqty text-center'])["+h+"]")).getText();
		
		}
		catch (Exception e1) {
			 System.out.println("catch    qtyy  :: "); 
			 qtyy=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"0')])/..//div[contains(@class,'productQtyInfo')]//p)["+h+"]")).getText();
				
			
		}
		String[] split = qtyy.split("=");

		// get the first value from the array and trim any whitespace
		split = split[0].split("Packs");
		
		quantity=split[0].trim();
		 
		 System.out.println( "k :: "+ k+  "quantity  catch   1228  :: "+quantity+ "   :: h  :: "+ h); 
		if(pname.equalsIgnoreCase(Productname))
			
		{
			Report.updateTestLog(Action, "Excepted Productname is ::  " +Productname  + " and Actual Productname is same::  " +pname , Status.PASS);
		}
		else
			
		{
			Report.updateTestLog(Action, "Excepted Productname is ::  " +Productname  + " and Actual Productname is  Not Matched ::  " +pname , Status.FAIL);
		}
		
		
		
	if(NDC.equalsIgnoreCase(product))
			
		{
			Report.updateTestLog(Action, "Excepted Productname is ::  " +product  + " and Actual Productname is same::  " +NDC , Status.PASS);
		}
		else
			
		{
			Report.updateTestLog(Action, "Excepted Productname is ::  " +product  + " and Actual Productname is  Not Matched ::  " +NDC , Status.FAIL);
		}


	if(qty.equalsIgnoreCase(quantity))
		
	{
		Report.updateTestLog(Action, "Excepted quantity is ::  " +qty  + " and Actual quantity is same::  " +quantity , Status.PASS);
	}
	else
		
	{
		Report.updateTestLog(Action, "Excepted quantity is ::  " +qty  + " and Actual quantity is  Not Matched ::  " +quantity , Status.FAIL);
	}



		
			
			
			if(lprice.equals(listprice))	
				
			{
				Report.updateTestLog(Action, "Excepted listprice is ::  " +listprice  + " and Actual listprice is same::  " +lprice , Status.PASS);
			}
			else
				
			{
				Report.updateTestLog(Action, "Excepted listprice is ::  " +listprice  + " and Actual listprice is  Not Matched ::  " +lprice , Status.FAIL);
			}
			
		if(cs.equals(ContractSaving_perpack))	
				
			{
				Report.updateTestLog(Action, "Excepted ContractSaving is ::  " +ContractSaving_perpack  + " and Actual ContractSaving is same::  " +cs , Status.PASS);
			}
			else
				
			{
				Report.updateTestLog(Action, "Excepted ContractSaving is ::  " +ContractSaving_perpack  + " and Actual ContractSaving  is  Not Matched ::  " +cs , Status.FAIL);
			}
	if(fet.equals(Fetdata))	
			
		{
			Report.updateTestLog(Action, "Excepted Federal Excise Tax is ::  " +Fetdata  + " and Actual Federal Excise Tax is same::  " +fet , Status.PASS);
		}
		else
			
		{
			Report.updateTestLog(Action, "Excepted Federal Excise Tax is ::  " +Fetdata  + " and Actual Federal Excise Tax is  Not Matched ::  " +fet , Status.FAIL);
		}

		if(ItemTotal.equals(It1))	
			
		{
			Report.updateTestLog(Action, "Excepted Item Total is ::  " +ItemTotal  + " and Actual Item Total is same::  " +It1 , Status.PASS);
		}
		else
			
		{
			Report.updateTestLog(Action, "Excepted Item Total is ::  " +ItemTotal  + " and Actual Item Total  is  Not Matched ::  " +It1 , Status.FAIL);
		}
		
		
//		pn2=pn2+1;	
		Report.updateTestLog(Action, "pn2=pn2+1;  1384 catch  ::  " +pn2  , Status.DONE);
			
		
	}

           			
           		}
           		
           		
           		
               	addVar("%ContractSaving_OS%",Double.toString(ContractSaving_OS));	
               	addVar("%subtotal_OS%",Double.toString(subtotal_OS));
               	addVar("%Fet_OS%",Double.toString(Fet_OS));
               	addVar("%EST_OS%",Double.toString(EST_OS));
               	addVar("%total_OS%",Double.toString(total_OS));
           		
           		
           	}
           	
           	catch(Exception e1)
        	{
        	 	Report.updateTestLog(Action, " payBy_Selection  :: catch  5003 "+e1  , Status.DONE);
        		 
        	
        	}
			
			
			
			
			
			
			
		}
		
		 ordersummary_validation();
		 
		
		
	} catch (Exception e) {
        // Catch any exception and print the error message
        System.out.println("An error occurred: " + e.getMessage());
    }
	
}




@Action(object = ObjectType.BROWSER, desc = "Enter ProductCount,CartCount,ProductPerCart,ShipTo-BillTo [<Data>]", input = InputType.NO)
public void orderCompletedValidation_complexCart1()

{
	int pn1=0,pn2=0;
	String pname=null, product=null,qty=null;
	JavascriptExecutor js = (JavascriptExecutor) Driver;
	Double cprice=null,lprice=null,cs=null,fet=null,ItemTotal=null;
	Double listprice=0.00,contractprice=0.00,ContractSaving=0.00,Fetdata=0.00,EST=0.00,ContractSaving_perpack=0.00, It1=0.00;
	Double ContractSaving_OS=0.00, subtotal_OS=0.00,Fet_OS=0.00, EST_OS=0.00,total_OS=0.00;	
	String Productname=null,NDC=null,quantity=null,contract=null;
	spinnerLoad();
	
	orderConfirmation();
	try {
			
			List<WebElement> buttons = Driver.findElements(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-')])"));
			int btn=buttons.size();
//			Report.updateTestLog(Action, "Expanded Page :: "+btn , Status.DONE);
			
			for (int k = 1; k <= buttons.size();k++) {
				
				try {
//	            		Thread.sleep(5000);
					Validating_Paymenttype_orderpaage(k) ; 
	           	Report.updateTestLog(Action, " Validating payment Done   "  , Status.DONE);
	           	
	           	
	            	}catch(Exception e1)
	            	{
	            	 	Report.updateTestLog(Action, " Validating Payment fail "+e1  , Status.FAIL);
	            		  
	            	//	
	            	}
	            	
				
				
				
	           	try {
	           		List<WebElement> products = Driver.findElements(By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"')])/..//a[@class='productName']"));
	           		
	           		for (int h=1;h<=products.size();h++) {
	           			
	           			
	           			wait.until(	ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[contains(@class,'spinner-wrapper')]")));
	              		 product= (userData.getData("OrderDetails", "Product" +k ));
	              		System.out.println("Product ::  "+product);
	              		 qty=(userData.getData("OrderDetails", "qty" + k));
	              		System.out.println("qty ::  "+qty);
	              		 listprice=Double.parseDouble((userData.getData("OrdersPriceValidation", "ListPrice" + k)));
	              		System.out.println("listprice ::  "+listprice);
	              		 contractprice=Double.parseDouble((userData.getData("OrdersPriceValidation", "ContractPrice" + k)));
	              		System.out.println("contractprice ::  "+contractprice);
	              		 ContractSaving=Double.parseDouble((userData.getData("OrdersPriceValidation", "Savings with promotion" + k)));
	              		System.out.println("ContractSaving ::  "+ContractSaving);
	              		 Fetdata=Double.parseDouble((userData.getData("OrdersPriceValidation", "Total Federal excise tax" + k)));
	              		System.out.println("Fetdata :: 5019 "+Fetdata);
	              		 EST=Double.parseDouble((userData.getData("OrdersPriceValidation", "Total Estimated sales tax" + k)));
	              		 ContractSaving_perpack=Double.parseDouble((userData.getData("OrdersPriceValidation", "Savings with promotion" + k)));
	              		 addVar("%feaa%",Double.toString(Fetdata));
	              		try {
	              		 It1=Double.parseDouble((userData.getData("OrdersPriceValidation", "Price for contract" +k)));
	              		
	              		} catch (Exception e) {
	              	      
	              			try {
	              			It1=convertStringToDouble(userData.getData("OrdersPriceValidation", "Price for contract" +k));	
	              			
	              			} catch (Exception e1) {
	              				
	              				System.out.println(e1);
	              				
	              				
	              				
	              			}
	              			
	              			
	              	   }
	              		
	              		try {
	              			String pn = "%prodname" + k + "%";
	              			Productname=getVar(pn);
	              			}
	              			catch (Exception e) {
	              				 System.out.println("catch    Productname  :: "); 
	              				
	              			}
	              		
	              		
	              		
	              		System.out.println("It1 ::  "+It1);
	              		Double subtot=convertStringToDouble(userData.getData("OrdersPriceValidation", "Subtotal before savings" +k));
	              		System.out.println("subtot ::   "+k  + "  ::  "+subtot);	
	              		Report.updateTestLog(Action, "subtot ::   "+k  + "  ::  "+subtot   , Status.DONE);
	              		System.out.println( " ContractSaving_OS  :"+ContractSaving);
	              		ContractSaving_OS=get2DecimalDoubleValue(ContractSaving_OS+ContractSaving);
	              		System.out.println(ContractSaving_OS+ " ContractSaving_OS  :"+ContractSaving);
	              		
	              		subtotal_OS=get2DecimalDoubleValue(subtotal_OS+subtot);
	              		Fet_OS=Fet_OS+Fetdata;
	              		EST_OS=EST_OS+EST;
	              		total_OS=total_OS+It1;
//	              		System.out.println(subtotal_OS  +" ::   Fet_OS ::  "+Fet_OS+" ::   EST_OS :: "+EST_OS+" ::   total_OS  ::  "+total_OS);
	              		
//	              		Report.updateTestLog(Action, subtotal_OS  +" ::   Fet_OS ::  "+Fet_OS+" ::   EST_OS :: "+EST_OS+" ::   total_OS  ::  "+total_OS , Status.DONE);
	              			
	           			
	           			
	try {
	               			
	               			
	               			lprice=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"')])/..//p[@class='listPrice']//span)["+h+"]")).getText());
	                   		System.out.println("lprice ::  "+lprice);		
	               		pname	= Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"')])/..//a[@class='productName'])["+h+"]")).getText();
//	               		NDC=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"')])/..//a[@class='productName']/../../div/p/span)["+h+"]")).getText();
	               		NDC=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"')])/..//a[@class='productName']//following-sibling::p//span)["+h+"]")).getText();
	               		
//	               		quantity=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"')])/..//*[@class='productQtyBoxWrap']//input)["+h+"]")).getText();
	               		
	               		
	               		cprice=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"')])/..//p[@class='contractPrice']//span)["+h+"]")).getText());
	               		System.out.println("cprice ::  "+cprice);	
	               		
	               		
	               		cs=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"')])/..//p[contains(@class,'contractSaving')]//span)["+h+"]")).getText());
	               		System.out.println("cs ::  "+cs);	
	               		fet=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"')])/..//p[@class='fedtax']//span)["+h+"]")).getText());
	               		System.out.println("fet ::  "+fet);	
	               		
	               		ItemTotal=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"')])/..//p[@class='itemTotal']//span)["+h+"]")).getText());
	               		
	               		System.out.println("ItemTotal ::  "+ItemTotal);	
	               		
	               		

	               	String qtyy=null;
	               		try{
	               			qtyy=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"')])/..//*[@class='productQtyBoxWrap']//label[@class='packqty text-center'])["+h+"]")).getText();
	               		
	               		}
	               		catch (Exception e) {
	               			 System.out.println("catch    qtyy  :: "); 
	               			 qtyy=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"')])/..//div[contains(@class,'productQtyInfo')]//p)["+h+"]")).getText();
	               				
	               			
	               		}
	               		String[] split = qtyy.split("=");

	               		// get the first value from the array and trim any whitespace
	               		split = split[0].split("Packs");
	               		
	               		quantity=split[0].trim();
	               		 
	               		 System.out.println( "k :: "+ k+  "quantity    1073  :: "+quantity+ "   :: h  :: "+ h); 
	               		if(pname.equalsIgnoreCase(Productname))
	               			
	               		{
	               			Report.updateTestLog(Action, "Excepted Productname is ::  " +Productname  + " and Actual Productname is same::  " +pname , Status.PASS);
	               		}
	               		else
	               			
	               		{
	               			Report.updateTestLog(Action, "Excepted Productname is ::  " +Productname  + " and Actual Productname is  Not Matched ::  " +pname , Status.FAIL);
	               		}
	               		
	               		
	               		
	               	if(NDC.equalsIgnoreCase(product))
	               			
	               		{
	               			Report.updateTestLog(Action, "Excepted Productname is ::  " +product  + " and Actual Productname is same::  " +NDC , Status.PASS);
	               		}
	               		else
	               			
	               		{
	               			Report.updateTestLog(Action, "Excepted Productname is ::  " +product  + " and Actual Productname is  Not Matched ::  " +NDC , Status.FAIL);
	               		}


	               	if(qty.equalsIgnoreCase(quantity))
	               		
	               	{
	               		Report.updateTestLog(Action, "Excepted quantity is ::  " +qty  + " and Actual quantity is same::  " +quantity , Status.PASS);
	               	}
	               	else
	               		
	               	{
	               		Report.updateTestLog(Action, "Excepted quantity is ::  " +qty  + " and Actual quantity is  Not Matched ::  " +quantity , Status.FAIL);
	               	}



	               		
	               		if(cprice.equals(contractprice))	
	               			
	               		{
	               			Report.updateTestLog(Action, "Excepted Contract price is ::  " +contractprice  + " and Actual Contract price is same::  " +cprice , Status.PASS);
	               		}
	               		else
	               			
	               		{
	               			Report.updateTestLog(Action, "Excepted Contract price is ::  " +contractprice  + " and Actual Contract price is  Not Matched ::  " +cprice , Status.FAIL);
	               		}
	               			
	               			
	               			if(lprice.equals(listprice))	
	               				
	               			{
	               				Report.updateTestLog(Action, "Excepted listprice is ::  " +listprice  + " and Actual listprice is same::  " +lprice , Status.PASS);
	               			}
	               			else
	               				
	               			{
	               				Report.updateTestLog(Action, "Excepted listprice is ::  " +listprice  + " and Actual listprice is  Not Matched ::  " +lprice , Status.FAIL);
	               			}
	               			
	               		if(cs.equals(ContractSaving_perpack))	
	               				
	               			{
	               				Report.updateTestLog(Action, "Excepted ContractSaving is ::  " +ContractSaving_perpack  + " and Actual ContractSaving is same::  " +cs , Status.PASS);
	               			}
	               			else
	               				
	               			{
	               				Report.updateTestLog(Action, "Excepted ContractSaving is ::  " +ContractSaving_perpack  + " and Actual ContractSaving  is  Not Matched ::  " +cs , Status.FAIL);
	               			}

	               		if(fet.equals(Fetdata))	
	               			
	               		{
	               			Report.updateTestLog(Action, "Excepted Federal Excise Tax is ::  " +Fetdata  + " and Actual Federal Excise Tax is same::  " +fet , Status.PASS);
	               		}
	               		else
	               			
	               		{
	               			Report.updateTestLog(Action, "Excepted Federal Excise Tax is ::  " +Fetdata  + " and Actual Federal Excise Tax is  Not Matched ::  " +fet , Status.FAIL);
	               		}

	               		if(ItemTotal.equals(It1))	
	               			
	               		{
	               			Report.updateTestLog(Action, "Excepted Item Total is ::  " +ItemTotal  + " and Actual Item Total is same::  " +It1 , Status.PASS);
	               		}
	               		else
	               			
	               		{
	               			Report.updateTestLog(Action, "Excepted Item Total is ::  " +ItemTotal  + " and Actual Item Total  is  Not Matched ::  " +It1 , Status.FAIL);
	               		}

	               		
	               		
//	               		pn2=pn2+1;	
	               	//	
//	               		Report.updateTestLog(Action, "pn2=pn2+1;  1239 try  ::  " +pn2  , Status.DONE);
	               		}

	catch (Exception e) {
			
			
	       
			Report.updateTestLog(Action, "Excepted listprice is :: 1245   catch"  , Status.DONE);
			
			
			Driver.navigate().refresh();
			wait.until(	ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[contains(@class,'spinner-wrapper')]")));
			
			
			pname	= Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"')])/..//a[@class='productName'])["+h+"]")).getText();
			NDC=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"')])/..//a[@class='productName']//following-sibling::p//span)["+h+"]")).getText();
			
			
			lprice=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"')])/..//p[@class='contractPrice']//span)["+h+"]")).getText());
			System.out.println("lprice ::  "+lprice);	
			
			cs=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"')])/..//p[contains(@class,'contractSaving')]//span)["+h+"]")).getText());
			System.out.println("cs ::  "+cs);	
			fet=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"')])/..//p[@class='fedtax']//span)["+h+"]")).getText());
			System.out.println("fet ::  "+fet);	
			
			ItemTotal=convertStringToDouble(Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"')])/..//p[@class='itemTotal']//span)["+h+"]")).getText());
			
			System.out.println("ItemTotal ::  "+ItemTotal);	
			try {
			String pn = "%prodname" + h + "%";
			Productname=getVar(pn);
			}
			catch (Exception e1) {
				 System.out.println("catch    Productname  :: "); 
				
			}
			
		String qtyy=null;
			try{
				qtyy=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"')])/..//*[@class='productQtyBoxWrap']//label[@class='packqty text-center'])["+h+"]")).getText();
			
			}
			catch (Exception e1) {
				 System.out.println("catch    qtyy  :: "); 
				 qtyy=Driver.findElement(By.xpath("((//div[@id='accordionUpdate']//div[contains(@id,'heading-"+(k-1)+"')])/..//div[contains(@class,'productQtyInfo')]//p)["+h+"]")).getText();
					
				
			}
			String[] split = qtyy.split("=");

			// get the first value from the array and trim any whitespace
			split = split[0].split("Packs");
			
			quantity=split[0].trim();
			 
			 System.out.println( "k :: "+ k+  "quantity  catch   1228  :: "+quantity+ "   :: h  :: "+ h); 
			if(pname.equalsIgnoreCase(Productname))
				
			{
				Report.updateTestLog(Action, "Excepted Productname is ::  " +Productname  + " and Actual Productname is same::  " +pname , Status.PASS);
			}
			else
				
			{
				Report.updateTestLog(Action, "Excepted Productname is ::  " +Productname  + " and Actual Productname is  Not Matched ::  " +pname , Status.FAIL);
			}
			
			
			
		if(NDC.equalsIgnoreCase(product))
				
			{
				Report.updateTestLog(Action, "Excepted Productname is ::  " +product  + " and Actual Productname is same::  " +NDC , Status.PASS);
			}
			else
				
			{
				Report.updateTestLog(Action, "Excepted Productname is ::  " +product  + " and Actual Productname is  Not Matched ::  " +NDC , Status.FAIL);
			}


		if(qty.equalsIgnoreCase(quantity))
			
		{
			Report.updateTestLog(Action, "Excepted quantity is ::  " +qty  + " and Actual quantity is same::  " +quantity , Status.PASS);
		}
		else
			
		{
			Report.updateTestLog(Action, "Excepted quantity is ::  " +qty  + " and Actual quantity is  Not Matched ::  " +quantity , Status.FAIL);
		}



			
				
				
				if(lprice.equals(listprice))	
					
				{
					Report.updateTestLog(Action, "Excepted listprice is ::  " +listprice  + " and Actual listprice is same::  " +lprice , Status.PASS);
				}
				else
					
				{
					Report.updateTestLog(Action, "Excepted listprice is ::  " +listprice  + " and Actual listprice is  Not Matched ::  " +lprice , Status.FAIL);
				}
				
			if(cs.equals(ContractSaving_perpack))	
					
				{
					Report.updateTestLog(Action, "Excepted ContractSaving is ::  " +ContractSaving_perpack  + " and Actual ContractSaving is same::  " +cs , Status.PASS);
				}
				else
					
				{
					Report.updateTestLog(Action, "Excepted ContractSaving is ::  " +ContractSaving_perpack  + " and Actual ContractSaving  is  Not Matched ::  " +cs , Status.FAIL);
				}
		if(fet.equals(Fetdata))	
				
			{
				Report.updateTestLog(Action, "Excepted Federal Excise Tax is ::  " +Fetdata  + " and Actual Federal Excise Tax is same::  " +fet , Status.PASS);
			}
			else
				
			{
				Report.updateTestLog(Action, "Excepted Federal Excise Tax is ::  " +Fetdata  + " and Actual Federal Excise Tax is  Not Matched ::  " +fet , Status.FAIL);
			}

			if(ItemTotal.equals(It1))	
				
			{
				Report.updateTestLog(Action, "Excepted Item Total is ::  " +ItemTotal  + " and Actual Item Total is same::  " +It1 , Status.PASS);
			}
			else
				
			{
				Report.updateTestLog(Action, "Excepted Item Total is ::  " +ItemTotal  + " and Actual Item Total  is  Not Matched ::  " +It1 , Status.FAIL);
			}
			
			
//			pn2=pn2+1;	
			Report.updateTestLog(Action, "pn2=pn2+1;  1384 catch  ::  " +pn2  , Status.DONE);
				
			
		}

	           			
	           		}
	           		
	           		
	           		
	               	addVar("%ContractSaving_OS%",Double.toString(ContractSaving_OS));	
	               	addVar("%subtotal_OS%",Double.toString(subtotal_OS));
	               	addVar("%Fet_OS%",Double.toString(Fet_OS));
	               	addVar("%EST_OS%",Double.toString(EST_OS));
	               	addVar("%total_OS%",Double.toString(total_OS));
	           		
	           		
	           	}
	           	
	           	catch(Exception e1)
	        	{
	        	 	Report.updateTestLog(Action, " payBy_Selection  :: catch  5003 "+e1  , Status.DONE);
	        		 
	        	
	        	}
				
				
				
				
				
				
				
			}
			
			 ordersummary_validation();
			 
			
			
		} catch (Exception e) {
	        // Catch any exception and print the error message
	        System.out.println("An error occurred: " + e.getMessage());
	    }
	
	
	
}


@Action(object = ObjectType.BROWSER, desc = "Clicking On Order Number and Validating Order History page Validation", input = InputType.NO)
public void orderHistoryvalidation1() {
	JavascriptExecutor js = (JavascriptExecutor) Driver;
	WebDriverWait wait = new WebDriverWait(Driver,10);

	String Ordernum=null,res=null;
	
	List<WebElement> OrderNum = Driver.findElements(By.xpath("(//*[contains(@class,'thankYouSection')]//p//a)"));
	
	addVar("%OrderNumsize%",Integer.toString(OrderNum.size()));
	
	
	for(int l=1;l<=OrderNum.size();l++)
		
	{
		
		Ordernum=Driver.findElement(By.xpath("(//*[contains(@class,'thankYouSection')]//p//a)["+l+"]")).getText();
		
		 
		 Report.updateTestLog(Action, "Order Number"+l+" displayed ::  "+Ordernum , Status.PASS); 
		 
		 Driver.findElement(By.xpath("(//*[contains(@class,'thankYouSection')]//p//a)["+l+"]")).click();
		 spinnerLoad();
		 try {
			 
			 String text=(Driver.findElement(By.xpath("//div[contains(text(),'Order Details')]"))).getText(); 
			 Report.updateTestLog(Action, " Navigated To  ::  "+text  +"  Page Sucessfully " , Status.PASS);
			 
			 Driver.navigate().back();
			 
			 spinnerLoad();
		 }catch (Exception e) {
			 Report.updateTestLog(Action, " Unabe to Navigated To Order Details Page " , Status.FAIL);
		        System.out.println("An error occurred: " + e.getMessage());
		    }

		
		 			 
//		 OH_validation(l);
		 
	 
			
}
	
	
	
	try {
		
		
		Driver.findElement(By.xpath("//h3[@class='m-0'][contains(text(),'Hi,')]")).click();
		
		
		Driver.findElement(By.xpath("//div[contains(@class,'userDropdownList')]//a[contains(text(),'Order History')]")).click();
		spinnerLoad();
		
		
		
		
	}catch (Exception e) {
		 
		WebElement element1 = Driver.findElement(By.xpath("//h3[@class='m-0'][contains(text(),'Hi,')]"));
		
		 js.executeScript("arguments[0].click();", element1);
		 
		 WebElement element = Driver.findElement(By.xpath("//div[contains(@class,'userDropdownList')]//a[contains(text(),'Order History')]"));
		 js.executeScript("arguments[0].click();", element);
		 spinnerLoad();
		 
	    }
	
	
	
	
	
	
	


}


public void Oh_Search()


{
	String oh_ornum=null,ShipTo=null,oh_name=null,oh_adrs1=null,oh_adrs2=null,oh_CustomerType=null,oh_pname=null,oh_qty=null,oh_totalcost=null;
	String ordernum_Oh=null;
	String a=getVar("%OrderNumsize%");
	int ss=Integer.parseInt(a);
	
	By onum=By.xpath("//span[contains(text(),'Order # ')]/following-sibling::span");
	By shipto=By.xpath("//div[contains(@id,'collapse-order')]//span[2]");
	By name=By.xpath("//div[contains(@id,'collapse-order')]//p[2]");
	By adrs1=By.xpath("//div[contains(@id,'collapse-order')]//p[3]");
	By adrs2=By.xpath("//div[contains(@id,'collapse-order')]//p[4]");
	By CustomerType	=By.xpath("//div[contains(@id,'collapse-order')]//p[6]");
	By pname =By.xpath("//div[contains(@id,'collapse-products')]//p[1]");
	By qty =By.xpath("//div[contains(@id,'collapse-products')]//p[2]");
	By totalcost =By.xpath("//div[contains(@id,'collapse-total')]//p//span");
	By viewD =By.xpath("//div[contains(@class,'action-btns')]//button[2]");
	By reOrder=By.xpath("//div[contains(@class,'action-btns')]//button[1]");
	for(int i=1;i<=ss;i++) {
		
		String aa=getVar("%prodname"+i+"%");
		 ordernum_Oh=getVar("%OrderNumber"+i+"%");
try {
	
	Driver.findElement(By.xpath("//input[@id='searchBox']")).sendKeys(ordernum_Oh);
	
	spinnerLoad();
	
	Driver.findElement(viewD).click();

	OH_validation(i);
	spinnerLoad();
	
	oh_ornum=Driver.findElement(onum).getText();
	ShipTo=Driver.findElement(shipto).getText();
	oh_name=Driver.findElement(name).getText();
	oh_adrs1=Driver.findElement(adrs1).getText();
	oh_adrs2=Driver.findElement(adrs2).getText();
	oh_CustomerType=Driver.findElement(CustomerType).getText();
	oh_pname=Driver.findElement(pname).getText();
	oh_qty=Driver.findElement(qty).getText();
	oh_totalcost=Driver.findElement(totalcost).getText();
	
	
	
	
	
	
}catch (Exception e) {
	
	
}
	}
	
	
}
@Action(object = ObjectType.BROWSER, desc = "Quantity validation check ", input = InputType.NO)
public void qtyupdatecheck()
{
	By addqtybutton=By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-00')]/..//button[@aria-label='Add one more'][normalize-space()='+'])[1]");
	By removeqty=By.xpath("(//div[@id='accordionUpdate']//div[contains(@id,'heading-00')]/..//button[@aria-label='Remove one'][normalize-space()='-'])[1]");
String produtqty=userData.getData("OrderDetails", "qty1");

	try {
		
	
	Driver.findElement(addqtybutton).click();
	spinnerLoad();
	
	WebElement inputBox = Driver.findElement(By.xpath("(//input[@aria-label='itemCounter.quantity'])[1]"));
//	produtqty=Driver.findElement(By.xpath("(//input[@aria-label='itemCounter.quantity'])[1]")).getText();
	
	
	
	String updatedqty = inputBox.getAttribute("value");
    
	 userData.putData("OrderDetails", "qty1", updatedqty);
	 Report.updateTestLog(Action, " updated Quantity from ::  "+ produtqty +" to ::  "+updatedqty , Status.PASS);

		price_Split2();
		
		shippingcartPageValidation_complexCart();
		
		Driver.findElement(removeqty).click();
		spinnerLoad();
		
		 inputBox = Driver.findElement(By.xpath("(//input[@aria-label='itemCounter.quantity'])[1]"));
//		produtqty=Driver.findElement(By.xpath("(//input[@aria-label='itemCounter.quantity'])[1]")).getText();
		
		
		
		 updatedqty = inputBox.getAttribute("value");
	    
		 userData.putData("OrderDetails", "qty1", updatedqty);
		 Report.updateTestLog(Action, " updated Quantity from ::  "+ produtqty +" to ::  "+updatedqty , Status.PASS);

			price_Split2();
			
			shippingcartPageValidation_complexCart();
		
		

	}catch (Exception e) {
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
}

public void OH_validation(int l)
{
	String Orderdate_time=null,Confirmationnum=null,Confirmationsent=null,ordernum_Oh=null;
	String ordernum_history=null,ConNumber=null,Odt=null,CustomerType=null;
String ShipTo=null,BillTo=null,DeliveryAddress=null,Rdd=null,Sln=null,contract=null,ponum=null,ptype=null;
int count=0;
String pname=null,Ndc=null,qty=null,contract1=null,lprice1=null,cs=null,fet1=null,it1=null;
String prodname=null,Ndcdetails=null,quantity=null,lprice=null,contractsavings=null,fet=null,it=null;
	try {
		 
		spinnerLoad();
	 Orderdate_time=	 getVar("%Orderdate_time%");
	 Confirmationnum=	getVar("%Confirmationnum%");
	 Confirmationsent=getVar("%Confirmationsent%");
		 
	System.out.println("Orderdate_time  ::  "+Orderdate_time + " ::  Confirmationnum  ::  " +Confirmationnum+" :: Confirmationsent  ::  "+Confirmationsent );
	
	  ordernum_Oh=getVar("%OrderNumber"+l+"%");
	 
		 
		
			 wait.until(ExpectedConditions.visibilityOf(Driver.findElement(By.xpath("//div[contains(text(),'Order Details')]"))));
			 Thread.sleep(5000);
			 
			 ordernum_history=Driver.findElement(By.xpath("//span[@class='title-sm'][contains(text(),'Order #:')]//following-sibling::span")).getText();
			 ConNumber=Driver.findElement(By.xpath("//span[@class='title-sm'][contains(text(),'Confirmation Number:')]//following-sibling::span")).getText();
			 Odt=Driver.findElement(By.xpath("//span[@class='title-sm'][contains(text(),'Order Date/Time:')]//following-sibling::span")).getText();
//			 CustomerType=Driver.findElement(By.xpath("//span[@class='title-sm'][contains(text(),'Order #:')]//following-sibling::span")).getText();
			
//			 ordernum_history=Driver.findElement(By.xpath("//span[@class='title-sm'][contains(text(),'Order #:')]//following-sibling::span")).getText();
			 
			 
			 
			 if(ordernum_history.contains(ordernum_Oh))
					
				{
					Report.updateTestLog(Action, "Excepted Ordernumber in Order History ::  " +ordernum_Oh  + " and Actual Ordernumber is same::  " +ordernum_history , Status.PASS);
				}
				else
					
				{
					Report.updateTestLog(Action, "Excepted Ordernumber in Order History ::  " +ordernum_Oh  + " and Actual Ordernumber is same::  " +ordernum_history , Status.FAIL);
				}
				
				
				
			if(ConNumber.contains(Confirmationnum))
					
			{
				Report.updateTestLog(Action, "Excepted Confirmation Number in Order History ::  " +Confirmationnum  + " and Confirmation Number is same::  " +ConNumber , Status.PASS);
			}
			else
				
			{
				Report.updateTestLog(Action, "Excepted Confirmation Number in Order History ::  " +Confirmationnum  + " and Confirmation Number is  Not Matched ::  " +ConNumber , Status.FAIL);
			}

			if(Odt.contains(Orderdate_time))
				
			{
				Report.updateTestLog(Action, "Excepted Order Date/Time in Order History ::  " +Orderdate_time  + " and Order Date/Time:  is same::  " +Odt , Status.PASS);
			}
			else
				
			{
				Report.updateTestLog(Action, "Excepted Order Date/Time: in Order History ::  " +Orderdate_time  + " andOrder Date/Time: is Not Matched ::  " +Odt , Status.FAIL);
			}

			
	
			OrderSummary_History(l);	
			List<WebElement> oh=Driver.findElements(By.xpath("//div[@class='oi-od-desc']"));
			
//			for(int i=1;i<=oh.size();i++) {
				
		try {
				  String aa="%prodname"+l+"%";
				  prodname=getVar(aa);
		}catch(Exception e1) 
		{
			System.out.println(e1);
		}
				  Ndcdetails=userData.getData("OrderDetails", "Product"+l);
				quantity=userData.getData("OrderDetails", "qty"+l);
				lprice= userData.getData("OrdersPriceValidation", "ListPrice"+l);
				contractsavings=userData.getData("OrdersPriceValidation", "Savings with promotion"+l);
				fet=userData.getData("OrdersPriceValidation", "Total Federal excise tax"+l);
				it=	userData.getData("OrdersPriceValidation", "Price for contract"+l);
				
				
				
				
				try {
					contract=userData.getData("OrdersPriceValidation", "ContractPrice"+l);
				contract1=Driver.findElement(By.xpath("(//span[contains(text(),'Contract:')]/following-sibling::span)")).getText();
				pname=	Driver.findElement(By.xpath("(//div[@class='oi-od-desc']//span[@class='title-xl'])")).getText();
				Ndc=Driver.findElement(By.xpath("(//div[@class='oi-od-desc']//span[contains(text(),'NDC:')]/following-sibling::span)")).getText();
				qty=Driver.findElement(By.xpath("(//div[@class='od-od-tot-pack']//span[contains(text(),'Total Packs:')]/following-sibling::span)")).getText();
				
				lprice1	=Driver.findElement(By.xpath("(//span[contains(text(),'List:')]/following-sibling::span)")).getText();
				cs=Driver.findElement(By.xpath("(//span[contains(text(),'Contract Savings:')]/following-sibling::span)")).getText();
				fet1=Driver.findElement(By.xpath("(//span[contains(text(),'Federal Excise Tax:')]/following-sibling::span)")).getText();
				it1=Driver.findElement(By.xpath("(//span[contains(text(),'Item Total')]/following-sibling::span)")).getText();



		if(pname.contains(prodname))
			
		{
			Report.updateTestLog(Action, "Excepted Product Name in Order History ::  " +prodname  + " and Actual Product Name is same::  " +pname , Status.PASS);
		}
		else
			
		{
			Report.updateTestLog(Action, "Excepted Product Name in Order History ::  " +prodname  + " and Actual Product Name is  Not Matched ::  " +pname , Status.FAIL);
		}



		if(Ndc.contains(Ndcdetails))
			
		{
		Report.updateTestLog(Action, "Excepted NDC in Order History ::  " +Ndc  + " and Actual NDC is same::  " +Ndcdetails , Status.PASS);
		}
		else

		{
		Report.updateTestLog(Action, "Excepted NDC in Order History ::  " +Ndc  + " and Actual NDC is  Not Matched ::  " +Ndcdetails , Status.FAIL);
		}		


		if(qty.contains(quantity))
			
		{
			Report.updateTestLog(Action, "Excepted Quantity in Order History ::  " +quantity  + " and Actual Quantity is same::  " +qty , Status.PASS);
		}
		else
			
		{
			Report.updateTestLog(Action, "Excepted Quantity in Order History ::  " +quantity  + " and Actual Quantity is Not Matched ::  " +qty , Status.FAIL);
		}		

		if(contract1.contains(contract))

		{
		Report.updateTestLog(Action, "Excepted Contract Savings in Order Summary in Order History ::  " +contract  + " and Actual Contract Savings is same::  " +contract1 , Status.PASS);
		}
		else

		{
		Report.updateTestLog(Action, "Excepted Contract Savings  in Order Summary in Order History ::  " +contract  + " and Actual Contract Savings is  Not Matched ::  " +contract1 , Status.FAIL);
		}


		if(lprice1.contains(lprice))
			
		{
		Report.updateTestLog(Action, "Excepted ListPrice in Order History ::  " +lprice  + " and Actual ListPrice is same::  " +lprice1 , Status.PASS);
		}
		else

		{
		Report.updateTestLog(Action, "Excepted ListPrice in Order History ::  " +lprice  + " and Actual ListPrice is  Not Matched ::  " +lprice1 , Status.FAIL);
		}

		if(cs.contains(contractsavings))

		{
		Report.updateTestLog(Action, "Excepted contractsavings in Order History ::  " +contractsavings  + " and Actual contractsavings is same::  " +cs , Status.PASS);
		}
		else

		{
		Report.updateTestLog(Action, "Excepted contractsavings in Order History ::  " +contractsavings  + " and Actual contractsavings is  Not Matched ::  " +cs , Status.FAIL);
		}

		if(fet1.contains(fet))

		{
		Report.updateTestLog(Action, "Excepted Federal Excise Tax in Order Summary  in Order History ::  " +fet  + " and Federal Excise Tax is same::  " +fet1 , Status.PASS);
		}
		else

		{
		Report.updateTestLog(Action, "Excepted Federal Excise Tax in Order Summary in Order History ::  " +fet  + " and Federal Excise Tax is Not Matched ::  " +fet1 , Status.FAIL);
		}



			
			if(it1.contains(it))	
				
			{
				Report.updateTestLog(Action, "Excepted Item Total in Order History  ::  " +it  + " and Actual Item Total is same::  " +it1 , Status.PASS);
			}
			else
				
			{
				Report.updateTestLog(Action, "Excepted Item Total in Order History  ::  " +it  + " and Actual Item Total is Not Matched ::  " +it1 , Status.FAIL);
			}
										  
		     
		
			count++;	
			System.out.println(" Inside tryy last 9135");
				}catch (Exception e) {
					Report.updateTestLog(Action, "   " +e , Status.FAIL);
					System.out.println(" Inside catch last 9137");
					pname=	Driver.findElement(By.xpath("(//div[@class='oi-od-desc']//span[@class='title-xl'])")).getText();
					Ndc=Driver.findElement(By.xpath("(//div[@class='oi-od-desc']//span[contains(text(),'NDC:')]/following-sibling::span)")).getText();
					qty=Driver.findElement(By.xpath("(//div[@class='od-od-tot-pack']//span[contains(text(),'Total Packs:')]/following-sibling::span)")).getText();
					lprice1	=Driver.findElement(By.xpath("(//span[contains(text(),'List:')]/following-sibling::span)")).getText();
					cs=Driver.findElement(By.xpath("(//span[contains(text(),'Contract Savings:')]/following-sibling::span)")).getText();
					fet1=Driver.findElement(By.xpath("(//span[contains(text(),'Federal Excise Tax:')]/following-sibling::span)")).getText();
					it1=Driver.findElement(By.xpath("(//span[contains(text(),'Item Total')]/following-sibling::span)")).getText();
						
					

					
					if(pname.contains(prodname))
						
					{
						Report.updateTestLog(Action, "Excepted Product Name in Order History ::  " +prodname  + " and Actual Product Name is same::  " +pname , Status.PASS);
					}
					else
						
					{
						Report.updateTestLog(Action, "Excepted Product Name in Order History ::  " +prodname  + " and Actual Product Name is  Not Matched ::  " +pname , Status.FAIL);
					}
					
					
					
					if(Ndc.contains(Ndcdetails))
						
				{
					Report.updateTestLog(Action, "Excepted NDC in Order History ::  " +Ndc  + " and Actual NDC is same::  " +Ndcdetails , Status.PASS);
				}
				else
					
				{
					Report.updateTestLog(Action, "Excepted NDC in Order History ::  " +Ndc  + " and Actual NDC is  Not Matched ::  " +Ndcdetails , Status.FAIL);
				}		
					
					
					if(qty.contains(quantity))
						
					{
						Report.updateTestLog(Action, "Excepted Quantity in Order History ::  " +quantity  + " and Actual Quantity is same::  " +qty , Status.PASS);
					}
					else
						
					{
						Report.updateTestLog(Action, "Excepted Quantity in Order History ::  " +quantity  + " and Actual Quantity is Not Matched ::  " +qty , Status.FAIL);
					}		
					
				if(lprice1.contains(lprice))
						
				{
					Report.updateTestLog(Action, "Excepted ListPrice in Order History ::  " +lprice  + " and Actual ListPrice is same::  " +lprice1 , Status.PASS);
				}
				else
					
				{
					Report.updateTestLog(Action, "Excepted ListPrice in Order History ::  " +lprice  + " and Actual ListPrice is  Not Matched ::  " +lprice1 , Status.FAIL);
				}
				
				if(cs.contains(contractsavings))
					
				{
					Report.updateTestLog(Action, "Excepted contractsavings in Order History ::  " +contractsavings  + " and Actual contractsavings is same::  " +cs , Status.PASS);
				}
				else
					
				{
					Report.updateTestLog(Action, "Excepted contractsavings in Order History ::  " +contractsavings  + " and Actual contractsavings is  Not Matched ::  " +cs , Status.FAIL);
				}

				if(fet1.contains(fet))
					
				{
					Report.updateTestLog(Action, "Excepted Federal Excise Tax in Order Summary  in Order History ::  " +fet  + " and Federal Excise Tax is same::  " +fet1 , Status.PASS);
				}
				else
					
				{
					Report.updateTestLog(Action, "Excepted Federal Excise Tax in Order Summary in Order History ::  " +fet  + " and Federal Excise Tax is Not Matched ::  " +fet1 , Status.FAIL);
				}


				
						
						if(it1.contains(it))	
							
						{
							Report.updateTestLog(Action, "Excepted Item Total in Order History  ::  " +it  + " and Actual Item Total is same::  " +it1 , Status.PASS);
						}
						else
							
						{
							Report.updateTestLog(Action, "Excepted Item Total in Order History  ::  " +it  + " and Actual Item Total is Not Matched ::  " +it1 , Status.FAIL);
						}
							
						
						
						System.out.println(" Inside catch last 9234");
				
				}
				
				System.out.println(" After try  last 9238");
				
												
		
			
			
				 
	} catch (Exception e1) {
		Report.updateTestLog(Action, "   " +e1 , Status.FAIL);
		
	}
	
	
}

}

