package userDefinedPackage;


import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.Random;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.comparator.LastModifiedFileComparator;
import org.apache.commons.io.filefilter.WildcardFileFilter;
import org.apache.commons.lang3.time.StopWatch;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.hamcrest.core.IsEqual;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cognizant.cognizantits.engine.commands.General;
import com.cognizant.cognizantits.engine.core.CommandControl;
import com.cognizant.cognizantits.engine.execution.exception.element.ElementException;
import com.cognizant.cognizantits.engine.execution.exception.element.ElementException.ExceptionType;
import com.cognizant.cognizantits.engine.support.Status;
import com.cognizant.cognizantits.engine.support.methodInf.Action;
import com.cognizant.cognizantits.engine.support.methodInf.InputType;
import com.cognizant.cognizantits.engine.support.methodInf.ObjectType;
import com.google.common.util.concurrent.Service.State;
import com.testautomationguru.utility.PDFUtil;


public class userDefined1 extends General{

	
	
	public userDefined1(CommandControl cc) {
		super(cc);
		// TODO Auto-generated constructor stub
	}

	@Action(object = ObjectType.BROWSER, desc = "Radio buttion selection in BackOffice for true or false", input = InputType.YES)
	public void radio_btnBoffice() {
		String value = Data;
		WebElement t1 = null;
		WebElement t2 = null;

		try {
			t1 = Driver.findElement(By.xpath("(//span[text()='" + value + "']/ancestor::td[1]//span/input)[1]"));

			boolean type = t1.isSelected();

			if (type == true)

			{
				t2 = Driver.findElement(By.xpath("(//span[text()='" + value + "']/ancestor::td[1]//span/input)[2]"));
				// ((JavascriptExecutor)
				// Driver).executeScript("arguments[0].scrollIntoView(true);", t2);
				t2.click();
				userData.putData("Flu Reservation", "RecurringLink", "Join the Recurring Reservation Program");

				Report.updateTestLog(Action, "True buttion is selected 1st --Now selecting False Radio Button ",
						Status.DONE);
				// Join the Recurring Reservation Program

			} else {
				t1.click();

				userData.putData("Flu Reservation", "RecurringLink", "Member of the Recurring Reservation Program");
				// ((JavascriptExecutor)
				// Driver).executeScript("arguments[0].scrollIntoView(true);", t1);
				Report.updateTestLog(Action, "False buttion is selected 1st --Now selecting true Radio Button ",
						Status.DONE);

			}
		} catch (Exception e) {
			t2 = Driver.findElement(By.xpath("(//span[text()='" + value + "']/ancestor::td[1]//span/input)[2]"));

			boolean type = t2.isSelected();

			if (type == true) {
				t1 = Driver.findElement(By.xpath("(//span[text()='" + value + "']/ancestor::td[1]//span/input)[1]"));
				t1.click();

				userData.putData("Flu Reservation", "RecurringLink", "Member of the Recurring Reservation Program");
				// ((JavascriptExecutor)
				// Driver).executeScript("arguments[0].scrollIntoView(true);", t1);
				Report.updateTestLog(Action, "False buttion is selected 1st --Now selecting true Radio Button ",
						Status.DONE);

			}

			else {
				// ((JavascriptExecutor)
				// Driver).executeScript("arguments[0].scrollIntoView(true);", t2);
				t2.click();
				userData.putData("Flu Reservation", "RecurringLink", "Join the Recurring Reservation Program");

				Report.updateTestLog(Action, "True buttion is selected 1st --Now selecting False Radio Button ",
						Status.DONE);
				// Join the Recurring Reservation Program

			}

		}
		// WebElement t3=(WebElement)
		// Driver.findElements(By.xpath("(//span[text()='"+value+"']/ancestor::td[1]//span/input)[3]"));

	}

	@Action(object = ObjectType.BROWSER, desc = "verifying Recurring Reservation Program link", input = InputType.NO)
	public void recurrionLink_Verify() {

		// String optIn,optOut=null;
		try {

			if (Driver.findElement(By.xpath("//*[@id='opt-in-link']")).isDisplayed())

			{
				try {
					Report.updateTestLog(Action,
							Driver.findElement(By.xpath("//*[@id='opt-in-link']")).getText() + "  Is Displayed ",
							Status.PASS);

					Driver.findElement(By.xpath("//*[@id='opt-in-link']")).click();

					Thread.sleep(1000);
					WebElement link = Driver.findElement(By.xpath("//button[@id='recurringReservationClose']"));

					// Driver.switchTo().frame(link);
					Thread.sleep(5000);
					Report.updateTestLog(Action, link.getText() + "  Is Displayed ", Status.PASS);
					Thread.sleep(1000);

					link.click();
				}

				catch (Exception e) {
					Report.updateTestLog(Action, " Un able to Click on Link Details not Displayed ", Status.FAIL);
				}

			} else if (Driver.findElement(By.xpath("//*[@id='opt-out-link']/a")).isDisplayed()) {
				try {

					Report.updateTestLog(Action,
							Driver.findElement(By.xpath("//*[@id='opt-out-link']")).getText() + "  Is Displayed ",
							Status.PASS);

					Driver.findElement(By.xpath("//*[@id='opt-out-link']/a")).click();

					Thread.sleep(1000);
					WebElement link = Driver.findElement(By.xpath("//button[@id='recurringReservationOptOutCancel']"));

					// Driver.switchTo().frame(link);
					Thread.sleep(5000);
					Report.updateTestLog(Action, link.getText() + "  Is Displayed ", Status.PASS);
					Thread.sleep(1000);

					link.click();
				} catch (Exception e) {
					Report.updateTestLog(Action,
							Driver.findElement(By.xpath("//button[@id='recurringReservationOptOutCancel']")).getText()
									+ "Details not Displayed ",
							Status.FAIL);
				}

			} else {

				Report.updateTestLog(Action, "RecurrionLink Details not Displayed Please use another Id ", Status.FAIL);

			}

		} catch (Exception e) {
			Report.updateTestLog(Action, "Details not Displayed ", Status.FAIL);
		}

	}

	@Action(object = ObjectType.BROWSER, desc = "Selecting  GSK Flu Vaccine Dashboard", input = InputType.YES)
	public void helpCenter_Namevalidation() {

		String name = Data;
		String bo_name = null;
		try {

			List<WebElement> bo_findElements = Driver.findElements(By.xpath(
					"//tr[@data-drag-key='GSKHelpCenterDetail']//td[@class='yw-listview-cell z-listcell']/div/span[@class='yw-listview-cell-label z-label']"));
			//Report.updateTestLog(Action, bo_findElements.size() + "  ::  link avialbe   ", Status.DONE);

			for (int i = 1; i <= bo_findElements.size(); i++) {
				bo_name = Driver.findElement(By.xpath(
						"(//tr[@data-drag-key='GSKHelpCenterDetail']//td[@class='yw-listview-cell z-listcell']/div/span[@class='yw-listview-cell-label z-label'])["
								+ i + "]"))
						.getText();
				
				//Report.updateTestLog(Action, bo_name + " ::  namess   ", Status.DONE);

				
				  if(bo_name.contains(Data)) { 
					  
					  try { 
						/*
						 * WebElement nm=Driver.findElement(By.
						 * xpath("(//tr[@data-drag-key='GSKHelpCenterDetail']//td[@class='yw-listview-cell z-listcell']/div/span[@class='z-listitem-checkable z-listitem-checkbox']/i)["
						 * +i+"]"));
						 * 
						 * ((JavascriptExecutor) Driver).executeScript("arguments[0].click();", nm);
						 * Thread.sleep(2000); Report.updateTestLog(Action, " HelpCenter Name :: " +
						 * bo_name+"  :: checkbox is Selected", Status.PASS);
						 */
				
						  WebElement nm=Driver.findElement(By.xpath("(//tr[@data-drag-key='GSKHelpCenterDetail']//td[@class='yw-listview-cell z-listcell']/div/span[@class='z-listitem-checkable z-listitem-checkbox']/i)["+i+"]"));

						  nm.click();
						  				  Report.updateTestLog(Action, " HelpCenter Name :: " +
						  				  bo_name+"  :: checkbox is Selected", Status.PASS);
						  				  break;
					  
					  }
					  catch(Exception e)
				  { 
						 


				 
						  Report.updateTestLog(Action, " Unable to click on link::  namess   ", Status.FAIL);		  
				  
					  
				  }
					  
					  
				 
			}
			}

		}

		catch (Exception e) {
			Report.updateTestLog(Action, "Unable to Fetch HelpCenter list details  ", Status.FAIL);
		}

	}
	
	
	
	@Action(object = ObjectType.BROWSER, desc = "Give xpath of element in Input [<Data>]", input = InputType.YES)
	public void broswer_scrollTo() throws InterruptedException {
		Thread.sleep(10000);
		WebElement element = Driver.findElement(By.xpath(Data));
		((JavascriptExecutor) Driver).executeScript("arguments[0].scrollIntoView(true);", element);
		Thread.sleep(500); 
		
		
		
	}
	
	
	
	@Action(object = ObjectType.BROWSER, desc = "Validating the covid Visibility ", input = InputType.NO)
	public void covid_banner_check() {
		String banner = null;
		WebDriverWait wait = new WebDriverWait(Driver, 600);
		
		try {

			List<WebElement> bo_findElements = Driver.findElements(By.xpath("(//td[@class='yw-listview-cell z-listcell']//span[@class='yw-listview-cell-label z-label'])"));
		//	Report.updateTestLog(Action, bo_findElements.size() + "  ::  link avialbe   ", Status.DONE);
			
			
			for (int i = 1; i <= 9; i++) {
				
				banner = Driver.findElement(By.xpath(
						"(//td[@class='yw-listview-cell z-listcell']//span[@class='yw-listview-cell-label z-label'])["
								+ i + "]"))
						.getText();
				
				if(banner.equalsIgnoreCase("GSK Content Catalog : Staged"))
				{
					
					String visible= Driver.findElement(By.xpath(
							"(//td[@class='yw-listview-cell z-listcell']//span[@class='yw-listview-cell-label z-label'])["
									+ (i+1) + "]"))
							.getText();
					
					  Report.updateTestLog(Action, "  GSK Content Catalog : Staged value is displyed   ", Status.PASS);
					
					  Report.updateTestLog(Action, visible+ "  :value is displyed   ", Status.PASS);
					  
					  try {
					if(visible.equalsIgnoreCase("true"))
						
					{
						
						
						Driver.findElement(By.xpath(
								"(//td[@class='yw-listview-cell z-listcell']//span[@class='yw-listview-cell-label z-label'])["
										+ i + "]"))
								.click();
						 
						Thread.sleep(5000);
						
						 Report.updateTestLog(Action, "  GSK Content Catalog : Staged value is TRUE making it False for Testing   ", Status.PASS);
						 
						
						
						
						
							 wait.until(ExpectedConditions
						 .visibilityOf(Driver.findElement(By.xpath("//button[@ytestid='northButton']")
						  )));
						 
						 Driver.findElement(By.xpath("//button[@ytestid='northButton']")).click();	
						 
						 Thread.sleep(5000);
						 
						 radio_visibility_check();
							
						
					}
					else
					{
						
						wait.until(ExpectedConditions
								 .visibilityOf(Driver.findElement(By.xpath("//button[@ytestid='northButton']")
								  )));
								 
								 Driver.findElement(By.xpath("//button[@ytestid='northButton']")).click();	
								 
								 Thread.sleep(5000);
						 Report.updateTestLog(Action, "  Comming to else part   ", Status.PASS);
								
						
					}
					
					  }catch (Exception e) {
							Report.updateTestLog(Action, "Faling at true if condition  ", Status.FAIL);
						}

					 
				}
				
				
				
				
				
				
				
			}

		}
		catch (Exception e) {
			Report.updateTestLog(Action, "Unable to Fetch HelpCenter list details  ", Status.FAIL);
		}

		
	}
	
	
	
	
	
	public void radio_visibility_check() {
		WebDriverWait wait = new WebDriverWait(Driver, 600);
		; 
		
		WebElement t1 = null;
		WebElement t2 = null;

		try {
			
			
			t1 = Driver.findElement(By.xpath("(//span[@class='z-radio z-radio-default']/input[@type='radio'])[3]"));
			//Report.updateTestLog(Action, t1.getClass(),Status.FAIL);
			((JavascriptExecutor) Driver).executeScript("arguments[0].scrollIntoView(true);", t1);
			Thread.sleep(500);
			boolean type = t1.isSelected();
		//	Report.updateTestLog(Action,  t1.isSelected() + " type",Status.FAIL);
			if (type == true)

			{
				try {
				t2 = Driver.findElement(By.xpath("(//span[@class='z-radio z-radio-default']/input[@type='radio'])[4]"));
				 
				((JavascriptExecutor) Driver).executeScript("arguments[0].click();", t2);
				
				Thread.sleep(2000);
				Report.updateTestLog(Action, "True buttion is selected 1st --Now selecting False Radio Button ",
						Status.DONE);
				
				Thread.sleep(2000);
				Driver.findElement(By.xpath("//span[text()='Content Slots']")).click();
				
				wait.until(ExpectedConditions
						.visibilityOf(Driver.findElement(By.xpath("(//button[text()='Save'])[1]"))));

				Driver.findElement(By.xpath("(//button[text()='Save'])[1]")).click();
				
				
				Thread.sleep(2000);
				Report.updateTestLog(Action, "Clicked on Save  Button ",Status.PASS);
				
				}catch (Exception e) {
					t2 = Driver.findElement(By.xpath("(//span[@class='z-radio z-radio-default']/input[@type='radio'])[4]"));
					 
					
					((JavascriptExecutor) Driver).executeScript("arguments[0].click();", t2);
					
					Report.updateTestLog(Action, "True buttion is selected 1st --Now selecting False Radio Button ",
							Status.DONE);
					
					
					Driver.findElement(By.xpath("//span[text()='Content Slots']")).click();
					
					wait.until(ExpectedConditions
							.visibilityOf(Driver.findElement(By.xpath("(//button[text()='Save'])[1]"))));

					Driver.findElement(By.xpath("(//button[text()='Save'])[1]")).click();
					
					Report.updateTestLog(Action, "unable to select radio  ",Status.FAIL);
					

				}
				
				
				
			} 
		} catch (Exception e) {
			
			Report.updateTestLog(Action, "unable to select radio  ",Status.FAIL);
			

		}
		
	}
	

	
	@Action(object = ObjectType.BROWSER, desc = "Validating the Unexpted error in New paragraph Check ", input = InputType.NO)
	public void unexpted_error_check() {
		
		try {
			Thread.sleep(2000);
		String error_text=	Driver.findElement(By.xpath("//span[text()='Unable to create: Unexpected error']")).getText();
		//Report.updateTestLog(Action, error_text + "  :  Data  ",Status.FAIL);
		Thread.sleep(1000);
		if(error_text.equalsIgnoreCase("Unable to create: Unexpected error"))
		{
			
			Report.updateTestLog(Action, "Unexpected error Present :Change Banner Name in PMP data sheet :ID_name ",Status.FAIL);
			Report.updateTestLog(Action, "Duplicate Name with Same Banner Name  ",Status.FAIL);
			
			Driver.findElement(By.xpath("//i[@class='z-icon-times']")).click();
			
			Report.updateTestLog(Action, "Closing the Window  ",Status.FAIL);
			
			
			Driver.quit();
		}else
		{
			
		}
			
			
			
		}catch (Exception e) {
			
			Report.updateTestLog(Action, " Clicked on DONE button successfully   ",Status.DONE);
			

		}
		
		
		
	}
	
	
	public void radio_visibility_check_F2T() {
		WebDriverWait wait = new WebDriverWait(Driver, 600);
		; 
		
		WebElement t1 = null;
		WebElement t2 = null;

		try {
			
			
			t1 = Driver.findElement(By.xpath("(//span[@class='z-radio z-radio-default']/input[@type='radio'])[4]"));
			//Report.updateTestLog(Action, t1.getClass(),Status.FAIL);
			((JavascriptExecutor) Driver).executeScript("arguments[0].scrollIntoView(true);", t1);
			Thread.sleep(500);
			boolean type = t1.isSelected();
		//	Report.updateTestLog(Action,  t1.isSelected() + " type",Status.FAIL);
			if (type == true)

			{
				try {
				t2 = Driver.findElement(By.xpath("(//span[@class='z-radio z-radio-default']/input[@type='radio'])[3]"));
				 
				((JavascriptExecutor) Driver).executeScript("arguments[0].click();", t2);
				
				Thread.sleep(2000);
				Report.updateTestLog(Action, "False buttion is selected for Testing --Now Selecting True Radio Button ",
						Status.DONE);
				
				Thread.sleep(2000);
				Driver.findElement(By.xpath("//span[text()='Content Slots']")).click();
				
				wait.until(ExpectedConditions
						.visibilityOf(Driver.findElement(By.xpath("(//button[text()='Save'])[1]"))));

				Driver.findElement(By.xpath("(//button[text()='Save'])[1]")).click();
				
				
				Thread.sleep(2000);
				Report.updateTestLog(Action, "Clicked on Save  Button ",Status.PASS);
				
				}catch (Exception e) {
					t2 = Driver.findElement(By.xpath("(//span[@class='z-radio z-radio-default']/input[@type='radio'])[3]"));
					 
					
					((JavascriptExecutor) Driver).executeScript("arguments[0].click();", t2);
					
					Report.updateTestLog(Action, "False buttion is selected for Testing --Now Selecting True Radio Button ",
							Status.DONE);
					
					
					Driver.findElement(By.xpath("//span[text()='Content Slots']")).click();
					
					wait.until(ExpectedConditions
							.visibilityOf(Driver.findElement(By.xpath("(//button[text()='Save'])[1]"))));

					Driver.findElement(By.xpath("(//button[text()='Save'])[1]")).click();
					
					Report.updateTestLog(Action, "unable to select radio  ",Status.FAIL);
					

				}
				
				
				
			} 
		} catch (Exception e) {
			
			Report.updateTestLog(Action, "unable to select radio  ",Status.FAIL);
			

		}
		
	}
	
	
	
	@Action(object = ObjectType.BROWSER, desc = "Validating the covid Visibility ", input = InputType.NO)
	public void covid_banner_check_False_true() {
		String banner = null;
		WebDriverWait wait = new WebDriverWait(Driver, 600);
		
		try {

			List<WebElement> bo_findElements = Driver.findElements(By.xpath("(//td[@class='yw-listview-cell z-listcell']//span[@class='yw-listview-cell-label z-label'])"));
		//	Report.updateTestLog(Action, bo_findElements.size() + "  ::  link avialbe   ", Status.DONE);
			
			
			for (int i = 1; i <= 9; i++) {
				
				banner = Driver.findElement(By.xpath(
						"(//td[@class='yw-listview-cell z-listcell']//span[@class='yw-listview-cell-label z-label'])["
								+ i + "]"))
						.getText();
				
				if(banner.equalsIgnoreCase("GSK Content Catalog : Staged"))
				{
					
					String visible= Driver.findElement(By.xpath(
							"(//td[@class='yw-listview-cell z-listcell']//span[@class='yw-listview-cell-label z-label'])["
									+ (i+1) + "]"))
							.getText();
					
					  Report.updateTestLog(Action, "  GSK Content Catalog : Staged value is displyed   ", Status.PASS);
					
					  Report.updateTestLog(Action, visible+ "  :value is displyed   ", Status.PASS);
					  
					  try {
					if(visible.equalsIgnoreCase("false"))
						
					{
						
						
						Driver.findElement(By.xpath(
								"(//td[@class='yw-listview-cell z-listcell']//span[@class='yw-listview-cell-label z-label'])["
										+ i + "]"))
								.click();
						 
						Thread.sleep(5000);
						
						 Report.updateTestLog(Action, "  GSK Content Catalog : Staged value is TRUE making it False for Testing   ", Status.PASS);
						 
						
						
						
						
							 wait.until(ExpectedConditions
						 .visibilityOf(Driver.findElement(By.xpath("//button[@ytestid='northButton']")
						  )));
						 
						 Driver.findElement(By.xpath("//button[@ytestid='northButton']")).click();	
						 
						 Thread.sleep(5000);
						 
						 radio_visibility_check_F2T();
							
						
					}
					else
					{
						
						wait.until(ExpectedConditions
								 .visibilityOf(Driver.findElement(By.xpath("//button[@ytestid='northButton']")
								  )));
								 
								 Driver.findElement(By.xpath("//button[@ytestid='northButton']")).click();	
								 
								 Thread.sleep(5000);
						 Report.updateTestLog(Action, "  Comming to else part   ", Status.PASS);
								
						
					}
					
					  }catch (Exception e) {
							Report.updateTestLog(Action, "Faling at true if condition  ", Status.FAIL);
						}

					 
				}
				
				
				
				
				
				
				
			}

		}
		catch (Exception e) {
			Report.updateTestLog(Action, "Unable to Fetch HelpCenter list details  ", Status.FAIL);
		}

		
	}	
	
	
	
	
	@Action(object = ObjectType.BROWSER, desc = "Validating the GSK Flu Vaccine Dashboard Total doses ", input = InputType.NO)
	public void flu_dashboard_Doses_check() {
		String D_doses=null, total_doses_sting=null;
		int dose_num=0;
		int t_doses = 0,total_doses=0;
		
		try {
			
		String 	Dash_text = Driver.findElement(By.xpath("//*[@id='content']//h1/span[2]")).getText();
			
		Report.updateTestLog(Action, "GSK Flu "+ Dash_text, Status.DONE);

			List<WebElement> dash_Doses = Driver.findElements(By.xpath("//*[@id='content']/div/div[2]//div[2]//div[1]/ul/li/a/p[2]"));
			
for (int i = 1; i <= dash_Doses.size(); i++) {
				
	D_doses = Driver.findElement(By.xpath("(//*[@id='content']/div/div[2]//div[2]//div[1]/ul/li/a/p[2])["+ i +"]")).getText();
	
	
	
	Thread.sleep(1000);		
	
	try {
	//Report.updateTestLog(Action,  D_doses +"  :  D_doses  ", Status.DONE);	
	
	D_doses=D_doses.replaceAll(",","");
	}catch (Exception e) {
		Report.updateTestLog(Action, "D_doses replaceAll  failing  ", Status.FAIL);
	}
	Thread.sleep(1000);		
	/*---------------------------------------------------------*/
	try {
	dose_num = Integer.parseInt(D_doses);
	Thread.sleep(1000);		
	//Report.updateTestLog(Action,  dose_num +"  :  dose_num :  ", Status.DONE);	
	
	}catch (Exception e) {
		Report.updateTestLog(Action, "dose_num parseInt  failing  ", Status.FAIL);
	}
	
	/*---------------------------------------------------------*/
	try {
	t_doses=dose_num+t_doses;
	Thread.sleep(1000);		
//	Report.updateTestLog(Action,  " t_doses  : " +t_doses, Status.DONE);		
				
}
	catch (Exception e) {
	Report.updateTestLog(Action, "t_doses addtion failing  ", Status.FAIL);
}
}
Report.updateTestLog(Action,  "Total doses after adding (Reserved+Available+Shipped+Waitlisted+cancelled) : " +t_doses, Status.DONE);	



try {
total_doses_sting= Driver.findElement(By.xpath("//*[@id='content']//div[2]/span")).getText();


String[] arrOfStr = total_doses_sting.split(" ");

total_doses_sting=arrOfStr[0];

total_doses_sting=total_doses_sting.replaceAll(",","");

total_doses = Integer.parseInt(total_doses_sting);

Report.updateTestLog(Action,  " Total Doses of chart Below :  " +total_doses_sting, Status.DONE);
}
catch (Exception e) {
	Report.updateTestLog(Action, "Total Doses of chart failing  ", Status.FAIL);
}




if(t_doses==total_doses)

{
	Report.updateTestLog(Action,  " Total Doses of chart Below and Doses after adding are EQUAL  " , Status.PASS);
}
else
{
	Report.updateTestLog(Action,  " Total Doses of chart Below and Doses after adding are Not EQUAL " , Status.FAIL);
}


			
		}
		catch (Exception e) {
			Report.updateTestLog(Action, "Total Doses of GSK flu Dashboard Issue ", Status.FAIL);
		}
		
		
		
				
		
		
	}
	
	

	@Action(object = ObjectType.BROWSER, desc = "Validating Flue Dashboard Important Messages check ", input = InputType.NO)
	public void flu_DB_ImportantMessages_Check() {
		
		WebDriverWait wait = new WebDriverWait(Driver, 600);
		
		
		String available=null,Shipped=null;
		int Shipped_int =0,available_int=0;
		try {
			
		
		 available =  Driver.findElement(By.xpath("//*[@id='content']//ul/li[2]/a/p[2]")).getText();
		Thread.sleep(1000);
		available=available.replaceAll(",","");
		Thread.sleep(500);
		available_int = Integer.parseInt(available);
		Thread.sleep(500);
				

		 Shipped =  Driver.findElement(By.xpath("//*[@id='content']//ul/li[3]/a/p[2]")).getText();
		Thread.sleep(1000);
		Shipped=Shipped.replaceAll(",","");
		Thread.sleep(500);
		Shipped_int = Integer.parseInt(Shipped);
		Thread.sleep(500);
		
		try {
		
		boolean im = Driver.findElement(By.xpath("//*[@id='content']//h3[contains(text(),'Important Messages')]")).isDisplayed();
		
	//	Report.updateTestLog(Action,  im +"  : Im value  " , Status.DONE);
		
		if(im==false)
		{
			
			
			Report.updateTestLog(Action,  " Important Messages is Not available in the page  " , Status.DONE);		
			
		}
		} catch (Exception e) {
			Report.updateTestLog(Action, "Important Messages is Not available in the page ", Status.DONE);
		}
		
		
		try {
		List<WebElement> IM_list = Driver.findElements(By.xpath("//*[@id='content']//div[3]//div[2]/ul/li/span"));
		
	
		int IM_list_size=IM_list.size();
		

	//int add=Shipped_int+available_int;
	
		if(IM_list_size==0)
		{
			Report.updateTestLog(Action,  " No bulletin points displayed under important message " , Status.DONE);	
			
		} else
		if(IM_list_size==1)
		{
			Report.updateTestLog(Action,  " One bulletin point displayed under important message " , Status.DONE);
			
			
			wait.until(ExpectedConditions
					.visibilityOf(Driver.findElement(By.xpath("(//*[@id='content']//li//a[text()=' Click here'])"))));
		//	Driver.findElement(By.xpath("(//button[text()='Yes, Remove'])[2]")).click();
			Driver.findElement(By.xpath("//*[@id='content']//li//a[text()=' Click here']")).click();
			
			Thread.sleep(6000);
			
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[text()='Complete']")));
			Thread.sleep(1000);
			Report.updateTestLog(Action,  " Clicked on Click Hear link navigated to the page " , Status.DONE);
			
			Driver.navigate().back();
			Thread.sleep(6000);
			
			
		}else
	if(IM_list_size==2)
		
	{
		
		Report.updateTestLog(Action,  " 2 bulletin points displayed under important message " , Status.PASS);	
		
		
		
	try
	{
		
		
		wait.until(ExpectedConditions
				.visibilityOf(Driver.findElement(By.xpath("(//*[@id='content']//li//a[text()=' Click here'])"))));
	
		Driver.findElement(By.xpath("//*[@id='content']//li//a[text()=' Click here']")).click();
		
		Thread.sleep(6000);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[text()='Complete']")));
		Thread.sleep(1000);
		Report.updateTestLog(Action,  " Clicked on Click Hear link navigated to the page " , Status.DONE);
		
		Driver.navigate().back();
		Thread.sleep(6000);
		
		wait.until(ExpectedConditions
				.visibilityOf(Driver.findElement(By.xpath("(//*[@id='content']//li//a[text()=' Click here'])[2]"))));
	
		Driver.findElement(By.xpath("(//*[@id='content']//li//a[text()=' Click here'])[2]")).click();
		
		Thread.sleep(6000);
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[text()='Available']")));
		Thread.sleep(1000);
		Report.updateTestLog(Action,  " Clicked on Click Hear link navigated to the page " , Status.DONE);
		
		
		
	} catch (Exception e) {
		Report.updateTestLog(Action, " Unable to Click on Click here link  ", Status.FAIL);
	}
	}
		} catch (Exception e) {
			Report.updateTestLog(Action, "bulletin points NOT displayed under Important Messages in GSK flu Dashboard  ", Status.DONE);
		}
		
		
		
} catch (Exception e) {
	Report.updateTestLog(Action, "Important Messages Issue in GSK flu Dashboard  ", Status.FAIL);
}
		

				
		
		
		
		
		
	}
	
	
	
	
	
	
	
	@Action(object = ObjectType.BROWSER, desc = "Validating Flue Dashboard Your Orders check ", input = InputType.NO)
	public void flu_DB_YourOrders_Check() {
		
		
WebDriverWait wait = new WebDriverWait(Driver, 600);
		
		
		
		try {
			
			
			
			
			
		}catch (Exception e) {
			Report.updateTestLog(Action, "Your Orders Issue in GSK flu Dashboard  ", Status.FAIL);
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
	
	}
	
	
	
	@Action(object = ObjectType.BROWSER, desc = "Title", input = InputType.NO)
	public void title_get()  {
		
		
		
		userData.putData("PMG_data", "Linkname1",Driver.getTitle());
		
		
	}
	
	
	
	
	@Action(object = ObjectType.BROWSER, desc = "PDF Name validations", input = InputType.YES)
	public void PDF_validation_check() {
		String pdf_name=Data;
		File theNewestFile = null;
		int pageCount=0;
		String[] strs=null;

		String s=null;
		String Loca =null;
		try {
			
			
		//Driver.get(Data);
		Driver.getCurrentUrl();
		
		Report.updateTestLog(Action,  Driver.getCurrentUrl() + " PDF url   ", Status.DONE);
		Thread.sleep(1000);
		
		
		
	
		Robot robot = new Robot();
				
		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_CONTROL);
		
		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_S);
		
		Thread.sleep(1000);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		
		Thread.sleep(1000);
		robot.keyRelease(KeyEvent.VK_S);
		
		Thread.sleep(1000);
		robot.keyPress(KeyEvent.VK_ENTER);
		
		Thread.sleep(1000);
		robot.keyRelease(KeyEvent.VK_ENTER);
		
							 
		
        File dir = new File("C:\\Users\\sxk79989\\Downloads");
          
        FileFilter fileFilter = new WildcardFileFilter("*.pdf");
      
        //Report.updateTestLog(Action, fileFilter.toString() +"   : fileFilter  " , Status.PASS);
        
        File[] files = dir.listFiles(fileFilter);
        
			/*
			 * for(int i=0;i<=files.length-1;i++) { Report.updateTestLog(Action, files[i]
			 * +"  : Files  " , Status.PASS); }
			 */
       
      
        if (files.length > 0 ) {
            /** The newest file comes first **/
        	
        	
            Arrays.sort(files, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
            
            
            theNewestFile = files[0];
        
            //Report.updateTestLog(Action, theNewestFile+ "  theNewestFile  ", Status.DONE);
            
        
         Loca =theNewestFile.toString();
        
        Thread.sleep(1000);
				
				
        
     s=    Loca.replace("\\", "//");
    
    
    
    
     strs = s.split("//");
    Thread.sleep(2000);
  
    
    if(strs[4].contains(Data))
    {
    	
    	 Report.updateTestLog(Action, strs[4] +" PDF is Dowload sucessfully with Data  " , Status.PASS);
    	 
    	    	 
    	 
    	 
    	 Report.updateTestLog(Action, s, Status.DONE);
    	   
    	    
		  PDFUtil p = new PDFUtil();
		  pageCount = p.getPageCount(s);
		  Report.updateTestLog(Action,  "  PAGE Count of PDF :  "+pageCount, Status.DONE);
		  Report.updateTestLog(Action,  "   PDF  PAGE Contains Data:  "+pageCount, Status.PASS);
		  
    	
    }
    else
    {
    	Report.updateTestLog(Action," Getting Error in PDF Download ", Status.FAIL);
    	
    	
    }
    
    
    
 
				/*
				 * System.out.println(pageCount);
				 * 
				 * String text = p.getText(s);
				 */
			
			 
        
        

        }
        
        else
        {
        	
        	Report.updateTestLog(Action, "  PDF downloaded Failed and Getting Error   ", Status.FAIL);
        }
		
				
		
		
		
		
		
		
		
		
		
		
		
		}
		
		catch (Exception e) {
			Report.updateTestLog(Action, "PDF_validation_check Failing  ", Status.FAIL);
		}
		
		
		
		
	}
	
	
	@Action(object = ObjectType.BROWSER,desc = "Get Order Number and Navigating To Order History ",input = InputType.NO)
	public void getOrderNum_openOrder() throws ParseException {
		String[] split;
		String orderno ;

		WebDriverWait wait = new WebDriverWait(Driver, 600);
		
		
		
		try {
			
		orderno = Driver.findElement(By.xpath("//p[@class='order-to-title ']")).getText();
		split = orderno.split(" ");
		Thread.sleep(2000);
		orderno=split[split.length-1];
		Thread.sleep(2000);
		Report.updateTestLog(Action, "Order Number is  :  "+ orderno, Status.PASS);
		
		
		
		Driver.findElement(By.xpath("//a[@id='account-active']")).click();
		
		wait.until(ExpectedConditions
				.visibilityOf(Driver.findElement(By.xpath("//a[text()='Order History']"))));
		Report.updateTestLog(Action, " Account Page ", Status.PASS);
		
		
		Driver.findElement(By.xpath("//a[text()='Order History']")).click();
		
		wait.until(ExpectedConditions
				.visibilityOf(Driver.findElement(By.xpath("//input[@id='search_text_order']"))));
		
		Report.updateTestLog(Action, "Navigated to  Order History Page ", Status.PASS);
		
		
		Driver.findElement(By.xpath("//input[@id='search_text_order']")).sendKeys(orderno);
		
		Driver.findElement(By.xpath("//button[@id='searchtextBtn_order']//span[@class='glyphicon glyphicon-search']")).click();
		
		
		
		Report.updateTestLog(Action, " Order History Page  Search completed with Order No", Status.DONE);
		
		wait.until(ExpectedConditions
				.visibilityOf(Driver.findElement(By.xpath("//*[@id='content']//div[6]//div[6]/a[contains(text(),'"+orderno+"')]"))));
		
		Driver.findElement(By.xpath("//*[@id='content']//div[6]//div[6]/a[contains(text(),'"+orderno+"')]")).click();
		
		Report.updateTestLog(Action, " Clicked on Order No " +orderno , Status.DONE);
		
		wait.until(ExpectedConditions
				.visibilityOf(Driver.findElement(By.xpath("//h4//label[@id='order-number']"))));
		
		
		
		String num=Driver.findElement(By.xpath("//h4//label[@id='order-number']")).getText();
		
		
		if(num.equalsIgnoreCase(orderno))
		{
			Report.updateTestLog(Action, " Navigated to Order Details Page ", Status.DONE);
			
		}
		
		
		
		
		
		}catch(Exception e){
			Report.updateTestLog(Action, " Navigated to Order Details Page ", Status.FAIL);
			 
		}
		
	}
	
	
	
	@Action(object = ObjectType.BROWSER, desc = "Shopping cart removal", input = InputType.NO)
	public void clearShoppingCart_remove() {
		WebElement Element = Driver.findElement(By.xpath("//span[@class='yCmsComponent miniCart']/a[2]"));

		String[] qtyarray = Element.getText().split("\\D");

		int num = Integer.parseInt(qtyarray[1]);
		System.out.println(qtyarray[1]);

		if (!Element.getText().equals("(0)")) {
			Driver.findElement(By.xpath("//span[@class='yCmsComponent miniCart']")).click();

			for (int i = 1; i <= num; i++) {
				Driver.findElement(
						By.xpath("(//a[text()='Remove from cart'])[1]"))
						.click();
				WebDriverWait wait = new WebDriverWait(Driver, 600);
				wait.until(ExpectedConditions.visibilityOf(Driver
						.findElement(By.xpath("(//button[text()='Yes, Remove'])[2]"))));
				
				
				try {
				
				Report.updateTestLog(Action, " Clicked on   " +Driver.findElement(By.xpath("(//button[@id='removeProduct-close'])[2]")).getText(), Status.PASS);
				Driver.findElement(By.xpath("(//button[@id='removeProduct-close'])[2]")).click();
Driver.navigate().refresh();
				
				Thread.sleep(5000);
				}
				catch(Exception e){
					Report.updateTestLog(Action, " Unable to click on No, Don't remove  ", Status.FAIL);
					 
				}
				
				
				Driver.findElement(
						By.xpath("(//a[text()='Remove from cart'])[1]"))
						.click();
				
				
				wait.until(ExpectedConditions.visibilityOf(Driver
						.findElement(By.xpath("(//button[text()='Yes, Remove'])[2]"))));
				String s=Driver.findElement(By.xpath("(//button[text()='Yes, Remove'])[2]")).getText();
				
				Driver.findElement(By.xpath("(//button[text()='Yes, Remove'])[2]"))
				
						.click();
				
				Report.updateTestLog(Action, " Clicked on   " +s, Status.PASS);
				
			}

		} else {
			Report.updateTestLog(Action, "Cart is null ", Status.PASS);
		}

	}


	
	
}
