package userDefinedPackage;


import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileFilter;
import java.io.FileReader;
import java.io.FilenameFilter;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.Random;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.comparator.LastModifiedFileComparator;
import org.apache.commons.io.filefilter.WildcardFileFilter;
import org.eclipse.jetty.server.UserIdentity;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
//import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cognizant.cognizantits.engine.commands.General;
import com.cognizant.cognizantits.engine.core.CommandControl;
import com.cognizant.cognizantits.engine.support.Status;
import com.cognizant.cognizantits.engine.support.methodInf.Action;
import com.cognizant.cognizantits.engine.support.methodInf.InputType;
import com.cognizant.cognizantits.engine.support.methodInf.ObjectType;

import com.testautomationguru.utility.PDFUtil;


public class EcsUserDefined extends General {

	public EcsUserDefined(CommandControl cc) {
		super(cc);
	}


	@Action(object = ObjectType.BROWSER, desc = "Values should be in 1000, 1second =1000 [<Data>]", input = InputType.YES)
	public void thread_Sleep() throws InterruptedException {

		int time = Integer.parseInt(Data);
		Thread.sleep(time);

	}

	@Action(object = ObjectType.BROWSER, desc = "Get Download path from system", input = InputType.NO)
	public void downloadPath_Ecs() {
		
		
//		String s = Data;
//		String[] split = s.split(",");
//		String Sheetname = split[0].toString();
//		
//		String DownloadPath = split[1].toString();
		
		
		String property = System.getProperty("user.home");
		System.out.println(property);
		String replace = property.replace("\\", "\\\\");
		String path =replace+"\\\\Downloads";
				
		
//			userData.getData(Sheetname, DownloadPath);
//			userData.putData(Sheetname, DownloadPath, path);
			
			userData.getData("RegressionData", "Download Path");
			userData.putData("RegressionData", "Download Path", path);
	
		
	}

	@Action(object = ObjectType.BROWSER, desc = "Close Pending Req Popup", input = InputType.NO)
	public void pendingReqPopUpHandle_CA() {

		try {
			WebElement PendingReqPopUp = Driver.findElement(By.id("shiptoPendingOpen"));
			if (PendingReqPopUp.isDisplayed()) {
				Driver.findElement(By.id("cboxClose")).click();
			} else {
				System.out.println("PendingReqPopUp didn't display");
			} 
		} catch (Exception e) {
			System.out.println("PendingReqPopUp didn't display");
		}		
	}


	@Action(object = ObjectType.BROWSER, desc = "Verify Status Filter on Address Page", input = InputType.NO)
	public void verifyStatusFilterOnAddressPage_Ecs() {

		try {
			// Storing all the shipto status
			String[] shipToStatusList = {"ACTIVE","PENDING","INACTIVE","REQUESTED"};

			// Iterating through each status
			for (int i =1;i<=4;i++) {

				//Wait until page load is complete	
				WebDriverWait wait = new WebDriverWait(Driver,10);
				wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
						.executeScript("return document.readyState")));

				// Making all the status check boxes unchecked
				for (int j =1;j<=4;j++) {
					Driver.findElement(By.xpath("//div[@class='col-md-12 col-sm-12']/div["+j+"]/input")).click();
				}

				// Checking the respective status check boxes
				WebElement ChkBox = Driver.findElement(By.xpath("//div[@class='col-md-12 col-sm-12']/div["+i+"]/input"));
				ChkBox.click();

				// Get ship to count based of check box selection
				ArrayList<WebElement> list= new ArrayList<>(Driver.findElements(By.xpath("//div[@id='addressesList']/div[not(contains(@style, 'display: none;')) and @class='row addresslist-content accountManageAddressListTr']")));
				int totalMatchingShiptoCount = list.size();

				// Matching Shipto status with check box selected
				if(totalMatchingShiptoCount>0) {
					for (int k=1;k<=totalMatchingShiptoCount;k++) {
						String shipToStatus = Driver.findElement(By.xpath("//div[@id='addressesList']/div[not(contains(@style, 'display: none;')) and @class='row addresslist-content accountManageAddressListTr']["+k+"]/div[11]")).getText();

						if (shipToStatus.equalsIgnoreCase(shipToStatusList[i-1])) {
							Report.updateTestLog(Action, "ShipTo Status is "+ shipToStatus +" And checkbox selected is "+shipToStatusList[i-1], Status.PASS);
						}
						else {
							Report.updateTestLog(Action, "ShipTo Status is "+ shipToStatus +" And checkbox selected is "+shipToStatusList[i-1], Status.FAIL);
						}

					}
				}else {
					Report.updateTestLog(Action, shipToStatusList[i-1] + " checkbox selected but matching shipto is not found" , Status.PASS);
				}

				Driver.navigate().refresh();
			}

			Driver.navigate().refresh();


		} catch (Exception e) {
			System.out.println("Error encountered");
		}		
	}


	@Action(object = ObjectType.BROWSER, desc = "Verify Status Filter on Address Page", input = InputType.NO)
	public void ProductsPage_FilterValidation() {
		
		 WebDriverWait wait = new WebDriverWait(Driver, 50);
//		try {
			
			try {
			    WebElement selectElement = Driver.findElement(By.xpath("//*[@id='statusFilter-ECS']"));
			    Select select = new Select(selectElement);
			    List<WebElement> options = select.getOptions();

			    for (int i = 1; i < options.size(); i++) {
			        try {
			            System.out.println(options.get(i).getText());
			            select.selectByIndex(i);
			            
			            wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
			    				.executeScript("return document.readyState")));
		        	  
		        	  
		        	  
		        	  
		        	  showalldrpdown();
		  			
		 			 wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
		 	    				.executeScript("return document.readyState")));
		 			 
		 			 String s =Driver.findElement(By.xpath("//*[@id='statusFilter-ECS']//option[@selected='selected']")).getAttribute("value");
		        	  filterDropwonValidation(s);
			
			
			System.out.println(" Try block ended");
			            
			            
			        } catch (Exception e) {
			            // Handle StaleElementReferenceException here
			        	
//			        	Report.updateTestLog(Action,  "Error encountered"+e, Status.DONE);	
//			        
			        	
			        	selectElement = Driver.findElement(By.xpath("//*[@id='statusFilter-ECS']"));
					     select = new Select(selectElement);
					   options = select.getOptions();
			        	 System.out.println("Inside Catch block");
			        	
			        	 select.selectByIndex(i);
				            
				            wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
				    				.executeScript("return document.readyState")));
			        	  
			      	
			        	  
			        	  String s =Driver.findElement(By.xpath("//*[@id='statusFilter-ECS']//option[@selected='selected']")).getAttribute("value");
			        	  filterDropwonValidation(s);
			        	  
			        	
			        }
			    }
			} catch (Exception e) {
				Report.updateTestLog(Action,  "Error encountered"+e, Status.DONE);	
			}
	        	
	        	
		
					
		


		
		
		
		
		
	}
	
	public void filterDropwonValidation(String a)
	
	{
		try {  
			
			List<String> validStrings = Arrays.asList("Active", "Backordered", "Discontinued","Divested", "Miscellaneous", "OutOfStock");
			
		if(validStrings.contains(a))	
		{
			

      	 
      	  
List<WebElement>      	  Active=Driver.findElements(By.xpath("//div[contains(@class,'ECS_status plp-status-margin')][contains(text(),'" + a + "')]"));
//	String l= Active.get(1).getText();

WebElement ShowingCount=Driver.findElement(By.xpath("//*[@id='search_text_plp_page']/../../../div[1]"));

String listdata=Integer.toString(Active.size());

if(ShowingCount.getText().contains(listdata))
{

	Report.updateTestLog(Action,  a +" List Size  :: " +Active.size() +"   :: Matching with the Count of  "+ShowingCount.getText(), Status.PASS);
}
else
{
	Report.updateTestLog(Action,  a +" List Size  :: " +Active.size() +"   :: Not Matching with the Count of  "+ShowingCount.getText() , Status.FAIL);
}

		}
			
			
			
			
			
			
		}
	catch (Exception e) {
		System.out.println("Error encountered"+e);
		Report.updateTestLog(Action,  "Error encountered"+e, Status.DONE);	            
//        
}
	
		
		
	}
	
	
	
	public void showalldrpdown()
	
	{
		
		
		try {   
			System.out.println(" Try block showalldrpdown ");
			WebElement showpage=Driver.findElement(By.xpath("//*[@id='dropDownSlectedID']"));
		

			if(!showpage.getAttribute("value").contains("Show All"))
			{
    	  Select showpageselect = new Select(showpage);
    	         	  showpageselect.selectByVisibleText("Show All");
    	         	  
			}
    	     
			//System.out.println(" Try block showalldrpdown  Ended");
		} catch (Exception e) {
			
			System.out.println(" Catch block showalldrpdown ");
			
			Report.updateTestLog(Action,  "Show All Selected "+e, Status.DONE);
		}
		
		
		
	}
	
	
	
	
	
	@Action(object = ObjectType.BROWSER, desc = "Verify Status Filter on Address Page", input = InputType.NO)
	public void showPage_FilterValidation() {
		

		 WebDriverWait wait = new WebDriverWait(Driver, 50);
		
		
		try {

			WebElement showpage=Driver.findElement(By.xpath("//*[@id='dropDownSlectedID']"));
		    Select select = new Select(showpage);
		    List<WebElement> options = select.getOptions();

		    for (int i = 0; i < options.size(); i++) {
		        try {
		            System.out.println(options.get(i).getText());
		            select.selectByIndex(i);
		            
		            
		            wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
	 	    				.executeScript("return document.readyState")));
	 			
		            
		        	List<String> validStrings_Showpage = Arrays.asList("0", "10", "20","50");
//		            if(showpage.getAttribute("value").contains("10"))
		        	if(validStrings_Showpage.contains(showpage.getAttribute("value")))	
		    		
					{
		            	List<WebElement>      	  Active=Driver.findElements(By.xpath("//div[contains(@class,'ECS_status plp-status-margin')]"));
		            	WebElement ShowingCount=Driver.findElement(By.xpath("//*[@id='search_text_plp_page']/../../../div[1]"));

		            	String listdata=Integer.toString(Active.size());

		            	if(ShowingCount.getText().contains(listdata))
		            	{

		            		Report.updateTestLog(Action,  " List Size  :: " +Active.size() +"   :: Matching with the Count of  "+ShowingCount.getText(), Status.PASS);
		            		try {
		                        // Wait until the element is present and clickable
		                        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@id='downloadPLPLinkId']")));

		                        // Click on the element
		                        element.click();
		                        //
		                        Report.updateTestLog(Action,  element.getText()+ " clicked Sucessfully ", Status.DONE);
		                        Thread.sleep(40000);
		                        Download_Buttonvalidation();
		                    } catch (Exception e) {
		                        System.out.println("Element not found or not clickable");
		                        Report.updateTestLog(Action,  " Element not found or not clickable ", Status.DONE);
		                        e.printStackTrace();
		                    }
		            		
		            	}
		            	else
		            	{
		            		Report.updateTestLog(Action,  " List Size  :: " +Active.size() +"   :: Not Matching with the Count of  "+ShowingCount.getText() , Status.FAIL);
		            	}
		            	
					}  
		            
		            
		            
		            
		            
		            
		            
		        } catch (Exception e) {

		        	 showpage=Driver.findElement(By.xpath("//*[@id='dropDownSlectedID']"));
				     select = new Select(showpage);
				   options = select.getOptions();

		        	
select.selectByIndex(i);
		            
		            
		            wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
	 	    				.executeScript("return document.readyState")));
	 			
		            
		        	List<String> validStrings_Showpage = Arrays.asList("0", "10", "20","50");
//		            if(showpage.getAttribute("value").contains("10"))
		        	if(validStrings_Showpage.contains(showpage.getAttribute("value")))	
		    		
					{
		            	List<WebElement>      	  Active=Driver.findElements(By.xpath("//div[contains(@class,'ECS_status plp-status-margin')]"));
		            	WebElement ShowingCount=Driver.findElement(By.xpath("//*[@id='search_text_plp_page']/../../../div[1]"));

		            	String listdata=Integer.toString(Active.size());

		            	if(ShowingCount.getText().contains(listdata))
		            	{

		            		Report.updateTestLog(Action,  " List Size  :: " +Active.size() +"   :: Matching with the Count of  "+ShowingCount.getText(), Status.PASS);
		            	
		            	
		            		try {
		                        // Wait until the element is present and clickable
		                        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@id='downloadPLPLinkId']")));

		                        // Click on the element
		                        element.click();
		                        //
		                        Report.updateTestLog(Action,  element.getText()+ " clicked Sucessfully ", Status.DONE);
		                        Download_Buttonvalidation();
		                    } catch (Exception e1) {
		                        System.out.println("Element not found or not clickable");
		                        Report.updateTestLog(Action,  " Element not found or not clickable ", Status.DONE);
		                        e1.printStackTrace();
		                    }
		            	
		            	
		            	
		            	
		            	
		            	}
		            	else
		            	{
		            		Report.updateTestLog(Action,  " List Size  :: " +Active.size() +"   :: Not Matching with the Count of  "+ShowingCount.getText() , Status.FAIL);
		            	}
		            	
					}  
		            
		            
		        	
		        	
		        }
		    }
		} catch (Exception e) {
		    // Handle NoSuchElementException here
		}
	
		
		
	}
	
	
	
	
	

	@Action(object = ObjectType.BROWSER, desc = "Verifying the Product Data Row validation on ProductPage", input = InputType.YES)
	public void Product_DataValidation() {
		
		WebElement Prodname =null;
		List<WebElement> Rowsize ,Productlinks =null;
		WebDriverWait wait = new WebDriverWait(Driver,10);
		
//		
//		String s=Data;
//		Report.updateTestLog(Action, "Data   ::   "+s, Status.DONE);
		
		try
		{
			 Prodname =Driver.findElement(By.xpath("//a[contains(text(),'"+Data+"')]"));
			 Rowsize =Driver.findElements(By.xpath("//*[normalize-space()='"+Data+"']/../../..//div"));
			 
			 Report.updateTestLog(Action, "Prodname   ::   "+Prodname.getText(), Status.DONE);
			 
			 for(int i=1;i<=Rowsize.size()-1;i++)
				{
					
					
				String RowData=	Driver.findElement(By.xpath("(//a[normalize-space()='"+Data+"']/../../..//div)["+i+"]")).getText();
				
				if(i==1)
				{
					
					
			String img=	Driver.findElement(By.xpath("(//a[normalize-space()='"+Data+"']/../../../../div)["+i+"]/a/img")).getAttribute("class");
			
			
			if(img.contains("img-responsive"))
			{
				
				 Report.updateTestLog(Action, "Product Image dispalyed on the  Page   ", Status.PASS);

				Driver.findElement(By.xpath("(//img[@title='"+Data+"'])")).click();
				
				wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
						.executeScript("return document.readyState")));
				
				if	(Driver.findElement(By.xpath("//h1[contains(text(),'"+Data+"')]")).isDisplayed())
				{
					
					 
					
					Report.updateTestLog(Action, "Sucessfully Navigated to Product Details Page   "+Driver.findElement(By.xpath("//h1[contains(text(),'"+Data+"')]")).getText(), Status.PASS);
				
				Driver.navigate().back();
				wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
						.executeScript("return document.readyState")));
				
				}
				else
				{
					 Report.updateTestLog(Action, "Unable to Navigated to Product Details Page   ", Status.FAIL);
				}
				
			}
			
					
				}
				
				if(i==2)
				{
					
					
					Productlinks =Driver.findElements(By.xpath("(//a[normalize-space()='"+Data+"']/../../..//div)["+i+"]//a"));	
					
					
					for(int k=1;k<=Productlinks.size();k++)
					{
						try {
						
						String ProductRowData=	Driver.findElement(By.xpath("((//a[normalize-space()='"+Data+"']/../../..//div)["+i+"]//a)["+k+"]")).getText();
						
						
						if(ProductRowData.equalsIgnoreCase(Data))
						{
							
							
							Driver.findElement(By.xpath("((//a[normalize-space()='"+Data+"']/../../..//div)["+i+"]//a)["+k+"]")).click();
							
							wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
									.executeScript("return document.readyState")));
							
							if	(Driver.findElement(By.xpath("//h1[contains(text(),'"+Data+"')]")).isDisplayed())
							{
								
								 
								
								Report.updateTestLog(Action, "Sucessfully Navigated to Product Details Page   "+Driver.findElement(By.xpath("//h1[contains(text(),'"+Data+"')]")).getText(), Status.PASS);
							
							Driver.navigate().back();
							wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
									.executeScript("return document.readyState")));
							
							}
							else
							{
								 Report.updateTestLog(Action, "Unable to Navigated to Product Details Page   ", Status.FAIL);
							}
							
							
							
						}
						
						if((ProductRowData.equalsIgnoreCase("Prescribing Information"))||(ProductRowData.equalsIgnoreCase("Safety Data Sheet")))
						{
								Driver.findElement(By.xpath("((//a[normalize-space()='"+Data+"']/../../..//div)["+i+"]//a)["+k+"]")).click();
							
							wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
									.executeScript("return document.readyState")));
							 ArrayList<String> tabs = new ArrayList<String> (Driver.getWindowHandles());
							    Driver.switchTo().window(tabs.get(1));
							    
							    wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
										.executeScript("return document.readyState")));
								
							    System.out.println(Driver.getCurrentUrl());
							    
							    if(Driver.getCurrentUrl().contains("Prescribing_Information"))
							    { 
							    	Report.updateTestLog(Action, "Sucessfully Clickd on Prescribing Information Link and Navigated to the Product PDF page " , Status.PASS);
							    
							    	
							    	
							    	 Driver.close();
									  Driver.switchTo().window(tabs.get(0));
									  wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
												.executeScript("return document.readyState")));
										
							    }
							    else
							    if((Driver.getCurrentUrl().contains("https://www.msds-gsk.com/Default.aspx"))&&(Driver.findElement(By.xpath("//h1[contains(text(),'Safety Data Sheets &')]")).getText().contains("Safety Data Sheets")))
							    { 
							    	
							    	
							    	Report.updateTestLog(Action, "Sucessfully Clickd on Safety Data Sheet Link and Navigated to the Safety Data Sheets & Environmental Risk Assessments page " , Status.PASS);
							    
							    	
							    	
							    	 Driver.close();
									  Driver.switchTo().window(tabs.get(0));
									  wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
												.executeScript("return document.readyState")));
										
							    }
							    else
							    {
							    	Report.updateTestLog(Action, "Link Verification Failed unable to click " , Status.FAIL);
							    	
							    }
							  
							
							
							
							
							
						}
						
						} catch (Exception e) {
							
					String		ProductRowData=	Driver.findElement(By.xpath("((//a[normalize-space()='"+Data+"']/../../..//div)["+i+"]//a)["+k+"]")).getText();
							
							
					if((ProductRowData.equalsIgnoreCase("Prescribing Information"))||(ProductRowData.equalsIgnoreCase("Safety Data Sheet")))
					{
						Driver.findElement(By.xpath("((//a[normalize-space()='"+Data+"']/../../..//div)["+i+"]//a)["+k+"]")).click();
						
						wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
								.executeScript("return document.readyState")));
						
						
						 ArrayList<String> tabs = new ArrayList<String> (Driver.getWindowHandles());
						    Driver.switchTo().window(tabs.get(1));
						    
						    wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
									.executeScript("return document.readyState")));
							
						    System.out.println(Driver.getCurrentUrl());
						    
						    if(Driver.getCurrentUrl().contains("Prescribing_Information"))
						    { 
						    	Report.updateTestLog(Action, "Sucessfully Clickd on Prescribing Information Link and Navigated to the Product PDF page " , Status.PASS);
						    
						    	
						    	
						    	 Driver.close();
								  Driver.switchTo().window(tabs.get(0));
								  wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
											.executeScript("return document.readyState")));
									
						    }
						    else
						    							
						    if((Driver.getCurrentUrl().contains("https://www.msds-gsk.com/Default.aspx"))&&(Driver.findElement(By.xpath("//h1[contains(text(),'Safety Data Sheets &')]")).getText().contains("Safety Data Sheets")))
						    { 
						    	
						    	
						    	Report.updateTestLog(Action, "Sucessfully Clickd on Safety Data Sheet Link and Navigated to the Safety Data Sheets & Environmental Risk Assessments page " , Status.PASS);
						    
						    	
						    	
						    	 Driver.close();
								  Driver.switchTo().window(tabs.get(0));
								  wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
											.executeScript("return document.readyState")));
									
						    }
						    else
						    {
						    	Report.updateTestLog(Action, "Link Verification Failed unable to click " , Status.FAIL);
						    	
						    }
						  
						
						
						
						
						
					}
										
							
							
							
							
							
							
						}
						
					}
					
					
					
				}
					
				Report.updateTestLog(Action, "Product Details are    ::   "+RowData, Status.DONE);
				
				
				
				
					
				}
			
			 
			} catch (Exception e) {
				
				
				Report.updateTestLog(Action, "Error file  "+e, Status.DONE);
		
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
	
	
	
	
	
	public void Download_Buttonvalidation() {
		String property = System.getProperty("user.home");
		System.out.println(property);
		String replace = property.replace("\\", "\\\\");
		String path =replace+"\\\\Downloads";
		
		 try {
			 //Thread.sleep(10000);
				//String path=userData.getData("RegressionData", "Download Path");
	            File dir = new File(path);
	            if (dir.exists()) {
	                // Filter to find files that start with .csv
	                FilenameFilter csvFilter = new FilenameFilter() {
	                    public boolean accept(File dir, String name) {
	                        String lowercaseName = name.toLowerCase();
	                        if (lowercaseName.endsWith(".csv")) {
	                            return true;
	                        } else {
	                            return false;
	                        }
	                    }
	                };

	                File[] files = dir.listFiles(csvFilter);
	                if (files.length == 0) {
	                	
	                	Report.updateTestLog(Action, "No .csv files found  ", Status.DONE);
	                    System.out.println("No .csv files found");
	                } else {
	                    File lastModifiedFile = files[0];
	                    for (int i = 1; i < files.length; i++) {
	                        if (lastModifiedFile.lastModified() < files[i].lastModified()) {
	                            lastModifiedFile = files[i];
	                        }
	                    }
	                    System.out.println("Last downloaded file: " + lastModifiedFile.getName());
	                    
	                    Report.updateTestLog(Action, "Last downloaded file: " + lastModifiedFile.getName(), Status.DONE);

	                    // Validate if the file name contains the current date
	                    String pattern = "yyyyMMdd";
	                    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
	                    String date = simpleDateFormat.format(new Date());
	                    
	                    String fileName = "download_products__" +date;
	                    System.out.println("Simple  downloaded file: " + fileName);
	                    Report.updateTestLog(Action, "Simple  downloaded file: " + fileName, Status.DONE);
	                    if (lastModifiedFile.getName().contains(fileName)) {
	                    	Report.updateTestLog(Action, "File name matches", Status.DONE);
	                        System.out.println("File name contains the current date");
	                        
	                        // Count the number of rows in the file excluding the header
		                    BufferedReader reader = new BufferedReader(new FileReader(lastModifiedFile));
		                    int lines = 0;
		                    while (reader.readLine() != null)
		                    	{lines++;
		                    	}
		                    reader.close();
		                    	
		                    System.out.println("Number of rows excluding header: " + (lines - 1));     
		                    
		                    Report.updateTestLog(Action, "Number of rows Present in the page excluding header : " + (lines - 1), Status.DONE);  
	                        
		                    	
	                        
	                        
	                        
	                    } else {
	                        System.out.println("File name does not contain the current date");
	                        Report.updateTestLog(Action, "File name does not contain the current date", Status.DONE);
	                    }
	                    
	                    
	                   
	                    
	                    
	                    
	                }
	            } else {
	                System.out.println("Directory does not exist");
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
		
		
		
		
	
	
	@Action(object = ObjectType.BROWSER, desc = "Clicking on the names of Product details in Staged Like GSK,Properties on BackOffice Page", input = InputType.YES)
	public void name_Click_BO() {
		
		String nametoSelect=Data;
		String name=null;
		
		
		try {
			
			List<WebElement> areaName=Driver.findElements(By.xpath("//span[@class='yw-editorarea-tablabel z-label']"));
			
			 WebElement leftSideArrow = Driver.findElement(By.xpath("(//div[contains(@class,'right-scroll')]//i[@class='z-icon-chevron-right'])[1]"));
			
			  while (true) {
			        for (WebElement textLink : areaName) {
			            if (textLink.getText().equals(nametoSelect)) {
			                // Click the text link and return
			                textLink.click();
			                return;
			            }
			        }
			        leftSideArrow.click();

			        // Wait for the page to load
			       
			     // Wait for the page to load
			        try {
			            Thread.sleep(2000); // replace with a more robust wait condition if necessary
			        } catch (InterruptedException e) {
			            e.printStackTrace();
			        }

			        // Refresh the list of text links
			        areaName = Driver.findElements(By.xpath("//span[@class='yw-editorarea-tablabel z-label']")); // replace with actual class name	
					        
			
			
		}
			
			
			
			
			
			
			
			
		}catch(Exception e) {
			
			
		}
		
		
		
		
		
		
	}
	

	
	
	@Action(object = ObjectType.BROWSER, desc = "Clicking on Processes and Chekking for FINISHED status in BackOffice Page", input = InputType.NO)
	public void process_link_Check_BO() {
		
		
	
	    WebDriverWait wait = new WebDriverWait(Driver, 30); // 30 seconds timeout
	  

	    

        try {
        	Driver.findElement(By.xpath("//*[contains(@title,'Processes')]")).click();
        	
            Driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            

            while (true) {
                try {
                	
                    WebElement element = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("((//div[@class='yw-processes-list-item-content z-div'])[1]//span)[4]")));
                    String dateTimeFromPage = element.getText();
                    
                    
    	            //String[] InputData = dateTimeFromPage.split("finished ");
    	    		
                    String webPageTime = dateTimeFromPage.split(",")[2].trim(); 
    	            
    	            SimpleDateFormat dateFormat = new SimpleDateFormat("h:mm a");
    	            String systemTime = dateFormat.format(new Date());
    	            
    	       //     Report.updateTestLog(Action, "systemTime :: " +systemTime +"   dateTimeFromPage ::: "+dateTimeFromPage ,  Status.DONE);
    	            System.out.println("systemTime :: " +systemTime +"   dateTimeFromPage ::: "+dateTimeFromPage );
    	            
    	            Date webPageDateTime = dateFormat.parse(webPageTime);
    	            Date systemDateTime = dateFormat.parse(systemTime);
    	            
    	         
    	            
    	            System.out.println("webPageDateTime :: " +webPageDateTime +"   systemDateTime ::: "+systemDateTime);
    	            
				
                    
    	            if (webPageDateTime.compareTo(systemDateTime) >= 0) {
    	                System.out.println("Webpage time is greater than or equal to the system time.");
    	                
    	                WebElement statusElement = Driver.findElement(By.xpath("((//div[@class='yw-processes-list-item-content z-div'])[1]//span)[1]"));
    	                String elementText = statusElement.getText();
    	                Report.updateTestLog(Action, "elementText :: " +elementText, Status.PASS); 
    	                
    	                if ((elementText.equalsIgnoreCase("Finished")  )||(elementText.equalsIgnoreCase("finished ")))
    	                {
    	                	
    	                	Report.updateTestLog(Action, "FINISHED", Status.PASS); 
    		                
    		                Driver.findElement(By.xpath("//*[contains(@class,'close-btn z-a')]")).click();
    		                break;
                      }
    	                
    	                
    	            } 
//    	            
                    
                    
                } catch (TimeoutException e) {
                    System.out.println("Waiting for element to be present on the page...");
                } catch (ParseException e) {
                    System.out.println("An error occurred while parsing the time: " + e.getMessage());
                } 
                Thread.sleep(10000);
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        } 
	    
	    
	    
	    
	    
	}
	
	
	@Action(object = ObjectType.BROWSER, desc = "Clicking on Solr Config for Backoffice and waiting it to completedd in BackOffice Page", input = InputType.NO)
	public void SolrConfigBackoffice_Check() {
		
		WebDriverWait wait = new WebDriverWait(Driver,30);
		try {
		WebElement index=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//*[@valign='top']//div[@class='cng-action-text z-div']//span[contains(text(),'Index')])[1]")));
		
		 
		index.click();
		
		Report.updateTestLog(Action, "Clicked on INDEX ", Status.PASS);
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("	//*[contains(text(),'Create New SolrIndexerOperationWizard')]")));
		
		try {
		
		WebElement startbutton=Driver.findElement(By.xpath("//button[contains(text(),'START')]"));
		if(startbutton.getText().equalsIgnoreCase("START"))
			
		{
			startbutton.click();
			
			Report.updateTestLog(Action, "Clicked on START ", Status.PASS);
			
			// Wait for up to 60 seconds, checking every 10 seconds
			try {
			
            WebDriverWait wait1 = new WebDriverWait(Driver, 60, 10000);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(), 'Indexing finished successfully')]")));	
           
            Report.updateTestLog(Action, "Indexing finished successfully Displayed ", Status.PASS);
			
			Driver.findElement(By.xpath("//*[contains(text(),'Done')]")).click();
            
//			if(wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(), 'Indexing finished successfully')]"))).isDisplayed())
//			{
//				Report.updateTestLog(Action, "Indexing finished successfully Displayed ", Status.PASS);
//				
//				Driver.findElement(By.xpath("//*[contains(text(),'Done')]")).click();
//				
//				
//			}
			}catch (TimeoutException e) {
                System.out.println("Waiting for text to be visible...");
            } catch (Exception e) {
                System.out.println("An error occurred: " + e.getMessage());
              
            }
				
			
		}
		} catch (Exception e) {
			
			Report.updateTestLog(Action, "Unable to get Start details "+e, Status.FAIL);
            
        } 
				
		
		
		
		
		
		} catch (Exception e) {
            e.printStackTrace();
        } 
		
		
	
	}
	
	

	
	
	@Action(object = ObjectType.BROWSER, desc = "RadioButton Selection WS & CH  ", input = InputType.YES)
	public void ws_Ch_Radiobutton_Selection() {

		 WebDriverWait wait = new WebDriverWait(Driver, 60);
		 String[] InputData = Data.split(",");
			String Name,shiptoname=null;
			
			try {
			 Name = InputData[0];
			 shiptoname = InputData[1];
			 Report.updateTestLog(Action, Name+" :: "+shiptoname, Status.DONE);
			}
			catch (Exception e) {
				 Name = InputData[0];
	           
	        } 
			
			
		try {
			
		String title= Driver.findElement(By.xpath("//p[contains(@class,'registerPageHeading')]")).getText();
		
		if(Driver.findElement(By.xpath("//p[contains(@class,'registerPageHeading')]")).isDisplayed())
		{
			
			Driver.findElement(By.xpath("//label[normalize-space()='"+Name+"']/../input")).click();
			
			Report.updateTestLog(Action, Name +"  Radio button Selected", Status.PASS);
			
			
			
			
			if(("GSK Authorized Wholesaler/Distributor").contains(Name))
			{
				
		            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//label[contains(@class,'selectLabelWidth')]")));	
		           
		            Report.updateTestLog(Action, "Select a Wholesaler  Displayed ", Status.PASS);
		            
		            Select wholesaler= new Select(Driver.findElement(By.xpath("//select[@name='customerID']")));
		            
		            wholesaler.selectByVisibleText(shiptoname);
		            
		            Driver.findElement(By.xpath("//button[@type='submit']")).click();
		            
		            RegistrationConfirmAccountDetails();
		            
		            Driver.findElement(By.xpath("//button[normalize-space()='Continue']")).click();
		            
		            
		            thanksforRegistring();
				
				
			}else if(Name.equalsIgnoreCase("GSK Authorized Contract Holder"))
			{
				
				
			}
			
			
		}
		
		
		
			
		}
		catch (Exception e) {
            e.printStackTrace();
        } 
		
		
	}
		
	
	

	public void RegistrationConfirmAccountDetails()
	
	{
		try {
			
			WebElement  title=Driver.findElement(By.xpath("//div[@class='sucess-font']"));
			
			Report.updateTestLog(Action, title.getText(), Status.PASS);
			
			List<WebElement> names=Driver.findElements(By.xpath("//div[@class='form-group']//input"));
			
			for (WebElement name : names) {
				
				Report.updateTestLog(Action, "Select a Wholesaler Displayed " +name.getAttribute("value"), Status.DONE);
	        }
			
				
			
		}catch (Exception e) {
            e.printStackTrace();
        } 
		
		
	}
	
	public void thanksforRegistring()
	{ List<String> strings = new ArrayList<>();

	// Wait until page load is complete
	WebDriverWait wait = new WebDriverWait(Driver, 10);
//	 WebElement emailInput =null;
//	 WebElement passwordInput=null;
//	 WebElement loginButton=null;
		 try {
		
		String title =Driver.findElement(By.xpath("//p[@class='sucess-font']")).getText();
		
		Report.updateTestLog(Action, title+ "  Displayed " , Status.PASS);
		
		   List<WebElement> elements = Driver.findElements(By.xpath("//main[@id='content']//p//a")); 
	       
				for (WebElement element : elements) {
					strings.add(element.getText());
				}

	        // Navigate to login page
	       
				Driver.findElement(By.xpath("//a[@id='signOutLink']")).click();
				
				wait.until(webDriver -> "complete"
						.equals(((JavascriptExecutor) webDriver).executeScript("return document.readyState")));
	        // Try each string as email until login is successful
				
				Driver.findElement(By.xpath("//a[contains(normalize-space(text()),'Log-in')]")).click();
				
	        for (String s : strings) {
	        	Driver.get("https://global-uat1-cust-ecs.ecommerce.gsk.com/gskstorefront/gskEcs/en_US/USD/");
	        	Driver.findElement(By.xpath("//a[contains(normalize-space(text()),'Log-in')]")).click();
	        	
	        	for (int i=0;i<strings.size();i++) {
	        	
	        	try {
	            WebElement emailInput = Driver.findElement(By.id("j_username"));
	            WebElement passwordInput = Driver.findElement(By.id("j_password")); 
	            WebElement loginButton = Driver.findElement(By.xpath("//button[@type='submit']"));
	            
	            emailInput.clear();
	            emailInput.sendKeys(s);
	            passwordInput.sendKeys("temp123"); // replace with your actual password
	            loginButton.click();
// Wait until page load is complete
				
				wait.until(webDriver -> "complete"
						.equals(((JavascriptExecutor) webDriver).executeScript("return document.readyState")));
				// Wait for the page to load
                wait.until(ExpectedConditions.stalenessOf(loginButton));
	         
                try {
	            
	                // Wait for the error message to appear
	                Thread.sleep(1000);
	                WebElement errorMessage = Driver.findElement(By.xpath("//div[@class='alert negative']")); 

	                // If error message is displayed, clear the email input
	                if (errorMessage.isDisplayed()) {
	                   
	                    continue;
	                }
	                
                } catch (Exception e) {
                	 System.out.println("Faild with NoSuchElementException" + e.getMessage());
	                }
	                if (!Driver.findElements(By.xpath("//a[@id='signOutLink']")).isEmpty()) {
		            	
		            	Report.updateTestLog(Action,  " Logged Successfully with email  "+s , Status.PASS);
		            	
		                break;
		            }                
	                
	                
	                
	                
	            } catch (StaleElementReferenceException e) {
	                e.printStackTrace();
	                if (i+1 == strings.size()) {
                        // If it still fails after 3 attempts, print an error message and break the loop
                        System.out.println("Failed to perform action due to stale element: " + e.getMessage());
                        Report.updateTestLog(Action,  " Email validation getting faild " +e, Status.FAIL);
                        break;
                    }
	               
	                
	               
	            }

	        	
	            // If sign out link is displayed, break the loop
	           
	            
	        	}
	        	
//	        	if (!Driver.findElements(By.xpath("//a[@id='signOutLink']")).isEmpty()) {
//	            	
//	            	Report.updateTestLog(Action,  " Logged Successfully with email  "+s , Status.PASS);
//	            	
//	                break;
//	            }
	        	
	        	
		 
	        }
	        
		 }
		 catch (Exception e) {
			 
			// Report.updateTestLog(Action,  " "+e , Status.FAIL);
			 System.out.println("Faild with " + e.getMessage());
		 }
		
		
		
		
	}
	
	
	
	
	
	
	
	@Action(object = ObjectType.BROWSER, desc = "Giving Access or Rejecting user ", input = InputType.YES)
	public void UserAcceptence_Rejecting() {
		
		String access=Data;

		 WebDriverWait wait = new WebDriverWait(Driver, 60);
		
		if(Driver.findElement(By.xpath("//*[contains(text(),'My Account')]")).isDisplayed())
		{
			Report.updateTestLog(Action,  " Logged in to Page  " , Status.PASS);
			
			Driver.findElement(By.xpath("//*[contains(text(),'My Account')]")).click();
			
			
			wait.until(webDriver -> "complete"
			.equals(((JavascriptExecutor) webDriver).executeScript("return document.readyState")));

			Report.updateTestLog(Action,  " Navigated to My Account Page " , Status.PASS);
			
			Driver.findElement(By.xpath("//a[normalize-space()='User Management']")).click();	
			
			
			String email=null;
			
			try {
				
				email=userData.getData("Registration and Add New Account", "Email");
				
				Driver.findElement(By.xpath("//a[contains(text(),'"+email+"')]/../../div[2]")).click();
				
				if(access.contains("Approve"))
				{
					
					if(Driver.findElement(By.xpath("//*[contains(text,'Approve User')]")).isDisplayed())
					{
						Report.updateTestLog(Action,  " Approving User " , Status.PASS);
						
						Driver.findElement(By.xpath("//*[contains(text,'Approve User')]")).click();
					}
					
					
					
				}
				else if(access.contains("Reject")){
					
					if(Driver.findElement(By.xpath("//*[contains(text,'Reject User')]")).isDisplayed())
					{
						Report.updateTestLog(Action,  " Rejecting User " , Status.PASS);
						
						Driver.findElement(By.xpath("//*[contains(text,'Reject User')]")).click();
						
						
						
						String expectedENMsg = "Are you sure you want to reject the user ?";
					

						String rejectMsg = Driver.findElement(By.xpath("//div[@id='cboxWrapper']//p[@class='rejectUserMessage']")).getText().trim();

						if (rejectMsg.equalsIgnoreCase(expectedENMsg)) {
							Report.updateTestLog(Action, "The Reject Pop-up Text is correctly Disaplyed in English", Status.PASS);
						}  else {
							Report.updateTestLog(Action,
									"The Reject Pop-up Text is correctly Not Correct Disaplyed and is: " + rejectMsg, Status.PASS);
						}

						WebElement btnNO = Driver
								.findElement(By.xpath("//div[@id='cboxWrapper']//input[contains(@onclick,'cancelUrl')]"));
						WebElement btnYES = Driver
								.findElement(By.xpath("//div[@id='cboxWrapper']//input[contains(@onclick,'rejectUser')]"));

						if (btnNO.isDisplayed() && btnYES.isDisplayed()) {
							Report.updateTestLog(Action, "The Reject Pop-up has both Yes and No Option Displayed", Status.PASS);
						} else {
							Report.updateTestLog(Action, "The Reject Pop-up dosn't have both Yes and No Option Displayed", Status.FAIL);
						}

						btnYES.click();
						try {
							Thread.sleep(1000);
						} catch (InterruptedException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}

						if (Driver.findElements(By.xpath("//a[text()='" + email + "']")).isEmpty()) {
							Report.updateTestLog(Action,
									"The User " + email + " was successfully rejected and No Longer Displayed in User Management List",
									Status.PASS);
						} else {
							Report.updateTestLog(Action, "The User " + email + " was not successfully rejected", Status.FAIL);
						}
						
									
						
						
						
						
						
						
						
						
						
					}
					
					
					
				}
				
				
				
				
			}
			catch (Exception e) {
				
				email=userData.getData("Registration and Add New Account", "Email");
				
				String path = "//*[contains(@href,'"+email+"')]/../..//select";

				WebElement user = Driver.findElement(By.xpath(path));
				Select opt = new Select(user);
				
				
				if(access.contains("Approve"))
				{
					
					opt.selectByVisibleText("Approve User");
					
					
					
				}
				else if(access.contains("Reject")){
					
					opt.selectByValue("rejectUser");

					String expectedENMsg = "Are you sure you want to reject the user ?";
					String expectedFRMsg = "Êtes-vous certain de vouloir refuser l’utilisateur?";

					String rejectMsg = Driver.findElement(By.xpath("//div[@id='cboxWrapper']//p[@class='rejectUserMessage']"))
							.getText().trim();

					if (rejectMsg.equals(expectedENMsg)) {
						Report.updateTestLog(Action, "The Reject Pop-up Text is correctly Disaplyed in English", Status.PASS);
					} else if (rejectMsg.equals(expectedFRMsg)) {
						Report.updateTestLog(Action, "The Reject Pop-up Text is correctly Disaplyed in French", Status.PASS);
					} else {
						Report.updateTestLog(Action,
								"The Reject Pop-up Text is correctly Not Correct Disaplyed and is: " + rejectMsg, Status.PASS);
					}

					WebElement btnNO = Driver
							.findElement(By.xpath("//div[@id='cboxWrapper']//input[contains(@onclick,'cancelUrl')]"));
					WebElement btnYES = Driver
							.findElement(By.xpath("//div[@id='cboxWrapper']//input[contains(@onclick,'rejectUser')]"));

					if (btnNO.isDisplayed() && btnYES.isDisplayed()) {
						Report.updateTestLog(Action, "The Reject Pop-up has both Yes and No Option Displayed", Status.PASS);
					} else {
						Report.updateTestLog(Action, "The Reject Pop-up dosn't have both Yes and No Option Displayed", Status.FAIL);
					}

					btnYES.click();
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

					if (Driver.findElements(By.xpath("//a[text()='" + email + "']")).isEmpty()) {
						Report.updateTestLog(Action,
								"The User " + email + " was successfully rejected and No Longer Displayed in User Management List",
								Status.PASS);
					} else {
						Report.updateTestLog(Action, "The User " + email + " was not successfully rejected", Status.FAIL);
					}
					
				
	         }
			
			
			
			
			
			
			
		}
		}
		
		
		
		
		
		
		
		
	}
	
	@Action(object = ObjectType.BROWSER, desc = "Perform Click on the Custom Xpath as Input", input = InputType.YES)

	public void clickCustomXpath_ecs() {
	      
	      Driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	      WebElement element = Driver.findElement(By.xpath(Data));
	      element.click();
	      System.out.println(Data);
	      Report.updateTestLog(Action, "The Click is Performed on the custom xpath", Status.PASS);
	      
	}
	
	
	
	@Action(object = ObjectType.BROWSER, desc = "Validating the Customer Contract Eligibility _Custmore search", input = InputType.YES)

	public void CustomerContractEligibility_ecs() {
		WebDriverWait wait = new WebDriverWait(Driver,30);
		
		
		String [] details=Data.split(",");
		String drpdown,textbox,name=null;
		try {
		 drpdown=details[0];
		 textbox=details[1];
		 name=details[2];
		
		}
		catch (Exception e1) {
			drpdown=details[0];
			 textbox=details[1];
			
		}
		
		WebElement cce=Driver.findElement(By.xpath("//a[normalize-space()='Customer Contract Eligibility']"));
		WebElement custRefIdopts=Driver.findElement(By.xpath("//select[@id='customerReferenceIDOptions']"));
		WebElement custRefField=Driver.findElement(By.xpath("//input[@id='customerReferenceIDField']"));
		WebElement bulkSearchRefeIDField=Driver.findElement(By.xpath("//textarea[@id='bulkSearchReferenceIDField']"));
		WebElement custNameOptions=Driver.findElement(By.xpath("//select[@id='customerNameOptions']"));
		WebElement custNameField=Driver.findElement(By.xpath("//input[@id='customerNameField']"));
		WebElement adrsLine1Options=Driver.findElement(By.xpath("//select[@id='addressLine1Options']"));
		WebElement adrsLine1Field=Driver.findElement(By.xpath("//input[@id='addressLine1Field']"));
		WebElement city =Driver.findElement(By.xpath("//input[@id='city']"));
		WebElement state=Driver.findElement(By.xpath("//select[@id='state']"));
		WebElement zip=Driver.findElement(By.xpath("//input[@id='zip']"));
		WebElement search=Driver.findElement(By.xpath("//button[@value='submit']"));
		
		
		
		try {
			List<String> custrefdrpdown = Arrays.asList("DEA", "SLN", "HIN","PHS");
			List<String> CustomerNamedrpdown = Arrays.asList("Starts With", "Contains");
		//	List<String> AddressLine1 = Arrays.asList("DEA", "SLN", "HIN","PHS");
			
			
			if(custrefdrpdown.contains(drpdown))
				
			{
				 Select select = new Select(custRefIdopts);
				 select.selectByValue(drpdown);
				 Report.updateTestLog(Action, "Customer Reference ID:" +drpdown, Status.PASS);
				 custRefField.clear();
				 custRefField.sendKeys(textbox);
				 
				 
			} else if(CustomerNamedrpdown.contains(drpdown))
				
			{
				Report.updateTestLog(Action, name+" :: " +drpdown, Status.DONE);
				
				if(name.equalsIgnoreCase("Customer Name"))
				{
					
					Select select = new Select(custNameOptions);
					 select.selectByValue(drpdown);
					 Report.updateTestLog(Action, "Customer Name:" +drpdown, Status.PASS);
					 custNameField.clear();
					 custNameField.sendKeys(textbox);
					
					
				}
				else if(name.equalsIgnoreCase("Address Line"))
				{
					
					Select select = new Select(adrsLine1Options);
					 select.selectByValue(drpdown);
					 Report.updateTestLog(Action, "Address Line 1" +drpdown, Status.PASS);
					 adrsLine1Field.clear();
					 adrsLine1Field.sendKeys(textbox);
				}
				
						
			
			}
			else if(textbox.equalsIgnoreCase("state"))
			{
				
				Select select = new Select(state);
				 select.selectByValue(drpdown);
				 Report.updateTestLog(Action, "Selected State" +drpdown, Status.PASS);
			}
			
			
			
			search.click();
			
			
			wait.until(webDriver -> "complete".equals(((JavascriptExecutor) webDriver)
					.executeScript("return document.readyState")));
			
			Customer_ecs(textbox);
			
			
			
			
			
			
			
			
		}catch (Exception e1) {
			
			e1.printStackTrace();
		}	
		
		
		
		
		
		
		
		
		
		
		
	
	}
	
	
	
	
	
	

	public void Customer_ecs( String datavalidation) {
		
		String[] InputData =null;
		String refdata=null;
		WebDriverWait wait = new WebDriverWait(Driver, 60);
		
		try {
		 InputData = datavalidation.split(",");
		 
		 System.out.println(InputData.length  +"   Length ");

		for(int i=0;i<InputData.length;i++) {
			
			refdata=InputData[i];
			System.out.println(refdata  +"   Inside try");
			
		}
		
		}catch (Exception e) {
			
			refdata=InputData[0];
			System.out.println(refdata  +"   Inside Catch");
			
		}
		
		List<WebElement> rows=null;
		List<WebElement> columns=null;
		
		try {
		 rows=Driver.findElements(By.xpath("//table[@class='contractEligibilityCustSearchResultTable']//tr//td"));
		 
//		 Report.updateTestLog(Action, "Size ::"+rows.size(), Status.DONE);
		 
		 if(rows.size()==0)
		 {
			 
			 Report.updateTestLog(Action, " No data displayed ", Status.FAIL);
		 }
		 
		 
		 for (int i=2;i<=rows.size();i++)
		 {
			 
			 
			 
			 columns=Driver.findElements(By.xpath("(//table[@class='contractEligibilityCustSearchResultTable']//tr)["+i+"]//td"));
			 
			 for(int k=2;k<columns.size();k++)
			 {
				 String data=Driver.findElement(By.xpath("((//table[@class='contractEligibilityCustSearchResultTable']//tr)["+i+"]//td)["+k+"]")).getText();
			 
			 Report.updateTestLog(Action, data, Status.PASS);
			 
			
			 try {
				 
				 Driver.findElement(By.xpath("((//table[@class='contractEligibilityCustSearchResultTable']//tr)["+i+"]//td)["+k+"]//a")).click();
			 
			  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='chargebacksRejectionCodeCloseBtn']")));
			  
			  if(element.isDisplayed()) {
			  popupdatavalidation(refdata);
			  element.click();
			  
				Driver.findElement(By.xpath("//input[@id='customerReferenceIDField']")).clear();
				Driver.findElement(By.xpath("//textarea[@id='bulkSearchReferenceIDField']")).clear();
				Driver.findElement(By.xpath("//input[@id='customerNameField']")).clear();
				
				Driver.findElement(By.xpath("//input[@id='addressLine1Field']")).clear();
				Driver.findElement(By.xpath("//input[@id='city']")).clear();
			//	Driver.findElement(By.xpath("//select[@id='state']")).clear();
				Driver.findElement(By.xpath("//input[@id='zip']")).clear();
			  
			  
			  }
			  else {
				  Report.updateTestLog(Action, "Popout not opening ", Status.FAIL);
				  
			  }
			 }catch (Exception e) {
					System.out.println("Search not worked didn't display");
					 Report.updateTestLog(Action, "link not working ", Status.FAIL);
				}
			 
			 
			 }
			 
		 }
		 
		 
		}catch (Exception e) {
			System.out.println("Search not worked didn't display");
			 Report.updateTestLog(Action, "Search not worked didn't display", Status.FAIL);
		}
		
		
		
		
	}
	
	
	
	
	
		
	
	
	public void popupdatavalidation(String ref)
	{
		
		String title=Driver.findElement(By.xpath("//h1[@class='chargebacksPopupHeading']")).getText();
		
		 Report.updateTestLog(Action, "Popup details" +title, Status.PASS);
		 
		 List<WebElement> rows= Driver.findElements(By.xpath("(//table[@class='chargebackCustomerInfoPopupTable']//tr)"));
		 
		 
		 for (int l=2;l<=rows.size();l++)
			 
		 {
			 List<WebElement> columnpopup= Driver.findElements(By.xpath("(//table[@class='chargebackCustomerInfoPopupTable']//tr)["+l+"]//td"));
			 
			 for(int k=1;k<=columnpopup.size();k++)
			 {
				 String element =Driver.findElement(By.xpath("((//table[@class='chargebackCustomerInfoPopupTable']//tr)["+l+"]//td)["+k+"]")).getText();
				 
				 
				 switch(k) {
	                case 1:
	                	 Report.updateTestLog(Action, "Name :: "+element, Status.DONE);
	                    break;
	                case 2:
	                	 Report.updateTestLog(Action, "Address :: "+element, Status.DONE);

	                    
	                    break;
	                case 3:
	                	 Report.updateTestLog(Action, "Phone :: "+element, Status.DONE);
	                    
	                    break;
	                case 4:
	                	 Report.updateTestLog(Action, "Email :: "+element, Status.DONE);
	                   
	                    break;
	                case 5:
	                	if(element.contains(ref))
	                	{
	                	 Report.updateTestLog(Action, ref+" ::  ReferenceIDs are Matching  ::  "+element, Status.PASS);
	                    
	                    break;
	                	}
	                	else
	                	{
	                		Report.updateTestLog(Action, ref+"  ::  ReferenceIDs are Not Matching  ::  "+element, Status.FAIL);
		                    
		                    break;
	                	}
	                default:
	                    throw new IllegalArgumentException("Invalid option");
	            }
			 
			
			 
			 }
			 
			 
		 }
		 
		 
		
		
	}
	
	
	
	
	@Action(object = ObjectType.BROWSER, desc = "Validating the Customer Contract Eligibility Bulk Search Reference IDs", input = InputType.YES)

	public void BulkSearch_ecs() {
		WebDriverWait wait = new WebDriverWait(Driver,30);
		
		WebElement bulkSearchRefeIDField=Driver.findElement(By.xpath("//textarea[@id='bulkSearchReferenceIDField']"));
		WebElement city =Driver.findElement(By.xpath("//input[@id='city']"));
		WebElement state=Driver.findElement(By.xpath("//select[@id='state']"));
		WebElement zip=Driver.findElement(By.xpath("//input[@id='zip']"));
		WebElement search=Driver.findElement(By.xpath("//button[@value='submit']"));
		
		
String bulkdata= Data;
System.out.println(bulkdata);

if(!(bulkdata.isEmpty()||bulkdata.isBlank()))
	
{
	System.out.println("Inside");

	
	bulkSearchRefeIDField.sendKeys(bulkdata);

	
search.click();

Report.updateTestLog(Action, "Bulk Data   ::  "+bulkdata, Status.PASS);
//Customer_ecs(bulkdata);



String[] InputData =null;
String refdata=null;


try {
 InputData = bulkdata.split(",");
 
 System.out.println(InputData.length  +"   Length ");

for(int i=0;i<InputData.length;i++) {
	
	refdata=InputData[i];
	System.out.println(refdata  +"   Inside try");
	
	
	
	 
	 Driver.findElement(By.xpath("((//table[@class='contractEligibilityCustSearchResultTable']//tr)["+(i+2)+"]//td)[2]//a")).click();

 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='chargebacksRejectionCodeCloseBtn']")));
 
 if(element.isDisplayed()) {
 popupdatavalidation(refdata);
 element.click();
	
	
}
 
}

}catch (Exception e) {
	
	refdata=InputData[0];
	System.out.println(refdata  +"   Inside Catch");
	
}


	
	
}
else
{
	
	System.out.println("Else condition ");
	
	
}
		
		
		
		
		
	}
	
	
	

	
	@Action(object = ObjectType.BROWSER, desc = "Validating the City and ", input = InputType.YES)

	public void State_ecs() {
		WebDriverWait wait = new WebDriverWait(Driver,30);
		
		WebElement city =Driver.findElement(By.xpath("//input[@id='city']"));
		WebElement state=Driver.findElement(By.xpath("//select[@id='state']"));
		WebElement zip=Driver.findElement(By.xpath("//input[@id='zip']"));
		WebElement search=Driver.findElement(By.xpath("//button[@value='submit']"));
		
		String[] InputData =null;
		
		InputData = Data.split(",");
		 
		String city_State_Zip = InputData[0]; //Cityzip
		String data2 = InputData[1]; //705809
	
		if(city_State_Zip.contains("city"))
		{
			
			city.sendKeys(data2);
			search.click();
			
			
			
		} else if(city_State_Zip.contains("zip")) 
			
		{
			
			zip.sendKeys(data2);
			search.click();
			
			
		}
		else if(city_State_Zip.contains("state")) 
		{
			Select select = new Select(Driver.findElement(By.xpath("//*[@id='state']")));
			select.selectByVisibleText(data2);
			
			

			
		}
		
		
		
		
		
		
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
	


}
	
	
