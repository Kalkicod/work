package userDefinedPackage;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.Random;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import java.net.URL;

import org.apache.commons.io.comparator.LastModifiedFileComparator;
import org.apache.commons.io.filefilter.WildcardFileFilter;
import org.apache.commons.lang3.time.StopWatch;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.hamcrest.core.IsEqual;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cognizant.cognizantits.engine.commands.General;
import com.cognizant.cognizantits.engine.core.CommandControl;
import com.cognizant.cognizantits.engine.execution.data.UserDataAccess;
import com.cognizant.cognizantits.engine.execution.exception.element.ElementException;
import com.cognizant.cognizantits.engine.execution.exception.element.ElementException.ExceptionType;
import com.cognizant.cognizantits.engine.support.Status;
import com.cognizant.cognizantits.engine.support.methodInf.Action;
import com.cognizant.cognizantits.engine.support.methodInf.InputType;
import com.cognizant.cognizantits.engine.support.methodInf.ObjectType;
import com.google.common.util.concurrent.Service.State;
import com.sun.jna.Function;
import com.testautomationguru.utility.PDFUtil;


public class UserDefined extends General {
	//Daily Order limit node
	String DC_ProductList ="//span[text()='Product']/parent::div/following-sibling::div//img/following-sibling::span";
	String three_DotsInProduct="//i[@id='uNCQqf3-icon']";
	String articleNumInput="//span[text()='Article Number']/parent::td/following-sibling::td[2]/div/input";
	
	String searchBtnInPopup="(//button[text()='Search'])[2]";
	
	@Action(object = ObjectType.SELENIUM, desc = "Get list of products in DC daily limit order", input = InputType.YES)
	public void Seleniumethods() throws InterruptedException {
		System.out.println("Sucessfull created selenium custom method");
		Report.updateTestLog(Action, "Sucessfull created selenium custom method", Status.DONE);
		Report.updateTestLog(Action, "Sucessfull created selenium custom method", Status.FAIL);
		Report.updateTestLog(Action, "Sucessfull created selenium custom method", Status.PASS);
	}
	
	
	
	@Action(object = ObjectType.BROWSER, desc = "Get list of products in DC daily limit order", input = InputType.NO)
	public void Dc_ProductList() throws InterruptedException {
		Thread.sleep(6000);
		List<WebElement> productList = Driver.findElements(By.xpath(DC_ProductList));
		String productNDC="";
		String articleNum ="";
		if (productList.size()>=1) {
			productNDC = productList.get(0).getText();
			String[] split = productNDC.split("");
			for (int i = 0; i < split.length; i++) {
				articleNum=articleNum+split[i];
				if (i==4) {
					articleNum=articleNum+"0";
				}
			}
			
		} else {
			productNDC = userData.getData("Flu Reservation", "Products");
			articleNum = userData.getData("Flu Reservation", "ArticleNumber");
			Driver.findElement(By.xpath(three_DotsInProduct)).click();
			Thread.sleep(5000);
			Driver.findElement(By.xpath(articleNumInput)).sendKeys(articleNum);
			Driver.findElement(By.xpath(searchBtnInPopup)).click();
			Thread.sleep(5000);
			Driver.findElement(By.xpath("(//span[text()='"+articleNum+"'])[1]/parent::div/parent::td/preceding-sibling::td//i")).click();
			Thread.sleep(3000);
			Driver.findElement(By.xpath("//button[text()='Select (1)']")).click();
			Thread.sleep(3000);
			Driver.findElement(By.xpath("//button[text()='Save' and not(contains(@disabled,'disabled'))]")).click();	
		}
		
		userData.putData("Flu Reservation", "Products", productNDC);
		userData.putData("Flu Reservation", "ArticleNumber",articleNum);	
		
	}
	
	public UserDefined(CommandControl cc) {
		super(cc);
	}
	@Action(object = ObjectType.BROWSER, desc = "Get Download path from system", input = InputType.NO)
	public void kk() throws IOException {
		/*
		 * URL url = new URL(
		 * "https://us-uat1-edatahub.ecommerce.gsk.com/datahub-webapp/v1/idoc/receiver",
		 * url); HttpURLConnection con =(HttpURLConnection) url.openConnection();
		 * con.setRequestMethod("POST"); con.setRequestProperty("Content-Type",
		 * "application/json"); con.setRequestProperty("Accept", "application/json");
		 * con.setDoOutput(true);
		 */
		URL target = new URL("http://www.google.com");
		HttpURLConnection conn = (HttpURLConnection) target.openConnection();
		conn.setRequestMethod("GET");

		// used for POST and PUT, usually
		// conn.setDoOutput(true);
		// OutputStream toWriteTo = conn.getOutputStream();

		conn.connect();
		int responseCode = conn.getResponseCode();

		try 
		{
		    InputStream response = conn.getInputStream();
		}
		catch (IOException e)
		{
		    InputStream error = conn.getErrorStream();
		}
	}
	
	@Action(object = ObjectType.BROWSER, desc = "Get Download path from system", input = InputType.NO)
	/*
	 * public void downloadPath() { String property =
	 * System.getProperty("user.home"); System.out.println(property); String replace
	 * = property.replace("\\", "\\\\"); String path =replace+"\\\\Downloads";
	 * userData.putData("Flu Reservation", "Download Path", path);
	 * 
	 * }
	 */
public void downloadPath() {
        String property = System.getProperty("user.home");
        System.out.println(property);
        String replace = property.replace("\\", "\\\\");
        String path =replace+"\\\\Downloads";
        try {
            userData.getData("Flu Reservation", "Download Path");
            userData.putData("Flu Reservation", "Download Path", path);
            
            
        }
        catch (Exception e) {
                userData.putData("PMG_data", "Path", path);
            }
    
        
    }
	
	@Action(object = ObjectType.BROWSER, desc = "Trim the value of [<Data>]", input = InputType.YES)
	public void trimNumber1() {

		String[] orderarray = Data.split(" ");
		int length = orderarray.length;
		if (length == 3) {
			userData.putData("DS_Smart reserve page", "flunumber", orderarray[length - 1]);
		} else {
			userData.putData("DS_Smart reserve page", "ordernumber", orderarray[length - 1]);
		}

	}

	
	
	@Action(object = ObjectType.BROWSER, desc = "Shopping cart removal", input = InputType.NO)
	public void clearShoppingCart_Latest() {
		WebElement Element = Driver.findElement(By.xpath("//*[contains(@class,'yCmsComponent')]//span[2]"));

		String[] qtyarray = Element.getText().split("\\D");

		int num = Integer.parseInt(qtyarray[1]);
		System.out.println(qtyarray[1]);
		try {
		if (!Element.getText().contains("(0)")) {
			Driver.findElement(By.xpath("//*[contains(@class,'yCmsComponent')]")).click();

			for (int i = 1; i <= num; i++) {
				Driver.findElement(
						By.xpath("(//a[text()='Remove from cart'])[1]"))
						.click();
				WebDriverWait wait = new WebDriverWait(Driver, 600);
				wait.until(ExpectedConditions.visibilityOf(Driver
						.findElement(By.xpath("(//button[text()='Yes, Remove'])[2]"))));
				Driver.findElement(By.xpath("(//button[text()='Yes, Remove'])[2]"))
						.click();
			}

		} else {
			Report.updateTestLog(Action, "Cart is null ", Status.PASS);
		}
		}catch(Exception e) {
			Report.updateTestLog(Action, "Cart is null ", Status.PASS);
			
			
		}

	}

	@Action(object = ObjectType.BROWSER, desc = "Today date", input = InputType.NO)
	public void todayDateandTime() {

		// Saturday,Sunday,Monday - take as Non deliverable date
		Date date = new Date();

		switch (date.getDay()) {

		case 4:
		case 1:
		case 3:
		case 2:
			DateFormat dateFormat1 = new SimpleDateFormat("MMM dd, y, 12:00:00");

			// get current date time with Date()
			Date date1 = new Date();

			// Now format the date
			String Today1 = dateFormat1.format(date1);
			// System.out.println(Current + " AM");
			// Print the Date
			userData.putData("Date", "Today", Today1 + " AM");
			break;
		case 0:
			DateFormat dateFormat2 = new SimpleDateFormat("MMM dd, y, 12:00:00");
			Calendar cell = Calendar.getInstance();

			cell.setTime(date);
			cell.add(Calendar.DATE, 1);

			String Today2 = dateFormat2.format(cell.getTime());
			// System.out.println(Toda + " AM");
			userData.putData("Date", "Today", Today2 + " AM");
			break;
		case 5:
			DateFormat dateFormat4 = new SimpleDateFormat("MMM dd, y, 12:00:00");
			Calendar d1 = Calendar.getInstance();

			d1.setTime(date);
			d1.add(Calendar.DATE, 3);

			String Today4 = dateFormat4.format(d1.getTime());
			// System.out.println(Todayy + " AM");
			userData.putData("Date", "Today", Today4 + " AM");
			break;

		case 6:
			DateFormat dateFormat3 = new SimpleDateFormat("MMM dd, y, 12:00:00");
			Calendar d = Calendar.getInstance();

			d.setTime(date);
			d.add(Calendar.DATE, 2);

			String Today3 = dateFormat3.format(d.getTime());
			// System.out.println(Todayy + " AM");
			userData.putData("Date", "Today", Today3 + " AM");
			break;

		default:

			break;
		}

	}
	@Action(object = ObjectType.BROWSER, desc = "Current date with adding the [<Data>] in file", input = InputType.YES)
	public void currentDatePlusData() {

		// Saturday,Sunday,Monday - take as Non deliverable date
		String input=Data;
		int futureDate = Integer.parseInt(Data);
		Date date = new Date();
			DateFormat dateFormat2 = new SimpleDateFormat("MMM dd, y, 12:00:00");
			Calendar cell = Calendar.getInstance();

			cell.setTime(date);
			cell.add(Calendar.DATE, futureDate );

			String Date = dateFormat2.format(cell.getTime());
			// System.out.println(Toda + " AM");
			userData.putData("Date", "Future Date", Date + " AM");
	}
	
	@Action(object = ObjectType.BROWSER, desc = "Current date with adding the [<Data>] in file", input = InputType.YES)
	public void notificationDate() {
		int parseInt = Integer.parseInt(Data);
		Date date = new Date();
		DateFormat dateFormat2 = new SimpleDateFormat("dd MMM yyyy");
		Calendar cell = Calendar.getInstance();

		cell.setTime(date);
		cell.add(Calendar.DATE, parseInt );

		String Date = dateFormat2.format(cell.getTime());
		// System.out.println(Toda + " AM");
		userData.putData("Flu Reservation","Expiry Date", Date);	
	}
	
	@Action(object = ObjectType.BROWSER, desc = "Current date and time with adding the [<Data>] in file [value,value]", input = InputType.YES)
	public void currentDateAndTimePlusData() {
		String input=Data;
		String[] split2 = input.split(",");
		int futureDate = Integer.parseInt(split2[0]);
		int hour = Integer.parseInt(split2[1]);
		Date date = new Date();
			DateFormat dateFormat2 = new SimpleDateFormat("MMM dd, y, hh:mm:ss a");
			Calendar cell = Calendar.getInstance();

			cell.setTime(date);
			cell.add(Calendar.DATE, futureDate );
			cell.add(Calendar.HOUR, hour);

			String Date = dateFormat2.format(cell.getTime());
			// System.out.println(Date);
			userData.putData("Date", "Future Date", Date);
	}
	@Action(object = ObjectType.BROWSER, desc = "Allocation ID Current date and time with adding the [<Data>] in file Input [value,value]", input = InputType.YES)
	public void allocationCurrentDateAndTimePlusData() {
		String input=Data;
		String[] split2 = input.split(",");
		int futureDate = Integer.parseInt(split2[0]);
		int hour = Integer.parseInt(split2[1]);
		Date date = new Date();
			DateFormat dateFormat2 = new SimpleDateFormat("MMM_d_y_hh_mm_ss_a");
			Calendar cell = Calendar.getInstance();

			cell.setTime(date);
			cell.add(Calendar.DATE, futureDate );
			cell.add(Calendar.HOUR, hour);

			String Date = dateFormat2.format(cell.getTime());
			// System.out.println(Date);
			
			try {
				userData.getData("Date", "Future Date");
			userData.putData("Date", "Future Date", Date);
			}catch (Exception e) {
				userData.putData("Promotion", "FormattedDate", Date);
			}
	}
	@Action(object = ObjectType.BROWSER, desc = "Current time with adding the [<Data>] in file", input = InputType.YES)
	public void currentTimePlusData() {	
String input=Data;
	
	int hour = Integer.parseInt(input);
	Date date = new Date();
		DateFormat dateFormat2 = new SimpleDateFormat("hh:mm:ss a");
		Calendar cell = Calendar.getInstance();

		cell.setTime(date);
		//cell.add(Calendar.DATE, futureDate );
		cell.add(Calendar.HOUR, hour);

		String Date = dateFormat2.format(cell.getTime());
		 System.out.println(Date);
		userData.putData("Date", "Future Date", Date);
	}
	
	@Action(object = ObjectType.BROWSER, desc = "Current time with adding the [<Data>] in file", input = InputType.YES)
	public void currentTimePlusDat() {
		String input=Data;
		
		int hour = Integer.parseInt(input);
		Date date = new Date();
			DateFormat dateFormat2 = new SimpleDateFormat("hh:mm:ss a");
			Calendar cell = Calendar.getInstance();

			cell.setTime(date);
			//cell.add(Calendar.DATE, futureDate );
			cell.add(Calendar.HOUR, hour);

			String Date = dateFormat2.format(cell.getTime());
			 System.out.println(Date);
			userData.putData("Date", "Future Date", Date);
	}
	
	@Action(object = ObjectType.BROWSER, desc = "Yesterday date", input = InputType.NO)
	public void yesterdayDateandTime() {

		// Saturday,Sunday,Monday - take as Non deliverable date
		Date date = new Date();

		switch (date.getDay()) {

		case 4:
		case 1:
		case 3:
		case 2:
		case 0:
		case 5:
		case 6:	
			DateFormat dateFormat1 = new SimpleDateFormat("MMM dd, y, 12:00:00");

			Calendar cll = Calendar.getInstance();

			cll.setTime(date);
			cll.add(Calendar.DATE, -1);

			String Yesterday1 = dateFormat1.format(cll.getTime());
			// System.out.println(Current + " AM");
			userData.putData("Date", "Yesterday", Yesterday1 + " AM");

			break;
		default:

			break;
		}

	}

	@Action(object = ObjectType.BROWSER, desc = "Tomorrow date", input = InputType.NO)
	public void tomorrowDateandTime() {

		// TODO Auto-generated method stub
		Date date = new Date();

		switch (date.getDay()) {

		case 4:
		case 1:
		case 3:
		case 2:
			DateFormat dateFormat1 = new SimpleDateFormat("MMM dd, y, 12:00:00");

			Calendar cll = Calendar.getInstance();

			cll.setTime(date);
			cll.add(Calendar.DATE, 1);
			// get current date time with Date()

			// Now format the date
			String Tomorrow1 = dateFormat1.format(cll.getTime());
			// System.out.println(Tomorrow1 + " AM");
			userData.putData("Date", "Tomorrow", Tomorrow1 + " AM");
			break;
		case 0:
			DateFormat dateForma = new SimpleDateFormat("MMM dd, y, 12:00:00");
			Calendar cell = Calendar.getInstance();

			cell.setTime(date);
			cell.add(Calendar.DATE, 2);

			String Tomorrow2 = dateForma.format(cell.getTime());
			// System.out.println(Toda + " AM");
			userData.putData("Date", "Tomorrow", Tomorrow2 + " AM");
			break;

		case 6:
			DateFormat dateFor = new SimpleDateFormat("MMM dd, y, 12:00:00");
			Calendar d = Calendar.getInstance();

			d.setTime(date);
			d.add(Calendar.DATE, 3);

			String Tomorrow3 = dateFor.format(d.getTime());
			// System.out.println(Todayy + " AM");
			userData.putData("Date", "Tomorrow", Tomorrow3 + " AM");
			break;
		case 5:
			DateFormat dateFormat4 = new SimpleDateFormat("MMM dd, y, 12:00:00");
			Calendar d1 = Calendar.getInstance();

			d1.setTime(date);
			d1.add(Calendar.DATE, 4);

			String Tomorrow4 = dateFormat4.format(d1.getTime());
			// System.out.println(Todayy + " AM");
			userData.putData("Date", "Tomorrow", Tomorrow4 + " AM");
			break;
		default:

			break;
		}

	}

	@Action(object = ObjectType.BROWSER, desc = "checkElementEnabledForTomorrow date", input = InputType.NO)
	public void checkElementEnabledForTomorrowDate() {

		// TODO Auto-generated method stub
		Date date = new Date();

		try {
			switch (date.getDay()) {

			case 4:
			case 1:
			case 3:
			case 2:

				DateFormat dateFormat1 = new SimpleDateFormat("d");

				Calendar cll = Calendar.getInstance();

				cll.setTime(date);
				cll.add(Calendar.DATE, 1);
				// get current date time with Date()

				// Now format the date
				String Tommorow1 = dateFormat1.format(cll.getTime());
				String path1 = "//a[text()='" + Tommorow1 + "']";
				// System.out.println(path1);

				if (Driver.findElement(By.xpath(path1)).isDisplayed()) {
					Report.updateTestLog(Action, "Tomorrow date is available for delivery", Status.PASS);

				} else {
					Report.updateTestLog(Action, "Element not present", Status.FAIL);
				}

				break;
			case 0:
				DateFormat dateForma = new SimpleDateFormat("d");
				Calendar cell = Calendar.getInstance();

				cell.setTime(date);
				cell.add(Calendar.DATE, 2);

				String Tommorow2 = dateForma.format(cell.getTime());
				String path2 = "//a[text()='" + Tommorow2 + "']";
				// System.out.println(path2);
				if (Driver.findElement(By.xpath(path2)).isDisplayed()) {
					Report.updateTestLog(Action, "Tomorrow date is available for delivery", Status.PASS);

				} else {
					Report.updateTestLog(Action, "Element not present", Status.FAIL);
				}

				break;

			case 6:
				DateFormat dateFor = new SimpleDateFormat("d");
				Calendar d = Calendar.getInstance();

				d.setTime(date);
				d.add(Calendar.DATE, 3);

				String Tommorow3 = dateFor.format(d.getTime());
				String path3 = "//a[text()='" + Tommorow3 + "']";
				// System.out.println(path3);
				if (Driver.findElement(By.xpath(path3)).isDisplayed()) {
					Report.updateTestLog(Action, "Tomorrow date is available for delivery", Status.PASS);

				} else {
					Report.updateTestLog(Action, "Element not present", Status.FAIL);
				}

				break;
			case 5:
				DateFormat dateFor5 = new SimpleDateFormat("d");
				Calendar da = Calendar.getInstance();

				da.setTime(date);
				da.add(Calendar.DATE, 4);

				String Tomorrow4 = dateFor5.format(da.getTime());
				String path4 = "//a[text()='" + Tomorrow4 + "']";

				if (Driver.findElement(By.xpath(path4)).isDisplayed()) {
					Report.updateTestLog(Action, "Tomorrow date is available for delivery", Status.PASS);

				} else {
					Report.updateTestLog(Action, "Element not present", Status.FAIL);
				}

				break;
			default:

				break;
			}

		}

		catch (org.openqa.selenium.NoSuchElementException e) {
			Report.updateTestLog(Action, "Tomorrow date is not available for delivery", Status.FAIL);
		}
	}

	
	@Action(object = ObjectType.BROWSER, desc = "Click day after tomo date", input = InputType.NO)
	public void clickDayAfterTomorrowDate() {

		// TODO Auto-generated method stub
		Date date = new Date();

		try {
			switch (date.getDay()) {

			
			case 1:
			case 3:
			case 2:

				DateFormat dateFormat1 = new SimpleDateFormat("d");

				Calendar cll = Calendar.getInstance();

				cll.setTime(date);
				cll.add(Calendar.DATE, 2);
				// get current date time with Date()

				// Now format the date
				String Tommorow1 = dateFormat1.format(cll.getTime());
				String path1 = "//a[text()='" + Tommorow1 + "']";
				// System.out.println(path1);

				if (Driver.findElement(By.xpath(path1)).isDisplayed()) {
					Driver.findElement(By.xpath(path1)).click();
					Report.updateTestLog(Action, "Day after tomorrow date is available for delivery", Status.PASS);

				} else {
					Report.updateTestLog(Action, "Element not present", Status.FAIL);
				}

				break;
			case 0:
				DateFormat dateForma = new SimpleDateFormat("d");
				Calendar cell = Calendar.getInstance();

				cell.setTime(date);
				cell.add(Calendar.DATE, 3);

				String Tommorow2 = dateForma.format(cell.getTime());
				String path2 = "//a[text()='" + Tommorow2 + "']";
				// System.out.println(path2);
				if (Driver.findElement(By.xpath(path2)).isDisplayed()) {
					Driver.findElement(By.xpath(path2)).click();
					Report.updateTestLog(Action, "Day after tomorrow date is available for delivery", Status.PASS);

				} else {
					Report.updateTestLog(Action, "Element not present", Status.FAIL);
				}

				break;

			case 6:
				DateFormat dateFor = new SimpleDateFormat("d");
				Calendar d = Calendar.getInstance();

				d.setTime(date);
				d.add(Calendar.DATE, 4);

				String Tommorow3 = dateFor.format(d.getTime());
				String path3 = "//a[text()='" + Tommorow3 + "']";
				// System.out.println(path3);
				if (Driver.findElement(By.xpath(path3)).isDisplayed()) {
					Driver.findElement(By.xpath(path3)).click();
					Report.updateTestLog(Action, "Day after tomorrow date is available for delivery", Status.PASS);

				} else {
					Report.updateTestLog(Action, "Element not present", Status.FAIL);
				}

				break;
			case 5: case 4:
				DateFormat dateFor5 = new SimpleDateFormat("d");
				Calendar da = Calendar.getInstance();

				da.setTime(date);
				da.add(Calendar.DATE, 5);

				String Tomorrow4 = dateFor5.format(da.getTime());
				String path4 = "//a[text()='" + Tomorrow4 + "']";

				if (Driver.findElement(By.xpath(path4)).isDisplayed()) {
					Driver.findElement(By.xpath(path4)).click();
					Report.updateTestLog(Action, "Day after tomorrow date is available for delivery", Status.PASS);

				} else {
					Report.updateTestLog(Action, "Element not present", Status.FAIL);
				}

				break;
			default:

				break;
			}

		}

		catch (org.openqa.selenium.NoSuchElementException e) {
			Report.updateTestLog(Action, "Day after Tomorrow date is not available for delivery", Status.FAIL);
		}
	}
	@Action(object = ObjectType.BROWSER, desc = "checkElementEnabledForTodaydate", input = InputType.NO)
	public void checkElementEnabledForTodayDate() {

		// Saturday,Sunday,Monday - take as Non deliverable date
		Date date = new Date();

		try {
			switch (date.getDay()) {

			case 4:
			case 1:
			case 3:
			case 2:
				DateFormat dateFormat1 = new SimpleDateFormat("d");

				Calendar cll = Calendar.getInstance();

				cll.setTime(date);
				cll.add(Calendar.DATE, 0);
				// get current date time with Date()

				// Now format the date
				String Today1 = dateFormat1.format(cll.getTime());
				String path1 = "//a[text()='" + Today1 + "']";
				// System.out.println(path1);

				if (Driver.findElement(By.xpath(path1)).isDisplayed()) {
					Report.updateTestLog(Action, "Element present", Status.PASS);

				} else {
					Report.updateTestLog(Action, "Element not present", Status.FAIL);
				}

				break;
			case 0:
				DateFormat dateForma = new SimpleDateFormat("d");
				Calendar cell = Calendar.getInstance();

				cell.setTime(date);
				cell.add(Calendar.DATE, 1);

				String Today2 = dateForma.format(cell.getTime());
				String path2 = "//a[text()='" + Today2 + "']";
				// System.out.println(path2);
				if (Driver.findElement(By.xpath(path2)).isDisplayed()) {
					Report.updateTestLog(Action, "Element present", Status.PASS);

				} else {
					Report.updateTestLog(Action, "Element not present", Status.FAIL);
				}
				break;
			case 5:
				DateFormat dateFor5 = new SimpleDateFormat("d");
				Calendar da = Calendar.getInstance();

				da.setTime(date);
				da.add(Calendar.DATE, 3);

				String Today3 = dateFor5.format(da.getTime());
				String path4 = "//a[text()='" + Today3 + "']";

				if (Driver.findElement(By.xpath(path4)).isDisplayed()) {
					Report.updateTestLog(Action, "Element present", Status.PASS);

				} else {
					Report.updateTestLog(Action, "Element not present", Status.FAIL);
				}

				break;

			case 6:
				DateFormat dateFor = new SimpleDateFormat("d");
				Calendar d = Calendar.getInstance();

				d.setTime(date);
				d.add(Calendar.DATE, 2);

				String Today4 = dateFor.format(d.getTime());
				String path3 = "//a[text()='" + Today4 + "']";
				// System.out.println(path3);
				if (Driver.findElement(By.xpath(path3)).isDisplayed()) {
					Report.updateTestLog(Action, "Element present", Status.PASS);

				} else {
					Report.updateTestLog(Action, "Element not present", Status.FAIL);
				}

				break;

			default:

				break;
			}
		} catch (org.openqa.selenium.NoSuchElementException e) {
			Report.updateTestLog(Action, "Today date is not available for delivery", Status.PASS);
		} catch (Exception e) {
			Report.updateTestLog(Action, "Need to check the custom method", Status.FAIL);
		}

	}

	@Action(object = ObjectType.BROWSER, desc = "Taking Zipcode from Addresses popup, Need to give ShipTo custom method infront of this method", input = InputType.NO)
	public void takingZipcodeFromAddressPopup() throws InterruptedException {
		String shipToNumber = userData.getData("Data", "Active ShipTo");
		String text = Driver
				.findElement(By
						.xpath("//span[contains(text(),'" + shipToNumber + "')]/parent::div/following-sibling::div[6]"))
				.getText();
		String[] split2 = text.split("-");
		String Zipcode = split2[0];
		userData.putData("Transit time data", "6 Digit Zipcode", Zipcode);
		userData.putData("Transit time data", "6 or 9 Digit Zipcode", text);

		Thread.sleep(10000);
		String shipTo = Driver.findElement(By.xpath("//span[contains(text(),'" + shipToNumber + "')]")).getText();
		userData.putData("Transit time data", "ShipTo Number", shipTo);
	}

	@Action(object = ObjectType.BROWSER, desc = "Selection of Zipcode from Addresses popup", input = InputType.NO)
	public void zipcodeSelection() {
		String shipToNumber="";
		try {
			shipToNumber = userData.getData("Data", "Active ShipTo");
		} catch (Exception e) {
			shipToNumber = userData.getData("Select Account", "ShipToNum");
		}
		
		Driver.findElement(
				By.xpath("//span[contains(text(),'" + shipToNumber + "')]/parent::div/following-sibling::div[6]"))
				.click();

	}

	@Action(object = ObjectType.BROWSER, desc = "Selection of Zipcode from Addresses popup", input = InputType.NO)
	public void zipcodeSelection_2() {
		String shipToNumber = userData.getData("Data", "Active ShipTo_2");
		Driver.findElement(
				By.xpath("//span[contains(text(),'" + shipToNumber + "')]/parent::div/following-sibling::div[6]"))
				.click();
	}

	@Action(object = ObjectType.BROWSER, desc = "Getting Owner name and Card name for the credit card", input = InputType.NO)
	public void card_Ownername_Cardname() {

		String text = Driver.findElement(By.id("firstName")).getAttribute("value");
		String text1 = Driver.findElement(By.id("lastName")).getAttribute("value");
		String trim = text.trim();
		String trim1 = text1.trim();
		String CardName = trim + " " + trim1;
		String Card_Ownername = trim + " " + trim1 + " (owner)";
		userData.putData("Authorized user Scenario", "Credit card name", CardName);
		userData.putData("Authorized user Scenario", "Card Owner Name", Card_Ownername);
	}

	@Action(object = ObjectType.BROWSER, desc = "Getting Owner name and Card name for the credit card", input = InputType.NO)
	public void secondaryCard_Ownername_Cardname() {

		String text = Driver.findElement(By.id("firstName")).getAttribute("value");
		String text1 = Driver.findElement(By.id("lastName")).getAttribute("value");
		String trim = text.trim();
		String trim1 = text1.trim();
		String CardName = trim + " " + trim1;
		String Card_Ownername = trim + " " + trim1 + " (owner)";
		userData.putData("Authorized user Scenario", "Secondary credit card name", CardName);
		userData.putData("Authorized user Scenario", "Secondary owner name", Card_Ownername);
	}

	@Action(object = ObjectType.BROWSER, desc = "Getting Last four digit of credit card", input = InputType.NO)
	public void creditcardnumberLastFourDigit() {

		String number = userData.getData("Authorized user Scenario", "Visa Card number");
		String[] split = number.split("");
		String VisaLastFourNumber = split[split.length - 4] + split[(split.length) - 3] + split[(split.length) - 2]
				+ split[(split.length) - 1];

		String number1 = userData.getData("Authorized user Scenario", "Master card number");
		String[] split1 = number1.split("");
		String MasterLastFourNumber = split1[split1.length - 4] + split1[(split1.length) - 3]
				+ split1[(split1.length) - 2] + split1[(split1.length) - 1];

		String number2 = userData.getData("Authorized user Scenario", "American express card number");
		String[] split2 = number2.split("");
		String AmericanLastFourNumber = split2[split2.length - 4] + split2[(split2.length) - 3]
				+ split2[(split2.length) - 2] + split2[(split2.length) - 1];

		userData.putData("Authorized user Scenario", "Visa Card last four number", VisaLastFourNumber);
		userData.putData("Authorized user Scenario", "Master Card last four number", MasterLastFourNumber);
		userData.putData("Authorized user Scenario", "American Card last four number", AmericanLastFourNumber);
	}

	@Action(object = ObjectType.BROWSER, desc = "Getting Last four digit of credit card", input = InputType.NO)
	public void creditcardnumberLastFourDigit_Regression() {
		String number = userData.getData("CreditCard Data", "CC Number");
		String[] split = number.split("");
		String LastFourNumber = split[split.length - 4] + split[(split.length) - 3] + split[(split.length) - 2]
				+ split[(split.length) - 1];
		userData.putData("LastFour number", "Visa Card last four number", LastFourNumber);

	}
	@Action(object = ObjectType.BROWSER, desc = "Check All values inside the table in prebook page", input = InputType.NO)
	public void toGetEstimatedCost() {
		String listPrice_1 = userData.getData("DS_Smart reserve page", "List Price");
		char[] charArray = listPrice_1.toCharArray();
		String pric = "";
		for (int i = 0; i < 7; i++) {
			if (i >= 1) {
				pric = pric + charArray[i];
			}
		}
		Double price=null;
		if (pric.contains(",")) {
			 String replaceAll = pric.replaceAll(",", "");
			 price = Double.parseDouble(replaceAll);
		} else {
			 price = Double.parseDouble(pric);
		}		
		String quantity_1 = userData.getData("DS_Smart reserve page", "Updated Quantity");
		String[] split = quantity_1.split(" ");
		String e = split[0];
		int valueOf = Integer.valueOf(e.replace(",", ""));
		DecimalFormat decimalFormat = new DecimalFormat("#.##");
		decimalFormat.setGroupingUsed(true);
		decimalFormat.setGroupingSize(3);
		String g =decimalFormat.format(valueOf*price);
		userData.putData("DS_Smart reserve page", "Estimated cost", g);
		
	}
	
	
	@Action(object = ObjectType.BROWSER, desc = "Check All values inside the table in prebook page", input = InputType.NO)
	public void checkAllValues_Prebook() {
		
		//check the estimated cost for Product 1
		String quantity_1 = userData.getData("Smart Reserve Validation", "Quantity 1");
		String[] split = quantity_1.split(" ");
		String e = split[0];
		int valueOf = Integer.valueOf(e.replace(",", ""));
		String listPrice_1 = userData.getData("Smart Reserve Validation", "List price 1");
		char[] charArray = listPrice_1.toCharArray();
		String pric = "";
		for (int i = 0; i < 7; i++) {
			if (i >= 1) {
				pric = pric + charArray[i];
			}
		}
		double price = Double.parseDouble(pric);
		DecimalFormat decimalFormat = new DecimalFormat("0.00");
		DecimalFormat decimalFormat1 = new DecimalFormat("#.##");
		decimalFormat.setGroupingUsed(true);
		decimalFormat.setGroupingSize(3);
		decimalFormat1.setGroupingUsed(true);
		decimalFormat1.setGroupingSize(3);
		String g =decimalFormat1.format(valueOf)+" "+"packs"+" ("+decimalFormat1.format(valueOf*10)+" doses)";
		
		//Check Quantity and doses
		if (g.equals(quantity_1)) {
			Report.updateTestLog(Action, "Total packs/doses verified "+g, Status.PASS);
		}else {
			Report.updateTestLog(Action, "Diffence between packs and doses "+g, Status.FAIL);
		}
		
		if (userData.getData("Smart Reserve Validation", "Estimated Cost 1")
				.equals("$" + decimalFormat.format((double)valueOf * price))) {
			Report.updateTestLog(Action, "Actual cost equal to Estimated cost "+"$" + decimalFormat.format((double)valueOf * price), Status.PASS);
		}else {
			Report.updateTestLog(Action, "Actual cost not equal to Estimated cost "+"$" + decimalFormat.format((double)valueOf * price), Status.FAIL);
		}
		
		//check the estimated cost for Product 1
		String quantity_2 = userData.getData("Smart Reserve Validation", "Quantity 2");
		String[] split1 = quantity_2.split(" ");
		String e1 = split1[0];
		int valueOf1 = Integer.valueOf(e1.replace(",", ""));
		String listPrice_2 = userData.getData("Smart Reserve Validation", "List price 2");
		char[] charArray1 = listPrice_2.toCharArray();
		String pric1 = "";
		for (int i = 0; i < 7; i++) {
			if (i >= 1) {
				pric1 = pric1 + charArray1[i];
			}
		}
		Double price1 = null;
		if (pric1.contains(",")) {
			String replace = pric1.replace(",", "");
			price1 = Double.parseDouble(replace);
		} else {
		 price1 = Double.parseDouble(pric1);
		}
	
		String g1 =decimalFormat1.format(valueOf1)+" "+"packs"+" ("+decimalFormat1.format(valueOf1*10)+" doses)";
		//Check Quantity and doses
		if (g1.equals(quantity_2)) {
			Report.updateTestLog(Action, "Total packs/doses verified "+g1, Status.PASS);
		}else {
			Report.updateTestLog(Action, "Diffence between packs and doses "+g1, Status.FAIL);
		}
		
		
		if (userData.getData("Smart Reserve Validation", "Estimated cost 2")
				
				
				.equals("$" + decimalFormat.format((double)valueOf1 * price1))) {
			Report.updateTestLog(Action, "Actual cost equal to Estimated cost "+"$" + decimalFormat.format((double)valueOf1 * price1), Status.PASS);
		}else {
			Report.updateTestLog(Action, "Actual cost not equal to Estimated cost "+"$" + decimalFormat.format((double)valueOf1 * price1), Status.FAIL);
		}
		
		//check total quantity
		int total_Qty =valueOf+valueOf1;
		if (userData.getData("Smart Reserve Validation", "Total Reserved Quantity")
				.equals("Total Quantity Reserved"+"\n"+decimalFormat1.format(total_Qty)+" "+"packs"+" ("+decimalFormat1.format(total_Qty*10)+" doses)")) {
			Report.updateTestLog(Action, "Actual Quantity equal to Estimated "+"Total Quantity Reserved "+decimalFormat1.format(total_Qty)+" "+"packs"+" ("+decimalFormat1.format(total_Qty*10)+" doses)", Status.PASS);
		}else {
			Report.updateTestLog(Action, "Actual Quantity not equal to Estimated "+"Total Quantity Reserved "+decimalFormat1.format(total_Qty)+" "+"packs"+" ("+decimalFormat1.format(total_Qty*10)+" doses)", Status.FAIL);
		}
		
		//check total estimated cost
	double total_Cost=	(double)(valueOf1 * price1)+(valueOf * price);
	if (userData.getData("Smart Reserve Validation", "Total Esitmated Cost")
			.equals("Estimated Cost*"+"\n"+"$" + decimalFormat.format(total_Cost))) {
		Report.updateTestLog(Action, "Actual cost equal to Estimated "+"Estimated Cost* "+"$" + decimalFormat.format(total_Cost), Status.PASS);
	}else {
		Report.updateTestLog(Action, "Actual cost not equal to Estimated "+"Estimated Cost* "+"$" + decimalFormat.format(total_Cost), Status.FAIL);
	}
		
	}
	

	@Action(object = ObjectType.BROWSER, desc = "To check the percentage in smart reserve page [<Data>]", input = InputType.YES)
	public void percentageCheckInSmartReservePage() {
		
		String s = Data;
		String[] split = s.split(" ");
		String e = split[0];
		int valueOf = Integer.valueOf(e.replace(",", ""));
		
		String h=userData.getData("Smart Reserve Validation", "Total Quantity");
		/*String[] split1 = h.split(" ");
		System.out.println(split1[3]);
		String ee = split1[3];  */
		int valueO1f = Integer.valueOf(h.replace(",", ""));
		DecimalFormat decimalFormat = new DecimalFormat("0.0");
		Double d =(double)valueOf*100/valueO1f;
		userData.putData("Smart Reserve Validation", "Percentage", decimalFormat.format(d).toString()+"% of your reservation");
		
	}

	@Action(object = ObjectType.BROWSER, desc = "Check the credit card by Last four digit number [<Data>]", input = InputType.YES)
	public void checkCreditCardNumber() {
		String Address = userData.getData("Authorized user Scenario", "Address line 1");
		if (Data.equalsIgnoreCase("visa")) {
			String number = userData.getData("Authorized user Scenario", "Visa Card last four number");
			String path = "//div[contains(text(),'" + number + "')]/parent::div/parent::div/following-sibling::div[2]/div/div[contains(text(),'"+ Address + "')]";
			if (Driver.findElement(By.xpath(path)).getText().contains(number)) {
				Report.updateTestLog(Action, "Assert element text equals", Status.PASS);
			}
		} else if (Data.equalsIgnoreCase("Master")) {

			String number = userData.getData("Authorized user Scenario", "Master Card last four number");
			String path = "//div[contains(text(),'" + number + "')]/parent::div/parent::div/following-sibling::div[2]/div/div[contains(text(),'"+ Address + "')]";
			if (Driver.findElement(By.xpath(path)).getText().contains(number)) {
				Report.updateTestLog(Action, "Assert element text equals", Status.PASS);

			}
		} else if (Data.equalsIgnoreCase("American")) {
			String number = userData.getData("Authorized user Scenario", "American Card last four number");
			String path = "//div[contains(text(),'" + number + "')]/parent::div/parent::div/following-sibling::div[2]/div/div[contains(text(),'"+ Address + "')]";
			if (Driver.findElement(By.xpath(path)).getText().contains(number)) {
				Report.updateTestLog(Action, "Assert element text equals", Status.PASS);
			}

		} else {
			Report.updateTestLog(Action, "Assert element text not equals", Status.FAIL);
		}

	}

	@Action(object = ObjectType.BROWSER, desc = "Check the credit card is removed,By using Last four digit number [<Data>]", input = InputType.YES)
	public void checkCreditCardisRemoved() {
		String Address = userData.getData("Authorized user Scenario", "Address line 1");
		if (Data.equalsIgnoreCase("visa")) {
			String number = userData.getData("Authorized user Scenario", "Visa Card last four number");
			String path = "//div[contains(text(),'" + number + "')]/parent::div/div[4]/div[2][contains(text(),'"
					+ Address + "')]";
			try {
				if (Driver.findElement(By.xpath(path)).isDisplayed()) {
					Report.updateTestLog(Action, "Credit card present", Status.FAIL);
				}
			} catch (org.openqa.selenium.NoSuchElementException e) {
				Report.updateTestLog(Action, "Credit card not present", Status.PASS);
			}

		} else if (Data.equalsIgnoreCase("Master")) {

			String number = userData.getData("Authorized user Scenario", "Master Card last four number");
			String path = "//div[contains(text(),'" + number + "')]/parent::div/div[4]/div[2][contains(text(),'"
					+ Address + "')]";
			try {
				if (Driver.findElement(By.xpath(path)).isDisplayed()) {
					Report.updateTestLog(Action, "Credit card present", Status.FAIL);
				}
			} catch (org.openqa.selenium.NoSuchElementException e) {
				Report.updateTestLog(Action, "Credit card not present", Status.PASS);
			}
		} else if (Data.equalsIgnoreCase("American")) {
			String number = userData.getData("Authorized user Scenario", "American Card last four number");
			String path = "//div[contains(text(),'" + number + "')]/parent::div/div[4]/div[2][contains(text(),'"
					+ Address + "')]";
			try {
				if (Driver.findElement(By.xpath(path)).isDisplayed()) {
					Report.updateTestLog(Action, "Credit card present", Status.FAIL);
				}
			} catch (org.openqa.selenium.NoSuchElementException e) {
				Report.updateTestLog(Action, "Credit card not present", Status.PASS);
			}
		} else {
			Report.updateTestLog(Action, "Check custom method", Status.FAIL);
		}

	}

	@Action(object = ObjectType.BROWSER, desc = "Check the AddessLine 1 [<Data>]", input = InputType.YES)
	public void checkAddressLineText() {

		if (Data.equalsIgnoreCase("visa")) {
			String number = userData.getData("Authorized user Scenario", "Visa Card last four number");
			String AddressLine1 = userData.getData("Authorized user Scenario", "Address line 1");
			String path = "//div[contains(text(),'" + number + "' )]/parent::div/parent::div/following-sibling::div[2]/div/div[2]";
			if (Driver.findElement(By.xpath(path)).getText().contains(AddressLine1)) {
				Report.updateTestLog(Action, "Assert element text equals", Status.PASS);
				Driver.findElement(By.xpath(path)).click();
			}
		} else if (Data.equalsIgnoreCase("Master")) {

			String number = userData.getData("Authorized user Scenario", "Master Card last four number");
			String AddressLine1 = userData.getData("Authorized user Scenario", "Address line 1");
			String path = "//div[contains(text(),'" + number + "' )]/parent::div/parent::div/following-sibling::div[2]/div/div[2]";
			if (Driver.findElement(By.xpath(path)).getText().contains(AddressLine1)) {
				Report.updateTestLog(Action, "Assert element text equals", Status.PASS);
				Driver.findElement(By.xpath(path)).click();

			}
		} else if (Data.equalsIgnoreCase("American")) {
			String number = userData.getData("Authorized user Scenario", "American Card last four number");
			String AddressLine1 = userData.getData("Authorized user Scenario", "Address line 1");
			String path = "//div[contains(text(),'" + number + "' )]/parent::div/parent::div/following-sibling::div[2]/div/div[2]";
			if (Driver.findElement(By.xpath(path)).getText().contains(AddressLine1)) {
				Report.updateTestLog(Action, "Assert element text equals", Status.PASS);
				Driver.findElement(By.xpath(path)).click();
			}

		} else {
			Report.updateTestLog(Action, "Assert element text not equals", Status.FAIL);
		}
	}

	@Action(object = ObjectType.BROWSER, desc = "Check owner name for the credit card [<Data>]", input = InputType.YES)
	public void CheckOwnername() {
		if (Data.equalsIgnoreCase("visa")) {
			String number = userData.getData("Authorized user Scenario", "Visa Card last four number");
			String ownerName = userData.getData("Authorized user Scenario", "Card Owner Name");

			WebElement findElement = Driver.findElement(
					By.xpath("//div[contains(text(),'" + number + "')]/parent::div/parent::div/following-sibling::div[3]"));
			String text = Driver
					.findElement(
							By.xpath("//div[contains(text(),'" + number + "')]/parent::div/parent::div/following-sibling::div[3]"))
					.getText();

			((JavascriptExecutor) Driver).executeScript("arguments[0].scrollIntoView(true);", findElement);
			if (text.equalsIgnoreCase(ownerName)) {
				Report.updateTestLog(Action, "Assert element text equals", Status.PASS);
			}
		} else if (Data.equalsIgnoreCase("Master")) {
			String number = userData.getData("Authorized user Scenario", "Master Card last four number");
			String ownerName = userData.getData("Authorized user Scenario", "Card Owner Name");

			WebElement findElement = Driver.findElement(
					By.xpath("//div[contains(text(),'" + number + "')]/parent::div/parent::div/following-sibling::div[3]"));
			String text = Driver
					.findElement(
							By.xpath("//div[contains(text(),'" + number + "')]/parent::div/parent::div/following-sibling::div[3]"))
					.getText();

			((JavascriptExecutor) Driver).executeScript("arguments[0].scrollIntoView(true);", findElement);
			if (text.equalsIgnoreCase(ownerName)) {
				Report.updateTestLog(Action, "Assert element text equals", Status.PASS);
			}
		} else if (Data.equalsIgnoreCase("American")) {
			String number = userData.getData("Authorized user Scenario", "American Card last four number");
			String ownerName = userData.getData("Authorized user Scenario", "Card Owner Name");

			WebElement findElement = Driver.findElement(
					By.xpath("//div[contains(text(),'" + number + "')]/parent::div/parent::div/following-sibling::div[3]"));
			String text = Driver
					.findElement(
							By.xpath("//div[contains(text(),'" + number + "')]/parent::div/parent::div/following-sibling::div[3]"))
					.getText();

			((JavascriptExecutor) Driver).executeScript("arguments[0].scrollIntoView(true);", findElement);
			if (text.equalsIgnoreCase(ownerName)) {
				Report.updateTestLog(Action, "Assert element text equals", Status.PASS);
			}
		} else {
			Report.updateTestLog(Action, "Assert element text not equals", Status.FAIL);
		}
	}

	// Once authorized user is added,check that the user name is visible below owner
	// name in payment information page
	@Action(object = ObjectType.BROWSER, desc = "Check authorized user is added for the credit card [<Data>]", input = InputType.YES)
	public void CheckAuthorizeduserisadded() {

		if (Data.equalsIgnoreCase("Visa")) {

			String number = userData.getData("Authorized user Scenario", "Visa Card last four number");
			String SecondaryUsername = userData.getData("Authorized user Scenario", "Secondary credit card name");
			if (Driver
					.findElement(
							By.xpath("//div[contains(text(),'" + number + "')]/parent::div/parent::div/following-sibling::div[3]/div/div[2]//li[2]"))
					.getText().equalsIgnoreCase(SecondaryUsername)) {
				Report.updateTestLog(Action, "Assert element text equals", Status.PASS);
			}

		} else if (Data.equalsIgnoreCase("Master")) {
			String number = userData.getData("Authorized user Scenario", "Master Card last four number");
			String SecondaryUsername = userData.getData("Authorized user Scenario", "Secondary credit card name");
			if (Driver
					.findElement(
							By.xpath("//div[contains(text(),'" + number + "')]/parent::div/parent::div/following-sibling::div[3]/div/div[2]//li[2]"))
					.getText().equalsIgnoreCase(SecondaryUsername)) {
				Report.updateTestLog(Action, "Assert element text equals", Status.PASS);
			}
		} else if (Data.equalsIgnoreCase("American")) {
			String number = userData.getData("Authorized user Scenario", "American Card last four number");
			String SecondaryUsername = userData.getData("Authorized user Scenario", "Secondary credit card name");
			if (Driver
					.findElement(
							By.xpath("//div[contains(text(),'" + number + "')]/parent::div/parent::div/following-sibling::div[3]/div/div[2]//li[2]"))
					.getText().equalsIgnoreCase(SecondaryUsername)) {
				Report.updateTestLog(Action, "Assert element text equals", Status.PASS);
			}
		} else {
			Report.updateTestLog(Action, "Assert element text not equals", Status.FAIL);
		}
	}

	// After remove authorized user, check that the user is removed in payment
	// information page
	@Action(object = ObjectType.BROWSER, desc = "Check authorized user is removed for the credit card [<Data>]", input = InputType.YES)
	public void CheckAuthorizeduserisRemoved() {

		if (Data.equalsIgnoreCase("Visa")) {

			String number = userData.getData("Authorized user Scenario", "Visa Card last four number");
			// String SecondaryUsername=userData.getData("Authorized user Scenario",
			// "Secondary credit card name");
			try {
				if (Driver
						.findElement(By.xpath(
								"//div[contains(text(),'" + number + "')]/parent::div/parent::div/following-sibling::div[3]/div/div[2]//li[2]"))
						.isDisplayed()) {
					Report.updateTestLog(Action, "Authorized user not removed", Status.FAIL);
				}
			} catch (org.openqa.selenium.NoSuchElementException e) {
				// TODO Auto-generated catch block
				Report.updateTestLog(Action, "Authorized user removed", Status.PASS);
			}

		} else if (Data.equalsIgnoreCase("Master")) {
			String number = userData.getData("Authorized user Scenario", "Master Card last four number");
			// String SecondaryUsername=userData.getData("Authorized user Scenario",
			// "Secondary credit card name");
			try {
				if (Driver
						.findElement(By.xpath(
								"//div[contains(text(),'" + number + "')]/parent::div/parent::div/following-sibling::div[3]/div/div[2]//li[2]"))
						.isDisplayed()) {
					Report.updateTestLog(Action, "Authorized user not removed", Status.FAIL);
				}
			} catch (org.openqa.selenium.NoSuchElementException e) {
				Report.updateTestLog(Action, "Authorized user removed", Status.PASS);
			}
		} else if (Data.equalsIgnoreCase("American")) {
			String number = userData.getData("Authorized user Scenario", "American Card last four number");
			// String SecondaryUsername=userData.getData("Authorized user Scenario",
			// "Secondary credit card name");
			try {
				if (Driver
						.findElement(By.xpath(
								"//div[contains(text(),'" + number + "')]/parent::div/parent::div/following-sibling::div[3]/div/div[2]//li[2]"))
						.isDisplayed()) {
					Report.updateTestLog(Action, "Authorized user not removed", Status.FAIL);
				}
			} catch (org.openqa.selenium.NoSuchElementException e) {
				Report.updateTestLog(Action, "Authorized user removed", Status.PASS);
			}
		} else {
			Report.updateTestLog(Action, "Check custom method", Status.FAIL);
		}
	}

	@Action(object = ObjectType.BROWSER, desc = "Add user in Add authorized popup", input = InputType.NO)
	public void AddAuthorizeduser() {
		String SecondaryUsername = userData.getData("Authorized user Scenario", "Secondary user");
		/*
		 * Driver.findElement(By.xpath("(//li[@onclick=\"ACC.newpayment.liClick('" +
		 * SecondaryUsername + "','#cboxLoadedContent .mainUl')\"])[2]")).click(); ;
		 */
		WebElement findElement = Driver.findElement(By.xpath("(//li[@onclick=\"ACC.newpayment.liClick('" + SecondaryUsername
				+ "','#cboxLoadedContent .mainUl')\"])[2]"));
		((JavascriptExecutor) Driver).executeScript("arguments[0].click();", findElement);
	}

	@Action(object = ObjectType.BROWSER, desc = "Get reservation from smart reserve page [<Data>]", input = InputType.YES)
	public void getReservation_SmartReservePage() {
		List<WebElement> findElements = Driver.findElements(By.xpath("//table[@id='DataTables_Table_"+Data+"']//tbody//tr"));
		int i = 1;
		for (WebElement webElement : findElements) {

			try {
				if (i <= 10) {
					Driver.findElement(By.xpath("//table[@id='DataTables_Table_"+Data+"']/tbody/tr[" + i + "]/td[6]/input"))
							.clear();
					String text = Driver
							.findElement(By.xpath("//table[@id='DataTables_Table_"+Data+"']/tbody/tr[" + i + "]/td[1]/a"))
							.getText();
					String attribute = Driver
							.findElement(
									By.xpath("//a[contains(text(),'" + text + "')]/parent::td/following::td[5]/input"))
							.getAttribute("onloadval");
					int parseInt = Integer.parseInt(attribute);
					String increasedQty = Integer.toString(parseInt + 1);
					String decreasedQty = Integer.toString(parseInt - 1);
					if (parseInt>1) {
						userData.putData("DS_Smart reserve page", "Reservation number", text);
						userData.putData("DS_Smart reserve page", "Quantity", attribute);
						userData.putData("DS_Smart reserve page", "Increase qty", increasedQty);
						userData.putData("DS_Smart reserve page", "Decrease qty", decreasedQty);
						break;	
					}
					
				}
			} catch (Exception e) {

			}
			i = i + 1;
		}
	}
	
	@Action(object = ObjectType.BROWSER, desc = "Swipe reservation in reservation summary", input = InputType.YES)
	public void swipeReservation() throws InterruptedException {
		/*
		 * WebElement findElement =
		 * Driver.findElement(By.xpath("(//span[text()=' Reservations Summary'])[1]"));
		 * ((JavascriptExecutor)
		 * Driver).executeScript("arguments[0].scrollIntoView(true);",findElement);
		 * Driver.findElement(By.xpath("(//span[text()=' Reservations Summary'])[1]")).
		 * click();
		 */
		String data2 = Data;
		String[] split = data2.split(",");
		List<WebElement> findElements = Driver.findElements(By.xpath("//table[@id='DataTables_Table_"+split[0]+"']//tbody//tr"));
		int i = 1;
		List li = new ArrayList<Integer>();
		List li1 = new ArrayList<Integer>();
		for (WebElement webElement : findElements) {

			try {
				if (i <= 10) {
					Driver.findElement(By.xpath("//table[@id='DataTables_Table_"+split[0]+"']/tbody/tr[" + i + "]/td[6]/input"))
							.clear();
					String text = Driver
							.findElement(By.xpath("//table[@id='DataTables_Table_"+split[0]+"']/tbody/tr[" + i + "]/td[1]/a"))
							.getText();
					String attribute = Driver
							.findElement(
									By.xpath("//a[contains(text(),'" + text + "')]/parent::td/following::td[5]/input"))
							.getAttribute("onloadval");
						int parseInt = Integer.parseInt(attribute);
						System.out.println(text);
						System.out.println(attribute);
						li.add(attribute);
						li1.add(text);
				}
			} catch (Exception e) {

			}
			i = i + 1;
	}
		 for (int l = 0, j = li.size() - 1; l < j; l++) {
	         // remove element from end and add it to beginning
	         String endElement = (String) li.remove(j);
	         li.add(l, endElement);
	      }
		for (int j = 0; j < li.size(); j++) {
			 Driver.findElement(By.xpath("//input[@aria-controls='DataTables_Table_"+split[0]+"']")).click();
			 Driver.findElement(By.xpath("//input[@aria-controls='DataTables_Table_"+split[0]+"']")).clear();
			Driver.findElement(By.xpath("//input[@aria-controls='DataTables_Table_"+split[0]+"']")).sendKeys((String) li1.get(j));
			Driver.findElement(By.xpath("(//tbody)["+split[1]+"]/tr/td[6]/input")).clear();
			Driver.findElement(By.xpath("(//tbody)["+split[1]+"]/tr/td[6]/input")).sendKeys((String)li.get(j));
			Thread.sleep(3000);
			if (Driver.findElement(By.xpath("(//button[contains(text(),'CONFIRM TOTAL')])["+split[1]+"]")).isEnabled()) {
				System.out.println("Confirm button enabled");
			} else {
				System.out.println("Confirm button not enabled");
			}
			int size = li.size();
			String valueOf = String.valueOf(size);
			userData.putData("DS_Smart reserve page", "Reservation number_"+j, (String) li1.get(j));
			userData.putData("DS_Smart reserve page", "Quantity_"+j, (String) li.get(j));
			userData.putData("DS_Smart reserve page", "Count", valueOf);
		}
	
	}
	@Action(object = ObjectType.BROWSER, desc = "Check the modified reservation in Reservation detail page", input = InputType.NO)
	public void modifiedReservationValuesCheck() {
		String data = userData.getData("DS_Smart reserve page", "Count");
		int count = Integer.parseInt(data);
		if (count>=1){
		for (int i = 0; i < count ; i++) {
			String reservationNumber = userData.getData("DS_Smart reserve page", "Reservation number_"+i);
			String quantity = userData.getData("DS_Smart reserve page", "Quantity_"+i);
			Driver.findElement(By.xpath("//input[@placeholder='You can search for anything here...']")).clear();
			Driver.findElement(By.xpath("//input[@placeholder='You can search for anything here...']")).sendKeys(reservationNumber);
			Driver.findElement(By.xpath("//i[@id='reservationKeywordsSearch']")).click();
			Driver.findElement(By.xpath("//u[contains(text(),'"+reservationNumber+"')]")).click();
			if(Driver.findElement(By.xpath("//p[contains(@class,'order-confirmation-summary')]")).getText().contains(reservationNumber)) {
				Report.updateTestLog(Action, reservationNumber+" Reservation number displayed as Expected", Status.PASS);
				WebElement findElement = Driver.findElement(By.xpath("//div[contains(@class,'rsv-packs-value')]"));
				((JavascriptExecutor) Driver).executeScript("arguments[0].scrollIntoView(true);",findElement);
				if (findElement.getText().contains(quantity)) {
					Report.updateTestLog(Action, quantity+" Quantity displayed as Expected", Status.PASS);
					Driver.findElement(By.xpath("//a[text()='Reservations']")).click();
				} else {
					Report.updateTestLog(Action, quantity+" Quantity displayed is not matched", Status.FAIL);
					Driver.findElement(By.xpath("//a[text()='Reservations']")).click();
				}
			}else {
				Report.updateTestLog(Action, reservationNumber+" Reservation number is not Matched", Status.FAIL);
			}
		}
		}else {
			Report.updateTestLog(Action, "Reservation cannot be modified in that page due to those are completed", Status.FAIL);
		}
	}
	
	@Action(object = ObjectType.BROWSER, desc = "To check the lock in date in footer [<Data>]", input = InputType.YES)
	public void checkLockInDateInFooter() {
		String s= Data;
		String[] l = s.split(" ");
		String[] split1 = l[2].toString().split(",");
		if (s.contains("Jan")) {
			String a = "January"+" "+l[1]+" "+split1[0];
			userData.putData("DS_Smart reserve page", "Date in footer", a);
			
		} else if (s.contains("Feb")){
			String a = "February"+" "+l[1]+" "+split1[0];
			userData.putData("DS_Smart reserve page", "Date in footer", a);
		} else if (s.contains("Mar")) {
			String a = "March"+" "+l[1]+" "+split1[0];
			userData.putData("DS_Smart reserve page", "Date in footer", a);
		} else if (s.contains("Apr")){
			String a = "April"+" "+l[1]+" "+split1[0];
			userData.putData("DS_Smart reserve page", "Date in footer", a);
			
		} else if (s.contains("May")) {
			String a = "May"+" "+l[1]+" "+split1[0];
			userData.putData("DS_Smart reserve page", "Date in footer", a);
		} else if (s.contains("Jun")){
			String a = "June"+" "+l[1]+" "+split1[0];
			userData.putData("DS_Smart reserve page", "Date in footer", a);
			
		} else if (s.contains("Jul")) {
			String a = "July"+" "+l[1]+" "+split1[0];
			userData.putData("DS_Smart reserve page", "Date in footer", a);
		} else if (s.contains("Aug")){
			String a = "August"+" "+l[1]+" "+split1[0];
			userData.putData("DS_Smart reserve page", "Date in footer", a);
			
		} else if (s.contains("Sep")) {
			String a = "September"+" "+l[1]+" "+split1[0];
			userData.putData("DS_Smart reserve page", "Date in footer", a);
		} else if (s.contains("Oct")){
			String a = "October"+" "+l[1]+" "+split1[0];
			userData.putData("DS_Smart reserve page", "Date in footer", a);
			
		} else if (s.contains("Nov")) {
			String a = "November"+" "+l[1]+" "+split1[0];
			userData.putData("DS_Smart reserve page", "Date in footer", a);
		}  else if (s.contains("Dec")) {
			String a = "December"+" "+l[1]+" "+split1[0];
			userData.putData("DS_Smart reserve page", "Date in footer", a);
		}
		
		
	}

	@Action(object = ObjectType.BROWSER, desc = "Select by state code", input = InputType.NO)
	public void selectByStateCode() {
		String statecode = userData.getData("Transit time data", "State Code");
		try {
			
		
		Driver.findElement((By.xpath("//span[text()='" + statecode + "']/parent::div//i"))).click();
		
		
		}catch(Exception e)
		{
			System.out.println("unable to click on the element");
			Driver.findElement((By.xpath("//span[text()='" + statecode + "']/parent::div/span[1]"))).click();	
			//span[text()='WA']/parent::div/span[1]
		}
	
	
	}

	// h4[text()='Authorized
	// users']//parent::div/ul/li[@data-uid='dinesh.subramanian74@gmail.com']/a
	@Action(object = ObjectType.BROWSER, desc = "Remove user by clicking X icon", input = InputType.NO)
	public void Xicon_RemoveAuthorizeduser() {
		String SecondaryUsername = userData.getData("Authorized user Scenario", "Secondary user");
		Driver.findElement(
				By.xpath("//h4[text()='Authorized users']//parent::div/ul/li[@data-uid='" + SecondaryUsername + "']/a"))
				.click();;
	}
	@Action(object = ObjectType.BROWSER, desc = "Get waitlisted doses from Flu dashboard page", input = InputType.NO)
	public void toGetWaitlistedDoses() {
		String text = Driver.findElement(By.xpath("//p[text()='Waitlisted']/following-sibling::p")).getText();
	/*	
		//  Old path  - //div[@class='flu-progress-wrapper'])[4]/div/span
		String[] split = text.split("    ");
		String f = split[1].toString();
		String[] split2 = f.split("/");
		System.out.println(Integer.parseInt(split2[0])/10);
		String waitlistPackDose = Integer.parseInt(split2[0])/10+" packs ("+split2[0]+" doses)";
		userData.putData("Smart Reserve Validation", "Wailisted packs dose", waitlistPackDose);
	*/
		String text1 = null;
		if (text.contains(",")) {
			text1 =text.replaceAll(",", "");
		} else {
			text1= text;
		}
		if (Integer.parseInt(text1)>0) {
			String waitlistPackDose = Integer.parseInt(text1)/10+" packs ("+text1+" doses)";
			userData.putData("Smart Reserve Validation", "Wailisted packs dose", waitlistPackDose);	
		}else {
			userData.putData("Smart Reserve Validation", "Wailisted packs dose", "");	
		}
		
	}
	
	@Action(object = ObjectType.BROWSER, desc = "To find List of webelements [<Data>]", input = InputType.YES)
	public void findelements() {
		String f = Data;
		
		List<WebElement> findElements = Driver.findElements(By.xpath(f));
		int size = findElements.size();
		int count = 0;
		for (WebElement webElement : findElements) {
			String text = webElement.getText();
			int parseInt = Integer.parseInt(text);
			count =parseInt;
		}
		String valueOf = String.valueOf(count);
		try {
			userData.putData("Smart Reserve Validation", "Count", valueOf);
		} catch (Exception e) {
			// TODO: handle exception
			userData.putData("Flu Reservation", "Reservation Count", valueOf);
		}
		
	}
	//div[@id='DataTables_Table_0_length']/following-sibling::div/a[2]/span
	@Action(object = ObjectType.BROWSER, desc = "Click on Right arrow in Reservation summary table [<Data>]", input = InputType.YES)
	public void clickRightArrow_SRP() throws InterruptedException {
		int reservation =11;
		String totalReservation =userData.getData("Smart Reserve Validation", "Total Row");
		String parsnt =userData.getData("Smart Reserve Validation", "Count");
		int parseInt = Integer.parseInt(parsnt);
		int size1=10;
			
				for (int i = 2; i <= parseInt; i++) {
					
				WebElement findElement = Driver.findElement(By.xpath("//div[@id='DataTables_Table_"+Data+"_length']/following-sibling::div/a[2]/span"));
				((JavascriptExecutor) Driver).executeScript("arguments[0].click();", findElement);
				Report.updateTestLog(Action, "Page count "+i, Status.PASS);	
				List<WebElement> findElements = Driver.findElements(By.xpath("//table[@id='DataTables_Table_"+Data+"']/tbody/tr"));
				
				int size = findElements.size();
				size1=size1+size;
			if(	Driver.findElement(By.xpath("//div[@id='DataTables_Table_"+Data+"_info']")).getText().contains("Displaying "+reservation+" to "+size1+" of "+totalReservation+" Orders")) {
				Report.updateTestLog(Action, "Text below reservation summary table "+"Displaying "+reservation+" to "+size1+" of "+totalReservation+" Orders", Status.PASS);	
				}else {
					Report.updateTestLog(Action, "Text not equals "+"Displaying "+reservation+" to "+size1+" of "+totalReservation+" Orders", Status.FAIL);
				}
			reservation=reservation+10;
				}
	}
	
	@Action(object = ObjectType.BROWSER, desc = "Click on Left arrow in Reservation summary table [<Data>]", input = InputType.YES)
	public void clickLeftArrow_SRP() {
		String parsnt =userData.getData("Smart Reserve Validation", "Count");
		int parseInt = Integer.parseInt(parsnt);
				for (int i = parseInt-1; i >=1 ; i--) {
					
				WebElement findElement = Driver.findElement(By.xpath("//div[@id='DataTables_Table_"+Data+"_length']/following-sibling::div/a[1]/span"));
				((JavascriptExecutor) Driver).executeScript("arguments[0].click();", findElement);
				Report.updateTestLog(Action, "Page count "+i, Status.PASS);	
			}
	}
	@Action(object = ObjectType.BROWSER, desc = "Click on Right arrow in Reservation summary table [<Data>]", input = InputType.YES)
	public void clickRightArrow_SRP_Bottom() throws InterruptedException {
		int reservation =11;
		String totalReservation =userData.getData("Smart Reserve Validation", "Total Row");
		String parsnt =userData.getData("Smart Reserve Validation", "Count");
		int parseInt = Integer.parseInt(parsnt);
		int size1=10;
				for (int i = 2; i <= parseInt; i++) {
					
				WebElement findElement = Driver.findElement(By.xpath("//div[@id='DataTables_Table_"+Data+"_info']/following-sibling::div/a[2]/span"));
				((JavascriptExecutor) Driver).executeScript("arguments[0].click();", findElement);
				Report.updateTestLog(Action, "Page count "+i, Status.PASS);	
				List<WebElement> findElements = Driver.findElements(By.xpath("//table[@id='DataTables_Table_"+Data+"']/tbody/tr"));
				
				int size = findElements.size();
				size1=size1+size;
			if(	Driver.findElement(By.xpath("//div[@id='DataTables_Table_"+Data+"_info']")).getText().contains("Displaying "+reservation+" to "+size1+" of "+totalReservation+" Orders")) {
				Report.updateTestLog(Action, "Text below reservation summary table "+"Displaying "+reservation+" to "+size1+" of "+totalReservation+" Orders", Status.PASS);	
				}else {
					Report.updateTestLog(Action, "Text not equals "+"Displaying "+reservation+" to "+size1+" of "+totalReservation+" Orders", Status.FAIL);
				}
			reservation=reservation+10;
				}
	}
	
	@Action(object = ObjectType.BROWSER, desc = "Click on Left arrow in Reservation summary table [<Data>]", input = InputType.YES)
	public void clickLeftArrow_SRP_Bottom() {
		String parsnt =userData.getData("Smart Reserve Validation", "Count");
		int parseInt = Integer.parseInt(parsnt);
			
				for (int i = parseInt-1; i >=1 ; i--) {
					
				WebElement findElement = Driver.findElement(By.xpath("//div[@id='DataTables_Table_"+Data+"_info']/following-sibling::div/a[1]/span"));
				((JavascriptExecutor) Driver).executeScript("arguments[0].click();", findElement);
				Report.updateTestLog(Action, "Page count "+i, Status.PASS);	
				
			}
		 
	}
	@Action(object = ObjectType.BROWSER, desc = "To check ::after ::before content in DOM structure [<Data>]", input = InputType.YES)
	public void toCheck_After_Before_Content() throws InterruptedException {
		String g=Data;
	//	WebElement switchLabel = Driver.findElement(By.cssSelector("#reservationsummarybtn")); 
		WebElement switchLabel = Driver.findElement(By.xpath("(//button[@id='reservationsummarybtn'])["+g+"]")); 
		String colorRG1B = ((JavascriptExecutor)Driver) 
		        .executeScript("return window.getComputedStyle(arguments[0], ':after').getPropertyValue('content');",switchLabel).toString(); 
	//	((JavascriptExecutor) Driver).executeScript("arguments[0].scrollIntoView(true);", switchLabel);
		if (colorRG1B.contains("View Details +")) {
			Report.updateTestLog(Action, "Text Present "+colorRG1B, Status.PASS);	
		} else {
			Report.updateTestLog(Action, "Text not Present "+colorRG1B, Status.FAIL);
		}
	//	WebElement switchLabel1 = Driver.findElement(By.cssSelector("#reservationsummarybtn")); 
		((JavascriptExecutor) Driver).executeScript("arguments[0].click();", switchLabel);
		String colorRG1B2 = ((JavascriptExecutor)Driver) 
		        .executeScript("return window.getComputedStyle(arguments[0], ':after').getPropertyValue('content');",switchLabel).toString();
		if (colorRG1B2.contains("Hide Details -")) {
			Report.updateTestLog(Action, "Text Present "+colorRG1B2, Status.PASS);	
		} else {
			Report.updateTestLog(Action, "Text not Present "+colorRG1B2, Status.FAIL);
		}
	}

	@Action(object = ObjectType.BROWSER, desc = "Get active shipTo from addresses tab", input = InputType.NO)
	public void getActiveShipToNumber() throws InterruptedException {
		List<WebElement> findElements = Driver.findElements(By.xpath("//table/tbody/tr")); 
		List<String> e1 = new ArrayList<String>();
		int i=1; 
		for (WebElement webElement:findElements){
		String b = "";
			System.out.println(Driver.findElement(By.xpath("//tbody/tr[" + i + "]/td[6]")).getText());
			if (Driver.findElement(By.xpath("//tbody/tr[" + i + "]/td[6]")).getText().contains("Active")) { 
																											 
				String text =
				Driver.findElement(By.xpath("(//tbody//tr[" + i + "]//td[contains(text(),'')])[3]")).getText();
				String[] split = text.split(" ");
				String a = split[3].toString();
				String[] split2 = a.split("");
				
				for (int j = 0; j < 10; j++) {
					b = b + split2[j].toString();
				}
				System.out.println(b);
				e1.add(b);
			}
			i = i + 1;

		}
		Driver.findElement(By.id("order-active")).click(); 
		  Thread.sleep(10000);
		for (String string : e1) {
			System.out.println(string);

		  Thread.sleep(10000);
		 Driver.findElement(By.id("shiptosearch")).sendKeys(string);
		 
		// ((JavascriptExecutor) Driver).executeScript("arguments[0].scrollIntoView(true);",  Driver.findElement(By.xpath("//span[contains(text(),'1100551403')]")));
		 Driver.findElement(By.xpath("//span[contains(text(),'"+string+"')]")).click();
		 Driver.findElement(By.id("orderForThisAddressBtn")).click();
		 
		 Thread.sleep(10000);
		 if(Driver.findElement(By.xpath("//div[@id='account-information-div']/div[3]/div/div[1]/div[6]")).getText().contains("Not valid") || Driver.findElement(By.xpath("//div[@id='account-information-div']/div[3]/div/div[1]/div[6]")).getText().contains("Due to expire on") || Driver.findElement(By.xpath("//div[@id='account-information-div']/div[3]/div/div[2]/div[6]")).getText().contains("Class of trade:FEDERAL")) {
			 
			 Driver.findElement(By.id("changeShipToLink")).click();
			 System.out.println("state licence not valid");
		 }else {
			 try {
				 userData.getData("Data", "Active ShipTo");
				 userData.putData("Data", "Active ShipTo", string); 
					System.out.println("Active shipto");
			} catch (Exception e) {
				// TODO: handle exception
				userData.putData("Flu Reservation", "ShipTo", string); 
				System.out.println("Active shipto");
			}
			 
			
			break;
		 }
		}
	}

	@Action(object = ObjectType.BROWSER, desc = "Get Active shipTo_2 from addresses tab", input = InputType.NO)
	public void getActiveShipToNumber_2() throws InterruptedException {
		List<WebElement> findElements = Driver.findElements(By.xpath("//table/tbody/tr")); 
		List<String> e1 = new ArrayList<String>();
		int i=1; 
		for (WebElement webElement:findElements){
		String b = "";
			System.out.println(Driver.findElement(By.xpath("//tbody/tr[" + i + "]/td[6]")).getText());
			if (Driver.findElement(By.xpath("//tbody/tr[" + i + "]/td[6]")).getText().contains("Active")) { 
																											 
				String text =
				Driver.findElement(By.xpath("(//tbody//tr[" + i + "]//td[contains(text(),'')])[3]")).getText();
				String[] split = text.split(" ");
				String a = split[3].toString();
				String[] split2 = a.split("");
				
				for (int j = 0; j < 10; j++) {
					b = b + split2[j].toString();
				}
				System.out.println(b);
				e1.add(b);
			}
			i = i + 1;

		}
		Driver.findElement(By.id("order-active")).click(); 
		  Thread.sleep(10000);
		for (String string : e1) {
			System.out.println(string);

		  Thread.sleep(10000);
		 Driver.findElement(By.id("shiptosearch")).sendKeys(string);
		 
		// ((JavascriptExecutor) Driver).executeScript("arguments[0].scrollIntoView(true);",  Driver.findElement(By.xpath("//span[contains(text(),'1100551403')]")));
		 Driver.findElement(By.xpath("//span[contains(text(),'"+string+"')]")).click();
		 Driver.findElement(By.id("orderForThisAddressBtn")).click();
		 
		 Thread.sleep(10000);
		 if(Driver.findElement(By.xpath("//div[@id='account-information-div']/div[3]/div/div[1]/div[6]")).getText().contains("Not valid") || Driver.findElement(By.xpath("//div[@id='account-information-div']/div[3]/div/div[1]/div[6]")).getText().contains("Due to expire on")|| Driver.findElement(By.xpath("//div[@id='account-information-div']/div[3]/div/div[2]/div[6]")).getText().contains("Class of trade:FEDERAL")) {
			
			 Driver.findElement(By.id("changeShipToLink")).click();
			 System.out.println("State licence not valid");
		 }else {
			 String data2 ="";
			 try {
			  data2 =  userData.getData("Data", "Active ShipTo");
				if (data2.contains(string)) {
					 Driver.findElement(By.id("changeShipToLink")).click();
				}
					
				}catch(Exception e){
					 data2 =  userData.getData("Flu Reservation", "ShipTo");
						if (data2.contains(string)) {
							 Driver.findElement(By.id("changeShipToLink")).click();
						}	
					}
				if (!data2.contains(string)) {
					try {
						userData.getData("Data", "Active ShipTo");
						System.out.println("Active shipto 2");
						userData.putData("Data", "Active ShipTo_2", string);
						
					} catch (Exception e) {
						userData.putData("Flu Reservation", "shipto2", string); 
						System.out.println("Active shipto");
					}
					break;
				}
		 }
		}
	}

	
	@Action(object = ObjectType.BROWSER, desc = "Get Active shipTo_3 from addresses tab", input = InputType.NO)
	public void getActiveShipToNumber_3() throws InterruptedException {
		List<WebElement> findElements = Driver.findElements(By.xpath("//table/tbody/tr")); 
		List<String> e1 = new ArrayList<String>();
		int i=1; 
		for (WebElement webElement:findElements){
		String b = "";
			System.out.println(Driver.findElement(By.xpath("//tbody/tr[" + i + "]/td[6]")).getText());
			if (Driver.findElement(By.xpath("//tbody/tr[" + i + "]/td[6]")).getText().contains("Active")) { 
																											 
				String text =
				Driver.findElement(By.xpath("(//tbody//tr[" + i + "]//td[contains(text(),'')])[3]")).getText();
				String[] split = text.split(" ");
				String a = split[3].toString();
				String[] split2 = a.split("");
				
				for (int j = 0; j < 10; j++) {
					b = b + split2[j].toString();
				}
				System.out.println(b);
				e1.add(b);
			}
			i = i + 1;

		}
		Driver.findElement(By.id("order-active")).click(); 
		  Thread.sleep(10000);
		for (String string : e1) {
			System.out.println(string);

		  Thread.sleep(10000);
		 Driver.findElement(By.id("shiptosearch")).sendKeys(string);
		 
		// ((JavascriptExecutor) Driver).executeScript("arguments[0].scrollIntoView(true);",  Driver.findElement(By.xpath("//span[contains(text(),'1100551403')]")));
		 Driver.findElement(By.xpath("//span[contains(text(),'"+string+"')]")).click();
		 Driver.findElement(By.id("orderForThisAddressBtn")).click();
		 
		 Thread.sleep(10000);
		 if(Driver.findElement(By.xpath("//div[@id='account-information-div']/div[3]/div/div[1]/div[6]")).getText().contains("Not valid") || Driver.findElement(By.xpath("//div[@id='account-information-div']/div[3]/div/div[1]/div[6]")).getText().contains("Due to expire on")|| Driver.findElement(By.xpath("//div[@id='account-information-div']/div[3]/div/div[2]/div[6]")).getText().contains("Class of trade:FEDERAL")) {
			
			 Driver.findElement(By.id("changeShipToLink")).click();
			 System.out.println("State licence not valid");
		 }else {
			 String data2 =  userData.getData("Data", "Active ShipTo");
			 String data3 =  userData.getData("Data", "Active ShipTo_2"); 
				if (data2.contains(string) || data3.contains(string)) {
					 Driver.findElement(By.id("changeShipToLink")).click();
					 
					}
				if (!data2.contains(string) && !data3.contains(string)) {
					System.out.println("Active shipto 3");
					userData.putData("Data", "Active ShipTo_3", string);
					break;
				}
		 }
		}
	}

	@Action(object = ObjectType.BROWSER, desc = "Get Pending shipTo from addresses tab", input = InputType.NO)
	public void getPendingShipToNumber() {
		List<WebElement> findElements = Driver.findElements(By.xpath("//table/tbody/tr"));
		// int k =findElements.size();

		int i = 1;
		for (WebElement webElement : findElements) {
			System.out.println(Driver.findElement(By.xpath("//tbody/tr[" + i + "]/td[6]")).getText());
			if (Driver.findElement(By.xpath("//tbody/tr[" + i + "]/td[6]")).getText().contains("Pending")) {
				// System.out.println("activeeee");
				String text = Driver.findElement(By.xpath("(//tbody//tr[" + i + "]//td[contains(text(),'')])[3]"))
						.getText();
				String[] split = text.split(" ");
				String a = split[3].toString();
				String[] split2 = a.split("");
				String shipTo = "";
				for (int j = 0; j < 10; j++) {
					shipTo = shipTo + split2[j].toString();
				}
				// System.out.println(b);
				userData.putData("Data", "Pending ShipTo", shipTo);
				break;
			}
			i = i + 1;

		}
	}
	
	@Action(object = ObjectType.BROWSER, desc = "Select newly added credit card in shopping cart page,  Visa, Mastercard, Amercian Express [<Data>]", input = InputType.YES)
	public void selectCreditCardFromDropdown() {
	/*	org.openqa.selenium.support.ui.Select objSelect = new org.openqa.selenium.support.ui.Select(
				Driver.findElement(By.xpath("//select[@class='form-control1 card-section']")));
		*/
		Driver.findElement(By.xpath("//select[@class='form-control1 card-section']")).click();
		if (Data.equalsIgnoreCase("Visa")) {
			String data2 = userData.getData("Authorized user Scenario", "Visa Card last four number");
			Driver.findElement(By.xpath("//option[contains(text(),'Visa  ************"+data2+"')]")).click();
			//objSelect.selectByVisibleText("Visa  ************" + data2);
		} else if (Data.equalsIgnoreCase("Master")) {
			String data2 = userData.getData("Authorized user Scenario", "Master Card last four number");
			Driver.findElement(By.xpath("//option[contains(text(),'MasterCard  ********"+data2+"')]")).click();
			//objSelect.selectByVisibleText("MasterCard  ********" + data2);
		} else if (Data.equalsIgnoreCase("American")) {
			String data2 = userData.getData("Authorized user Scenario", "American Card last four number");
			Driver.findElement(By.xpath("//option[contains(text(),'American Express  ********"+data2+"')]")).click();
			//objSelect.selectByVisibleText("American Express  ********" + data2);
		} else {
			System.out.println("No card");
		}

	}

	@Action(object = ObjectType.BROWSER, desc = "Select newly added credit card in shopping cart page,  Visa, Mastercard, Amercian Express [<Data>]", input = InputType.YES)
	public void selectCreditCardFromDropdown_Regression() {
		org.openqa.selenium.support.ui.Select objSelect = new org.openqa.selenium.support.ui.Select(
				Driver.findElement(By.xpath("//select[@class='form-control1 card-section']")));

		if (Data.equalsIgnoreCase("Visa")) {
			String data2 = userData.getData("LastFour number", "Visa Card last four number");
			objSelect.selectByVisibleText("Visa ************" + data2);
			Report.updateTestLog(Action, "Creditcard selected", Status.PASS);

		} else if (Data.equalsIgnoreCase("Master")) {
			String data2 = userData.getData("LastFour number", "Master Card last four number");
			objSelect.selectByVisibleText("MasterCard ********" + data2);
			Report.updateTestLog(Action, "Creditcard selected", Status.PASS);
		} else if (Data.equalsIgnoreCase("American")) {
			String data2 = userData.getData("LastFour number", "American Card last four number");
			objSelect.selectByVisibleText("American Express ********" + data2);
			Report.updateTestLog(Action, "Creditcard selected", Status.PASS);
		} else {
			Report.updateTestLog(Action, "No Card", Status.FAIL);
			System.out.println("No card");
		}
	}

	
	@Action(object = ObjectType.BROWSER, desc = "click Custom element [<Data>]", input = InputType.YES)
	public void clickNDCInBackoffice() throws InterruptedException {
		Thread.sleep(10000);
		WebElement findElement = Driver.findElement(By.xpath(Data));
	findElement.click();
	System.out.println(Data);
	}
	
	@Action(object = ObjectType.BROWSER, desc = "Double click Custom element [<Data>]", input = InputType.YES)
	public void doubleClick() throws InterruptedException {
	Thread.sleep(10000);	
		WebElement findElement = Driver.findElement(By.xpath(Data));
	Actions a = new Actions(Driver);
	a.doubleClick(findElement);
	System.out.println(Data);
	}
	
	
	@Action(object = ObjectType.BROWSER, desc = "Get only state licence number from product orderable page [<Data>]", input = InputType.YES)
	public void splitStateLicenceNumber() {
		String s = Data;
		String[] split = s.split(":");
		String string = split[1].toString();
		String[] split2 = string.split("-");
		String statelicencenumber = split2[0].toString().trim();
		userData.putData("Data", "State Licence Number", statelicencenumber);
	}
	@Action(object = ObjectType.BROWSER, desc = "Get only state licence number from product orderable page [<Data>]", input = InputType.YES)
	public void stateLicenceExpirationDate() {	
	String s = Data;
	String[] split = s.split(" ");
	String f=split[1].toString().replace(",", "-") + split[0].toString()+"-"+split[2].toString().replace(",", "").substring(2, 4);
	userData.putData("Date", "Expiration Date", f);
	}
	
	@Action(object = ObjectType.BROWSER, desc = "Get only state licence number from product orderable page [<Data>]", input = InputType.YES)
	public void identifier_Type() {	
		String sln = Data;
String type = Driver.findElement(By.xpath("//span[contains(text(),'"+sln+"')]/ancestor::td[1]/preceding-sibling::td[1]/div/span")).getText();
String[] identifier = type.split("-");
userData.putData("Data", "Identifier Type", identifier[0]);
	}
	@Action(object = ObjectType.BROWSER, desc = "Split state code from country in backoffice addresses tab [<Data>]", input = InputType.YES)
	public void splitStateCode() {	
	String s=Data;
	String[] split = s.split(" ");
	
	for (int i = 0; i < split.length; i++) {
		if (split[i].toString().contains("[")) {
			int length = split[i].toString().length();
			System.out.println(length);
			if (length<=4) {
				CharSequence subSequence = split[i].toString().subSequence(1, 3);
				userData.putData("Data", "State Code", subSequence.toString());
			} else {
				CharSequence subSequence = split[i].toString().subSequence(4, 6);
				userData.putData("Data", "State Code", subSequence.toString());
				
			}
		}
	}
	}
	
	@Action(object = ObjectType.BROWSER, desc = "values should be in 1000, 1second =1000  [<Data>]", input = InputType.YES)
	public void thread_Sleep() throws InterruptedException {
		int time = Integer.parseInt(Data);
		Thread.sleep(time);
	}
	@Action(object = ObjectType.BROWSER, desc = "Validate percent in Flu Dashboard page [<Data>]", input = InputType.YES)
	public void validate_PercentInFluDashboard() {
		String s = Data;
		String[] split = s.replace("%", "").split(" ");
		
	}
	
	
	
	
	
	
	
	
	@Action(object = ObjectType.BROWSER,desc = "Trim the value of [<Data>]",input = InputType.YES)
	public void trimNumber() {
		
		String[] orderarray=Data.split(" ");
		int length=orderarray.length;
		if(length==3)
		{
		userData.putData("ReturnData", "flunumber", orderarray[length-1]);
		}
		else
		{
			Report.updateTestLog(Action, "Order number is :: " +orderarray[length-1], Status.DONE);	
			userData.putData("ReturnData", "ordernumber", orderarray[length-1]);	
		}
	
	}
	
	
	@Action(object = ObjectType.BROWSER,desc = "Date Format [<Object>]",input = InputType.YES)
	public void formatDate() {
		Date objDate = new Date(); // Current System Date and time is assigned to objDate
		System.out.println(objDate);
		String strDateFormat = "MMM dd, yy, hh:mm:ss a"; // Date format is Specified
		SimpleDateFormat objSDF = new SimpleDateFormat(strDateFormat); // Date format string is passed as an argument to
																		// the Date format object
		System.out.println(objSDF.format(objDate));
		userData.putData("CMR", "FormattedDate", objSDF.format(objDate));
	}
	@Action(object = ObjectType.BROWSER,desc = "Date Format [<Data>]",input = InputType.YES)
	public void setStartDate() throws ParseException {
		Date objDate=new SimpleDateFormat("dd/MM/yyyy").parse(Data);
		String strDateFormat = "MMM dd, yy, 12:00:00 a"; // Date format is Specified
		SimpleDateFormat objSDF = new SimpleDateFormat(strDateFormat); // Date format string is passed as an argument to
																// the Date format object
		userData.putData("Promotion", "FormattedDate", objSDF.format(objDate));
	}
	@Action(object = ObjectType.BROWSER,desc = "Date Format [<Data>]",input = InputType.YES)
	public void setEndDate() throws ParseException {
		Date objDate=new SimpleDateFormat("dd/MM/yyyy").parse(Data);
		String strDateFormat = "MMM dd, yy, 11:59:59 aa"; // Date format is Specified
		SimpleDateFormat objSDF = new SimpleDateFormat(strDateFormat); // Date format string is passed as an argument to
																		// the Date format object
		userData.putData("Promotion", "FormattedDate", objSDF.format(objDate));
	}
	@Action(object = ObjectType.BROWSER,desc = "Get Reservation Number [<Object>]",input = InputType.NO)
	public void getReservationNumber() throws ParseException {
		String reservno = Driver.findElement(By.xpath("//h2[@class='order-to-title orderConfirmPageTitle']")).getText();
		String[] split = reservno.split(" ");
		try {		
			//Get qty due to create exception  while running the promotion scripts
			
			String qty = userData.getData("Flu Reservation", "Qty");
			userData.putData("Flu Reservation", "ReservationNo", split[split.length-1]);
			
			Report.updateTestLog(Action, "Flu Reservation number is :: " +split[split.length-1], Status.DONE);	
		} catch (Exception e) {
			// TODO: handle exception
			userData.putData("Promotion", "ReservationNumber", split[split.length-1]);
			Report.updateTestLog(Action, "Promotion Reservation number is :: " +split[split.length-1], Status.DONE);
		}
	}
	@Action(object = ObjectType.BROWSER,desc = "Get Order Number [<Object>]",input = InputType.NO)
	public void getOrderNumber() throws ParseException {
		String[] split;
		try {
		String orderno = Driver.findElement(By.xpath("//p[@class='order-to-title orderConfirmPageTitle']")).getText();
		split = orderno.split(" ");
		userData.getData("ComplexCart", "Order1");
		userData.putData("ComplexCart", "Order1", split[split.length-1]);
		
		}catch(Exception e){
			String orderno = Driver.findElement(By.xpath("//p[@class='order-to-title orderConfirmPageTitle']")).getText();
			split = orderno.split(" ");
			userData.putData("Flu Reservation", "OrderNo", split[split.length-1]);
		}
		
	}
	@Action(object = ObjectType.BROWSER,desc = "Upload File [<Object>]",input = InputType.NO)
    public void uploadFile() throws IOException, AWTException, InterruptedException {
           File fo = new File("Import Allocation.csv");
           System.out.println(fo.getAbsolutePath());
		StringSelection ss = new StringSelection(fo.getAbsolutePath());
           Robot robot = new Robot();
             Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
             Thread.sleep(5000);
             robot.keyPress(KeyEvent.VK_CONTROL);
             robot.keyPress(KeyEvent.VK_V);
             robot.keyRelease(KeyEvent.VK_CONTROL); 
             robot.keyRelease(KeyEvent.VK_V);
             robot.keyRelease(KeyEvent.VK_CONTROL); 
             robot.keyPress(KeyEvent.VK_ENTER);
    robot.keyRelease(KeyEvent.VK_ENTER);
    }
	@Action(object = ObjectType.BROWSER,desc = "Upload File [<Object>]",input = InputType.NO)
    public void uploadOrderUpload() throws IOException, AWTException, InterruptedException {
           File fo = new File("Order Upload For Allocation.csv");
           System.out.println(fo.getAbsolutePath());
		StringSelection ss = new StringSelection(fo.getAbsolutePath());
           Robot robot = new Robot();
             Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
             Thread.sleep(5000);
             robot.keyPress(KeyEvent.VK_CONTROL);
             robot.keyPress(KeyEvent.VK_V);
             robot.keyRelease(KeyEvent.VK_CONTROL); 
             robot.keyRelease(KeyEvent.VK_V);
             robot.keyRelease(KeyEvent.VK_CONTROL); 
             robot.keyPress(KeyEvent.VK_ENTER);
    robot.keyRelease(KeyEvent.VK_ENTER);
    }
	@Action(object = ObjectType.BROWSER,desc = "Upload File [<Object>]",input = InputType.YES)
    public void uploadOrderFile() throws IOException, AWTException, InterruptedException {
           File fo = new File(Data);
           System.out.println(fo.getAbsolutePath());
		StringSelection ss = new StringSelection(fo.getAbsolutePath());
           Robot robot = new Robot();
             Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
             Thread.sleep(5000);
             robot.keyPress(KeyEvent.VK_CONTROL);
             robot.keyPress(KeyEvent.VK_V);
             robot.keyRelease(KeyEvent.VK_CONTROL); 
             robot.keyRelease(KeyEvent.VK_V);
             robot.keyRelease(KeyEvent.VK_CONTROL); 
             robot.keyPress(KeyEvent.VK_ENTER);
    robot.keyRelease(KeyEvent.VK_ENTER);
    }
	
	@Action(object = ObjectType.BROWSER,desc = "Edit CSV File [<Object>] with no input",input = InputType.NO)
    public void ESTDateAndTime() {
		Locale locale = new Locale("en", "US");
		Date date = new Date();
		//Jun 1, 22, 3:43:08 AM
		DateFormat df = new SimpleDateFormat("MMM dd, yy, hh:mm:ss a");
		Calendar cell = Calendar.getInstance();
		cell.setTime(date);
		cell.add(Calendar.HOUR, 0);
		df.setTimeZone(TimeZone.getTimeZone("America/New_York"));
		String Date = df.format(cell.getTime());
		System.out.println("Date and time in America: " + df.format(date));
		
		try {
			userData.getData("Data", "State Licence Number");
			userData.putData("Data", "TimeCreated", df.format(date));
		} catch (Exception e) {
			// TODO: handle exception
			userData.putData("Flu Reservation", "TimeCreated", df.format(date));
		}
		
	}
	@Action(object = ObjectType.BROWSER,desc = "Edit CSV File [<Object>] with input <0,0>",input = InputType.YES)
    public void estDateAndTime_withInputs() {
		Locale locale = new Locale("en", "US");
		Date date = new Date();
		String[] split = Data.split(",");
		DateFormat df = new SimpleDateFormat("MMM dd, yy, hh:mm:ss a");
		df.setTimeZone(TimeZone.getTimeZone("America/New_York"));
		Calendar cell = Calendar.getInstance();
		cell.setTime(date);
		cell.add(Calendar.HOUR, Integer.parseInt(split[1]));
		cell.add(Calendar.MINUTE, Integer.parseInt(split[2]));
		cell.add(Calendar.DATE, Integer.parseInt(split[0]));
		String Date = df.format(cell.getTime());
		try {
		try {
			userData.getData("Data", "State Licence Number");
			userData.putData("Data", "TimeCreated", Date);
		} catch (Exception e) {
			// TODO: handle exception
			userData.getData("Flu Reservation", "TimeCreated");
			userData.putData("Flu Reservation", "TimeCreated", Date);
		}
	} catch (Exception e) {
		// TODO: handle exception
		userData.putData("Promotion", "FormattedDate", Date);
	}
	}
	
	@Action(object = ObjectType.BROWSER,desc = "Edit CSV File [<Object>] with input <Date,Hour,Minute>",input = InputType.YES)
    public void estDateAndTime_DSI() {
		Locale locale = new Locale("en", "US");
		Date date = new Date();
		String[] split = Data.split(",");
		DateFormat df = new SimpleDateFormat("hh:mm:ss a");
		df.setTimeZone(TimeZone.getTimeZone("America/New_York"));
		Calendar cell = Calendar.getInstance();
		cell.setTime(date);
		cell.add(Calendar.HOUR, Integer.parseInt(split[1]));
		cell.add(Calendar.MINUTE, Integer.parseInt(split[2]));
		cell.add(Calendar.DATE, Integer.parseInt(split[0]));
		String Date = df.format(cell.getTime());
		try {
			userData.putData("Date", "Future Date", Date);
	} catch (Exception e) {
		Report.updateTestLog(Action, "check custom method", Status.FAIL);
	}
	}
	

	@Action(object = ObjectType.BROWSER,desc = "check error file was created for OUP, IA (ErrorDataFile,Error Validation File,Error Validation)",input = InputType.YES)
    public void errorFileCreatedCheck() {
	 try {
		 
		 Actions mouse = new Actions(Driver);
		 WebElement errorfileinputbox = Driver.findElement(By.xpath("//span[contains(text(),'"+Data+"')]/parent::div/following-sibling::div/div[2]/div//span"));
		 ((JavascriptExecutor) Driver).executeScript("arguments[0].scrollIntoView(true);", errorfileinputbox);
		 errorfileinputbox.getText();
		 System.out.println(errorfileinputbox.getText());
		 WebElement errorfileinputbox1 = Driver.findElement(By.xpath("(//span[contains(text(),'"+Data+"')]/parent::div/following-sibling::div/div[2]/div//tr)[1]")); 
		 System.out.println(errorfileinputbox1);
		 Thread.sleep(10000);
		 System.out.println("Sleep Added");
		 ((JavascriptExecutor) Driver).executeScript("arguments[0].scrollIntoView(true);", errorfileinputbox1);
		 mouse.doubleClick(errorfileinputbox1).build().perform();
		 System.out.println("Clicked");
		// errorfileinputbox.click();
		 Report.updateTestLog(Action, "Error File was created and going forward to download", Status.PASS);
		 
		 Thread.sleep(5000);
		 WebElement btnDownload = Driver.findElement(By.xpath("//button[text()='Download']"));
		 ((JavascriptExecutor) Driver).executeScript("arguments[0].scrollIntoView(true);", btnDownload);
		 btnDownload.click();
		 if (Data.contains("Error Validation")) {
			 System.out.println("Entering Loop if");
			errorFileValidation_ImportFile(Data);
		} else {
			 System.out.println("Entering Loop else");
			errorFileValidation();
		}
		 
	} catch (Exception e) {
		Report.updateTestLog(Action, "Error File was not created Check it manual", Status.FAIL);
	}
		
	}
	
	@Action(object = ObjectType.BROWSER,desc = "Error file validation for Import allocation order file",input = InputType.NO)
    public void errorFileValidation_ImportFile(String value) throws InterruptedException {
		List<String> y = new ArrayList<String>();
		Thread.sleep(10000);
		System.out.println("entering Error file loop");
		
	if (value.equals("Error Validation File")) {	
		System.out.println("Enter list add");
		y.add("Error details");
		y.add("Reservation Order Reserve does not exist. ");
		y.add("One or more fields not populated. ");
		y.add("\"Allocation quantity must be a positive"); 
		//, non-zero number. Quantity read: 0 converts to: 0.
		y.add("Allocation Criteria ID does not exist. "); 
		y.add("Allocation Criteria ID does not exist. ");
		y.add("One or more fields not populated. ");
		y.add("Reservation Order null does not exist. "); 
		y.add("Reservation Order 1226369847 does not exist. "); 
		y.add("Reservation Order 0000000000 does not exist. ");
		y.add("\"Invalid allocation quantity: Allocation Quantity Formatting error: java.lang.NumberFormatException: For input string: \"\"Allocation Quantity\"\". Reservation Order 344534523 does not exist. Allocation Criteria ID does not exist. \"");
		y.add("\"Invalid allocation quantity: Allocation Quantity Formatting error: java.lang.NumberFormatException: For input string: \"\"Allocation Quantity\"\". Reservation Order null does not exist. Allocation Criteria ID does not exist. \"");
	} else if(value.contains("ErrorDataFile")) {	
		 String shipto = userData.getData("Flu Reservation", "ShipTo");
			String qty = userData.getData("Flu Reservation", "Qty");
	      	String reservenumber = userData.getData("Flu Reservation", "ReservationNo");	
	        String  data2 = userData.getData("Flu Reservation", "PK ID");
	       Long.valueOf(data2);
	       String ndc1 = userData.getData("Flu Reservation", "Products");
	       String shipto2 = userData.getData("Flu Reservation","shipto2");
	       String ndc2 = userData.getData("Flu Reservation", "product 2");
//	[null]:Uploaded Product NDC 5816089052 does not match with reservation Order NDC 19515080852 for the  Reservation Order 1007989273 with allocation Id 8816508228305       
y.add("Alternate Delivery Address Line 1");
y.add("[null]:Ship to 4433234566 is not valid for the reservation order "+reservenumber+" with allocation Id "+ Long.valueOf(data2));
y.add("[null]:Given Contract 32434323 is not active  for reservation order "+reservenumber+" with shipto "+shipto);	
y.add("[null]:Product NDC 1434541852 is not valid for the Reservation Order "+reservenumber+" with allocation Id "+Long.valueOf(data2));
y.add("[null]:uploaded quantity 10000 can not be more then total reserved quantity "+qty+".0 for the AllocationId "+Long.valueOf(data2)+" and the Reservation Order No "+reservenumber);
y.add("[null]:Delivery Date Thu Jun 09 00:00:00 EDT 2022 is Not an Available Date for Delivery  for the Reservation Order "+reservenumber+" with allocation id "+Long.valueOf(data2));
y.add("[null]:User with user id ppg@gsk.com cannot be found for the Reservation Order "+reservenumber+" with Ship To "+shipto);
y.add("[null]:Reservation Order1043234523 is not valid with Allocation Id "+ Long.valueOf(data2));
y.add("[null]:Allocation cannot be found for the allocation Id 8976565656243 and the Reservation Order No "+reservenumber);
y.add("[null]:Given Contract 0 is not active  for reservation order "+reservenumber+" with shipto "+shipto);
y.add("[null]:Ship to 0 is not valid for the reservation order "+reservenumber+" with allocation Id "+Long.valueOf(data2));
y.add("[null]:Product Quantity must not be null or zero for the Reservation Order "+reservenumber+" with Allocation Id "+Long.valueOf(data2));
y.add("[null]:Reservation Order0 is not valid with Allocation Id "+Long.valueOf(data2));
y.add("[null]:Allocation cannot be found for the allocation Id 0 and the Reservation Order No "+reservenumber);
y.add("[null]:User with user id 0 cannot be found for the Reservation Order "+reservenumber+" with Ship To "+shipto);
y.add("[null]:Payment Info 0 must be invoice for the Reservation Order "+reservenumber+" with allocation Id "+Long.valueOf(data2));
y.add("[null]:User with user id null cannot be found for the Reservation Order "+reservenumber+" with Ship To "+shipto);
y.add("[null]:Payment Info null must be invoice for the Reservation Order "+reservenumber+" with allocation Id "+Long.valueOf(data2));
y.add("[null]:Uploaded Product NDC "+ndc2+" does not match with reservation Order NDC "+ndc1+" for the Reservation Order "+reservenumber+" with allocation Id "+Long.valueOf(data2));
y.add("[null]:Customer does not belong to the shipTo "+shipto2+" for Reservation Order "+reservenumber+" with allocation Id is"+Long.valueOf(data2));
y.add("[null]:Given Contract null is not active  for reservation order "+reservenumber+" with shipto "+shipto);
y.add("[null]:Reservation Ordernull is not valid with Allocation Id null");
y.add("[null]:Reservation Ordernull is not valid with Allocation Id "+Long.valueOf(data2));
y.add("[null]:Ship to null is not valid for the reservation order "+reservenumber+" with allocation Id "+Long.valueOf(data2));
y.add("[null]:Ship to shipto is not valid for the reservation order "+reservenumber+" with allocation Id "+Long.valueOf(data2));
y.add("[null]:Given Contract contract is not active  for reservation order "+reservenumber+" with shipto "+shipto);
y.add("[null]:Product NDC ndc is not valid for the Reservation Order "+reservenumber+" with allocation Id "+Long.valueOf(data2));
y.add("[null]:User with user id user cannot be found for the Reservation Order "+reservenumber+" with Ship To "+shipto);
y.add("[null]:Payment Info payment must be invoice for the Reservation Order "+reservenumber+" with allocation Id "+Long.valueOf(data2));
y.add("[null]:Reservation Orderreservatio is not valid with Allocation Id "+Long.valueOf(data2));
y.add("[null]:Product NDC must not be null for the Reservation Order "+reservenumber+" with allocation Id "+Long.valueOf(data2));
y.add("[null]:Ship To Number/ID must not be null for the reservation Order "+reservenumber+" with allocation Id"+Long.valueOf(data2));
	 }
	else {
		String qty = userData.getData("Flu Reservation", "Qty");
		String reservenumber = userData.getData("Flu Reservation", "ReservationNo");
		y.add("Error details");
		y.add("Allocation Quantity "+qty+" exceeds the Remaining Quantity or Total Pull Forward Quantity in the Allocation Criteria. Allocation Quantity "+qty+" exceeds the Remaining Quantity available in reservation order : "+reservenumber+". ");	
		
	}
//[null]:Delivery Date Thu Jun 09 00:00:00 EDT 2022	
	System.out.println("After adding list of file going to download the error file");
	 File theNewestFile = null;
	 String pathh = userData.getData("Flu Reservation", "Download Path");
	    File dir = new File(pathh);
	    System.out.println(dir);
	

	    FileFilter fileFilter = new WildcardFileFilter("*.csv");
	    File[] files = dir.listFiles(fileFilter);

	    if (files.length > 0) {
	        /** The newest file comes first **/
	        Arrays.sort(files, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
	        theNewestFile = files[0];
	    }
	String line = "";
    String splitBy = ",";
    List<String> l = new ArrayList<String>();
    try {
      //parsing a CSV file into BufferedReader class constructor  
    //	"C:\\Users\\dxs31911\\Downloads\\list.csv"
      BufferedReader br = new BufferedReader(new FileReader(theNewestFile));
      System.out.println(theNewestFile);
     
      while ((line = br.readLine()) != null ) {
      //returns a Boolean value  
  
        String[] employee = line.split(splitBy);
      try {
    	  if (value.equals("Error Validation File")) {
    		  System.out.println(l.add(employee[3]));
    			System.out.println(employee[3]);
		} else if(value.contains("ErrorDataFile")){
			System.out.println(l.add(employee[12]));
			System.out.println(employee[12]);
		}else {
			System.out.println(l.add(employee[3]));
			System.out.println(employee[3]);
		}
		
	} catch (Exception e) {
	}
    }
    }
    catch(IOException e) {
      e.printStackTrace();
      System.out.println("Unable to take the latest file from Download folder");
    }
  
    List<String> l2 = new ArrayList<String>();
    //implement new
    if (l.size()==y.size()) {
  	  System.out.println(l);
   	  System.out.println(y);
   	for (String object : l) {
		for (String object2 : y) {
			if (object2.toString().contains(object.toString())) {
				System.out.println(l2.add(object));
				Report.updateTestLog(Action,object , Status.PASS);
				break;
			}
		}
	}
    }
    System.out.println("===");
    System.out.println(l2);
   	 if (l.equals(l2)) {
    	 Report.updateTestLog(Action, "Values from downloaded file and custom method values are equal" , Status.PASS);	
	} else {
		Report.updateTestLog(Action, "Actual value from download file and custom method values are not equal" , Status.FAIL);
	}
	}
	
	
	@Action(object = ObjectType.BROWSER,desc = "Error file creation for Import Allocation (Specially for Error popup)",input = InputType.YES)
    public void errorFileEditCsvImportAllocation() throws FileNotFoundException {
		 File fo = new File("Import Allocation.csv");
         System.out.println(fo.getAbsolutePath());
         String path =fo.getAbsolutePath();
         PrintWriter pw = new PrintWriter(new File(path));
         StringBuilder s = new StringBuilder();
         
         if (Data.contains("4")) {
        	 s.append("");
         }else {
         s.append("Reservation Order # ");
         s.append(",");
         s.append(" Allocation Quantity");
         s.append(",");
         s.append(" Allocation Criteria ID");
         s.append(",");
         s.append("\r\n");
         
         }
         
		if (Data.contains("1")) {
			s.append(userData.getData("Flu Reservation", "ReservationNo"));
			s.append(",");
			 s.append(userData.getData("Flu Reservation", "Qty"));   
			 s.append(",");
		}else if (Data.contains("2")) {
			
			
		}else if (Data.contains("3")) {
			s.append(userData.getData("Flu Reservation", "ReservationNo"));
			s.append(",");
			s.append("quantity");
			s.append(",");
			s.append(userData.getData("Flu Reservation", "AllocationCriteriaID")); 
			s.append(",");
			
		}else if (Data.contains("5")) {
			s.append(userData.getData("Flu Reservation", "ReservationNo"));
			s.append(",");
			s.append("null");
			s.append(",");
			s.append(userData.getData("Flu Reservation", "AllocationCriteriaID")); 
			s.append(",");
		}
         pw.write(s.toString());
         pw.close();
         System.out.println("Finished");
	}
	

	@Action(object = ObjectType.BROWSER,desc = "Error file creation for Import Allocation for invalid and valid scenario's",input = InputType.NO)
    public void errorFileEditCsvImportAllocation_Sc() throws FileNotFoundException {
		 File fo = new File("Import Allocation.csv");
         System.out.println(fo.getAbsolutePath());
         String path =fo.getAbsolutePath();
         PrintWriter pw = new PrintWriter(new File(path));
         StringBuilder s = new StringBuilder();
        
         s.append("Reservation Order # ");
         s.append(",");
         s.append(" Allocation Quantity");
         s.append(",");
         s.append(" Allocation Criteria ID");
         s.append(",");
         s.append("\r\n");
         
      for (int i = 0; i <=11; i++) {
		
	  
		if (i==0) {
			s.append("null");
			s.append(",");
			 s.append(userData.getData("Flu Reservation", "Qty"));   
			 s.append(",");
			 s.append(userData.getData("Flu Reservation", "AllocationCriteriaID"));
			 s.append(",");
		}else if (i==1) {
			s.append("0000000000");
			s.append(",");
			 s.append(userData.getData("Flu Reservation", "Qty"));   
			 s.append(",");
			 s.append(userData.getData("Flu Reservation", "AllocationCriteriaID"));
			 s.append(",");
		}else if (i==2) {
			
			s.append("Reserve");
			s.append(",");
			 s.append(userData.getData("Flu Reservation", "Qty"));
			s.append(",");
			s.append(userData.getData("Flu Reservation", "AllocationCriteriaID")); 
			s.append(",");
			
		}else if (i==3) {
			s.append(userData.getData("Flu Reservation", "ReservationNo"));
			s.append(",");
			 s.append("0");
			s.append(",");
			s.append(userData.getData("Flu Reservation", "AllocationCriteriaID")); 
			s.append(",");
		}else if (i==4) {
			s.append(userData.getData("Flu Reservation", "ReservationNo"));
			s.append(",");
			 s.append(userData.getData("Flu Reservation", "Qty"));
			s.append(",");
			s.append("0"); 
			s.append(",");
		}else if (i==5) {
			s.append(userData.getData("Flu Reservation", "ReservationNo"));
			s.append(",");
			 s.append(userData.getData("Flu Reservation", "Qty"));
			s.append(",");
			s.append("null"); 
			s.append(",");
		}else if (i==6) {
			s.append(",");
			 s.append(userData.getData("Flu Reservation", "Qty"));
			s.append(",");
			s.append(userData.getData("Flu Reservation", "AllocationCriteriaID")); 
			s.append(",");
		}else if (i==7) {
			s.append(userData.getData("Flu Reservation", "ReservationNo"));
			s.append(",");
			s.append(",");
			s.append(userData.getData("Flu Reservation", "AllocationCriteriaID")); 
			s.append(",");
		}else if (i==8) {
			s.append("1226369847");
			s.append(",");
			 s.append(userData.getData("Flu Reservation", "Qty")); 
			s.append(",");
			s.append(userData.getData("Flu Reservation", "AllocationCriteriaID")); 
			s.append(",");
		}else if (i==9) {
			//Valid Loop
			s.append(userData.getData("Flu Reservation", "ReservationNo"));
			s.append(",");
			 s.append(userData.getData("Flu Reservation", "Qty")); 
			s.append(",");
			s.append(userData.getData("Flu Reservation", "AllocationCriteriaID")); 
			s.append(",");
		} else if(i==10) {
			s.append("null");
			s.append(",");
			 s.append("Allocation Quantity"); 
			s.append(",");
			s.append("Allocation Criteria ID"); 
			s.append(",");
		}else if (i==11) {
			s.append("344534523");
			s.append(",");
			 s.append("Allocation Quantity"); 
			s.append(",");
			s.append("Allocation Criteria ID"); 
			s.append(",");
		}
		 s.append("\r\n");
	}
      pw.write(s.toString());
      pw.close();
      System.out.println("Finished");
	}
	
	
	@Action(object = ObjectType.BROWSER,desc = "Error file validation for order upload for allocation file",input = InputType.NO)
    public void errorFileValidation() throws InterruptedException {
			Thread.sleep(10000);
			String shipto = userData.getData("Flu Reservation", "ShipTo");
			String qty = userData.getData("Flu Reservation", "Qty");
	      	String reservenumber = userData.getData("Flu Reservation", "ReservationNo");	
	        String  data2 = userData.getData("Flu Reservation", "PK ID");
	       Long.valueOf(data2);
	       String ndc1 = userData.getData("Flu Reservation", "Products");
	       String shipto2 = userData.getData("Flu Reservation","shipto2");
	       String ndc2 = userData.getData("Flu Reservation", "product 2");

	       List<String> y = new ArrayList<String>();
	
	       
	//	[null]:Uploaded Product NDC 5816089052 does not match with reservation Order NDC 19515080852 for the  Reservation Order 1007989273 with allocation Id 8816508228305       
	       
	y.add("Alternate Delivery Address Line 1");
	y.add("[null]:Ship to 4433234566 is not valid for the reservation order "+reservenumber+" with allocation Id "+ Long.valueOf(data2));
	y.add("[null]:Given Contract 32434323 is not active  for reservation order "+reservenumber+" with shipto "+shipto);	
	y.add("[null]:Product NDC 1434541852 is not valid for the Reservation Order "+reservenumber+" with allocation Id "+Long.valueOf(data2));
	y.add("[null]:uploaded quantity 10000 can not be more then total reserved quantity "+qty+".0 for the AllocationId "+Long.valueOf(data2)+" and the Reservation Order No "+reservenumber);
	y.add("[null]:Delivery Date Thu Jun 09 00:00:00 EDT 2022 is Not an Available Date for Delivery  for the Reservation Order "+reservenumber+" with allocation id "+Long.valueOf(data2));
	y.add("[null]:User with user id ppg@gsk.com cannot be found for the Reservation Order "+reservenumber+" with Ship To "+shipto);
	y.add("[null]:Reservation Order1043234523 is not valid with Allocation Id "+ Long.valueOf(data2));
	y.add("[null]:Allocation cannot be found for the allocation Id 8976565656243 and the Reservation Order No "+reservenumber);
	y.add("[null]:Given Contract 0 is not active  for reservation order "+reservenumber+" with shipto "+shipto);
	y.add("[null]:Ship to 0 is not valid for the reservation order "+reservenumber+" with allocation Id "+Long.valueOf(data2));
	y.add("[null]:Product Quantity must not be null or zero for the Reservation Order "+reservenumber+" with Allocation Id "+Long.valueOf(data2));
	y.add("[null]:Reservation Order0 is not valid with Allocation Id "+Long.valueOf(data2));
	y.add("[null]:Allocation cannot be found for the allocation Id 0 and the Reservation Order No "+reservenumber);
	y.add("[null]:User with user id 0 cannot be found for the Reservation Order "+reservenumber+" with Ship To "+shipto);
	y.add("[null]:Payment Info 0 must be invoice for the Reservation Order "+reservenumber+" with allocation Id "+Long.valueOf(data2));
	y.add("[null]:User with user id null cannot be found for the Reservation Order "+reservenumber+" with Ship To "+shipto);
	y.add("[null]:Payment Info null must be invoice for the Reservation Order "+reservenumber+" with allocation Id "+Long.valueOf(data2));
	y.add("[null]:Uploaded Product NDC "+ndc2+" does not match with reservation Order NDC "+ndc1+" for the Reservation Order "+reservenumber+" with allocation Id "+Long.valueOf(data2));
	y.add("[null]:Customer does not belong to the shipTo "+shipto2+" for Reservation Order "+reservenumber+" with allocation Id is"+Long.valueOf(data2));
	y.add("[null]:Given Contract null is not active  for reservation order "+reservenumber+" with shipto "+shipto);
	y.add("[null]:Reservation Ordernull is not valid with Allocation Id null");
	y.add("[null]:Reservation Ordernull is not valid with Allocation Id "+Long.valueOf(data2));
	y.add("[null]:Ship to null is not valid for the reservation order "+reservenumber+" with allocation Id "+Long.valueOf(data2));
	y.add("[null]:Ship to shipto is not valid for the reservation order "+reservenumber+" with allocation Id "+Long.valueOf(data2));
	y.add("[null]:Given Contract contract is not active  for reservation order "+reservenumber+" with shipto "+shipto);
	y.add("[null]:Product NDC ndc is not valid for the Reservation Order "+reservenumber+" with allocation Id "+Long.valueOf(data2));
	y.add("[null]:User with user id user cannot be found for the Reservation Order "+reservenumber+" with Ship To "+shipto);
	y.add("[null]:Payment Info payment must be invoice for the Reservation Order "+reservenumber+" with allocation Id "+Long.valueOf(data2));
	y.add("[null]:Reservation Orderreservatio is not valid with Allocation Id "+Long.valueOf(data2));
	y.add("[null]:Product NDC must not be null for the Reservation Order "+reservenumber+" with allocation Id "+Long.valueOf(data2));
	y.add("[null]:Ship To Number/ID must not be null for the reservation Order "+reservenumber+" with allocation Id"+Long.valueOf(data2));

	//[null]:Delivery Date Thu Jun 09 00:00:00 EDT 2022	
	String pathh = userData.getData("Flu Reservation", "Download Path");
		 File theNewestFile = null;
		    File dir = new File(pathh);
		    System.out.println(dir);
		
	
		    FileFilter fileFilter = new WildcardFileFilter("*.csv");
		    File[] files = dir.listFiles(fileFilter);

		    if (files.length > 0) {
		        /** The newest file comes first **/
		        Arrays.sort(files, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
		        theNewestFile = files[0];
		    }
		String line = "";
	    String splitBy = ",";
	    List<String> l = new ArrayList<String>();
	    try {
	      //parsing a CSV file into BufferedReader class constructor  
	    //	"C:\\Users\\dxs31911\\Downloads\\list.csv"
	      BufferedReader br = new BufferedReader(new FileReader(theNewestFile));
	      System.out.println(theNewestFile);
	     
	      while ((line = br.readLine()) != null ) {
	      //returns a Boolean value  
	  
	        String[] employee = line.split(splitBy);
	      try {
			System.out.println(l.add(employee[12]));
			System.out.println(employee[12]);
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	        //use comma as separator  
	      //  System.out.println("Emp[First Name=" + employee[1] + ", Last Name=" + employee[2] + ", Contact=" + employee[3] + "]");
	      }
	    }
	    catch(IOException e) {
	      e.printStackTrace();
	    }
	    
	    int k =0;
	      for (String string : l) {
	     for (int i = k; i <=k; i++) {
	    	 
			  System.out.println(l);
	    	  System.out.println(y);
			if (string.contains(y.get(i))) {
				Report.updateTestLog(Action, string , Status.PASS);	
			} else {
				Report.updateTestLog(Action, string , Status.FAIL);
			}
		}
	     k++;
	      }
	      if (l.equals(y)==true) {
	    	  Report.updateTestLog(Action, "Values from downloaded file and custom method values are equal" , Status.PASS);	
		}else {
			Report.updateTestLog(Action, "Values from downloaded file and custom method values are not equal" , Status.FAIL);	
		}
	}
	
	
	@Action(object = ObjectType.BROWSER,desc = "Edit CSV File [<Object>]",input = InputType.YES)
    public void multipleReservation() throws FileNotFoundException {
		 File theNewestFile = null;
		    File dir = new File(Data);
		    System.out.println(dir);
		
	
		    FileFilter fileFilter = new WildcardFileFilter("*.csv");
		    File[] files = dir.listFiles(fileFilter);

		    if (files.length > 0) {
		        /** The newest file comes first **/
		        Arrays.sort(files, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
		        theNewestFile = files[0];
		    }
		String line = "";
	    String splitBy = ";";
	    //List l -> This is for Reservation numbers
	    //List q -> This is for Quantity
	    List l = new ArrayList<Long>();
	    List qty = new ArrayList<Long>();
	    
	    Long a = 0L;
	    
	    try {
	      //parsing a CSV file into BufferedReader class constructor  
	    //	"C:\\Users\\dxs31911\\Downloads\\list.csv"
	      BufferedReader br = new BufferedReader(new FileReader(theNewestFile));
	     
	      while ((line = br.readLine()) != null ) {
	      //returns a Boolean value  
	    	  System.out.println("++++");
	  System.out.println(line );
	  System.out.println("++++");
	        String[] employee = line.split(splitBy);
	      try {
	    	  
			System.out.println(Long.valueOf(employee[0]));
			System.out.println(l.add(Long.valueOf(employee[0])));
			String s=employee[4].toString();
			System.out.println(s);
			String replace = s.replace(".", ",");
			String[] split = replace.split(",");
			
			System.out.println(split[0].toString());
			System.out.println(qty.add(split[0].toString()));
			a=a+Long.valueOf(split[0].toString());
			
			
		} catch (Exception e) {
			// TODO: handle exception
			//Report.updateTestLog(Action, "Enter Catch 1 method, Please check custom method" , Status.FAIL);				
		}
	        //use comma as separator  
	      //  System.out.println("Emp[First Name=" + employee[1] + ", Last Name=" + employee[2] + ", Contact=" + employee[3] + "]");
	      }
	    }
	    catch(IOException e) {
	    //  e.printStackTrace();
	     // Report.updateTestLog(Action, "Enter Catch 2 method, Please check custom method" , Status.FAIL);	
	    }
	    
	    userData.putData("Flu Reservation", "Qty", Long.toString(a));
	    PrintWriter pw = new PrintWriter(new File(System.getProperty("user.dir")+"\\Import Allocation.csv"));
	    System.out.println(System.getProperty("user.dir")+"\\Import Allocation.csv");
     StringBuilder s = new StringBuilder();
     s.append("Reservation Order # ");
     s.append(",");
     s.append(" Allocation Quantity");
     s.append(",");
     s.append(" Allocation Criteria ID");
     s.append(",");
     s.append("\r\n");
     for (int i = 0; i < l.size(); i++) {
     	s.append(l.get(i))	;
     	s.append(",");
     	s.append(qty.get(i));
     	s.append(",");
     	s.append(userData.getData("Flu Reservation", "AllocationCriteriaID"));
     	s.append("\r\n");
		}
     pw.write(s.toString());
     pw.close();
	}
	
	
	@Action(object = ObjectType.BROWSER,desc = "Edit CSV File [<Object>]",input = InputType.NO)
    public void editCSVFile() throws IOException, AWTException, InterruptedException {
           File fo = new File("Import Allocation.csv");
           System.out.println(fo.getAbsolutePath());
           String path =fo.getAbsolutePath();
           PrintWriter pw = new PrintWriter(new File(path));
           StringBuilder s = new StringBuilder();
           s.append("Reservation Order # ");
           s.append(",");
           s.append(" Allocation Quantity");
           s.append(",");
           s.append(" Allocation Criteria ID");
           s.append(",");
           s.append("\r\n");
           try {
        	   s.append(userData.getData("Promotion", "ReservationNumber"));
		} catch (Exception e) {
			// TODO: handle exception
			 s.append(userData.getData("Flu Reservation", "ReservationNo"));
		}
          
           s.append(",");
           try {
        	   s.append(userData.getData("Promotion", "AllocationQTY"));
           }catch(Exception e) {
        	   s.append(userData.getData("Flu Reservation", "Qty"));   
           }
           s.append(",");
           try {
        	   s.append(userData.getData("Promotion", "AllocationCriteriaID"));
           }catch(Exception e) {
        	   s.append(userData.getData("Flu Reservation", "AllocationCriteriaID"));   
           }
           s.append(",");
           s.append("\r\n");
           pw.write(s.toString());
           pw.close();
           System.out.println("Finished");
    }
	
	
	@Action(object = ObjectType.BROWSER,desc = "Promotion : Creating import allocation file for multiple flu products",input = InputType.YES)
    public void editImportAllocationFile_MultipleProduct() throws IOException, AWTException, InterruptedException {
           File fo = new File("Import Allocation.csv");
           
           String[] split = Data.split(",");
           System.out.println(fo.getAbsolutePath());
           String path =fo.getAbsolutePath();
           PrintWriter pw = new PrintWriter(new File(path));
           StringBuilder s = new StringBuilder();
           s.append("Reservation Order # ");
           s.append(",");
           s.append(" Allocation Quantity");
           s.append(",");
           s.append(" Allocation Criteria ID");
           s.append(",");
           s.append("\r\n");
           for (int i = 1; i <= 2; i++) {	
           if (i==1) {
        	   s.append(userData.getData("Promotion", "ReservationNumber"));
		} else {
			 s.append(split[0].toString());
		}
           s.append(",");
           s.append(userData.getData("Promotion", "AllocationQTY"));
           s.append(",");
           if (i==1) {
        	  s.append(userData.getData("Promotion", "AllocationCriteriaID"));
		} else {
			 s.append(split[1].toString());
		}
           s.append(",");
           s.append("\r\n");
           }
           pw.write(s.toString());
           pw.close();
           System.out.println("Finished");
    }
	
	@Action(object = ObjectType.BROWSER,desc = "To select expected delivery date for order upload file",input = InputType.NO)
    public void mulitpleExpectedDeliveryDate() throws InterruptedException {
		expectedDeliveryDate();
		Driver.findElement(By.xpath("//i[@class='fa fa-calendar fa-lg cursor-pointer']")).click();
		
		List<WebElement> findElements = Driver.findElements(By.xpath("//td[@title='Available']"));
		String data2 = userData.getData("Flu Reservation", "Delivery date");
		System.out.println(data2);
		int i =0;
		for (WebElement webElement : findElements) {
			if (i==1) {
				webElement.click();
				expectedDeliveryDate();
				String data3 = userData.getData("Flu Reservation", "Delivery date");
				System.out.println(data3);
				userData.putData("Flu Reservation", "Delivery date", data2+","+data3);
				System.out.println(data2+","+data3);
				break;
			}
			i++;
		}
	}
	
	
	@Action(object = ObjectType.BROWSER,desc = "To select expected delivery date for order upload file",input = InputType.NO)
    public void expectedDeliveryDate() throws InterruptedException  {
		//Prerequesites: need to add one product to shopping cart
		String attribute = Driver.findElement(By.xpath("//input[@class='form-control1 deliverydate hasDatepicker']")).getAttribute("value");
		String[] split2 = attribute.split(" ");
		String[] split3 = split2[0].split("-");
		
		if (split3[1].equalsIgnoreCase("January")) {
			split3[1]="1";
		} else if (split3[1].equalsIgnoreCase("February")){
			split3[1]="2";
		} else if (split3[1].equalsIgnoreCase("March")) {
	
			split3[1]="3";
		} else if (split3[1].equalsIgnoreCase("April")){
			split3[1]="4";
		} else if (split3[1].equalsIgnoreCase("May")) {
			split3[1]="5";
		} else if (split3[1].equalsIgnoreCase("June")){
			split3[1]="6";
		} else if (split3[1].equalsIgnoreCase("July")) {
			split3[1]="7";
		} else if (split3[1].equalsIgnoreCase("August")){
			split3[1]="8";
		} else if (split3[1].equalsIgnoreCase("September")) {
			split3[1]="9";
		} else if (split3[1].equalsIgnoreCase("October")){
			split3[1]="10";
		} else if (split3[1].equalsIgnoreCase("November")) {
			split3[1]="11";
		}  else if (split3[1].equalsIgnoreCase("December")) {
			split3[1]="12";
		}	
		System.out.println(split3[1]+"/"+split3[0]+"/"+split2[1]);
		userData.putData("Flu Reservation", "Delivery date", split3[1]+"/"+split3[0]+"/"+split2[1]);
		/*Alternate way
		 * String Date; Thread.sleep(2000); Driver.findElement(By.
		 * xpath("//i[@class='fa fa-calendar fa-lg cursor-pointer']")).click();
		 * List<WebElement> findElements =
		 * Driver.findElements(By.xpath("//td[@title='Available']"));
		 * System.out.println(findElements.size()); for (int i = 1; i <=
		 * findElements.size(); i++) { System.out.println("doc");
		 * System.out.println("ddd"); Thread.sleep(10000); System.out.println(
		 * Driver.findElement(By.xpath("(//td[@title='Available'])["+i+"]/a")).getText()
		 * ); System.out.println("bingo"); DateFormat f = new
		 * SimpleDateFormat("M/yyyy"); Date date = new Date(); Calendar cell =
		 * Calendar.getInstance();
		 * 
		 * cell.setTime(date); Date =
		 * Driver.findElement(By.xpath("(//td[@title='Available'])["+i+"]/a")).getText()
		 * +"/"+f.format(cell.getTime()); String[] split = Date.split("/"); String
		 * Expected
		 * =split[1].toString()+"/"+split[0].toString()+"/"+split[2].toString();
		 * userData.putData("Flu Reservation", "Delivery date", Expected);
		 * System.out.println(Expected); break; }
		 */
		
	}
	
	@Action(object = ObjectType.BROWSER,desc = "Take all the available shipto from split shipment page",input = InputType.YES)
    public void shipToFromSplitShipment() throws IOException, AWTException, InterruptedException {
		List l = new ArrayList<String>();
		List<WebElement> findElements = Driver.findElements(By.xpath("//div[contains(@class,'ss-flu-top row productRowItem product-item row')]/div[1]"));
		int j=1;
		for (WebElement webElement : findElements) {
			for (int i = j; i <= j; i++) {
				WebElement findElement3 = Driver.findElement(By.xpath("(//div[contains(@class,'ss-flu-top row productRowItem product-item row')])["+i+"]"));
				WebElement findElement2 = Driver.findElement(By.xpath("(//div[contains(@class,'cart-product-info-shipto col')])["+i+"]"));
				if (!findElement3.getAttribute("class").contains("disable") && !findElement2.getText().contains("PENDING")) {
					System.out.println(findElement2.getText());
					l.add(findElement2.getText());
				} else {
System.out.println("Please check custom method");
				}	
			}
			j++;
			
			}
		if (Data.equalsIgnoreCase("Single Delivery date")) {
			editCsvOrderupload(l);
		} else {
			editCsvOrderupload_Mulituple(l);
		}
		
	}

	@Action(object = ObjectType.BROWSER,desc = "Edit CSV File [<Object>]",input = InputType.NO)
    public void editCsvOrderupload_Mulituple(List l) throws IOException, AWTException, InterruptedException {
		
		 File fo = new File("Order Upload For Allocation.csv");
         System.out.println(fo.getAbsolutePath());
         String path =fo.getAbsolutePath();
         PrintWriter pw = new PrintWriter(new File(path));
         
         StringBuilder s = new StringBuilder();
         s.append("Ship To Number/ID");
         s.append(",");
         s.append("Contract GNUM");
         s.append(",");
         s.append("NDC");
         s.append(",");
         s.append("QTY (Packs)");
         s.append(",");
         s.append("PO #");
         s.append(",");
         s.append("Expected Delivery Date");
         s.append(",");
         s.append("Admin User ID of ST");
         s.append(",");
         s.append("Payment Info");
         s.append(",");
         s.append("paymentInfoId");
         s.append(",");
         s.append("Reservation Order Number");
         s.append(",");
         s.append("Allocation ID");
         s.append(",");
         s.append("Alternate Delivery Address Company Name");
         s.append(",");
         s.append("Alternate Delivery Address Line 1");
         s.append(",");
         s.append("Alternate Delivery Address Line 2");
         s.append(",");
         s.append("Alternate Delivery Address City");
         s.append(",");
         s.append("Alternate Delivery Address State");
         s.append(",");
         s.append("Alternate Delivery Address ZIP Code");
         s.append(",");
         s.append("Delivery Instructions");
         s.append(",");
         s.append("\r\n");
         //2nd Row
         int u =l.size();
 		int tk = 220/u;
 		userData.putData("Flu Reservation", "Reservation Count", String.valueOf(u*tk));
 		for (int kk = 0; kk < tk; kk++) {
        for (int i = 0; i < l.size(); i++) {
        	
         s.append(l.get(i)); // -- NEED TO CONDILIDATE
         s.append(",");
        // String d = "=\"00000000\"";
         String d ="00000000";
         s.append(d);
         s.append(",");
         s.append(userData.getData("Flu Reservation", "Products"));
         s.append(","); 
         s.append(userData.getData("Flu Reservation", "Allocation QTY"));
         s.append(",");
         s.append("PO Instruction");
         s.append(",");
         String data3 = userData.getData("Flu Reservation", "Delivery date");
         String[] split = data3.split(",");
         if (i==0) {
			s.append(split[0]);
			s.append(",");
		}else {
			s.append(split[1]);
			s.append(",");
		}
		s.append(userData.getData("Flu Reservation", "User ID"));
         s.append(",");
         s.append("Invoice");
         s.append(",");
         s.append("");
         s.append(",");
         s.append(userData.getData("Flu Reservation", "ReservationNo"));
         s.append(",");
         String data2 = userData.getData("Flu Reservation", "PK ID");
         s.append(Long.valueOf(data2));
         s.append(",");
         s.append("\r\n");
         } 
        
 		}
         pw.write(s.toString());
 		Thread.sleep(10000);
 	 pw.close();
         System.out.println("Finished");
	}
	
	@Action(object = ObjectType.BROWSER,desc = "Edit CSV error File [<Object>]",input = InputType.NO)
	public void errorFileEditCsvOrderUpload() throws FileNotFoundException, InterruptedException {
		// TODO Auto-generated method stub
		 File fo = new File("Order Upload For Allocation.csv");
        System.out.println(fo.getAbsolutePath());
        String path =fo.getAbsolutePath();
        PrintWriter pw = new PrintWriter(new File(path));
        StringBuilder s = new StringBuilder();
        s.append("Ship To Number/ID");
        s.append(",");
        s.append("Contract GNUM");
        s.append(",");
        s.append("NDC");
        s.append(",");
        s.append("QTY (Packs)");
        s.append(",");
        s.append("PO #");
        s.append(",");
        s.append("Expected Delivery Date");
        s.append(",");
        s.append("Admin User ID of ST");
        s.append(",");
        s.append("Payment Info");
        s.append(",");
        s.append("paymentInfoId");
        s.append(",");
        s.append("Reservation Order Number");
        s.append(",");
        s.append("Allocation ID");
        s.append(",");
        s.append("Alternate Delivery Address Company Name");
        s.append(",");
        s.append("Alternate Delivery Address Line 1");
        s.append(",");
        s.append("Alternate Delivery Address Line 2");
        s.append(",");
        s.append("Alternate Delivery Address City");
        s.append(",");
        s.append("Alternate Delivery Address State");
        s.append(",");
        s.append("Alternate Delivery Address ZIP Code");
        s.append(",");
        s.append("Delivery Instructions");
        s.append(",");
        s.append("\r\n");
        //2nd Row
    //    int u =l.size();
	//	int tk = 220/u;
		userData.putData("Flu Reservation", "Reservation Count", "36");
	//	for (int kk = 0; kk < tk; kk++) {
       for (int i = 0; i < 35; i++) {
       	
        if (i==0) {
			s.append("4433234566");	
		}
        else if (i==10) {
        	s.append("0");
		} else if (i==23) {
        	s.append("null");
		} else if (i==24) {
        	s.append("shipto");
		} else if (i==31) {
			
		}
		else if (i==19) {
		s.append(userData.getData("Flu Reservation", "shipto2"));
		}
        else {
			s.append(userData.getData("Flu Reservation", "ShipTo"));
		}
        s.append(",");
        String d =null;
        if (i==1) {
        	d ="32434323";
		} else if (i==8) {
			d = userData.getData("Flu Reservation", "ContractNum");
		}  else if (i==9) {
			d="0";
		} else if (i==25) {
        	d="contract";
		} else if (i==20) {
        	d=null;
		}
		else {
			d ="00000000";
		}
        s.append(d);
        s.append(",");
        if (i==2) {
			s.append("1434541852");
		} else if (i==18) {
			s.append(userData.getData("Flu Reservation", "product 2"));
		}  
        else if (i==26) {
        	s.append("ndc");
		} else if(i==30) {
			
		}
        else {
			s.append(userData.getData("Flu Reservation", "Products"));
		}
        s.append(","); 
        if (i==3) {
			s.append("10000");
		} else if (i==11) {
        	s.append("0");
		} 
        else {
			s.append(userData.getData("Flu Reservation", "Allocation QTY"));
		}   
        s.append(",");
        
        s.append("PO Instruction");
        s.append(",");
        if (i==4) {
			s.append("6/9/2022");
		} else {
			s.append(userData.getData("Flu Reservation", "Delivery date"));
		}
        s.append(",");
        
        if (i==5) {
			s.append("ppg@gsk.com");
		} else if (i==14) {
        	s.append("0");
		} else if (i==16) {
        	s.append("null");
		} else if (i==27) {
        	s.append("user");
		}
		else {
			s.append(userData.getData("Flu Reservation", "User ID"));
		}
        s.append(",");
         if (i==28) {
        	s.append("payment");
		} else if (i==17) {
        	s.append("null");
		}  else if (i==15) {
        	s.append("0");
		} else {
        s.append("Invoice");
		}
        s.append(",");
        s.append("");
        s.append(",");
        
        if (i==6) {
			s.append("1043234523");
      		}  else if (i==12) {
            	s.append("0");
    		}  else if (i==21) {
            	s.append("null");
    		}else if (i==22) {
    			s.append("null");
    		}
    		 else if (i==29) {
    	        	s.append("reservatio");
    			}
        else {
      			 s.append(userData.getData("Flu Reservation", "ReservationNo"));	
      		}
       
        s.append(",");
        String data2=null; 
        if (i==7) {
			s.append("8976565656243");
      		}  else if (i==13) {
            	s.append("0");
    		}
      		 else if (i==21) {
             	s.append("null");
     		}
        else {
      	 data2 = userData.getData("Flu Reservation", "PK ID");
       	s.append(Long.valueOf(data2));
      		}
        
        
        s.append(",");
        s.append("\r\n");
        } 
       
        pw.write(s.toString());
		Thread.sleep(10000);
	 pw.close();
        System.out.println("Finished");
	}
	
	@Action(object = ObjectType.BROWSER,desc = "Edit CSV File [<Object>]",input = InputType.NO)
    public void editCsvOrderupload(List l) throws IOException, AWTException, InterruptedException {
		
		 File fo = new File("Order Upload For Allocation.csv");
         System.out.println(fo.getAbsolutePath());
         String path =fo.getAbsolutePath();
         PrintWriter pw = new PrintWriter(new File(path));
         
         StringBuilder s = new StringBuilder();
         s.append("Ship To Number/ID");
         s.append(",");
         s.append("Contract GNUM");
         s.append(",");
         s.append("NDC");
         s.append(",");
         s.append("QTY (Packs)");
         s.append(",");
         s.append("PO #");
         s.append(",");
         s.append("Expected Delivery Date");
         s.append(",");
         s.append("Admin User ID of ST");
         s.append(",");
         s.append("Payment Info");
         s.append(",");
         s.append("paymentInfoId");
         s.append(",");
         s.append("Reservation Order Number");
         s.append(",");
         s.append("Allocation ID");
         s.append(",");
         s.append("Alternate Delivery Address Company Name");
         s.append(",");
         s.append("Alternate Delivery Address Line 1");
         s.append(",");
         s.append("Alternate Delivery Address Line 2");
         s.append(",");
         s.append("Alternate Delivery Address City");
         s.append(",");
         s.append("Alternate Delivery Address State");
         s.append(",");
         s.append("Alternate Delivery Address ZIP Code");
         s.append(",");
         s.append("Delivery Instructions");
         s.append(",");
         s.append("\r\n");
         //2nd Row
         int u =l.size();
 		int tk = 220/u;
 		userData.putData("Flu Reservation", "Reservation Count", String.valueOf(u*tk));
 		for (int kk = 0; kk < tk; kk++) {
        for (int i = 0; i < l.size(); i++) {
        	
         s.append(l.get(i)); 
         s.append(",");
        // String d = "=\"00000000\"";
         String d ="00000000";
         s.append(d);
         s.append(",");
         s.append(userData.getData("Flu Reservation", "Products"));
         s.append(","); 
         s.append(userData.getData("Flu Reservation", "Allocation QTY"));
         s.append(",");
         s.append("PO Instruction");
         s.append(",");
         s.append(userData.getData("Flu Reservation", "Delivery date"));
         s.append(",");
         s.append(userData.getData("Flu Reservation", "User ID"));
         s.append(",");
         s.append("Invoice");
         s.append(",");
         s.append("");
         s.append(",");
         s.append(userData.getData("Flu Reservation", "ReservationNo"));
         s.append(",");
         String data2 = userData.getData("Flu Reservation", "PK ID");
         s.append(Long.valueOf(data2));
         s.append(",");
         s.append("\r\n");
         } 
        
 		}
         pw.write(s.toString());
 		Thread.sleep(10000);
 	 pw.close();
         System.out.println("Finished");
	}
	
	@Action(object = ObjectType.BROWSER,desc = "Product NDC [<Data>]",input = InputType.YES)
    public void findAllElements() {
		List<WebElement> findElements = Driver.findElements(By.xpath(Data));
		userData.putData("Flu Reservation", "Reservation Count", String.valueOf(findElements.size()));
	}
	@Action(object = ObjectType.BROWSER,desc = "To get available date from shopping cart page",input = InputType.NO)
    public void selectDateFromShoppingCartpage() throws InterruptedException {
		 String[] monthNames = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
		List<WebElement> availableCalenderDyz = Driver.findElements(By.xpath("//td[@title='Available']"));
		if (availableCalenderDyz.size()>3) {
			WebElement dateValue = availableCalenderDyz.get(3);
			String attribute = dateValue.getAttribute("data-month");
			//System.out.println(attribute);
			String text = dateValue.getText();
			String year= dateValue.getAttribute("data-year");
			userData.putData("Flu Reservation", "Expiry Date", monthNames[Integer.parseInt(attribute)]+" "+text+", "+year+", "+"12:00:00 AM");
			System.out.println(monthNames[Integer.parseInt(attribute)]+" "+text+", "+year+", "+"12:00:00 AM");
			dateValue.click();
		} else {
			Thread.sleep(5000);
			Driver.findElement(By.xpath("//span[text()='Next']")).click();
			List<WebElement> availableCalenderDyz1 = Driver.findElements(By.xpath("//td[@title='Available']"));
			if (availableCalenderDyz1.size()>3) {
				WebElement dateValue = availableCalenderDyz1.get(3);
				dateValue.click();
				String month = dateValue.getAttribute("data-month");
				//November 30, 22, 2:56:00 AM
				String year= dateValue.getAttribute("data-year");
				System.out.println(monthNames[Integer.parseInt(month)]+" "+availableCalenderDyz1.get(3).getText()+", "+year+", "+"12:00:00 AM");
				userData.putData("Flu Reservation", "Expiry Date",monthNames[Integer.parseInt(month)]+" "+availableCalenderDyz1.get(3).getText()+", "+year+", "+"12:00:00 AM");
				Report.updateTestLog("Action", "Available days is more than 3 ", Status.PASS );
			} else {
				Report.updateTestLog("Action", "Available days is less than 3", Status.FAIL );
			}
		}
	}
	
	@Action(object = ObjectType.BROWSER,desc = "Product NDC [<Data>]",input = InputType.YES)
    public void clickDynamicXpath_V1() throws InterruptedException  {
		Thread.sleep(10000);
    Driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    WebElement addToCart=null;
    
    try {
    try {
    	addToCart = Driver.findElement(By.xpath("//div[@class='row orderable-product-row']//div[2]//span[contains(text(),'"+Data+"')]/parent::div/parent::div/following-sibling::div[5]/a"));
    	((JavascriptExecutor) Driver).executeScript("arguments[0].scrollIntoView(true);", addToCart);
    	addToCart.click(); 
    	flu_Availabledoses();
    	  
    } catch (Exception e) {
           
           addToCart = Driver.findElement(By.xpath("//div[@class='row orderable-product-row otherProduct']//div[2]//span[contains(text(),'"+Data+"')]/parent::div/parent::div/following-sibling::div[5]/a"));
           ((JavascriptExecutor) Driver).executeScript("arguments[0].scrollIntoView(true);", addToCart);
           addToCart.click(); 
           flu_Availabledoses();
    }
    } catch (Exception e) {
    addToCart = Driver.findElement(By.xpath("//div[@class='row orderable-product-row favProduct']//div[2]//span[contains(text(),'"+Data+"')]/parent::div/parent::div/following-sibling::div[5]/a"));
    ((JavascriptExecutor) Driver).executeScript("arguments[0].scrollIntoView(true);", addToCart);
    addToCart.click();
    flu_Availabledoses();
    }
    }
	
	@Action(object = ObjectType.BROWSER,desc = "Product NDC [<Data>]",input = InputType.YES)
    public void clickDynamicXpath() throws InterruptedException  {
		Thread.sleep(10000);
    Driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    WebElement addToCart=null;
    
    try {
    try {
//    	addToCart = Driver.findElement(By.xpath("//div[@class='row orderable-product-row']//div[2]//span[contains(text(),'"+Data+"')]/parent::div/parent::div/following-sibling::div[5]/a"));
//    	((JavascriptExecutor) Driver).executeScript("arguments[0].scrollIntoView(true);", addToCart);
//    	addToCart.click(); 
    	    	
    	
    	addToCart = Driver.findElement(By.xpath("//div[@class='row orderable-product-row']//div[2]//span[contains(text(),'"+Data+"')]/parent::div/parent::div/following-sibling::div[5]/a"));
    	((JavascriptExecutor) Driver).executeScript("arguments[0].scrollIntoView(true);", addToCart);
    	addToCart.click(); 
    	 } catch (Exception e) {
           
//           addToCart = Driver.findElement(By.xpath("//div[@class='row orderable-product-row otherProduct']//div[2]//span[contains(text(),'"+Data+"')]/parent::div/parent::div/following-sibling::div[5]/a"));
//           ((JavascriptExecutor) Driver).executeScript("arguments[0].scrollIntoView(true);", addToCart);
//           addToCart.click(); 
     
    		 
    		 addToCart = Driver.findElement(By.xpath("//div[@class='row orderable-product-row otherProduct']//div[2]//span[contains(text(),'"+Data+"')]/parent::div/parent::div/following-sibling::div[5]/a"));
             ((JavascriptExecutor) Driver).executeScript("arguments[0].scrollIntoView(true);", addToCart);
             addToCart.click(); 
    		 
    }
    } catch (Exception e) {
//    addToCart = Driver.findElement(By.xpath("//div[@class='row orderable-product-row favProduct']//div[2]//span[contains(text(),'"+Data+"')]/parent::div/parent::div/following-sibling::div[5]/a"));
//    ((JavascriptExecutor) Driver).executeScript("arguments[0].scrollIntoView(true);", addToCart);
//    addToCart.click();
    	

    	 addToCart = Driver.findElement(By.xpath("//div[@class='row orderable-product-row favProduct']//div[2]//span[contains(text(),'"+Data+"')]/parent::div/parent::div/following-sibling::div[5]/a"));
    	    ((JavascriptExecutor) Driver).executeScript("arguments[0].scrollIntoView(true);", addToCart);
    	    addToCart.click();
    }
    Thread.sleep(10000);
    }
	@Action(object = ObjectType.BROWSER,desc = "Reservation No [<Data>]",input = InputType.YES)
    public void clickAvailableDosesRadio()  {
    Driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    WebElement dosesRadio=null;
    dosesRadio=Driver.findElement(By.xpath("//strong[text()='"+Data+"']//parent::label/parent::label/parent::div//input"));
    dosesRadio.click();
	}
	


	
	@Action(object = ObjectType.BROWSER,desc = "MultipleOrdersSplitShipment[<Object>]",input = InputType.YES)
	public void MultipleOrdersSplitShipment() {

			List l = new ArrayList<String>();
              List<WebElement> findElements = Driver.findElements(By.xpath("//div[contains(@class,'ss-flu-top row productRowItem product-item row')]/div[1]"));
              int j=1;
              for (WebElement webElement : findElements) {
                     for (int i = j; i <= j; i++) {
                           WebElement findElement3 = Driver.findElement(By.xpath("(//div[contains(@class,'ss-flu-top row productRowItem product-item row')])["+i+"]"));
                           WebElement findElement2 = Driver.findElement(By.xpath("(//div[contains(@class,'cart-product-info-shipto col')])["+i+"]"));
                           if (!findElement3.getAttribute("class").contains("disable") && !findElement2.getText().contains("PENDING")) {
                                  System.out.println(findElement2.getText());
                                  l.add(findElement2.getText());
                           } else {
                        	   		System.out.println("Please check custom method");
                           }      
                     }
                     j++;
              }
              
              
              
              for(int i=0; i<=j; i++) {
            	  int parseInt = Integer.parseInt(Data);
            	  if (i<parseInt) {
					        	 
            	  
            	  WebElement calElement = Driver.findElement(By.xpath("//div[contains(text(),'"+l.get(i)+"')]/following-sibling::div[3]//input[2]"));
            	  ((JavascriptExecutor) Driver).executeScript("arguments[0].scrollIntoView(true);",  calElement);
            	  calElement.click();
            	  
            	  try {
					WebElement datepickElement = Driver.findElement(By.xpath("(//td[@title='Available']/a)[1]"));
					  ((JavascriptExecutor) Driver).executeScript("arguments[0].scrollIntoView(true);",  datepickElement);
					  datepickElement.click();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					Driver.findElement(By.xpath("//span[text()='Next']")).click();
					WebElement datepickElement = Driver.findElement(By.xpath("(//td[@title='Available']/a)[1]"));
					  ((JavascriptExecutor) Driver).executeScript("arguments[0].scrollIntoView(true);",  datepickElement);
					  datepickElement.click();
				}
            	  
            	  WebElement qtyElement = Driver.findElement(By.xpath("//div[contains(text(),'"+l.get(i)+"')]/following-sibling::div[4]/div/input"));
            	  ((JavascriptExecutor) Driver).executeScript("arguments[0].scrollIntoView(true);",  qtyElement);
            	  qtyElement.clear();
            	  qtyElement.sendKeys(userData.getData("Flu Reservation", "QuantityInput"));
            	  
            	  }  
              }
                     }

	@Action(object = ObjectType.BROWSER,desc = "Escape key to handle the print window",input = InputType.NO)
    public void escKey() throws AWTException, InterruptedException  {
		Report.updateTestLog("Action", "Entered escKey block", Status.PASS );
		Thread.sleep(8000);
		Robot r = new Robot();
		r.keyPress(KeyEvent.VK_ESCAPE);
		r.keyRelease(KeyEvent.VK_ESCAPE);
		Report.updateTestLog("Action", "Exit escKey block", Status.PASS );
	}
	@Action(object = ObjectType.BROWSER,desc = "Change date format by taking the values from BO and verify it in Storefront",input = InputType.YES)
    public void dateFormatForReplaceReservation() {
	String[] split = Data.split(" ");
	String[] split2 = split[3].toString().split(":");
	String llll =split2[0].toString()+":"+split2[1].toString();
String kk =	split[1].toString().replace(",", "")+" "+split[0].toString()+" 20"+split[2].toString().replace(",", "")+" at "+llll+" "+split[4].toString()+". EDT";
System.out.println(kk);
userData.putData("Flu Reservation", "TimeCreated", kk);
	}
	
	
	@Action(object = ObjectType.BROWSER,desc = "This method Will take all the prices and put data in Promotion datasheet",input = InputType.YES)
    public void price_Split() throws InterruptedException  {
		
	Thread.sleep(5000); 
    WebElement listPrice=null;
    DecimalFormat decimalFormat = new DecimalFormat("#,###.##");
    
    Double federalTax = Double.valueOf(userData.getData("Promotion", "Federal excise tax"));
  // Double salesTax = Double.valueOf(userData.getData("Promotion", "Estimated sales tax"));
    //List price
    String	 quantity = userData.getData("Promotion", "QTY_SplitShipment");
    Double qty = Double.valueOf(quantity);
    System.out.println("Entering try catch block");
    try {
    try {
    	listPrice = Driver.findElement(By.xpath("//div[@class='row orderable-product-row otherProduct']//div[2]//span[contains(text(),'"+Data+"')]/parent::div/parent::div/following-sibling::div[2]/div[1]"));
    	Driver.findElement(By.xpath("//div[@class='row orderable-product-row otherProduct']//div[2]//span[contains(text(),'"+Data+"')]/parent::div/parent::div/following-sibling::div[4]/div/input")).click();
    	// listPrice.click();
    } catch (Exception e) {
    	System.out.println("Entered 1st catch");
    	listPrice = Driver.findElement(By.xpath("//div[@class='row orderable-product-row']//div[2]//span[contains(text(),'"+Data+"')]/parent::div/parent::div/following-sibling::div[2]/div[1]"));
    	Driver.findElement(By.xpath("//div[@class='row orderable-product-row']//div[2]//span[contains(text(),'"+Data+"')]/parent::div/parent::div/following-sibling::div[4]/div/input")).click();
    	//listPrice.click();
    }
    } catch (Exception e) {
    	System.out.println("Entered 2nd try");
    	listPrice = Driver.findElement(By.xpath("//div[@class='row orderable-product-row favProduct']//div[2]//span[contains(text(),'"+Data+"')]/parent::div/parent::div/following-sibling::div[2]/div[1]"));
    	   Driver.findElement(By.xpath("//div[@class='row orderable-product-row favProduct']//div[2]//span[contains(text(),'"+Data+"')]/parent::div/parent::div/following-sibling::div[4]/div/input")).click();
    	//listPrice.click();
    }   
    
    String text = listPrice.getText();
    System.out.println(text);
    String textStr[] = text.split("\\r\\n|\\n|\\r");
 	String a="";
   	for (String string : textStr) {
   		if(string.toString().contains("$") && string.toString().contains("pack")) {
   		a = string.toString().replace("$", ""); 		
   		}
   		if (a.contains(",")) {
			a= a.replaceAll(",", "");
		}
   	}
   	String[] splitss = a.split("/");
   	Double valueOf = Double.valueOf(splitss[0].toString());
    Report.updateTestLog(Action, "List Price : "+valueOf, Status.PASS);

   	
   //Contract price 
    
   WebElement contractPrice=null;
    try {
        try {
        	contractPrice = Driver.findElement(By.xpath("//div[@class='row orderable-product-row otherProduct']//div[2]//span[contains(text(),'"+Data+"')]/parent::div/parent::div/following-sibling::div[2]/div[2]/div/div[2]/span[1]"));
        	Driver.findElement(By.xpath("//div[@class='row orderable-product-row otherProduct']//div[2]//span[contains(text(),'"+Data+"')]/parent::div/parent::div/following-sibling::div[4]/div/input")).click();
        } catch (Exception e) {
        	contractPrice = Driver.findElement(By.xpath("//div[@class='row orderable-product-row']//div[2]//span[contains(text(),'"+Data+"')]/parent::div/parent::div/following-sibling::div[2]/div[2]/div/div[2]/span[1]"));
        	Driver.findElement(By.xpath("//div[@class='row orderable-product-row']//div[2]//span[contains(text(),'"+Data+"')]/parent::div/parent::div/following-sibling::div[4]/div/input")).click();
        }
        } catch (Exception e) {
        	try {
        	contractPrice = Driver.findElement(By.xpath("//div[@class='row orderable-product-row favProduct']//div[2]//span[contains(text(),'"+Data+"')]/parent::div/parent::div/following-sibling::div[2]/div[2]/div/div[2]/span[1]"));
        	Driver.findElement(By.xpath("//div[@class='row orderable-product-row favProduct']//div[2]//span[contains(text(),'"+Data+"')]/parent::div/parent::div/following-sibling::div[4]/div/input")).click();
        	}catch (Exception e1) {
        		Report.updateTestLog(Action, "No Contract associated to this product", Status.PASS);
			}
        	}   
   Double valueOf1 = null;
    if (contractPrice == null) {
    	Report.updateTestLog(Action, "No Contract associated to this product", Status.PASS);
	} else {
		 String text1 = contractPrice.getText();
		 
//		 Report.updateTestLog(Action, Data+  " :::  contractPrice   ::  " +text1, Status.DONE);
 		String[] split = text1.split("/");
 		
 		for (String string2 : split) {
 			
// 			Report.updateTestLog(Action, " string2   ::  " +string2, Status.DONE);
 			if (string2.contains("$")) {
 				//contract price
 				System.out.println(string2.toString().replace("$", ""));
// 				 Report.updateTestLog(Action, " string2.toString().replace   ::  " +string2.toString().replace("$", ""), Status.DONE);
 				if (string2.contains(",")) {
 					String replaceAll = string2.replaceAll(",", "");
 					
 					valueOf1 = Double.valueOf(replaceAll.toString().replace("$", ""));
 					
// 					 Report.updateTestLog(Action, " valueOf1   ::  " +valueOf1, Status.DONE);
 	 				
 					
				} else {
					valueOf1 = Double.valueOf(string2.toString().replace("$", ""));
//					 Report.updateTestLog(Action, " valueOf1   ::  " +valueOf1, Status.DONE);
				}
 				
 				 
 			}
 		}
 		Report.updateTestLog(Action, "Contract Price : "+valueOf1, Status.PASS);
 	    userData.putData("Promotion", "Contract Price", String.valueOf(valueOf1));
	}
    	
	
		// TODO: handle exception
		
	
   
	//List price
	Report.updateTestLog(Action, "List Price : "+valueOf, Status.PASS);
	userData.putData("Promotion", "List Price", String.valueOf(valueOf));
	//Contract Price
    
    //You saved price
	
	 if (contractPrice == null) {
		 Report.updateTestLog(Action, "You saved price : Contract Not associated", Status.PASS);
		 userData.putData("Promotion", "You saved", "");
			 }
	 else {
				 Report.updateTestLog(Action, "You saved : "+String.valueOf(decimalFormat.format(valueOf-valueOf1)), Status.PASS);
				 
				   userData.putData("Promotion", "You saved", String.valueOf(decimalFormat.format(valueOf-valueOf1)));
		
	 }
    
    String percent = userData.getData("Promotion", "Percentage");
    
    DecimalFormat decimalFormat1 = new DecimalFormat("#,###.##");
    DecimalFormat decimalFormat2 = new DecimalFormat("#,###.###");
    DecimalFormat decimalFormat3 = new DecimalFormat("#,###.####");
    String promotion_Dis1="";
    String promotion_Dis="";
	 if (contractPrice == null) {
		 promotion_Dis1 = decimalFormat3.format(valueOf/100*Double.valueOf(percent));
		 
		
		 if (promotion_Dis1.contains(",")) {
			 promotion_Dis = (String) promotion_Dis1;
			 
//			 if (promotion_Dis1.contains(".")) {
//			 String[] split = promotion_Dis1.split("[.]", 0);
//			 if (split[1].toString().length()>2) {
//				 promotion_Dis = (String) promotion_Dis1.subSequence(0, promotion_Dis1.length()-1);
//			}else {
//				promotion_Dis = (String) promotion_Dis1.subSequence(0, promotion_Dis1.length());
//			}
//			 }else {
//				 promotion_Dis = (String) promotion_Dis1;
//			 }
			 
		} else {
			 promotion_Dis1 = decimalFormat3.format(valueOf/100*Double.valueOf(percent));
			 
			 System.out.println(promotion_Dis1);
			 
	//	 Report.updateTestLog(Action, "promotion_Dis1   1 St else : "+promotion_Dis1, Status.PASS);
		 promotion_Dis = (String) promotion_Dis1;
//			 
//			 Report.updateTestLog(Action, "valueOf/100*Double.valueOf(percent) 1 St  : "+(valueOf/100*Double.valueOf(percent)), Status.DONE);
//			 
//			 Report.updateTestLog(Action, "(Double.valueOf(percent)) 1 St  : "+(Double.valueOf(percent)), Status.DONE);
//			 
//			 
//			 String[] split = promotion_Dis1.split("[.]", 0);
//			 System.out.println("After split");
//			 Report.updateTestLog(Action, "split[1]  1 St : "+split[1]   , Status.DONE);
//			 if (promotion_Dis1.contains(".")) {
//				 System.out.println(split[1].toString());
//			
//			 if (split[1].toString().length()>2) {
//				 System.out.println("Entering IF loop");
//				
//				 promotion_Dis = (String) promotion_Dis1.subSequence(0, promotion_Dis1.length()-1);
//				 
//				 Report.updateTestLog(Action, "promotion_Dis in if loop >2  1 St: "+promotion_Dis   , Status.DONE);
//			}else {
//				promotion_Dis = (String) promotion_Dis1.subSequence(0, promotion_Dis1.length());
//				 Report.updateTestLog(Action, "promotion_Dis in else loop   1 St: "+promotion_Dis   , Status.DONE);
//			}
//			 }else {
//				 promotion_Dis = (String) promotion_Dis1; 
//				 
//				 Report.updateTestLog(Action, "promotion_Dis in else loop 2nd  1 St: "+promotion_Dis   , Status.DONE);
//			 }
		}	      
	 }
	 else {
     promotion_Dis1 = decimalFormat3.format(valueOf1/100.00*Double.valueOf(percent));
     
    // Report.updateTestLog(Action, "promotion_Dis1  2nd  else : "+promotion_Dis1, Status.PASS);
     
	 promotion_Dis = (String) promotion_Dis1;
	 
//	 Report.updateTestLog(Action, "valueOf/100*Double.valueOf(percent) 2nd  : "+(valueOf/100*Double.valueOf(percent)), Status.DONE);
	 
//	 Report.updateTestLog(Action, "(Double.valueOf(percent)) 2nd  : "+(Double.valueOf(percent)), Status.DONE);
     
//   System.out.println(promotion_Dis1);
//     if (promotion_Dis1.contains(",")) {
//    	 if (promotion_Dis1.contains(".")) {
//    		 
//		 String[] split = promotion_Dis1.split("[.]", 0);
//		 
//		 Report.updateTestLog(Action, "split.length-1 : "+split[split.length-1 ]  , Status.DONE);
//		 
//		 Report.updateTestLog(Action, "split.length-1 : "+split[split.length ]  , Status.DONE);
//		 if (split[split.length-1].toString().length()>2) {
//			 promotion_Dis = (String) promotion_Dis1.subSequence(0, promotion_Dis1.length()-1);
//			 
//			 Report.updateTestLog(Action, "promotion_Dis in if loop >2  2nd: "+promotion_Dis   , Status.DONE);
//		}else {
//			promotion_Dis = (String) promotion_Dis1.subSequence(0, promotion_Dis1.length());
//			 Report.updateTestLog(Action, "promotion_Dis in else loop   2nd: "+promotion_Dis   , Status.DONE);
//		}
//    	 }else {
//    		 promotion_Dis = (String) promotion_Dis1;
//    		 Report.updateTestLog(Action, "promotion_Dis in else loop 2nd  2nd: "+promotion_Dis   , Status.DONE);
//    	 }
//		System.out.println(promotion_Dis); 
//	} 
    	 
//    	 else {
//    		 if (promotion_Dis1.contains(".")) {
//		 String[] split = promotion_Dis1.split("[.]", 0);
//		 
//		 Report.updateTestLog(Action, "split.length-1 :  3734 "+split[split.length-1 ]  , Status.DONE);
//		 if (split[split.length-1].toString().length()>2) {
//			 promotion_Dis = (String) promotion_Dis1.subSequence(0, promotion_Dis1.length()-1);
//			 Report.updateTestLog(Action, "promotion_Dis in if loop >2  3nd: "+promotion_Dis   , Status.DONE);
//			 
//		}else {
//			promotion_Dis = (String) promotion_Dis1.subSequence(0, promotion_Dis1.length());
//			
//			Report.updateTestLog(Action, "promotion_Dis in else loop   3nd: "+promotion_Dis   , Status.DONE);
//		}}else {
//			promotion_Dis = (String) promotion_Dis1;
//			Report.updateTestLog(Action, "promotion_Dis in else loop   3nd: "+promotion_Dis   , Status.DONE);
//		}
//	}
     System.out.println(promotion_Dis); 
	 }
    
//	 Report.updateTestLog(Action, "promotion_Dis  3755 :: "+ promotion_Dis, Status.PASS);
	//System.out.println(subSequence);
	 String discount_Value =null;
	 if (promotion_Dis.contains(",")) {
		String replaceAll = promotion_Dis.replaceAll(",", "");
		discount_Value= decimalFormat.format(Double.valueOf(replaceAll)*qty);
		
		 Report.updateTestLog(Action, "discount_Value  if codition :: "+ discount_Value, Status.PASS);
	} else {
		    
		      	   
		   
		      discount_Value= decimalFormat3.format(Double.valueOf(promotion_Dis)*qty);
		  // Report.updateTestLog(Action, "discount_Value else codition :: "+ discount_Value, Status.PASS); 
		   
		   
	}
  
    Double saved=null;
    if (contractPrice == null) {
    	saved = 0.00;
    }else {
    	
    	saved	= valueOf*qty-valueOf1*qty;  
    	   
    	
   }
   Double savings =Double.valueOf(discount_Value)+saved;
   
   //savings=get2DecimalDoubleValue(savings);
  
   
   Report.updateTestLog(Action, "savings  :: "+ (savings), Status.PASS);
   
   //Discount value according to promotion
   userData.putData("Promotion", "Product level discount", String.valueOf(get2DecimalDoubleValue(discount_Value)));
//   userData.putData("Promotion", "Product level discount", String.valueOf((discount_Value)));
   Report.updateTestLog(Action, "Product level discount   :: "+ discount_Value, Status.PASS);
   Report.updateTestLog(Action, "Saved : "+ saved, Status.PASS);
   if (contractPrice == null) {
	   Report.updateTestLog(Action, "Promotion message discount :"+ decimalFormat1.format(valueOf*10.00/100.00), Status.PASS);
	    userData.putData("Promotion", "Promotion discount", String.valueOf(decimalFormat1.format(valueOf*10/100.00)));   
   }else {
    Report.updateTestLog(Action, "Promotion message discount :"+ decimalFormat1.format(valueOf1*10.00/100.00), Status.PASS);
    userData.putData("Promotion", "Promotion discount", String.valueOf(decimalFormat1.format(valueOf1*10.00/100.00)));
   }
    
    Report.updateTestLog(Action, "Savings: "+decimalFormat1.format(savings), Status.PASS);
    userData.putData("Promotion", "Savings", String.valueOf(decimalFormat1.format(saved)));
    userData.putData("Promotion", "Savings with promotion", String.valueOf(decimalFormat1.format(savings)));
    Report.updateTestLog(Action, "Subtotal before savings: "+valueOf*qty, Status.PASS);
    userData.putData("Promotion", "Subtotal before savings", String.valueOf(decimalFormat1.format(valueOf*qty)));
   
    Double salestax =null;
    Double salestax_Promotion = null;
    String state_Txt = userData.getData("Promotion", "Sales Tax state");
    
    if (state_Txt.contains("Illinois") ||state_Txt.contains("Michigan") ||state_Txt.contains("Minnesota") ||state_Txt.contains("Hawaii")) {
    	  salestax = Double.valueOf(decimalFormat1.format((valueOf*qty-saved)/100.00));
    	    salestax_Promotion = Double.valueOf(decimalFormat1.format((valueOf*qty-savings)/100.00));
    	    
    	    Report.updateTestLog(Action, "salestax_Promotion  "+salestax_Promotion, Status.PASS);
	}else {
		salestax = 0.00;
		salestax_Promotion = 0.00;
	}
  
    
   // userData.putData("Promotion", "", String.valueOf(decimalFormat.format(valueOf*qty))); get2DecimalDoubleValue
    Report.updateTestLog(Action, "Federal excise tax : "+federalTax*qty, Status.PASS);
    userData.putData("Promotion", "Total Federal excise tax", String.valueOf(decimalFormat.format(federalTax*qty)));
    
    
    Report.updateTestLog(Action, "Estimated sales tax without promotion: "+salestax, Status.PASS);
    Report.updateTestLog(Action, "Estimated sales tax with promotion: "+salestax_Promotion, Status.PASS);
    
    userData.putData("Promotion", "Total Estimated sales tax", String.valueOf(decimalFormat.format(salestax)));
    userData.putData("Promotion", "Total Estimated sales tax with Promotion", String.valueOf(decimalFormat.format(salestax_Promotion)));
   
    Report.updateTestLog(Action, "Price for contract: "+ String.valueOf(decimalFormat.format((valueOf*qty-saved)+(federalTax*qty)+salestax)), Status.PASS);
    Report.updateTestLog(Action, "Price for contract with promotion : "+ (valueOf*qty-savings), Status.DONE);
     
    Report.updateTestLog(Action, "Price for contract with promotion : "+ (federalTax*qty), Status.DONE);
    Report.updateTestLog(Action, "Price for contract with promotion : "+ salestax_Promotion, Status.DONE);
    
    userData.putData("Promotion", "Price for contract with promotion", String.valueOf(decimalFormat1.format((valueOf*qty-savings)+(federalTax*qty)+salestax_Promotion)));
    
    
    userData.putData("Promotion", "Price for contract", String.valueOf(decimalFormat.format((valueOf*qty-saved)+(federalTax*qty)+salestax)));
	}
	
	
	
	public static double get2DecimalDoubleValue(String discount_Value) {

		 double discount_Value1=Double.parseDouble(discount_Value);

        double final2DecimalDoubleValue = Math.round(discount_Value1 * Math.pow(10, 2))/ Math.pow(10, 2);
        return final2DecimalDoubleValue;
    }
	
	
	
	@Action(object = ObjectType.BROWSER, desc = "Get State name from Addresses popup and trim Using shipto number", input = InputType.YES)
	public void stateNameTrim() throws InterruptedException {
		Thread.sleep(10000);
		String text = Driver.findElement(By.xpath("//span[contains(text(),'"+Data+"')]/parent::div/following-sibling::div[5]")).getText();
		String trim = text.trim();
		userData.putData("Promotion", "Sales Tax state", trim);
	}
	
	@Action(object = ObjectType.BROWSER,desc = "Price Validation for Estimated sales tax, Saved price, Estimated savings",input = InputType.NO)
    public void price_Validation() {
		String text =null;
		try {
			 text = Driver.findElement(By.xpath("//div[@class='product-contract-name hidden-xs']")).getText();	
		} catch (Exception e) {
			text = Driver.findElement(By.xpath("//div[@class='product-contract-name']")).getText();
		}
	
	if (text.contains("No Contract")) {
		Report.updateTestLog(Action, "Save price will not appilcable due to No Contract associated to this shipto", Status.PASS);	
	} else {
String text2 = Driver.findElement(By.xpath("//div[contains(text(),'You save')]")).getText();
String saved_Price = userData.getData("Promotion", "You saved");

if (text2.contains(saved_Price)) {
	Report.updateTestLog(Action, "Saved price :" + text2, Status.PASS);
} else {
	Report.updateTestLog(Action, "Saved price mismatch :"+text2, Status.FAIL);
}

	}
		
		  String state_Txt = userData.getData("Promotion", "Sales Tax state");
		    if (state_Txt.contains("Illinois") ||state_Txt.contains("Michigan") ||state_Txt.contains("Minnesota") ||state_Txt.contains("Hawaii")) {
		    	Report.updateTestLog(Action, "see custom method", Status.FAIL);
		    }else {
		    	Report.updateTestLog(Action, "Estimated sales tax is not appiled to these states", Status.PASS);
		    }
		    try {
		    	
		    	Driver.findElement(By.xpath("//ul[@class='promotion-purchase']")).getText();
		    	System.out.println("Promotion rule applied");
		    	
		    	String data2 = null;
		    	String text2 = null;
		    	try {
		    		data2=userData.getData("Promotion", "Savings with promotion");
		    		
		    		text2 = Driver.findElement(By.xpath("//span[contains(text(),'Estimated Savings')]/parent::div/following-sibling::div[1]/span")).getText();
				} catch (Exception e) {
					// TODO: handle exception
					data2=userData.getData("Promotion", "Product level discount");
					text2=Driver.findElement(By.xpath("//span[contains(text(),'Estimated') and contains(text(),'Product-level')]/parent::div/following-sibling::div[1]")).getText();
				}
		    	
				if (text2.contains(data2)) {
					Report.updateTestLog(Action, "Estimated savings :" +text2, Status.PASS);
				}else {
					Report.updateTestLog(Action, "Estimated savings Should have   :: "+data2 +"   but Estimated savings contains :" +text2, Status.FAIL);
				}
		    	
		    	Report.updateTestLog(Action, "Promotion Applied", Status.PASS);
		    	Report.updateTestLog(Action, "Estimated Savings :"+text2, Status.PASS);
			} catch (Exception e) {
				// TODO: handle exception
				
				
				System.out.println("Promotion rule not applied");
				String text2 = null;
				String data2 = null;
				try {
					String text4 = null;
					try {
						 text4 = Driver.findElement(By.xpath("//div[@class='product-contract-name hidden-xs']")).getText();
					} catch (Exception e2) {
						 text4 = Driver.findElement(By.xpath("//div[@class='product-contract-name']")).getText();
					}
					
			
					if (text4.contains("No Contract")) {
						Report.updateTestLog(Action, "Promotion and contract Not applied", Status.PASS);
					}else {
						try {
						try {
							data2 = userData.getData("Promotion", "Savings");
							
				    		text2 = Driver.findElement(By.xpath("//span[contains(text(),'Estimated Savings')]/parent::div/following-sibling::div[1]/span")).getText();
				    		if (text2.contains(data2)) {
								Report.updateTestLog(Action, "Estimated savings :" +text2, Status.PASS);
							}else {
								Report.updateTestLog(Action, "Estimated savings Should have  ctt1 :: "+data2 +"   but Estimated savings contains :" +text2, Status.FAIL);
							}
						} catch (Exception e1) {
							// TODO: handle exception
							data2=userData.getData("Promotion", "Product level discount");
							text2=Driver.findElement(By.xpath("//span[contains(text(),'Estimated') and contains(text(),'Product-level')]/parent::div/following-sibling::div[1]")).getText();
							if (text2.contains(data2)) {
								Report.updateTestLog(Action, "Estimated savings :" +text2, Status.PASS);
							}else {
								Report.updateTestLog(Action, "Estimated savings Should have ctc1  :: "+data2 +"   but Estimated savings contains :" +text2, Status.FAIL);
							}
						}
					}catch (Exception e3) {
						data2 = userData.getData("Promotion", "Savings");
						
						 text2 = Driver.findElement(By.xpath("//span[contains(text(),'Estimated Contract Savings')]/parent::div/following-sibling::div[1]")).getText();
						 if (text2.contains(data2)) {
								Report.updateTestLog(Action, "Estimated savings :" +text2, Status.PASS);
							}else {
								Report.updateTestLog(Action, "Estimated savings Should have Cc1  :: "+data2 +"   but Estimated savings contains :" +text2, Status.FAIL);
							}
						
					}
				} 
				}catch (Exception e2) {
					System.out.println("No Such");
				}
		    
			}
	}
	
	@Action(object = ObjectType.BROWSER,desc = "Product NDC [<Data>]",input = InputType.YES)
    public void addQty()  {
		String quantity="";
    Driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    WebElement addQty=null;
    
    try {
    	 try {
    	    	quantity= userData.getData("ComplexCart", "quantity");
    	    	System.out.println("CC Sheet->"+quantity);
    	    }catch (Exception e) {
    	    	 quantity = userData.getData("Flu Reservation", "Qty");
    	    }
	} catch (Exception e) {
		// TODO: handle exception
		 quantity = userData.getData("Promotion", "QTY_SplitShipment");
	}
    try {
    try {
    	addQty = Driver.findElement(By.xpath("//div[@class='row orderable-product-row otherProduct']//div[2]//span[contains(text(),'"+Data+"')]/parent::div/parent::div/following-sibling::div[4]/div/input"));
    	addQty.click();
    	addQty.clear();
    	addQty.sendKeys(quantity);
    } catch (Exception e) {
    	addQty = Driver.findElement(By.xpath("//div[@class='row orderable-product-row']//div[2]//span[contains(text(),'"+Data+"')]/parent::div/parent::div/following-sibling::div[4]/div/input"));
    	addQty.click();
    	addQty.clear();
    	addQty.sendKeys(quantity);
    }
    } catch (Exception e) {
    	addQty = Driver.findElement(By.xpath("//div[@class='row orderable-product-row favProduct']//div[2]//span[contains(text(),'"+Data+"')]/parent::div/parent::div/following-sibling::div[4]/div/input"));
    	addQty.click();
    	addQty.clear();
    	addQty.sendKeys(quantity);
    }   
    }
	
	
	@Action(object = ObjectType.BROWSER,desc = "Add qunatity ",input = InputType.YES)
    public void addQty_1()  {
		String quantity="";
    Driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    WebElement addQty=null;
    
    quantity = userData.getData("Flu Reservation", "NewQty");
 
    try {
    try {
    	addQty = Driver.findElement(By.xpath("//div[@class='row orderable-product-row otherProduct']//div[2]//span[contains(text(),'"+Data+"')]/parent::div/parent::div/following-sibling::div[4]/div/input"));
    	addQty.click();
    	addQty.clear();
    	addQty.sendKeys(quantity);
    } catch (Exception e) {
    	addQty = Driver.findElement(By.xpath("//div[@class='row orderable-product-row']//div[2]//span[contains(text(),'"+Data+"')]/parent::div/parent::div/following-sibling::div[4]/div/input"));
    	addQty.click();
    	addQty.clear();
    	addQty.sendKeys(quantity);
    }
    } catch (Exception e) {
    	addQty = Driver.findElement(By.xpath("//div[@class='row orderable-product-row favProduct']//div[2]//span[contains(text(),'"+Data+"')]/parent::div/parent::div/following-sibling::div[4]/div/input"));
    	addQty.click();
    	addQty.clear();
    	addQty.sendKeys(quantity);
    }   
    }
	
	@Action(object = ObjectType.BROWSER,desc = "Product NDC [<Data>]",input = InputType.YES)
    public void addQtyInSplitShipment()  {
    Driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    WebElement addQty=null;
    String quantity = userData.getData("Promotion", "QTY_SplitShipment");
    
    	addQty = Driver.findElement(By.xpath("(//div[contains(text(),'"+Data+"')]/following-sibling::div[4]//input)[1]"));
    	addQty.clear();//click();
    	addQty.sendKeys(quantity);
    }
	
	@Action(object = ObjectType.BROWSER,desc = "Product NDC [<Data>]",input = InputType.YES)
    public void clickCheckoutInSplitShipment()  {
    Driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
    WebElement checkOut=null;
    JavascriptExecutor js = (JavascriptExecutor) Driver;  
   
    checkOut = Driver.findElement(By.xpath("//div[contains(text(),'"+Data+"')]/following-sibling::div[5]//button"));
    js.executeScript("arguments[0].click();",checkOut);
    }
	
	@Action(object = ObjectType.BROWSER,desc = "Product NDC [<Data>]",input = InputType.YES)
    public void clickDateInSplitShipment()  {
    Driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    WebElement dateInput=null;    
    dateInput = Driver.findElement(By.xpath("//div[contains(text(),'"+Data+"')]/following-sibling::div[3]//input[2]"));
    dateInput.click();
    }
	@Action(object = ObjectType.SELENIUM,desc = "Setup Promotion Message [<Data>]",input = InputType.YES)
    public void setPromotionMessage()  {
    Driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    WebElement percentageQuesSymbol=Driver.findElement(By.xpath("//span[text()='Percentage discount value']/parent::div/div/i"));  
    percentageQuesSymbol.click();
    Driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    WebElement encryptData = Driver.findElement(By.xpath("//span[@class='yrb-parameter-uuid z-label']"));
    String encryptedPromotion = encryptData.getText();
    Driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    WebElement messageTextArea = Driver.findElement(By.xpath("//span[text()='Message']/parent::div/following::div/textarea"));
    if(Data.equals("RRD")) 
    	messageTextArea.sendKeys("{"+encryptedPromotion+"} percentage discount (Recurring Reservation)"); 
    else if(Data.equals("DGD"))
    	messageTextArea.sendKeys("{"+encryptedPromotion+"} percentage discount (Delivery Guarantee)");
    else if(Data.equals("RRDDGD"))
    	messageTextArea.sendKeys("{"+encryptedPromotion+"} percentage discount (Recurring Reservation and Delivery Guarantee)");
    }
	@Action(object = ObjectType.BROWSER, desc = "checkElementEnabledForTomorrow date", input = InputType.NO)
    public void clickElementEnabledForTomorrowDate() {
		 Driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
           // TODO Auto-generated method stub
           Date date = new Date();

           try {
                  switch (date.getDay()) {
                  case 1:
                  case 3:
                  case 2:
           
                        DateFormat dateFormat1 = new SimpleDateFormat("d");

                        Calendar cll = Calendar.getInstance();

                        cll.setTime(date);
                        cll.add(Calendar.DATE, 2);
                        // get current date time with Date()

                        // Now format the date
                        String Tommorow1 = dateFormat1.format(cll.getTime());
                        String path1 = "//a[text()='" + Tommorow1 + "']";
                        // System.out.println(path1);
                        Driver.findElement(By.xpath(path1)).click();                       
                        Report.updateTestLog(Action, "Date "+Tommorow1+" is Selected", Status.PASS);

                       
                        break;
                  case 4:
                  case 5:
                        DateFormat dateForma = new SimpleDateFormat("d");
                        Calendar cell = Calendar.getInstance();

                        cell.setTime(date);
                        cell.add(Calendar.DATE, 5);

                        String Tommorow2 = dateForma.format(cell.getTime());
                        String path2 = "//a[text()='" + Tommorow2 + "']";
                        // System.out.println(path2);
                        Driver.findElement(By.xpath(path2)).click();                       
                        Report.updateTestLog(Action, "Date "+Tommorow2+" is Selected", Status.PASS);

                        break;

                  case 6:
                        DateFormat dateFor = new SimpleDateFormat("d");
                        Calendar d = Calendar.getInstance();

                        d.setTime(date);
                        d.add(Calendar.DATE, 4);

                        String Tommorow3 = dateFor.format(d.getTime());
                        String path3 = "//a[text()='" + Tommorow3 + "']";
                        // System.out.println(path3);
                        Driver.findElement(By.xpath(path3)).click();                       
                        Report.updateTestLog(Action, "Date "+Tommorow3+" is Selected", Status.PASS);
                        break;
                  case 0:
                        DateFormat dateFor5 = new SimpleDateFormat("d");
                        Calendar da = Calendar.getInstance();

                        da.setTime(date);
                        da.add(Calendar.DATE, 3);

                        String Tomorrow4 = dateFor5.format(da.getTime());
                        String path4 = "//a[text()='" + Tomorrow4 + "']";
                        
                        Driver.findElement(By.xpath(path4)).click();                       
                        Report.updateTestLog(Action, "Date "+Tomorrow4+" is Selected", Status.PASS);                        
                        break;
                  default:

                        break;
                  }
                  
           }
           
           catch (org.openqa.selenium.NoSuchElementException e) {
                  Report.updateTestLog(Action, "No Such Element Exception:Element not present in the DOM", Status.PASS);
           }
    }
	@Action(object = ObjectType.SELENIUM,desc = "verify the list of value of [<Data>]",input = InputType.YES)
	public void verifyQualifyingProducts() {
		List<WebElement> optionslist = Driver.findElements(By.xpath("//img[@class='z-image']//parent::div//span"));
		Report.updateTestLog(Action, "Products Size " + optionslist.size() , Status.DONE);
		Report.updateTestLog(Action, "Products Value1 " + optionslist.get(0).getText() + " is present", Status.DONE);
		Report.updateTestLog(Action, "Products Value2 " + optionslist.get(1).getText() + " is present", Status.DONE);
        for (int i=0;i<optionslist.size();i++) {
        	String products = optionslist.get(i).getText();
        	if(products.equalsIgnoreCase(Data)) {
        		Report.updateTestLog(Action, "Products Value " + products + " is present", Status.DONE);
        	}
        }
	}
	
	@Action(object = ObjectType.BROWSER,desc = "Generate Random ID [<Object>]",input = InputType.NO)
	public void generateRandomID() {
		Random rand = new Random();
		int min=1,max=10000;   
		int value = rand.nextInt((max - min) + 1) + min; 
		String randomID = String.valueOf(value);
		try {
			userData.putData("CMR", "ShipToCompanyName", "CMR STR BTR" + randomID);
		} catch (Exception e) {
			// TODO: handle exception
			userData.putData("Flu Reservation", "AllocationCriteriaID", "TA" + randomID);
		}
	}
	
	@Action(object = ObjectType.BROWSER,desc = "Compare Excel [<Object>]",input = InputType.NO)
	public void compareExcel() {	
		try {
	         FileInputStream excellFile1 = new FileInputStream(//new File(
	                 "C:\\Users\\axm80963\\OneDrive - GSK\\Desktop\\Nov16 - Copy\\Pending Return Export Data_16-Nov-2021.xlsx");
	         FileInputStream excellFile2 = new FileInputStream(//new File(
	                 "C:\\Users\\axm80963\\OneDrive - GSK\\Desktop\\Nov16 - Copy\\PENDING_RETURN_VALIDATION_11152021.xlsx");
	         XSSFWorkbook workbook1 = new XSSFWorkbook(excellFile1);
	         XSSFWorkbook workbook2 = new XSSFWorkbook(excellFile2);

	         XSSFSheet sheet1 = workbook1.getSheetAt(0);
	         XSSFSheet sheet2 = workbook2.getSheetAt(0);

	         if(compareTwoSheets(sheet1, sheet2)) {
	             System.out.println("\n\nThe two excel sheets are Equal");
	        	// userData.putData("CompareExcel", "SheetsStatus", "Sheets are Equal");
	         } else {
	        	 System.out.println("\n\nThe two excel sheets are Not Equal");
	        	 //userData.putData("CompareExcel", "SheetsStatus", "Sheets are Not Equal");
	         }
	        
	         excellFile1.close();
	         excellFile2.close();
	     }catch (Exception e) {
	         e.printStackTrace();
	     }
	 }

	 public static boolean compareTwoSheets(XSSFSheet sheet1, XSSFSheet sheet2) {
	     int firstRow1 = sheet1.getFirstRowNum();
	     int lastRow1 = sheet1.getLastRowNum();
	     boolean equalSheets = true;
	     for(int i=firstRow1+1; i <= lastRow1; i++) {
	        
	         System.out.println("\n\nComparing Row "+i);
	        
	         XSSFRow row1 = sheet1.getRow(i);
	         XSSFRow row2 = sheet2.getRow(i);
	         if(!compareTwoRows(row1, row2,i)) {
	             equalSheets = false;
	             System.out.println("\n\nThe Row "+i+" are Not Equal");	           
	            // userData.putData("CompareExcel", "RowStatus", "Row "+i+"is Equal");
	             break;
	         } else {	        	
	        	 System.out.println("\n\nThe Row "+i+" are Equal");
	        	 //userData.putData("CompareExcel", "RowStatus", "Row "+i+"is Not Equal");
	         }
	     }
	     return equalSheets;
	 }

	 public static boolean compareTwoRows(XSSFRow row1, XSSFRow row2, int compRow) {
	     if((row1 == null) && (row2 == null)) {
	         return true;
	     } else if((row1 == null) || (row2 == null)) {
	         return false;
	     }
	    
	     int firstCell1 = row1.getFirstCellNum();
	     int lastCell1 = row1.getLastCellNum();
	     boolean equalRows = true;
	    
	     // Compare all cells in a row
	     for(int i=firstCell1; i <= lastCell1; i++) {
	         XSSFCell cell1 = row1.getCell(i);
	         XSSFCell cell2 = row2.getCell(i);
	         if(!compareTwoCells(cell1,cell2)) {
	        	 try {
	             equalRows = false;
	             System.err.println("       Cell "+i+" - NOt Equal");
	             Cell resultCell = row1.createCell(lastCell1);
	             resultCell.setCellValue(row1.getCell(i)+"Not Equal");
	             FileInputStream fis = new FileInputStream("C:\\Users\\axm80963\\OneDrive - GSK\\Desktop\\Nov16 - Copy\\Pending Return Export Data_16-Nov-2021.xlsx");
	             XSSFWorkbook workbook = new XSSFWorkbook(fis);
	             XSSFSheet sheet = workbook.getSheetAt(0);
	             XSSFRow row = sheet.getRow(compRow);
	             Cell cell = row.createCell(lastCell1);
	             cell.setCellValue(row1.getCell(i)+" is Not Equal");
	             FileOutputStream fos = new FileOutputStream("C:\\Users\\axm80963\\OneDrive - GSK\\Desktop\\Nov16 - Copy\\Pending Return Export Data_16-Nov-2021.xlsx");
	             workbook.write(fos);
	             fos.close();
	             //userData.putData("CompareExcel", "CellStatus", "Cell "+i+"is Not Equal");
	             break;
	        	 }catch(Exception e) {}
	         } else {
	            System.out.println("       Cell "+i+" - Equal");
	        	// userData.putData("CompareExcel", "CellStatus", "Cell "+i+"is Equal");
	         }
	     }
	     return equalRows;
	 }

	 public static boolean compareTwoCells(XSSFCell cell1, XSSFCell cell2) {
	     if((cell1 == null) && (cell2 == null)) {
	         return true;
	     } else if((cell1 == null) || (cell2 == null)) {
	         return false;
	     }
	    
	     boolean equalCells = false;
	     CellType type1 = cell1.getCellType();
	     CellType type2 = cell2.getCellType();
	     
	     if (type1 == type2) {
	         if (cell1.getCellStyle().equals(cell2.getCellStyle())) {
	             // Compare cells based on its type
	          //   switch (cell1.getCellType()) {
	             
	          //   case HSSFCell.CELL_TYPE_NUMERIC:
	                /* if (cell1.getNumericCellValue() == cell2
	                         .getNumericCellValue()) {
	                     equalCells = true;
	                 }*/
	            //     break;
	             //case HSSFCell.CELL_TYPE_STRING:
	                /* if (cell1.getStringCellValue().equals(cell2
	                         .getStringCellValue())) {
	                     equalCells = true;
	                 }*/
	               //  break;
	                        
	            // default:
	                 if (cell1.getStringCellValue().equals(
	                         cell2.getStringCellValue())) {
	                     equalCells = true;
	                 }
	               //  break;
	             //}
	         } else {
	             return false;
	         }
	     } else {
	         return false;
	     }
	     return equalCells;
	 }
	 @Action(object = ObjectType.BROWSER,desc = "Iterate [<Data>] times through the objects with date as [<Object>]",input = InputType.YES)
		public void datePicker() {


			int num = Integer.parseInt(Data);
			String qty = userData.getData("SplitShipment", "Quantity");

			int j=2; //added by sujay
			for(int i=0;i<num;i++)
			{

				if (Driver.findElement(By.xpath("/html/body/div[1]/div[6]/div[6]/div/div/div/div/div/div[2]/div/form[1]/div[1]/div["+j+"]/div[4]/div[1]/div/i")).isEnabled()){
					try 
					{ JavascriptExecutor js = (JavascriptExecutor) Driver;
					//js.executeScript("arguments[0].click();", Driver.findElement(By.xpath(datelist.get(i)))); --commented out by sujay
					js.executeScript("arguments[0].click();", Driver.findElement(By.xpath("/html/body/div[1]/div[6]/div[6]/div/div/div/div/div/div[2]/div/form[1]/div[1]/div["+j+"]/div[4]/div[1]/div/i")));

					//Driver.findElement(By.xpath("/html/body/div[6]/div/a[2]/span")).click();

					Driver.findElement(By.linkText(userData.getData("SplitShipment", "Date"))).click();


					JavascriptExecutor js1 = (JavascriptExecutor) Driver;
					//js1.executeScript("arguments[0].click();", Driver.findElement(By.xpath(iterateqty.get(i)))); --commented out by sujay
					js1.executeScript("arguments[0].click();", Driver.findElement(By.xpath("/html/body/div[1]/div[6]/div[6]/div/div/div/div/div/div[2]/div/form[1]/div[1]/div["+j+"]/div[5]/div/input")));

					//Driver.findElement(By.xpath(iterateqty.get(i))).click();
					//Driver.findElement(By.xpath(iterateqty.get(i))).sendKeys(qty); --commented out by sujay
					Driver.findElement(By.xpath("/html/body/div[1]/div[6]/div[6]/div/div/div/div/div/div[2]/div/form[1]/div[1]/div["+j+"]/div[5]/div/input")).sendKeys(qty);

					//Driver.findElement(By.xpath(datelist.get(i))).click();
					Report.updateTestLog(Action, "Clicking on " + ObjectName, Status.DONE);
					
					
					}
					
					catch(WebDriverException e)
					{ num=num+1;
					
					j=j+1;
					continue;
					}
					j=j+1; //added by sujay
				} else {
					
					j=j+1; //added by sujay
					continue;
				}

			}

		}
		
		@Action(object = ObjectType.BROWSER,desc = "Trim the value of [<Data>]",input = InputType.YES)
		public void trimOrderNumber() {
			
			String[] orderarray=Data.split(" ");
			int length=orderarray.length;
			if(length==3)
			{
			userData.putData("ReturnData", "flunumber", orderarray[length-1]);
			}
			else
			{
				userData.putData("ReturnData", "ordernumber", orderarray[length-1]);	
			}
		
		}
		@Action(object = ObjectType.BROWSER,desc = "Remove alternate address",input = InputType.NO)
		public void removeAltaddress() {
			
			if(Driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[2]/div[2]/div[1]/div/div[3]/table/tbody/tr[2]/td[7]/a")).isDisplayed())
			{
				Driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[2]/div[2]/div[1]/div/div[3]/table/tbody/tr[2]/td[7]/a")).click();
			}
			
		}
		
		@Action(object = ObjectType.BROWSER,desc = "Format [<Data>]",input = InputType.YES)
		public void expirationDatePicker() {
			/*
			 * String[] orderarray=Data.split("/"); int length=orderarray.length; LocalDate
			 * currentDate= LocalDate.parse(Data); Month month =currentDate.getMonth();
			 * String mon =month;
			 */
			if(Data.equals("Add"))
			{

			DateFormat fmt = new SimpleDateFormat("MMM dd, yy", Locale.US);
			Calendar c = Calendar.getInstance();
			c.setTime(new Date()); // Using today's date
			c.add(Calendar.DATE, 2); // Adding 5 days
			String output = fmt.format(c.getTime());
			userData.putData("License", "Date", output+" 12:00:00 AM");
			
			}
			else if(Data.equals("Sub"))
			{
				
				DateFormat fmt = new SimpleDateFormat("MMM dd, yy", Locale.US);
				Calendar c = Calendar.getInstance();
				c.setTime(new Date()); // Using today's date
				c.add(Calendar.DATE, -2); // Adding 5 days
				String output = fmt.format(c.getTime());
				userData.putData("License", "Date", output+" 12:00:00 AM");
			}
			
		}
		@Action(object = ObjectType.BROWSER,desc = "GetCheckout time",input = InputType.NO)
		public void checkOutTime() {
			
			StopWatch pageLoad = new StopWatch();
			Driver.findElement(By.xpath("/html/body/div/div[6]/div[6]/div/div/div/div/div/div[2]/div/div[6]/div/div[3]/button[2]")).click();
			 pageLoad.start();
		        
		        WebDriverWait wait = new WebDriverWait(Driver, 600);
		        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(/html/body/div/div[6]/form/button)[1]")));

		        pageLoad.stop();
		        //Get the time
		        long pageLoadTime_ms = pageLoad.getTime();
		        //long pageLoadTime_Seconds = pageLoadTime_ms / 1000;
		        String pageLoadTime_Seconds = Long.toString(pageLoadTime_ms / 1000);
		        userData.putData("SplitShipment", "CheckoutLoad", pageLoadTime_Seconds);
		     
			
		}
		@Action(object = ObjectType.BROWSER,desc = "Verify [<Data>] tab",input = InputType.YES)
		public void verifyNewTab() {
			
			String URL = Data+"URL";
			
			 ArrayList<String> tabs = new ArrayList<String> (Driver.getWindowHandles());
			    Driver.switchTo().window(tabs.get(1));
			    
			    System.out.println(Driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[2]/div[1]/div/div/div/div[2]")).getText());
			    System.out.println(userData.getData("ResourcesTradeInformation", URL));
			    System.out.println(Driver.getCurrentUrl());
			    
			    if(!Driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[2]/div[1]/div/div/div/div[2]")).getText().equals("ERR_INVALID_RESPONSE") && Driver.getCurrentUrl().equals(userData.getData("ResourcesTradeInformation", URL)))
			    { Report.updateTestLog(Action, "Verifying " + URL, Status.PASS);}
			    else
			    {Report.updateTestLog(Action, "Verifying " + URL, Status.FAIL);}
			    Driver.close();
			    Driver.switchTo().window(tabs.get(0));
			
		}
		
		@Action(object = ObjectType.SELENIUM,desc = "Wait for [<Object>]",input = InputType.NO)
		public void waitFor() {
			
			try {
				WebDriverWait wait = new WebDriverWait(Driver, 600);
		        wait.until(ExpectedConditions.visibilityOf(Element));
			}
			catch(StaleElementReferenceException e)
			{
				WebDriverWait wait = new WebDriverWait(Driver, 600);
		        wait.until(ExpectedConditions.visibilityOf(Element));
			}
		        
		        

		        
		     
			
		}
		
		@Action(object = ObjectType.SELENIUM,desc = "Shopping cart removal",input = InputType.NO)
		public void clearShoppingCart() {
			
		
			String[] qtyarray=Element.getText().split("\\D");
			
			int num = Integer.parseInt(qtyarray[1]);
			
			
			if(!Element.getText().equals("(0)"))
			{

				Driver.findElement(By.xpath("/html/body/div[1]/div[3]/div[1]/span[2]/span/a[1]")).click();
				
				for(int i=1;i<=num;i++)
				{
					Driver.findElement(By.xpath("//*[@id=\"content\"]/div[3]/div[2]/div/div[3]/div[3]/div[2]/div[2]/div[2]/a")).click();
					////*[@id="content"]/div[3]/div[2]/div/div[3]/div[3]/div[2]/div[2]/div[2]/a
					///html/body/div[1]/div[7]/div[3]/div[2]/div/div[3]/div[3]/div[2]/div[2]/div[2]/a
					WebDriverWait wait = new WebDriverWait(Driver, 600);
			        wait.until(ExpectedConditions.visibilityOf(Driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[2]/div[2]/div[1]/div/div[3]/button[2]"))));
					Driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[2]/div[2]/div[1]/div/div[3]/button[2]")).click();
				}
				
				
			}
			else
			{
				Report.updateTestLog(Action, "Cart is null ", Status.PASS);
			}
			
			
			
		}	
		
		@Action(object = ObjectType.BROWSER,desc = "ShipTo number check",input = InputType.YES)
		public void shipToCheck() {
			
		
			String[] shipto=Data.split(" ");
			
			int num = Integer.parseInt(shipto[0]);
			 userData.putData("UserValidation", "ShipTo", shipto[0]);
			
			if(num>1)
			{
				Driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div/div[1]/a[4]")).click();
		 Driver.switchTo().activeElement();
				//WebDriverWait wait = new WebDriverWait(Driver, 600);
		        //wait.until(ExpectedConditions.visibilityOf(Driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[2]/div[2]/div[1]/div/div/div[1]/form/div[2]/div[2]"))));
		        ///html/body/div[4]/div[1]/div[2]/div[2]/div[1]/div/div/div[1]/form/div[2]/div[2]/span[1]
				String[] shiptocheck=Driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[2]/div[2]/div[1]/div/div/div[1]/form/div[2]/div[2]")).getText().split(" ");
				
				if(shipto[0].equals(shiptocheck[1]))
				{
					Report.updateTestLog(Action, "Ship To num verified ", Status.PASS);
				}
				else
				{
					Report.updateTestLog(Action, "Ship to num error ", Status.FAIL);
				}
				
				Driver.findElement(By.xpath("/html/body/div[4]/div/div[2]/div[2]/button[4]")).click();	
				Driver.findElement(By.xpath("(/html/body/div/div[2]/div[2]/div/div/a/span)[1]")).click();	
			}
			else
			{
				Driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div/div[1]/a[1]/span[1]")).click();
				Report.updateTestLog(Action, "Single ship To ", Status.PASS);
			}
			
			
			
		}	
		
		@Action(object = ObjectType.BROWSER,desc = "implicit wait for [<Data>]",input = InputType.YES)
		public void implicitWait() {
			
			int num = Integer.parseInt(Data);
			Driver.manage().timeouts().implicitlyWait(num,TimeUnit.SECONDS) ;
			
			
			
		}	
		
		@Action(object = ObjectType.BROWSER,desc = "find [<Data>] Product",input = InputType.YES)
		public void findProduct() {
			
			//Driver.findElement(By.linkText(Data)).click();
			
			Driver.findElement(By.xpath("(//a[@title='"+Data+"'])[2]")).click();
			
		}
		
		@Action(object = ObjectType.BROWSER,desc = "SCroll function [<Object>]",input = InputType.NO)
		public void scroll_fuction() {
		WebElement findElement=Driver.findElement(By.xpath("//div[text()='Creation Time']"));
		((JavascriptExecutor) Driver).executeScript("arguments[0].scrollIntoView(true);", findElement);
		}
		
		@Action(object = ObjectType.BROWSER,desc = "Cancel [<Data>] order",input = InputType.YES)
		public void changeOrderStatus() {
			Driver.findElement(By.xpath("/html/body/div/div/div/div[2]/div[2]/div/div[2]/div/div[2]/div/div[2]/div[2]/div[2]/div/div/div[2]/div/div/div[2]/div/div/div[2]/div/div/div/div/div/div[2]/div/div/div/div/div/div[2]/div/div[2]/div/span/input")).sendKeys("Orders");
			Driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			Driver.findElement(By.xpath("(/html/body/div/div/div/div[2]/div[2]/div/div[2]/div/div[2]/div/div[2]/div[2]/div[2]/div/div/div[2]/div/div/div[2]/div/div/div[2]/div/div/div/div/div/div[2]/div/div/div/div/div/div[2]/div/div[3]/div/div/div/table/tbody/tr[2]/td/div/div/div)[1]")).click();
			Driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			Driver.findElement(By.xpath("/html/body/div/div/div/div[2]/div[2]/div/div[2]/div/div[2]/div/div[2]/div[2]/div[2]/div/div/div[2]/div/div/div[2]/div/div/div[2]/div/div[2]/div/div/div/div[2]/div/div/div[2]/div[2]/div/div[2]/div/div/div[2]/div/div/div/div/div/div/div/div/div/button")).click();
			Driver.findElement(By.xpath("(/html/body/div/div/div/div[2]/div[2]/div/div[2]/div/div[2]/div/div[2]/div[2]/div[2]/div/div/div[2]/div/div/div[2]/div/div/div[2]/div/div[2]/div/div/div/div[2]/div/div/div[2]/div[2]/div/div[2]/div/div/div[2]/div/div[2]/div/div/div[2]/div[2]/div/div/div[3]/table/tbody/tr/td[3]/div/input)[1]")).sendKeys(Data);

			//Driver.findElement(By.xpath(""))
			Driver.findElement(By.xpath("/html/body/div/div/div/div[2]/div[2]/div/div[2]/div/div[2]/div/div[2]/div[2]/div[2]/div/div/div[2]/div/div/div[2]/div/div/div[2]/div/div[2]/div/div/div/div[2]/div/div/div[2]/div[2]/div/div[2]/div/div/div[2]/div/div/div/div/div/div/div/div/div/div[2]/button")).click();
			Driver.findElement(By.xpath("/html/body/div/div/div/div[2]/div[2]/div/div[2]/div/div[2]/div/div[2]/div[2]/div[2]/div/div/div[2]/div/div/div[2]/div/div/div[2]/div/div[2]/div/div/div/div[2]/div/div/div[2]/div[2]/div/div[2]/div/div/div[2]/div/div[2]/div/div/div[2]/div[2]/div[3]/div[2]/div/div[2]/div/div[3]/table/tbody/tr/td/div/span[2]")).click();
			
			
			
		}
		@Action(object = ObjectType.BROWSER,desc = "find [<Data>] Account",input = InputType.YES)
		public void findAccount() {
			Driver.findElement(By.linkText(Data)).click();
		}
		
		
		@Action(object = ObjectType.BROWSER,desc = "Select [<Data>] Account",input = InputType.YES)
		public void selectEnteredAccount() {
			
			List<WebElement> listofaccounts= Driver.findElements(By.id("shipToUid"));
			
			for (int i=1; i<=listofaccounts.size();i++)
			{
				String accnum =Driver.findElement(By.xpath("/html/body/div[7]/div[1]/div[2]/div[2]/div[1]/div/div/div[3]/div["+i+"]/div[1]/span[2]")).getText();
				
				//int j=i+1;			
				if(accnum.equals(Data))
				{
					Driver.findElement(By.xpath("/html/body/div[7]/div[1]/div[2]/div[2]/div[1]/div/div/div[3]/div["+i+"]/div[1]/span[2]")).click();
					break;
				}
			}
			
			
		}
		@Action(object = ObjectType.BROWSER,desc = "Select Available amount in stock popup",input = InputType.NO)
		public void selectAvailableAmountInStockPopup() throws InterruptedException {
			Thread.sleep(10000);
			List<WebElement> findElements = Driver.findElements(By.xpath("//div[text()='Product Code']/ancestor::table/parent::div/following-sibling::div[2]/table/tbody[1]/tr/td[3]/div/span"));
			for (WebElement webElement : findElements) {
				if (!webElement.getText().equals("0")) {
					webElement.click();
				}
			}
		}
		@Action(object = ObjectType.BROWSER,desc = "Get Order Number [<Object>]",input = InputType.NO)
		public void getOrderNumberForSalesTax() throws ParseException {
			String[] split;
			try {
				List<WebElement> orderno = Driver.findElements(By.xpath("//p[@class='order-to-title ']"));
				for (int i=1;i<=orderno.size();i++) {
				String orderNoTxt = Driver.findElement(By.xpath("(//p[@class='order-to-title '])["+i+"]")).getText();
				split = orderNoTxt.split(" ");	
				userData.putData("Flu Reservation", "OrderNo"+i, split[split.length-1]);
				Report.updateTestLog(Action, "Order No" + split[split.length-1] + "is displayed", Status.DONE);	
				}
			}catch(Exception e){
			}		
		}	
		@Action(object = ObjectType.BROWSER,desc = "Remove Dollar From SalesTax [<Data>]",input = InputType.YES)
		public void removeDollarFromSalesTax() throws ParseException {
			StringBuilder salesTax;
				salesTax = new StringBuilder(Data);	
				userData.putData("Flu Reservation", "SalesTax",new String(salesTax.deleteCharAt(0)));
		}
		
		@Action(object = ObjectType.BROWSER,desc = "Verify HCOSL HCPSL [<Object>]",input = InputType.NO)
		public void checkHCOSLHCPSL() throws ParseException {
				List<WebElement> identifierType = Driver.findElements(By.xpath("(//table[@style='table-layout:fixed;'])[10]//tr//td[2]"));
				for (int i=0;i<identifierType.size();i++) {
		        	String type = identifierType.get(i).getText();
		        	if(type.contains("HCOSL") || type.contains("HCPSL")) {
		        		Report.updateTestLog(Action, "Verify Identifiers" + "No HCOSL & HCPSL is present", Status.DONE);
		        	}
		        }
		}
		
		@Action(object = ObjectType.BROWSER,desc = "Product NDC [<Data>]",input = InputType.YES)
	    public void addQtyReservCancel()  {
			String quantity="";
	    Driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    WebElement addQty=null;
	       	 quantity = userData.getData("Flu Reservation", "NewQty");   
	        
	    try {
	    try {
	    	addQty = Driver.findElement(By.xpath("//div[@class='row orderable-product-row otherProduct']//div[2]//span[contains(text(),'"+Data+"')]/parent::div/parent::div/following-sibling::div[4]/div/input"));
	    	addQty.click();
	    	addQty.clear();
	    	addQty.sendKeys(quantity);
	    } catch (Exception e) {
	    	addQty = Driver.findElement(By.xpath("//div[@class='row orderable-product-row']//div[2]//span[contains(text(),'"+Data+"')]/parent::div/parent::div/following-sibling::div[4]/div/input"));
	    	addQty.click();
	    	addQty.clear();
	    	addQty.sendKeys(quantity);
	    }
	    } catch (Exception e) {
	    	addQty = Driver.findElement(By.xpath("//div[@class='row orderable-product-row favProduct']//div[2]//span[contains(text(),'"+Data+"')]/parent::div/parent::div/following-sibling::div[4]/div/input"));
	    	addQty.click();
	    	addQty.clear();
	    	addQty.sendKeys(quantity);
	    }   
	    }

		@Action(object = ObjectType.BROWSER,desc = "SCroll function [<Object>]",input = InputType.YES)
		public void scroll_function() throws InterruptedException {
			WebElement findElement=Driver.findElement(By.xpath(Data));
			Thread.sleep(5000);
			((JavascriptExecutor) Driver).executeScript("arguments[0].scrollIntoView(true);", findElement);
		}
		
		@Action(object = ObjectType.BROWSER,desc = "Quantity Input in Split Shipment",input = InputType.YES)
		public void QuantityInput() throws InterruptedException {
			
			String  a[]= Data.split(",");
			Thread.sleep(5000);
			Driver.findElement(By.xpath("//div[contains(text(),'"+a[0].toString()+"')]/following-sibling::div[4]/div/input")).sendKeys(a[1].toString());
		}
		
		@Action(object = ObjectType.BROWSER,desc = "Reading_State_Values_Knoxville [<Object>]",input = InputType.NO)
		public void Reading_State_Values_Knoxville() {
			
			
			List la = new ArrayList<String>();
			la.add("Minnesota [US-MN]");
			la.add("Oklahoma [US-OK]");
			la.add("Georgia [US-GA]");
			la.add("Louisiana [US-LA]");
			la.add("Washington [US-WA]");
			la.add("Alabama [US-AL]");
			la.add("Illinois [US-IL]");
			la.add("New Mexico [US-NM]");
			la.add("Iowa [US-IA]");
			la.add("Missouri [US-MO]");
			la.add("Wyoming [US-WY]");
			la.add("Montana [US-MT]");
			la.add("California [US-CA]");
			la.add("South Dakota [US-SD]");
			la.add("Tennessee [US-TN]");
			la.add("Puerto Rico [US-PR]");
			la.add("North Dakota [US-ND]");
			la.add("Colorado [US-CO]");
			la.add("Mississippi [US-MS]");	
			la.add("Oregon [US-OR]");
			la.add("Nevada [US-NV]");
			la.add("Texas [US-TX]");
			la.add("Wisconsin [US-WI]");
			la.add("Nebraska [US-NE]");
			List la_new = new ArrayList();
			List<WebElement> findElement = Driver.findElements(By.xpath("(//span[text()='States']/parent::div/following-sibling::div//table)[2]/tbody[1]/tr"));
			for (WebElement webElement : findElement) {
			for (int i = 0; i < la.size(); i++) {
			if (webElement.getAttribute("title").contains(la.get(i).toString())) 
			{
				((JavascriptExecutor) Driver).executeScript("arguments[0].scrollIntoView(true);", webElement);
				la_new.add(webElement.getAttribute("title"));
				Report.updateTestLog(Action, "State list matched  " + webElement.getAttribute("title"), Status.PASS);
			} 
			}
			}
	        boolean isEqual = org.apache.commons.collections.CollectionUtils.isEqualCollection(la, la_new);
	        if (isEqual) {
	        	Report.updateTestLog(Action, "both states list are matched  ", Status.PASS) ;
	        }
	        else {
	        	Report.updateTestLog(Action, "both states list are not matched  ", Status.FAIL);

	        }
		}
		
		@Action(object = ObjectType.BROWSER,desc = "Reading_State_Values_Richmond [<Object>]",input = InputType.NO)
		public void Reading_State_Values_Richmond() {
			List la = new ArrayList<String>();
			la.add("North Carolina [US-NC]");
			la.add("Rhode Island [US-RI]");
			la.add("Hawaii [US-HI]");
			la.add("Maryland [US-MD]");
			la.add("West Virginia [US-WV]");
			la.add("Florida [US-FL]");
			la.add("New York [US-NY]");
			la.add("Virginia [US-VA]");
			la.add("Massachusetts [US-MA]");
			la.add("Indiana [US-IN]");
			la.add("Vermont [US-VT]");
			la.add("South Carolina [US-SC]");
			la.add("New Jersey [US-NJ]");
			la.add("Delaware [US-DE]");
			la.add("Connecticut [US-CT]");
			la.add("Michigan [US-MI]");
			la.add("New Hampshire [US-NH]");
			la.add("Ohio [US-OH]");
			la.add("Pennsylvania [US-PA]");	
			la.add("Alaska [US-AK]");
			la.add("Maine [US-ME]");
			la.add("District of Columbia [US-DC]");
					
			List la_new = new ArrayList();
			List<WebElement> findElement = Driver.findElements(By.xpath("(//span[text()='States']/parent::div/following-sibling::div//table)[2]/tbody[1]/tr"));
			for (WebElement webElement : findElement) {
			for (int i = 0; i < la.size(); i++) {
			if (webElement.getAttribute("title").contains(la.get(i).toString())) 
			{
				((JavascriptExecutor) Driver).executeScript("arguments[0].scrollIntoView(true);", webElement);
				la_new.add(webElement.getAttribute("title"));
				Report.updateTestLog(Action, "State list matched  " + webElement.getAttribute("title"), Status.PASS);
		} 
		}
			}
			boolean isEqual = org.apache.commons.collections.CollectionUtils.isEqualCollection(la, la_new);
	        if (isEqual) {
	        	Report.updateTestLog(Action, "both states list are matched  ", Status.PASS) ;
	        }
	        else {
	        	Report.updateTestLog(Action, "both states list are not matched  ", Status.FAIL);
	        }
		}

		@Action(object = ObjectType.BROWSER,desc = "Click on Mouse Hover [<Object>]",input = InputType.NO)
		public void ClickOnMouseHover() {
			Actions actions = new Actions(Driver);
			//WebElement menuOption = Driver.findElement(By.xpath("//span[text()='Minnesota [US-MN]']"));
			//actions.moveToElement(menuOption).perform();
			WebElement subMenuOption = Driver.findElement(By.xpath("(//div[@class='ye-default-reference-editor-remove-button ye-delete-btn z-div'])[2]")); 
			    	//Delete Icon
			actions.moveToElement(subMenuOption).perform();
			subMenuOption.click();
		}
		
		@Action(object = ObjectType.BROWSER, desc = "Radio buttion selection in BackOffice for true or false", input = InputType.YES)
		public void radio_btnBoffice() {
			String value = Data;
			WebElement t1 = null;
			WebElement t2 = null;

			try {
				t1 = Driver.findElement(By.xpath("(//span[text()='" + value + "']/ancestor::td[1]//span/input)[1]"));

				boolean type = t1.isSelected();

				if (type == true)

				{
					t2 = Driver.findElement(By.xpath("(//span[text()='" + value + "']/ancestor::td[1]//span/input)[2]"));
					// ((JavascriptExecutor)
					// Driver).executeScript("arguments[0].scrollIntoView(true);", t2);
					t2.click();
					userData.putData("Flu Reservation", "RecurringLink", "Join the Recurring Reservation Program");

					Report.updateTestLog(Action, "True buttion is selected 1st --Now selecting False Radio Button ",
							Status.DONE);
					// Join the Recurring Reservation Program

				} else {
					t1.click();

					userData.putData("Flu Reservation", "RecurringLink", "Member of the Recurring Reservation Program");
					// ((JavascriptExecutor)
					// Driver).executeScript("arguments[0].scrollIntoView(true);", t1);
					Report.updateTestLog(Action, "False buttion is selected 1st --Now selecting true Radio Button ",
							Status.DONE);

				}
			} catch (Exception e) {
				t2 = Driver.findElement(By.xpath("(//span[text()='" + value + "']/ancestor::td[1]//span/input)[2]"));

				boolean type = t2.isSelected();

				if (type == true) {
					t1 = Driver.findElement(By.xpath("(//span[text()='" + value + "']/ancestor::td[1]//span/input)[1]"));
					t1.click();

					userData.putData("Flu Reservation", "RecurringLink", "Member of the Recurring Reservation Program");
					// ((JavascriptExecutor)
					// Driver).executeScript("arguments[0].scrollIntoView(true);", t1);
					Report.updateTestLog(Action, "False buttion is selected 1st --Now selecting true Radio Button ",
							Status.DONE);

				}

				else {
					// ((JavascriptExecutor)
					// Driver).executeScript("arguments[0].scrollIntoView(true);", t2);
					t2.click();
					userData.putData("Flu Reservation", "RecurringLink", "Join the Recurring Reservation Program");

					Report.updateTestLog(Action, "True buttion is selected 1st --Now selecting False Radio Button ",
							Status.DONE);
					// Join the Recurring Reservation Program

				}

			}
			// WebElement t3=(WebElement)
			// Driver.findElements(By.xpath("(//span[text()='"+value+"']/ancestor::td[1]//span/input)[3]"));

		}

		@Action(object = ObjectType.BROWSER, desc = "verifying Recurring Reservation Program link", input = InputType.NO)
		public void recurrionLink_Verify() {

			// String optIn,optOut=null;
			try {

				if (Driver.findElement(By.xpath("//*[@id='opt-in-link']")).isDisplayed())

				{
					try {
						Report.updateTestLog(Action,
								Driver.findElement(By.xpath("//*[@id='opt-in-link']")).getText() + "  Is Displayed ",
								Status.PASS);

						Driver.findElement(By.xpath("//*[@id='opt-in-link']")).click();

						Thread.sleep(1000);
						WebElement link = Driver.findElement(By.xpath("//button[@id='recurringReservationClose']"));

						// Driver.switchTo().frame(link);
						Thread.sleep(5000);
						Report.updateTestLog(Action, link.getText() + "  Is Displayed ", Status.PASS);
						Thread.sleep(1000);

						link.click();
					}

					catch (Exception e) {
						Report.updateTestLog(Action, " Un able to Click on Link Details not Displayed ", Status.FAIL);
					}

				} else if (Driver.findElement(By.xpath("//*[@id='opt-out-link']/a")).isDisplayed()) {
					try {

						Report.updateTestLog(Action,
								Driver.findElement(By.xpath("//*[@id='opt-out-link']")).getText() + "  Is Displayed ",
								Status.PASS);

						Driver.findElement(By.xpath("//*[@id='opt-out-link']/a")).click();

						Thread.sleep(1000);
						WebElement link = Driver.findElement(By.xpath("//button[@id='recurringReservationOptOutCancel']"));

						// Driver.switchTo().frame(link);
						Thread.sleep(5000);
						Report.updateTestLog(Action, link.getText() + "  Is Displayed ", Status.PASS);
						Thread.sleep(1000);

						link.click();
					} catch (Exception e) {
						Report.updateTestLog(Action,
								Driver.findElement(By.xpath("//button[@id='recurringReservationOptOutCancel']")).getText()
										+ "Details not Displayed ",
								Status.FAIL);
					}

				} else {

					Report.updateTestLog(Action, "RecurrionLink Details not Displayed Please use another Id ", Status.FAIL);

				}

			} catch (Exception e) {
				Report.updateTestLog(Action, "Details not Displayed ", Status.FAIL);
			}

		}

		@Action(object = ObjectType.BROWSER, desc = "Selecting  GSK Flu Vaccine Dashboard", input = InputType.YES)
		public void helpCenter_Namevalidation() {

			String name = Data;
			String bo_name = null;
			try {

				List<WebElement> bo_findElements = Driver.findElements(By.xpath(
						"//tr[@data-drag-key='GSKHelpCenterDetail']//td[@class='yw-listview-cell z-listcell']/div/span[@class='yw-listview-cell-label z-label']"));
				//Report.updateTestLog(Action, bo_findElements.size() + "  ::  link avialbe   ", Status.DONE);

				for (int i = 1; i <= bo_findElements.size(); i++) {
					bo_name = Driver.findElement(By.xpath(
							"(//tr[@data-drag-key='GSKHelpCenterDetail']//td[@class='yw-listview-cell z-listcell']/div/span[@class='yw-listview-cell-label z-label'])["
									+ i + "]"))
							.getText();
					
					//Report.updateTestLog(Action, bo_name + " ::  namess   ", Status.DONE);

					
					  if(bo_name.contains(Data)) { 
						  
						  try { 
							/*
							 * WebElement nm=Driver.findElement(By.
							 * xpath("(//tr[@data-drag-key='GSKHelpCenterDetail']//td[@class='yw-listview-cell z-listcell']/div/span[@class='z-listitem-checkable z-listitem-checkbox']/i)["
							 * +i+"]"));
							 * 
							 * ((JavascriptExecutor) Driver).executeScript("arguments[0].click();", nm);
							 * Thread.sleep(2000); Report.updateTestLog(Action, " HelpCenter Name :: " +
							 * bo_name+"  :: checkbox is Selected", Status.PASS);
							 */
					
							  WebElement nm=Driver.findElement(By.xpath("(//tr[@data-drag-key='GSKHelpCenterDetail']//td[@class='yw-listview-cell z-listcell']/div/span[@class='z-listitem-checkable z-listitem-checkbox']/i)["+i+"]"));

							  nm.click();
							  				  Report.updateTestLog(Action, " HelpCenter Name :: " +
							  				  bo_name+"  :: checkbox is Selected", Status.PASS);
							  				  break;
						  
						  }
						  catch(Exception e)
					  { 
							 


					 
							  Report.updateTestLog(Action, " Unable to click on link::  namess   ", Status.FAIL);		  
					  
						  
					  }
						  
						  
					 
				}
				}

			}

			catch (Exception e) {
				Report.updateTestLog(Action, "Unable to Fetch HelpCenter list details  ", Status.FAIL);
			}

		}
		
		
		
		@Action(object = ObjectType.BROWSER, desc = "Give xpath of element in Input [<Data>]", input = InputType.YES)
		public void broswer_scrollTo() throws InterruptedException {
			Thread.sleep(10000);
			WebElement element = Driver.findElement(By.xpath(Data));
			((JavascriptExecutor) Driver).executeScript("arguments[0].scrollIntoView(true);", element);
			Thread.sleep(500); 
			
			
			
		}
		
		
		
		@Action(object = ObjectType.BROWSER, desc = "Validating the covid Visibility ", input = InputType.NO)
		public void covid_banner_check() {
			String banner = null;
			WebDriverWait wait = new WebDriverWait(Driver, 600);
			
			try {

				List<WebElement> bo_findElements = Driver.findElements(By.xpath("(//td[@class='yw-listview-cell z-listcell']//span[@class='yw-listview-cell-label z-label'])"));
			//	Report.updateTestLog(Action, bo_findElements.size() + "  ::  link avialbe   ", Status.DONE);
				
				
				for (int i = 1; i <= 9; i++) {
					
					banner = Driver.findElement(By.xpath(
							"(//td[@class='yw-listview-cell z-listcell']//span[@class='yw-listview-cell-label z-label'])["
									+ i + "]"))
							.getText();
					
					if(banner.equalsIgnoreCase("GSK Content Catalog : Staged"))
					{
						
						String visible= Driver.findElement(By.xpath(
								"(//td[@class='yw-listview-cell z-listcell']//span[@class='yw-listview-cell-label z-label'])["
										+ (i+1) + "]"))
								.getText();
						
						  Report.updateTestLog(Action, "  GSK Content Catalog : Staged value is displyed   ", Status.PASS);
						
						  Report.updateTestLog(Action, visible+ "  :value is displyed   ", Status.PASS);
						  
						  try {
						if(visible.equalsIgnoreCase("true"))
							
						{
							
							
							Driver.findElement(By.xpath(
									"(//td[@class='yw-listview-cell z-listcell']//span[@class='yw-listview-cell-label z-label'])["
											+ i + "]"))
									.click();
							 
							Thread.sleep(5000);
							
							 Report.updateTestLog(Action, "  GSK Content Catalog : Staged value is TRUE making it False for Testing   ", Status.PASS);
							 
							
							
							
							
								 wait.until(ExpectedConditions
							 .visibilityOf(Driver.findElement(By.xpath("//button[@ytestid='northButton']")
							  )));
							 
							 Driver.findElement(By.xpath("//button[@ytestid='northButton']")).click();	
							 
							 Thread.sleep(5000);
							 
							 radio_visibility_check();
								
							
						}
						else
						{
							
							wait.until(ExpectedConditions
									 .visibilityOf(Driver.findElement(By.xpath("//button[@ytestid='northButton']")
									  )));
									 
									 Driver.findElement(By.xpath("//button[@ytestid='northButton']")).click();	
									 
									 Thread.sleep(5000);
							 Report.updateTestLog(Action, "  Comming to else part   ", Status.PASS);
									
							
						}
						
						  }catch (Exception e) {
								Report.updateTestLog(Action, "Faling at true if condition  ", Status.FAIL);
							}

						 
					}
					
					
					
					
					
					
					
				}

			}
			catch (Exception e) {
				Report.updateTestLog(Action, "Unable to Fetch HelpCenter list details  ", Status.FAIL);
			}

			
		}
		
		
		
		
		
		public void radio_visibility_check() {
			WebDriverWait wait = new WebDriverWait(Driver, 600);
			; 
			
			WebElement t1 = null;
			WebElement t2 = null;

			try {
				
				
				t1 = Driver.findElement(By.xpath("(//span[@class='z-radio z-radio-default']/input[@type='radio'])[3]"));
				//Report.updateTestLog(Action, t1.getClass(),Status.FAIL);
				((JavascriptExecutor) Driver).executeScript("arguments[0].scrollIntoView(true);", t1);
				Thread.sleep(500);
				boolean type = t1.isSelected();
			//	Report.updateTestLog(Action,  t1.isSelected() + " type",Status.FAIL);
				if (type == true)

				{
					try {
					t2 = Driver.findElement(By.xpath("(//span[@class='z-radio z-radio-default']/input[@type='radio'])[4]"));
					 
					((JavascriptExecutor) Driver).executeScript("arguments[0].click();", t2);
					
					Thread.sleep(2000);
					Report.updateTestLog(Action, "True buttion is selected 1st --Now selecting False Radio Button ",
							Status.DONE);
					
					Thread.sleep(2000);
					Driver.findElement(By.xpath("//span[text()='Content Slots']")).click();
					
					wait.until(ExpectedConditions
							.visibilityOf(Driver.findElement(By.xpath("(//button[text()='Save'])[1]"))));

					Driver.findElement(By.xpath("(//button[text()='Save'])[1]")).click();
					
					
					Thread.sleep(2000);
					Report.updateTestLog(Action, "Clicked on Save  Button ",Status.PASS);
					
					}catch (Exception e) {
						t2 = Driver.findElement(By.xpath("(//span[@class='z-radio z-radio-default']/input[@type='radio'])[4]"));
						 
						
						((JavascriptExecutor) Driver).executeScript("arguments[0].click();", t2);
						
						Report.updateTestLog(Action, "True buttion is selected 1st --Now selecting False Radio Button ",
								Status.DONE);
						
						
						Driver.findElement(By.xpath("//span[text()='Content Slots']")).click();
						
						wait.until(ExpectedConditions
								.visibilityOf(Driver.findElement(By.xpath("(//button[text()='Save'])[1]"))));

						Driver.findElement(By.xpath("(//button[text()='Save'])[1]")).click();
						
						Report.updateTestLog(Action, "unable to select radio  ",Status.FAIL);
						

					}
					
					
					
				} 
			} catch (Exception e) {
				
				Report.updateTestLog(Action, "unable to select radio  ",Status.FAIL);
				

			}
			
		}
		

		
		@Action(object = ObjectType.BROWSER, desc = "Validating the Unexpted error in New paragraph Check ", input = InputType.NO)
		public void unexpted_error_check() {
			
			try {
				Thread.sleep(2000);
			String error_text=	Driver.findElement(By.xpath("//span[text()='Unable to create: Unexpected error']")).getText();
			//Report.updateTestLog(Action, error_text + "  :  Data  ",Status.FAIL);
			Thread.sleep(1000);
			if(error_text.equalsIgnoreCase("Unable to create: Unexpected error"))
			{
				
				Report.updateTestLog(Action, "Unexpected error Present :Change Banner Name in PMP data sheet :ID_name ",Status.FAIL);
				Report.updateTestLog(Action, "Duplicate Name with Same Banner Name  ",Status.FAIL);
				
				Driver.findElement(By.xpath("//i[@class='z-icon-times']")).click();
				
				Report.updateTestLog(Action, "Closing the Window  ",Status.FAIL);
				
				
				Driver.quit();
			}else
			{
				
			}
				
				
				
			}catch (Exception e) {
				
				Report.updateTestLog(Action, " Clicked on DONE button successfully   ",Status.DONE);
				

			}
			
			
			
		}
		
		
		public void radio_visibility_check_F2T() {
			WebDriverWait wait = new WebDriverWait(Driver, 600);
			; 
			
			WebElement t1 = null;
			WebElement t2 = null;

			try {
				
				
				t1 = Driver.findElement(By.xpath("(//span[@class='z-radio z-radio-default']/input[@type='radio'])[4]"));
				//Report.updateTestLog(Action, t1.getClass(),Status.FAIL);
				((JavascriptExecutor) Driver).executeScript("arguments[0].scrollIntoView(true);", t1);
				Thread.sleep(500);
				boolean type = t1.isSelected();
			//	Report.updateTestLog(Action,  t1.isSelected() + " type",Status.FAIL);
				if (type == true)

				{
					try {
					t2 = Driver.findElement(By.xpath("(//span[@class='z-radio z-radio-default']/input[@type='radio'])[3]"));
					 
					((JavascriptExecutor) Driver).executeScript("arguments[0].click();", t2);
					
					Thread.sleep(2000);
					Report.updateTestLog(Action, "False buttion is selected for Testing --Now Selecting True Radio Button ",
							Status.DONE);
					
					Thread.sleep(2000);
					Driver.findElement(By.xpath("//span[text()='Content Slots']")).click();
					
					wait.until(ExpectedConditions
							.visibilityOf(Driver.findElement(By.xpath("(//button[text()='Save'])[1]"))));

					Driver.findElement(By.xpath("(//button[text()='Save'])[1]")).click();
					
					
					Thread.sleep(2000);
					Report.updateTestLog(Action, "Clicked on Save  Button ",Status.PASS);
					
					}catch (Exception e) {
						t2 = Driver.findElement(By.xpath("(//span[@class='z-radio z-radio-default']/input[@type='radio'])[3]"));
						 
						
						((JavascriptExecutor) Driver).executeScript("arguments[0].click();", t2);
						
						Report.updateTestLog(Action, "False buttion is selected for Testing --Now Selecting True Radio Button ",
								Status.DONE);
						
						
						Driver.findElement(By.xpath("//span[text()='Content Slots']")).click();
						
						wait.until(ExpectedConditions
								.visibilityOf(Driver.findElement(By.xpath("(//button[text()='Save'])[1]"))));

						Driver.findElement(By.xpath("(//button[text()='Save'])[1]")).click();
						
						Report.updateTestLog(Action, "unable to select radio  ",Status.FAIL);
						

					}
					
					
					
				} 
			} catch (Exception e) {
				
				Report.updateTestLog(Action, "unable to select radio  ",Status.FAIL);
				

			}
			
		}
		
		
		
		@Action(object = ObjectType.BROWSER, desc = "Validating the covid Visibility ", input = InputType.NO)
		public void covid_banner_check_False_true() {
			String banner = null;
			WebDriverWait wait = new WebDriverWait(Driver, 600);
			
			try {

				List<WebElement> bo_findElements = Driver.findElements(By.xpath("(//td[@class='yw-listview-cell z-listcell']//span[@class='yw-listview-cell-label z-label'])"));
			//	Report.updateTestLog(Action, bo_findElements.size() + "  ::  link avialbe   ", Status.DONE);
				
				
				for (int i = 1; i <= 9; i++) {
					
					banner = Driver.findElement(By.xpath(
							"(//td[@class='yw-listview-cell z-listcell']//span[@class='yw-listview-cell-label z-label'])["
									+ i + "]"))
							.getText();
					
					if(banner.equalsIgnoreCase("GSK Content Catalog : Staged"))
					{
						
						String visible= Driver.findElement(By.xpath(
								"(//td[@class='yw-listview-cell z-listcell']//span[@class='yw-listview-cell-label z-label'])["
										+ (i+1) + "]"))
								.getText();
						
						  Report.updateTestLog(Action, "  GSK Content Catalog : Staged value is displyed   ", Status.PASS);
						
						  Report.updateTestLog(Action, visible+ "  :value is displyed   ", Status.PASS);
						  
						  try {
						if(visible.equalsIgnoreCase("false"))
							
						{
							
							
							Driver.findElement(By.xpath(
									"(//td[@class='yw-listview-cell z-listcell']//span[@class='yw-listview-cell-label z-label'])["
											+ i + "]"))
									.click();
							 
							Thread.sleep(5000);
							
							 Report.updateTestLog(Action, "  GSK Content Catalog : Staged value is TRUE making it False for Testing   ", Status.PASS);
							 
							
							
							
							
								 wait.until(ExpectedConditions
							 .visibilityOf(Driver.findElement(By.xpath("//button[@ytestid='northButton']")
							  )));
							 
							 Driver.findElement(By.xpath("//button[@ytestid='northButton']")).click();	
							 
							 Thread.sleep(5000);
							 
							 radio_visibility_check_F2T();
								
							
						}
						else
						{
							
							wait.until(ExpectedConditions
									 .visibilityOf(Driver.findElement(By.xpath("//button[@ytestid='northButton']")
									  )));
									 
									 Driver.findElement(By.xpath("//button[@ytestid='northButton']")).click();	
									 
									 Thread.sleep(5000);
							 Report.updateTestLog(Action, "  Comming to else part   ", Status.PASS);
									
							
						}
						
						  }catch (Exception e) {
								Report.updateTestLog(Action, "Faling at true if condition  ", Status.FAIL);
							}

						 
					}
					
					
					
					
					
					
					
				}

			}
			catch (Exception e) {
				Report.updateTestLog(Action, "Unable to Fetch HelpCenter list details  ", Status.FAIL);
			}

			
		}	
		
		
		
		
		@Action(object = ObjectType.BROWSER, desc = "Validating the GSK Flu Vaccine Dashboard Total doses ", input = InputType.NO)
		public void flu_dashboard_Doses_check() {
			String D_doses=null, total_doses_sting=null;
			int dose_num=0;
			int t_doses = 0,total_doses=0;
			
			try {
				
			String 	Dash_text = Driver.findElement(By.xpath("//*[@id='content']//h1/span[2]")).getText();
				
			Report.updateTestLog(Action, "GSK Flu "+ Dash_text, Status.DONE);

				List<WebElement> dash_Doses = Driver.findElements(By.xpath("//*[@id='content']/div/div[2]//div[2]//div[1]/ul/li/a/p[2]"));
				
	for (int i = 1; i <= dash_Doses.size(); i++) {
					
		D_doses = Driver.findElement(By.xpath("(//*[@id='content']/div/div[2]//div[2]//div[1]/ul/li/a/p[2])["+ i +"]")).getText();
		
		
		
		Thread.sleep(1000);		
		
		try {
		//Report.updateTestLog(Action,  D_doses +"  :  D_doses  ", Status.DONE);	
		
		D_doses=D_doses.replaceAll(",","");
		}catch (Exception e) {
			Report.updateTestLog(Action, "D_doses replaceAll  failing  ", Status.FAIL);
		}
		Thread.sleep(1000);		
		/*---------------------------------------------------------*/
		try {
		dose_num = Integer.parseInt(D_doses);
		Thread.sleep(1000);		
		//Report.updateTestLog(Action,  dose_num +"  :  dose_num :  ", Status.DONE);	
		
		}catch (Exception e) {
			Report.updateTestLog(Action, "dose_num parseInt  failing  ", Status.FAIL);
		}
		
		/*---------------------------------------------------------*/
		try {
		t_doses=dose_num+t_doses;
		Thread.sleep(1000);		
//		Report.updateTestLog(Action,  " t_doses  : " +t_doses, Status.DONE);		
					
	}
		catch (Exception e) {
		Report.updateTestLog(Action, "t_doses addtion failing  ", Status.FAIL);
	}
	}
	Report.updateTestLog(Action,  "Total doses after adding (Reserved+Available+Shipped+Waitlisted+cancelled) : " +t_doses, Status.DONE);	



	try {
	total_doses_sting= Driver.findElement(By.xpath("//*[@id='content']//div[2]/span")).getText();


	String[] arrOfStr = total_doses_sting.split(" ");

	total_doses_sting=arrOfStr[0];

	total_doses_sting=total_doses_sting.replaceAll(",","");

	total_doses = Integer.parseInt(total_doses_sting);

	Report.updateTestLog(Action,  " Total Doses of chart Below :  " +total_doses_sting, Status.DONE);
	}
	catch (Exception e) {
		Report.updateTestLog(Action, "Total Doses of chart failing  ", Status.FAIL);
	}




	if(t_doses==total_doses)

	{
		Report.updateTestLog(Action,  " Total Doses of chart Below and Doses after adding are EQUAL  " , Status.PASS);
	}
	else
	{
		Report.updateTestLog(Action,  " Total Doses of chart Below and Doses after adding are Not EQUAL " , Status.FAIL);
	}


				
			}
			catch (Exception e) {
				Report.updateTestLog(Action, "Total Doses of GSK flu Dashboard Issue ", Status.FAIL);
			}
			
			
			
					
			
			
		}
		
		

		@Action(object = ObjectType.BROWSER, desc = "Validating Flue Dashboard Important Messages check ", input = InputType.NO)
		public void flu_DB_ImportantMessages_Check() {
			
			WebDriverWait wait = new WebDriverWait(Driver, 600);
			
			
			String available=null,Shipped=null;
			int Shipped_int =0,available_int=0;
			try {
				
			
			 available =  Driver.findElement(By.xpath("//*[@id='content']//ul/li[2]/a/p[2]")).getText();
			Thread.sleep(1000);
			available=available.replaceAll(",","");
			Thread.sleep(500);
			available_int = Integer.parseInt(available);
			Thread.sleep(500);
					

			 Shipped =  Driver.findElement(By.xpath("//*[@id='content']//ul/li[3]/a/p[2]")).getText();
			Thread.sleep(1000);
			Shipped=Shipped.replaceAll(",","");
			Thread.sleep(500);
			Shipped_int = Integer.parseInt(Shipped);
			Thread.sleep(500);
			
			try {
			
			boolean im = Driver.findElement(By.xpath("//*[@id='content']//h3[contains(text(),'Important Messages')]")).isDisplayed();
			
		//	Report.updateTestLog(Action,  im +"  : Im value  " , Status.DONE);
			
			if(im==false)
			{
				
				
				Report.updateTestLog(Action,  " Important Messages is Not available in the page  " , Status.DONE);		
				
			}
			} catch (Exception e) {
				Report.updateTestLog(Action, "Important Messages is Not available in the page ", Status.DONE);
			}
			
			
			try {
			List<WebElement> IM_list = Driver.findElements(By.xpath("//*[@id='content']//div[3]//div[2]/ul/li/span"));
			
		
			int IM_list_size=IM_list.size();
			

		//int add=Shipped_int+available_int;
		
			if(IM_list_size==0)
			{
				Report.updateTestLog(Action,  " No bulletin points displayed under important message " , Status.DONE);	
				
			} else
			if(IM_list_size==1)
			{
				Report.updateTestLog(Action,  " One bulletin point displayed under important message " , Status.DONE);
				
				
				wait.until(ExpectedConditions
						.visibilityOf(Driver.findElement(By.xpath("(//*[@id='content']//li//a[text()=' Click here'])"))));
			//	Driver.findElement(By.xpath("(//button[text()='Yes, Remove'])[2]")).click();
				Driver.findElement(By.xpath("//*[@id='content']//li//a[text()=' Click here']")).click();
				
				Thread.sleep(6000);
				
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[text()='Complete']")));
				Thread.sleep(1000);
				Report.updateTestLog(Action,  " Clicked on Click Hear link navigated to the page " , Status.DONE);
				
				Driver.navigate().back();
				Thread.sleep(6000);
				
				
			}else
		if(IM_list_size==2)
			
		{
			
			Report.updateTestLog(Action,  " 2 bulletin points displayed under important message " , Status.PASS);	
			
			
			
		try
		{
			
			
			wait.until(ExpectedConditions
					.visibilityOf(Driver.findElement(By.xpath("(//*[@id='content']//li//a[text()=' Click here'])"))));
		
			Driver.findElement(By.xpath("//*[@id='content']//li//a[text()=' Click here']")).click();
			
			Thread.sleep(6000);
			
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[text()='Complete']")));
			Thread.sleep(1000);
			Report.updateTestLog(Action,  " Clicked on Click Hear link navigated to the page " , Status.DONE);
			
			Driver.navigate().back();
			Thread.sleep(6000);
			
			wait.until(ExpectedConditions
					.visibilityOf(Driver.findElement(By.xpath("(//*[@id='content']//li//a[text()=' Click here'])[2]"))));
		
			Driver.findElement(By.xpath("(//*[@id='content']//li//a[text()=' Click here'])[2]")).click();
			
			Thread.sleep(6000);
			
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[text()='Available']")));
			Thread.sleep(1000);
			Report.updateTestLog(Action,  " Clicked on Click Hear link navigated to the page " , Status.DONE);
			
			
			
		} catch (Exception e) {
			Report.updateTestLog(Action, " Unable to Click on Click here link  ", Status.FAIL);
		}
		}
			} catch (Exception e) {
				Report.updateTestLog(Action, "bulletin points NOT displayed under Important Messages in GSK flu Dashboard  ", Status.DONE);
			}
			
			
			
	} catch (Exception e) {
		Report.updateTestLog(Action, "Important Messages Issue in GSK flu Dashboard  ", Status.FAIL);
	}
			

					
			
			
			
			
			
		}
		
		
		
		
		
		
		
		@Action(object = ObjectType.BROWSER, desc = "Validating Flue Dashboard Your Orders check ", input = InputType.NO)
		public void flu_DB_YourOrders_Check() {
			
			
	WebDriverWait wait = new WebDriverWait(Driver, 600);
			
			
			
			try {
				
				
				
				
				
			}catch (Exception e) {
				Report.updateTestLog(Action, "Your Orders Issue in GSK flu Dashboard  ", Status.FAIL);
			}
			
			
			
			
			
			
			
			
			
			
			
			
			
		
		}
		
		
		
		@Action(object = ObjectType.BROWSER, desc = "Title", input = InputType.NO)
		public void title_get()  {
			
			
			
			userData.putData("PMG_data", "Linkname1",Driver.getTitle());
			
			
		}
		
		
		
		
		@Action(object = ObjectType.BROWSER, desc = "PDF Name validations", input = InputType.YES)
		public void PDF_validation_check() {
			String pdf_name=Data;
			File theNewestFile = null;
			int pageCount=0;
			String[] strs=null;

			String s=null;
			String Loca =null;
			
			
			
			
			
			try {
			//Driver.get(Data);
				Thread.sleep(10000);
			Driver.getCurrentUrl();
			Report.updateTestLog(Action,  Driver.getCurrentUrl() + " PDF url   ", Status.DONE);
			
			
			
			try
            {
                
                WebElement findElement = Driver.findElement(By.xpath("//*[@id='error-information-popup-content']/div[contains(text(),'HTTP ERROR')]"));
                Thread.sleep(1000);
                findElement.isDisplayed();
                
                Report.updateTestLog(Action, "Getting HTTP ERROR  PDF download failed", Status.FAIL);
                
                
            }catch (Exception e) {
                Report.updateTestLog(Action, " PDF download failed or getting error in Opening PDF", Status.DONE);
                
            }
			
			
			
			
			
			Robot robot = new Robot();
			Thread.sleep(1000);
			robot.keyPress(KeyEvent.VK_CONTROL);
			
			Thread.sleep(1000);
			robot.keyPress(KeyEvent.VK_S);
			
			Thread.sleep(1000);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			
			Thread.sleep(1000);
			robot.keyRelease(KeyEvent.VK_S);
			
			Thread.sleep(1000);
			robot.keyPress(KeyEvent.VK_ENTER);
			
			Thread.sleep(1000);
			robot.keyRelease(KeyEvent.VK_ENTER);
			
								 
			String path = userData.getData("PMG_data", "Path");
	        File dir = new File(path);
	          
	        FileFilter fileFilter = new WildcardFileFilter("*.pdf");
	      
	        //Report.updateTestLog(Action, fileFilter.toString() +"   : fileFilter  " , Status.PASS);
	        
	        File[] files = dir.listFiles(fileFilter);
	        
				/*
				 * for(int i=0;i<=files.length-1;i++) { Report.updateTestLog(Action, files[i]
				 * +"  : Files  " , Status.PASS); }
				 */
	       
	      
	        if (files.length > 0 ) {
	            /** The newest file comes first **/
	        	
	        	
	            Arrays.sort(files, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
	            
	            
	            theNewestFile = files[0];
	        
	            //Report.updateTestLog(Action, theNewestFile+ "  theNewestFile  ", Status.DONE);
	            
	        
	         Loca =theNewestFile.toString();
	        
	        Thread.sleep(1000);
					
					
	        
	     s=    Loca.replace("\\", "//");
	    
	    
	    
	    
	     strs = s.split("//");
	    Thread.sleep(15000);
	  
	    
	    if(strs[4].contains(Data))
	    {
	    	
	    	 Report.updateTestLog(Action, strs[4] +" PDF is Dowload sucessfully with Data  " , Status.PASS);
	    	 
	    	    	 
	    	 
	    	 
	    	 Report.updateTestLog(Action, s, Status.DONE);
	    	   
	    	    
			  PDFUtil p = new PDFUtil();
			  pageCount = p.getPageCount(s);
			  Report.updateTestLog(Action,  "  PAGE Count of PDF :  "+pageCount, Status.DONE);
			  Report.updateTestLog(Action,  "   PDF  PAGE Contains Data:  "+pageCount, Status.PASS);
			  
	    	
	    }
	    else
	    {
	    	Report.updateTestLog(Action," Getting Error in PDF Download ", Status.FAIL);
	    	
	    	
	    }
	    
	    
	    
	 
					/*
					 * System.out.println(pageCount);
					 * 
					 * String text = p.getText(s);
					 */
				
				 
	        
	        

	        }
	        
	        else
	        {
	        	
	        	Report.updateTestLog(Action, "  PDF downloaded Failed and Getting Error   ", Status.FAIL);
	        }
			
					
			
			
			
			
			
			
			
			
			
			
			
			}
			
			catch (Exception e) {
				Report.updateTestLog(Action, "PDF_validation_check Failing  ", Status.FAIL);
			}
			
			
			
			
		}
		
		
		@Action(object = ObjectType.BROWSER,desc = "Get Order Number and Navigating To Order History ",input = InputType.NO)
		public void getOrderNum_openOrder() throws ParseException {
			String[] split;
			String orderno ;

			WebDriverWait wait = new WebDriverWait(Driver, 600);
			
			
			
			try {
				
			orderno = Driver.findElement(By.xpath("//p[@class='order-to-title ']")).getText();
			split = orderno.split(" ");
			Thread.sleep(2000);
			orderno=split[split.length-1];
			Thread.sleep(2000);
			Report.updateTestLog(Action, "Order Number is  :  "+ orderno, Status.PASS);
			
			
			
			Driver.findElement(By.xpath("//a[@id='account-active']")).click();
			
			wait.until(ExpectedConditions
					.visibilityOf(Driver.findElement(By.xpath("//a[text()='Order History']"))));
			Report.updateTestLog(Action, " Account Page ", Status.PASS);
			
			
			Driver.findElement(By.xpath("//a[text()='Order History']")).click();
			
			wait.until(ExpectedConditions
					.visibilityOf(Driver.findElement(By.xpath("//input[@id='search_text_order']"))));
			
			Report.updateTestLog(Action, "Navigated to  Order History Page ", Status.PASS);
			
			
			Driver.findElement(By.xpath("//input[@id='search_text_order']")).sendKeys(orderno);
			
			Driver.findElement(By.xpath("//button[@id='searchtextBtn_order']//span[@class='glyphicon glyphicon-search']")).click();
			
			
			
			Report.updateTestLog(Action, " Order History Page  Search completed with Order No", Status.DONE);
			
			wait.until(ExpectedConditions
					.visibilityOf(Driver.findElement(By.xpath("//*[@id='content']//div[6]//div[6]/a[contains(text(),'"+orderno+"')]"))));
			
			Driver.findElement(By.xpath("//*[@id='content']//div[6]//div[6]/a[contains(text(),'"+orderno+"')]")).click();
			
			Report.updateTestLog(Action, " Clicked on Order No " +orderno , Status.DONE);
			
			wait.until(ExpectedConditions
					.visibilityOf(Driver.findElement(By.xpath("//h4//label[@id='order-number']"))));
			
			
			
			String num=Driver.findElement(By.xpath("//h4//label[@id='order-number']")).getText();
			
			
			if(num.equalsIgnoreCase(orderno))
			{
				Report.updateTestLog(Action, " Navigated to Order Details Page ", Status.DONE);
				
			}
			
			
			
			
			
			}catch(Exception e){
				Report.updateTestLog(Action, " Navigated to Order Details Page ", Status.FAIL);
				 
			}
			
		}
		
		@Action(object = ObjectType.BROWSER, desc = "Fluent wait: It will check elements once in 90 seconds till 2hours", input = InputType.YES)
		public void fluent_Wait() {	
		FluentWait wait = new FluentWait(Driver)
		.withTimeout(6000, TimeUnit.SECONDS)
		.pollingEvery(90, TimeUnit.SECONDS)
		.ignoring(Exception.class);
		int count =1;
		//WebElement findElement = Driver.findElement(By.xpath(""));
		wait.until(new com.google.common.base.Function<WebDriver,WebElement>() {
			
			@Override
			public WebElement apply(WebDriver Driver) {
				System.out.println("Enter Block");
				try {
				Driver.switchTo().alert().accept();
				
				}
				catch(Exception e){
					System.out.println("No Alert");
					//count++;	
				}
				
			
				
				if (Driver.getTitle().contains("SAP CX Backoffice | Login")) {
					System.out.println("Check the login title");
				WebElement findElement = Driver.findElement(By.xpath("//button[text()='Login']"));
				findElement.isDisplayed();
				Report.updateTestLog(Action, "Log out automatically please check it manually", Status.FAIL);
				return findElement;
					
	
				}else {
					System.out.println("Entering else loop by skiping if condition");
					WebElement findElement = Driver.findElement(By.xpath(Data));
					findElement.click();
					return findElement;
					
				}
				
				
			}
			
			
			
			
			
		});

		}
		
		@Action(object = ObjectType.BROWSER, desc = "", input = InputType.YES)
		public void split_NewreservationNo() {
			String[] split = Data.split(" ");
			String string = split[split.length-1].toString();
			String[] split2 = string.split(":");
			userData.putData("Flu Reservation", "ReservationNo", split2[split2.length-1].toString());
		}
		
		@Action(object = ObjectType.BROWSER, desc = "Get user id from replace reservation popup and send back to sheet", input = InputType.YES)
		public void getUserFromReplacePopup() {
			List<WebElement> userList = Driver.findElements(By.xpath("//div[text()='ID']/ancestor::table/parent::div/following-sibling::div[2]/table/tbody[1]/tr"));
			if (userList.size()>1) {
				for (int i = 1; i <=userList.size() ; i++) {
					WebElement user = Driver.findElement(By.xpath("//div[text()='ID']/ancestor::table/parent::div/following-sibling::div[2]/table/tbody[1]/tr["+i+"]/td[1]/div/span"));
					if (!user.getText().contains(Data)) {
						user.click();
						userData.putData("Flu Reservation", "User ID", user.getText());
						break;
					}
				}
			} else {
				Report.updateTestLog(Action, "Only one user is available for this reservartion. Give some other user to validate different user", Status.FAIL);
				for (int i = 1; i <=userList.size() ; i++) {
					WebElement user = Driver.findElement(By.xpath("//div[text()='ID']/ancestor::table/parent::div/following-sibling::div[2]/table/tbody[1]/tr["+i+"]/td[1]/div/span"));
					user.click();
						userData.putData("Flu Reservation", "User ID", user.getText());
						break;
				}
			}
			
		}
		
		
		@Action(object = ObjectType.BROWSER, desc = "Shopping cart removal", input = InputType.NO)
		public void clearShoppingCart_remove() {
			WebElement Element = Driver.findElement(By.xpath("//span[@class='yCmsComponent miniCart']/a[2]"));

			String[] qtyarray = Element.getText().split("\\D");

			int num = Integer.parseInt(qtyarray[1]);
			System.out.println(qtyarray[1]);

			if (!Element.getText().equals("(0)")) {
				Driver.findElement(By.xpath("//span[@class='yCmsComponent miniCart']")).click();

				for (int i = 1; i <= num; i++) {
					Driver.findElement(
							By.xpath("(//a[text()='Remove from cart'])[1]"))
							.click();
					WebDriverWait wait = new WebDriverWait(Driver, 600);
					wait.until(ExpectedConditions.visibilityOf(Driver
							.findElement(By.xpath("(//button[text()='Yes, Remove'])[2]"))));
					
					
					try {
					
					Report.updateTestLog(Action, " Clicked on   " +Driver.findElement(By.xpath("(//button[@id='removeProduct-close'])[2]")).getText(), Status.PASS);
					Driver.findElement(By.xpath("(//button[@id='removeProduct-close'])[2]")).click();
	Driver.navigate().refresh();
					
					Thread.sleep(5000);
					}
					catch(Exception e){
						Report.updateTestLog(Action, " Unable to click on No, Don't remove  ", Status.FAIL);
						 
					}
					
					
					Driver.findElement(
							By.xpath("(//a[text()='Remove from cart'])[1]"))
							.click();
					
					
					wait.until(ExpectedConditions.visibilityOf(Driver
							.findElement(By.xpath("(//button[text()='Yes, Remove'])[2]"))));
					String s=Driver.findElement(By.xpath("(//button[text()='Yes, Remove'])[2]")).getText();
					
					Driver.findElement(By.xpath("(//button[text()='Yes, Remove'])[2]"))
					
							.click();
					
					Report.updateTestLog(Action, " Clicked on   " +s, Status.PASS);
					
				}

			} else {
				Report.updateTestLog(Action, "Cart is null ", Status.PASS);
			}

		}
	

		
		@Action(object = ObjectType.BROWSER,desc = "This method Will take all the prices,Quantity,Product details and put data in CocPageDetails datasheet",input = InputType.YES)
	    public void coc_price_Split() throws InterruptedException  {
			
		Thread.sleep(5000); 
	    WebElement listPrice=null;
	    DecimalFormat decimalFormat = new DecimalFormat("#,###.##");
	    
	    Double federalTax = Double.valueOf(userData.getData("Promotion", "Federal excise tax"));
	  //  Double salesTax = Double.valueOf(userData.getData("Promotion", "Estimated sales tax"));
	    //List price
	  //  String	 quantity = userData.getData("Promotion", "QTY_SplitShipment");
	    
	    String  quantity = userData.getData("ComplexCart", "quantity");
	    
	    String[] dynamicQty = quantity.split(",");
	    
	    
	    try {

			String[] dynamicproduct = Data.split(",");

			for (int i = 0; i <= dynamicproduct.length - 1; i++)

			{

			
				Double qty = Double.valueOf(dynamicQty[i]);
			    System.out.println("Entering try catch block");
	    try {
	    	
	    	
	    	
	    	
	    try {
	    	System.out.println("Entered 1st try");
	    	listPrice = Driver.findElement(By.xpath("//div[@class='row orderable-product-row']//div[2]//span[contains(text(),'"+dynamicproduct[i]+"')]/parent::div/parent::div/following-sibling::div[1]/div[1]/div"));
	   	    
	    	coc_product_Split(dynamicproduct[i],i) ;   
	    	
	    } catch (Exception e) {
	    	System.out.println("Entered 1st catch");
	    	
	    	
	    	
	    	
	    	
	listPrice = Driver.findElement(By.xpath("//div[@class='row orderable-product-row otherProduct']//div[2]//span[contains(text(),'"+dynamicproduct[i]+"')]/parent::div/parent::div/following-sibling::div[1]/div[1]/div"));
	    	
	coc_product_Split(dynamicproduct[i],i) ; 
	    	
	    	
	    }
	    } catch (Exception e) {
	    	System.out.println("Entered 2nd try");
	    	listPrice = Driver.findElement(By.xpath("//div[@class='row orderable-product-row favProduct']//div[2]//span[contains(text(),'"+dynamicproduct[i]+"')]/parent::div/parent::div/following-sibling::div[1]/div[1]/div"));
	    	
	    	coc_product_Split(dynamicproduct[i],i) ; 
	    }   
					
					 
	    String text = listPrice.getText();
	    System.out.println(text);
	    
	    String textStr[] = text.split("\\r\\n|\\n|\\r");
	    System.out.println("after split");
	 	String a="";
	   	for (String string : textStr) {
	   		if(string.toString().contains("$") && string.toString().contains("pack")) {
	   		a = string.toString().replace("$", ""); 
	   		
	   		System.out.println(a);
	   		}
	   	}
	   	String valueOf=	null;
	   	String[] splitss = a.split("/");
	   	if(splitss[0].toString().contains(","))
	   			
	   	{
	   		valueOf= splitss[0].toString().replace(",", "");
	   		
	   	} else
	   	{
	   		valueOf= splitss[0].toString();
	   	}
	   	
	   	   	Double valueOfdata = Double.valueOf(valueOf);
	    Report.updateTestLog(Action, "List Price : "+valueOf, Status.PASS);
	    userData.putData("CocPageDetails", "List Price"+i, String.valueOf(valueOfdata));
		
	    userData.putData("CocPageDetails", "qty"+i, dynamicQty[i]);
	    
	    
	    
	    
	    
	    }
		
		
		
			
	    
	    
		
		
	    }catch (Exception e) {
				
	    	Report.updateTestLog(Action,"List Price : ", Status.FAIL);
			}	
			
			
			
	}
		
		 public void coc_product_Split(String S, int l) throws InterruptedException  {
			String textprod=null;	
			String[] productname=null;
		try {
		
			 List<WebElement> product_list = Driver
						.findElements(By.xpath("(//div[@class='row orderable-product-row']//div[2]//span[contains(text(),'"+S+"')]/parent::div/parent::div/div)"));
		
			// Report.updateTestLog(Action,"Size ::::"+product_list.size(), Status.PASS);
			 for(int i=1;i<=product_list.size()-1;i++)
			 {
				 
				 textprod		= Driver
					.findElement(By.xpath("(//div[@class='row orderable-product-row']//div[2]//span[contains(text(),'"+S+"')]/parent::div/parent::div/div)["+i+"]")).getText();

				 
				 if(textprod.toString().contains("/"))
			   			
				   	{
					 productname= textprod.toString().split("/");
					 
					 textprod=productname[0];
				   	} else
				   	{
				   		textprod= textprod.toString();
				   	}
			 
				 
				//Report.updateTestLog(Action,"Text data ::::"+textprod, Status.DONE);
				
				
				if	(textprod.contains("�"))
					
				{
					Report.updateTestLog(Action,"Product Name ::::"+textprod, Status.DONE);
					userData.putData("CocPageDetails", "Product"+l,textprod) ;
					
				}
				else if(textprod.contains(S))
				{
					
					String[] ndc=textprod.split(":");
					
					Report.updateTestLog(Action,"NDC ::::"+ndc[1], Status.DONE);
					userData.putData("CocPageDetails", "NDC"+l,ndc[1]) ;
				}
				
				else
				{
					//Report.updateTestLog(Action,"Prod Disc ::::"+textprod, Status.DONE);
					userData.putData("CocPageDetails", "ProductDisc"+l,textprod) ;
					
				}
				
				
				 
			 }
			 
			 
			 
			 
		
		}catch (Exception e) {
			
	    	Report.updateTestLog(Action,"List Price : ", Status.FAIL);
			}
		
		
		 }
		
		
		
		
		
		
		 @Action(object = ObjectType.BROWSER,desc = "This method Will take all the prices,Quantity,Product details and put data in CocPageDetails datasheet",input = InputType.NO)
		    public void coc_checkoutPage_Validation() throws InterruptedException  {
			 String data=null;
			 
			 
			 List<WebElement> total = Driver
						.findElements(By.xpath("(//*[@id='content']/div[3]/div//div[3]/div[2]/div[1]/div[2])"));
			 
			 for(int l=1;l<=total.size();l++)
			 {
				
				
				 String P1= userData.getData("CocPageDetails", "Product0");
				 
				 String ndc1= userData.getData("CocPageDetails", "NDC0");
				 String lp1= userData.getData("CocPageDetails", "List Price0");
			 
	String P2= userData.getData("CocPageDetails", "Product1");
				 
				 String ndc2= userData.getData("CocPageDetails", "NDC1");
				 String lp2= userData.getData("CocPageDetails", "List Price1");
				 
				// Report.updateTestLog(Action, P1+"::::  : " +ndc1, Status.DONE);
			 List<WebElement> contract = Driver
						.findElements(By.xpath("(//*[@id='content']/div[3]/div//div[3]/div[2]/div[1]/div[2])["+l+"]/parent::div/parent::div/parent::div/div[2]/div"));
			 
			 for(int i=1;i<=contract.size()-1;i++)
			 {
				 data= Driver
					.findElement(By.xpath("((//*[@id='content']/div[3]/div//div[3]/div[2]/div[1]/div[2])["+l+"]/parent::div/parent::div/parent::div/div[2]/div)["+i+"]")).getText();
				
				 
				 
				 if((data.contains(P1) && data.contains(ndc1)) ||(data.contains(P2) && data.contains(ndc2))  )
				 {
					 
					 Report.updateTestLog(Action,"Product and NDC data  equals  : " +data, Status.PASS);
					 
				 }
				
				 
			 }
			 
			 }
			
			 
		 }
		

		WebDriverWait wait = new WebDriverWait(Driver, 600);
		Actions actions = new Actions(Driver);
		String payment = null, ctype = null, paytype = null;

		@Action(object = ObjectType.BROWSER, desc = "PayBy Radio button selection ", input = InputType.NO)
		public void payBy_Selection()

		{

			List<WebElement> invoiceMe_radio = Driver
					.findElements(By.xpath("(//label[text()='Invoice me']/parent::div/input)"));
			//Report.updateTestLog(Action, "List of elements       : " + invoiceMe_radio.size(), Status.DONE);
			try {
				for (int i = 1; i <= invoiceMe_radio.size(); i++) {
					//Report.updateTestLog(Action, "List of elements " + invoiceMe_radio.size(), Status.DONE);
					String ptype = userData.getData("ComplexCart", "PaymentType" + i);

					Report.updateTestLog(Action, "Payment type is   : " + ptype, Status.DONE);
					Thread.sleep(1000);

					String[] split = ptype.split(",");

					payment = split[0];

					if (payment.equalsIgnoreCase("Invoice me")) {

						//Report.updateTestLog(Action, " Entered to Invoice me loop  110 line ", Status.DONE);
						invoiceMe_Selection(i);

					} 
					
					
					if (payment.equalsIgnoreCase("Credit card")) {
					

						//Report.updateTestLog(Action, " Entered to Credit card loop  118 line ", Status.DONE);
						creditCard_Selection(i,ctype,paytype);
						
					//	Report.updateTestLog(Action, " creditCard_Selection(i) completed 120 line ", Status.DONE);

//						new_Payment(ctype);
//						Report.updateTestLog(Action, " Completed  to new_Payment(ctype);  ", Status.DONE);

						

						// Driver.findElement(By.xpath("//button[@id='checkoutButton']")).click();

					}

				}
			} catch (InterruptedException e) {

				e.printStackTrace();
			}

		}

		public void invoiceMe_Selection(int l) {
			int invoicesize = 0;

//			

			try {

				wait.until(ExpectedConditions
						.presenceOfElementLocated(By.xpath("(//label[text()='Invoice me']/parent::div/input)[" + l + "]")));

				WebElement in_me = Driver
						.findElement(By.xpath("(//label[text()='Invoice me']/parent::div/input)[" + l + "]"));

				actions.moveToElement(in_me).perform();

				in_me.click();

				Report.updateTestLog(Action, "Invoice Me Radio button Selected : " + l, Status.PASS);

			}

			catch (Exception e) {
				// TODO: handle exception
				Report.updateTestLog(Action, "Invoice Me Radio button Selecting Issue ", Status.FAIL);
			}

//				}

		}

		public void creditCard_Selection(int m,String type1,String paytype1) {
//
			try {

				Report.updateTestLog(Action, "creditCard_Selection  ::: " +m, Status.DONE);
				wait.until(ExpectedConditions.presenceOfElementLocated(
						By.xpath("(//label[text()='Credit card ']/parent::div/input)[" + m + "]")));

				WebElement in_me = Driver
						.findElement(By.xpath("(//label[text()='Credit card ']/parent::div/input)[" + m + "]"));

				

				actions.moveToElement(in_me).perform();

				in_me.click();

				Report.updateTestLog(Action, "Credit card Radio button Selected : " + m, Status.PASS);
				
				
				WebElement link_newCard = Driver.findElement(By
						.xpath("(//label[text()='Credit card ']/parent::div/label/a[text()='(Use new card)'])[" + m + "]"));

				//actions.moveToElement(link_newCard).perform();
				/*
				 * try {
				 * 
				 * Driver.findElement(By.
				 * xpath("(//select[@class='form-control1 card-section'])[" +m+ "]")).click();
				 * Report.updateTestLog(Action, "Select dropdown click : " , Status.PASS);
				 * 
				 * }catch (Exception e) { // TODO: handle exception Report.updateTestLog(Action,
				 * "Clicking dropdown click Issue ", Status.FAIL); }
				 */

				
				
				
				
				//Report.updateTestLog(Action, "New Credit card Link link_newCard.getLocation() : "+link_newCard.getLocation() , Status.DONE);
				link_newCard.click();
				Report.updateTestLog(Action, "New Credit card Link Selected : " , Status.PASS);
				
				new_Payment(type1);
				Report.updateTestLog(Action, " Completed  to new_Payment   ", Status.PASS);
				
				Thread.sleep(10000);
				creditCard_payNow_Paylater(type1,paytype1 ,m);
				//Report.updateTestLog(Action, " Completed to creditCard_payNow_Paylater(paytype);  213 line ",Status.PASS);

			}

			catch (Exception e) {
				// TODO: handle exception
				Report.updateTestLog(Action, "Credit card Radio button Selecting Issue ", Status.FAIL);
			}

		}

		public void new_Payment(String ctype) {

			wait.until(ExpectedConditions
					.presenceOfElementLocated(By.xpath("//h3[contains(text(),'Payment Information')]")));

			if (ctype.equalsIgnoreCase("Visa")) {

				Driver.findElement(By.xpath("//input[@value='Visa']")).click();

				new_Creditcard_DataFill(ctype);
			} else if (ctype.equalsIgnoreCase("MasterCard")) {

				Driver.findElement(By.xpath("//input[@value='MasterCard']")).click();
				new_Creditcard_DataFill(ctype);

			} else if (ctype.equalsIgnoreCase("AmericanExpress")) {

				Driver.findElement(By.xpath("//input[@value='AmericanExpress']")).click();
				new_Creditcard_DataFill(ctype);

			}

		}

		By name_cad = By.xpath("//input[@name='CreditCard_NameOnCard']");
		By ccard = By.xpath("//input[@name='CreditCard_CardAccountNumber']");
		By adress1 = By.xpath("//input[@id='addressline1']");
		By adress2 = By.xpath("//input[@id='addressline2']");
		By city = By.xpath("//input[@id='city']");
		By state = By.xpath("//select[@id='CreditCard_BillingAddress_StateProvinceCode']");

		By zipcode = By.xpath("//input[@id='zipCodeId']");

		By confirm_btn = By.xpath("//button[@id='paymentSubmit']");

		public void new_Creditcard_DataFill(String ctype) {
			try {
				String name = userData.getData("CreditCard Data", "Name");
				
				String visa_cardnum = userData.getData("CreditCard Data", "Visa");
				
				String Master_cardnum = userData.getData("CreditCard Data", "MasterCard");
				String AmericanExpress_cardnum = userData.getData("CreditCard Data", "AmericanExpress");

				String ccmonth = userData.getData("CreditCard Data", "Exp Month");
				String ccyear = userData.getData("CreditCard Data", "Exp Year");
				String ccAddress1 = userData.getData("CreditCard Data", "Address 1");
				String ccAddress2 = userData.getData("CreditCard Data", "Address 2");

				String ccCity = userData.getData("CreditCard Data", "City");
				String ccState = userData.getData("CreditCard Data", "State");
				String ccPcode = userData.getData("CreditCard Data", "Postal Code");
				
				
				
				
				if (ctype.equalsIgnoreCase("Visa")) {

					Driver.findElement(name_cad).sendKeys("VISA card");
					Report.updateTestLog(Action, " Name on Credit Card :  " + ctype, Status.DONE);

					Driver.findElement(ccard).sendKeys(visa_cardnum);
					Report.updateTestLog(Action, "Credit Card Number   :  " + visa_cardnum, Status.DONE);
					
					
					try {
						
						creditcardnumberLastFourDigit_COC(ctype);
						}
						catch (Exception e) {
							Report.updateTestLog(Action, "  CreditCard Last four num data  Failed ", Status.FAIL);
						}
					
				} else if (ctype.equalsIgnoreCase("MasterCard")) {

					Driver.findElement(name_cad).sendKeys("MasterCard");
					Report.updateTestLog(Action, " Name on Credit Card :  " + ctype, Status.DONE);

					Driver.findElement(ccard).sendKeys(Master_cardnum);
					Report.updateTestLog(Action, "Credit Card Number   :  " + Master_cardnum, Status.DONE);
					
	try {
						
						creditcardnumberLastFourDigit_COC(ctype);
						}
						catch (Exception e) {
							Report.updateTestLog(Action, "  CreditCard Last four num data  Failed ", Status.FAIL);
						}

				} else if (ctype.equalsIgnoreCase("AmericanExpress")) {

					Driver.findElement(name_cad).sendKeys("AmericanExpress");
					Report.updateTestLog(Action, " Name on Credit Card :  " + ctype, Status.DONE);

					Driver.findElement(ccard).sendKeys(AmericanExpress_cardnum);
					Report.updateTestLog(Action, "Credit Card Number   :  " + AmericanExpress_cardnum, Status.DONE);
					
	try {
						
						creditcardnumberLastFourDigit_COC(ctype);
						}
						catch (Exception e) {
							Report.updateTestLog(Action, "  CreditCard Last four num data  Failed ", Status.FAIL);
						}

				}
				
				Driver.findElement(By.xpath("//select[@id='CreditCard_ExpirationMonth']")).click();
				//org.openqa.selenium.support.ui.Select objMonth = new org.openqa.selenium.support.ui.Select(Driver.findElement(By.xpath("//select[@id='CreditCard_ExpirationMonth']")));

			//	objMonth.selectByVisibleText(ccmonth);

				Driver.findElement(By.xpath("//option[text()='Month']/following-sibling::option[contains(text(),'"+ccmonth+"')]")).click();			
				Driver.findElement(By.xpath("//select[@id='CreditCard_ExpirationYear']")).click();
				System.out.println(ccmonth);
				System.out.println(ccyear);
			//	org.openqa.selenium.support.ui.Select objyear = new org.openqa.selenium.support.ui.Select(Driver.findElement(By.xpath("//select[@id='CreditCard_ExpirationYear']")));
				Driver.findElement(By.xpath("//option[text()='Year']/following-sibling::option[contains(text(),'"+ccyear+"')]")).click();
			//	objyear.selectByVisibleText(ccyear);

				Report.updateTestLog(Action,
						" Expiration Month of Card  :  " + ccmonth + " Expiration Year of Card  :  " + ccyear, Status.PASS);

				Driver.findElement(adress1).sendKeys(ccAddress1);
				System.out.println(ccAddress1);
				System.out.println(ccAddress2);
				
				Driver.findElement(adress2).sendKeys(ccAddress2);

				Driver.findElement(city).sendKeys(ccCity);
				Driver.findElement(state).click();

				// org.openqa.selenium.support.ui.Select objstate = new
				// org.openqa.selenium.support.ui.Select(Driver.findElement(state));
//			
				Thread.sleep(2000);
//			objyear.selectByVisibleText(ccState);
//			Thread.sleep(10000);

				Driver.findElement(By.xpath(
						"//select[@id='CreditCard_BillingAddress_StateProvinceCode']//option[text()='" + ccState + "']"))
						.click();

				Driver.findElement(zipcode).sendKeys(ccPcode);

				Report.updateTestLog(Action, "Address of Card  : " + ccAddress1 + " , " + ccAddress2 + " , " + ccCity
						+ " , " + ccState + " , " + ccPcode, Status.PASS);

				wait.until(ExpectedConditions.visibilityOfElementLocated(confirm_btn));

				Driver.findElement(confirm_btn).click();

				Thread.sleep(15000);

				try {
					wait.until(ExpectedConditions
							.presenceOfElementLocated(By.xpath("(//button[@id='message-info-close'][text()='Close'])[2]")));

					Driver.findElement(By.xpath("(//button[@id='message-info-close'][text()='Close'])[2]")).click();
					Thread.sleep(10000);
					
					

				} catch (Exception e) {
					wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[@id='cboxClose']")));

					Driver.findElement(By.xpath("//button[@id='cboxClose']")).click();
					Thread.sleep(10000);

				}

			} catch (Exception e) {
				Report.updateTestLog(Action, "   Fill CreditCard data  ", Status.FAIL);

			}

		}
		
		
		
		
		public void creditcardnumberLastFourDigit_COC(String type1) {
			if (ctype.equalsIgnoreCase("Visa")) {
			String number = userData.getData("CreditCard Data", "Visa");
			String[] split = number.split("");
			String VisaLastFourNumber = split[split.length - 4] + split[(split.length) - 3] + split[(split.length) - 2]
					+ split[(split.length) - 1];
			
			userData.putData("CreditCard Data", "last four number", VisaLastFourNumber);
			}
			
			if (ctype.equalsIgnoreCase("MasterCard")) {

			String number1 = userData.getData("CreditCard Data", "MasterCard");
			String[] split1 = number1.split("");
			String MasterLastFourNumber = split1[split1.length - 4] + split1[(split1.length) - 3]
					+ split1[(split1.length) - 2] + split1[(split1.length) - 1];
			
			
			userData.putData("CreditCard Data", "MasterCardLast4num", MasterLastFourNumber);
			
			}
			
			if (ctype.equalsIgnoreCase("AmericanExpress")) {

			String number2 = userData.getData("CreditCard Data", "AmericanExpress");
			String[] split2 = number2.split("");
			String AmericanLastFourNumber = split2[split2.length - 4] + split2[(split2.length) - 3]
					+ split2[(split2.length) - 2] + split2[(split2.length) - 1];
			
			
			userData.putData("CreditCard Data", "AmericanExpressLast4num", AmericanLastFourNumber);
			
			}
			
			
			
			
		}

		public void creditCard_payNow_Paylater(String type1,String pnow_later, int o) {
			try {

			
				//Driver.switchTo().activeElement();
				//wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//*[@id='promptPaymentCardText'])[2]")));

				WebElement text = Driver.findElement(By.xpath("(//*[@id='promptPaymentCardText'])[2]"));
				//Report.updateTestLog(Action, " Paynow Popup ::: " + text.getText()   +"  -----------"+pnow_later, Status.DONE);
				

				if (pnow_later.contains("PayNow")) {

					Driver.findElement(By.xpath("(//*[@id='cboxLoadedContent']//input[@type='radio'])[1]")).click();

					Report.updateTestLog(Action, "Selected CrediCard Paynow Radio Button  ", Status.PASS);

					Driver.findElement(By.xpath("(//button[@id='promptPaymentPopupSubmit'])[2]")).click();

					Thread.sleep(5000);
					try {

						String pnow_string = Driver.findElement(By.xpath("//p[normalize-space()='Pay Now']")).getText();

						wait.until(
								ExpectedConditions.presenceOfElementLocated(By.xpath("//p[normalize-space()='Pay Now']")));
						if (pnow_string.equalsIgnoreCase("Pay Now")) {

							Report.updateTestLog(Action, " Paynow Text is displayed under Credit card   ", Status.PASS);
							
							Thread.sleep(10000);
						} else {
							Report.updateTestLog(Action, " Paynow Text is Not displayed under Credit card   ", Status.FAIL);
						}

					} catch (Exception e) {
						Report.updateTestLog(Action, " Paynow Text Fetching Failed  ", Status.FAIL);

					}
				}

				

				if (pnow_later.contains("Payatinvoice")) {

					//Driver.findElement(By.xpath("(//*[@id='cboxLoadedContent']//input[@type='radio'])[2]")).click();
					Driver.findElement(By.xpath("(/html/body/div[4]/div[1]/div[2]/div[2]/div[1]/div/div/div[3]/input)")).click();

					
					
					Report.updateTestLog(Action, "Selected CrediCard Pay at invoice due date Radio Button  ", Status.PASS);

					Thread.sleep(5000);

			
					Report.updateTestLog(Action,
							"Continue button :::::; " + Driver
									.findElement(By.xpath("//div[@id='cboxLoadedContent']//button[text()='Continue']")).getText(),
							Status.PASS);
					Driver.findElement(By.xpath("//div[@id='cboxLoadedContent']//button[text()='Continue']")).click();
					
					
				
					try {
						int h=0;
						List<WebElement> payatin=Driver.findElements(By.xpath("(//p[normalize-space()='Pay at invoice due date'])"));
						h=payatin.size();
						if(h==o)
						
						{
						String pnow_string = Driver
								.findElement(By.xpath("(//p[normalize-space()='Pay at invoice due date'])[" + o + "]")).getText();

						wait.until(ExpectedConditions
								.presenceOfElementLocated(By.xpath("(//p[normalize-space()='Pay at invoice due date'])[" + o + "]")));

						if (pnow_string.equalsIgnoreCase("Pay at invoice due date")) {

							Report.updateTestLog(Action, pnow_string + "  is displayed under Credit card   ", Status.PASS);
						} else {
							Report.updateTestLog(Action,
									" Pay at invoice due date Text is Not displayed under Credit card   ", Status.FAIL);
						}
						
						}
						
						if(h<o)
							
						{
						String pnow_string = Driver
								.findElement(By.xpath("(//p[normalize-space()='Pay at invoice due date'])[" + h + "]")).getText();

						wait.until(ExpectedConditions
								.presenceOfElementLocated(By.xpath("(//p[normalize-space()='Pay at invoice due date'])[" + h + "]")));

						if (pnow_string.equalsIgnoreCase("Pay at invoice due date")) {

							Report.updateTestLog(Action, pnow_string + "  is displayed under Credit card   ", Status.PASS);
						} else {
							Report.updateTestLog(Action,
									" Pay at invoice due date Text is Not displayed under Credit card   ", Status.FAIL);
						}
						
						}
						

					} catch (Exception e) {
						Report.updateTestLog(Action, " Pay at invoice due date Text Fetching Failed  ", Status.FAIL);
						//reselect_payatin(type1,o);

					}

				}

				// }

				// }
			} catch (Exception e) {
				Report.updateTestLog(Action, " CreditCard Paynow later radio button selection failed   ", Status.FAIL);

			}

		}

		By txt_path = By.xpath(
				"//div[contains(@id,'creditCart_div_st')]//p[@class='paymentDateOption cart-accInfo-shipTo flu-title-margin-class']");

		
		
		
		
		public void reselect_payatin(String type1,int o)
		
		{
			Report.updateTestLog(Action, " CreditCard Paynow reselect_payatin   " +o, Status.PASS);
			
			try {
				try {
			org.openqa.selenium.support.ui.Select objSelect = new org.openqa.selenium.support.ui.Select(
					Driver.findElement(By.xpath("(//select[@class='form-control1 card-section'])[" +o+ "]")));
			
			objSelect.selectByVisibleText("Select card");
			Thread.sleep(2000);
				
			Report.updateTestLog(Action, " Select card   " +o, Status.PASS);
				}
				catch (Exception e) {
					
					org.openqa.selenium.support.ui.Select objSelect = new org.openqa.selenium.support.ui.Select(
							Driver.findElement(By.xpath("(//select[@class='form-control card-section'])")));
					
					objSelect.selectByVisibleText("Select card");
					Thread.sleep(2000);
					Report.updateTestLog(Action, " Catch block Select card   " +o, Status.PASS);

				}
				try {
			WebElement in_me1 = Driver
					.findElement(By.xpath("(//label[text()='Invoice me']/parent::div/input)[" + o + "]"));

			actions.moveToElement(in_me1).perform();

			in_me1.click();
			
			Thread.sleep(2000);
			
				}catch (Exception e) {
					Report.updateTestLog(Action, " Invoice me card failed   ", Status.FAIL);

				}
				try {
			WebElement in_me = Driver
					.findElement(By.xpath("(//label[text()='Credit card ']/parent::div/input)[" + o + "]"));

			

			actions.moveToElement(in_me).perform();

			in_me.click();
			
			Thread.sleep(2000);
		
				}catch (Exception e) {
					Report.updateTestLog(Action, " Select card credit card failed   ", Status.FAIL);

				}
				try {
				
				org.openqa.selenium.support.ui.Select objSelect = new org.openqa.selenium.support.ui.Select(
						Driver.findElement(By.xpath("(//select[@class='form-control1 card-section'])[" +o+ "]")));
				
				
			//String name1 = userData.getData("CreditCard Data", "Name");	
			String lst_four = userData.getData("CreditCard Data", "last four number");
			String master_lst_four=userData.getData("CreditCard Data", "MasterCardLast4num");
			String American_lst_four=userData.getData("CreditCard Data", "AmericanExpressLast4num");
			
			
			Report.updateTestLog(Action, type1+  " ::::::::::::::::::::::::   "   +lst_four, Status.DONE);
			
			
			Thread.sleep(2000);
			
			if (type1.equalsIgnoreCase("Visa")) {
				
				
				objSelect.selectByVisibleText("Visa ************" +lst_four);
				Thread.sleep(5000);
				
				
				Report.updateTestLog(Action, type1+  " :::::::::::::::::::::::: Visa ************  "   +lst_four, Status.PASS);
				Driver.findElement(By.xpath("(/html/body/div[4]/div[1]/div[2]/div[2]/div[1]/div/div/div[3]/input)")).click();
				
				Thread.sleep(2000);
				
				
				Driver.findElement(By.xpath("//div[@id='cboxLoadedContent']//button[text()='Continue']")).click();
				
				
			} else if (type1.equalsIgnoreCase("MasterCard")) {
				
				
				objSelect.selectByVisibleText("MasterCard ********" + master_lst_four);
				
				
	Thread.sleep(5000);
				
				
				Report.updateTestLog(Action, type1+  " ::::::::::::::Inisde::::::::: MasterCard ************  "   +master_lst_four, Status.PASS);
				Driver.findElement(By.xpath("(/html/body/div[4]/div[1]/div[2]/div[2]/div[1]/div/div/div[3]/input)")).click();
				
				Thread.sleep(2000);
				
				
				Driver.findElement(By.xpath("//div[@id='cboxLoadedContent']//button[text()='Continue']")).click();
				
			} else if (type1.equalsIgnoreCase("AmericanExpress")) {
				
				objSelect.selectByVisibleText("American Express ********" + American_lst_four);
				
				
				
	Thread.sleep(5000);
				
				
				Report.updateTestLog(Action, type1+  " :::::::::::::::::::::::: American Express ************  "   +American_lst_four, Status.PASS);
				Driver.findElement(By.xpath("(/html/body/div[4]/div[1]/div[2]/div[2]/div[1]/div/div/div[3]/input)")).click();
				
				Thread.sleep(2000);
				
				
				Driver.findElement(By.xpath("//div[@id='cboxLoadedContent']//button[text()='Continue']")).click();
				
			} else {
				System.out.println("No card");
			}
			

			Thread.sleep(6000);
			
			}
			 catch (Exception e) {
				 drpdown_catch(type1);
					//Report.updateTestLog(Action, " FAILING at selting dropdown ", Status.FAIL);
					
					
				
				}
			try {

				String pnow_string = Driver
						.findElement(By.xpath("//p[normalize-space()='Pay at invoice due date']")).getText();

				wait.until(ExpectedConditions
						.presenceOfElementLocated(By.xpath("//p[normalize-space()='Pay at invoice due date']")));

				if (pnow_string.equalsIgnoreCase("Pay at invoice due date")) {

					Report.updateTestLog(Action, pnow_string + "  is displayed under Credit card   ", Status.PASS);
				} else {
					Report.updateTestLog(Action,
							" Pay at invoice due date Text is Not displayed under Credit card   ", Status.FAIL);
				}

			} catch (Exception e) {
				Report.updateTestLog(Action, " Pay at invoice due date Text Fetching Failed  ", Status.FAIL);
			
			}
			
			}catch (Exception e) {
				Report.updateTestLog(Action, " CreditCard Paynow later radio button  failed in reselect_payatin  ", Status.FAIL);
				
			}
			
			
			
		}
		
		
		
		
		public void drpdown_catch(String type1)
		{
			
			
	try {
				
				org.openqa.selenium.support.ui.Select objSelect = new org.openqa.selenium.support.ui.Select(
						Driver.findElement(By.xpath("(//select[@class='form-control card-section'])")));
				
				
			//String name1 = userData.getData("CreditCard Data", "Name");	
			String lst_four = userData.getData("CreditCard Data", "last four number");
			String master_lst_four=userData.getData("CreditCard Data", "MasterCardLast4num");
			String American_lst_four=userData.getData("CreditCard Data", "AmericanExpressLast4num");
			
			Report.updateTestLog(Action, type1+  " ::::::::::::::::::::::::   "   +lst_four, Status.DONE);
			
			
			Thread.sleep(2000);
			
			if (type1.equalsIgnoreCase("Visa")) {
				
				
				objSelect.selectByVisibleText("Visa ************" +lst_four);
				Thread.sleep(5000);
				
				
				Report.updateTestLog(Action, type1+  " :::::::::::::::::::::::: Visa ************  "   +lst_four, Status.PASS);
				Driver.findElement(By.xpath("(/html/body/div[4]/div[1]/div[2]/div[2]/div[1]/div/div/div[3]/input)")).click();
				
				Thread.sleep(2000);
				
				
				Driver.findElement(By.xpath("//div[@id='cboxLoadedContent']//button[text()='Continue']")).click();
				
				
			} else if (type1.equalsIgnoreCase("Master")) {
				
				objSelect.selectByVisibleText("MasterCard ************" + master_lst_four);
				
				
	Thread.sleep(5000);
				
				
				Report.updateTestLog(Action, type1+  " :::::::::::::::::::::::: MasterCard ************  "   +master_lst_four, Status.PASS);
				Driver.findElement(By.xpath("(/html/body/div[4]/div[1]/div[2]/div[2]/div[1]/div/div/div[3]/input)")).click();
				
				Thread.sleep(2000);
				
				
				Driver.findElement(By.xpath("//div[@id='cboxLoadedContent']//button[text()='Continue']")).click();
				
			} else if (type1.equalsIgnoreCase("American")) {
				
				objSelect.selectByVisibleText("American Express ************" + American_lst_four);
				
				
				
	Thread.sleep(5000);
				
				
				Report.updateTestLog(Action, type1+  " :::::::::::::::::::::::: American Express ************  "   +American_lst_four, Status.PASS);
				Driver.findElement(By.xpath("(/html/body/div[4]/div[1]/div[2]/div[2]/div[1]/div/div/div[3]/input)")).click();
				
				Thread.sleep(2000);
				
				
				Driver.findElement(By.xpath("//div[@id='cboxLoadedContent']//button[text()='Continue']")).click();
				
			} else {
				System.out.println("No card");
			}
			

			Thread.sleep(6000);
			
			}
			 catch (Exception e) {
					Report.updateTestLog(Action, " FAILING at selting dropdown from Catch block ", Status.FAIL);
				
				}
		}
		
		
		
		
		
		

		
			
		@Action(object = ObjectType.BROWSER, desc = "Multiple Product selection ", input = InputType.YES)
		public void clickDynamicXpath_multipul() throws InterruptedException

		{
			Thread.sleep(5000); 
		    WebElement listPrice=null;
		 //   DecimalFormat decimalFormat = new DecimalFormat("#,###.##");
		    
		  //  Double federalTax = Double.valueOf(userData.getData("Promotion", "Federal excise tax"));

			String quantity = "";
			Driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			WebElement addQty = null;
			int count=0;

			try {
				try {
					quantity = userData.getData("ComplexCart", "quantity");
					System.out.println("CC Sheet->" + quantity);
				} catch (Exception e) {
					quantity = userData.getData("Flu Reservation", "Qty");
				}
			} catch (Exception e) {

				quantity = userData.getData("Promotion", "QTY_SplitShipment");
			}

			String[] dynamicQty = quantity.split(",");
			// Report.updateTestLog(Action, " Product QTY "+dynamicQty.length, Status.DONE);

			try {

				String[] dynamicproduct = Data.split(",");

				for (int i = 0; i <= dynamicproduct.length - 1; i++)

				{
					
					// Report.updateTestLog(Action, " Product num "+dynamicQty[i], Status.DONE);
					// Report.updateTestLog(Action, " Product num "+dynamicproduct[i], Status.DONE);
					Thread.sleep(15000);

					Driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					WebElement addToCart = null;

	try {
					try {
		
								
								
								
								  
								addQty = Driver.findElement(
										By.xpath("//div[@class='row orderable-product-row']//div[2]//span[contains(text(),'"
												+ dynamicproduct[i]
												+ "')]/parent::div/parent::div/following-sibling::div[4]/div/input"));
								
		
								addQty.click();
								addQty.clear();
								addQty.sendKeys(dynamicQty[i]);
		
								Thread.sleep(1000);
		
								addToCart = Driver.findElement(
										By.xpath("//div[@class='row orderable-product-row']//div[2]//span[contains(text(),'"
												+ dynamicproduct[i]
												+ "')]/parent::div/parent::div/following-sibling::div[5]/a"));
								((JavascriptExecutor) Driver).executeScript("arguments[0].scrollIntoView(true);", addToCart);
								
								
								
								
								addToCart.click();
								Thread.sleep(1000);
								flu_Availabledoses();
								Thread.sleep(2000);
								Report.updateTestLog(Action,
										" Product NDC :   " + dynamicproduct[i] + " ,  Product Qty :  " + dynamicQty[i],
										Status.PASS);
								
								
										try{
			
			
									
									String s=Driver.findElement(By.
											  xpath("//div[@class='row orderable-product-row']//div[2]//span[contains(text(),'"
											  +dynamicproduct[i]+"')]/parent::div/parent::div/div[5]")).getText();
									
									  
									 
									if(s.contains("FLU"))
									{
										
										  
										 
										if(count==0)
										{
											Report.updateTestLog(Action,
												" INSIDE count 1   :  "+ count ,Status.DONE);
										
										userData.putData("ComplexCartMultipleProd", "fluqty1",dynamicQty[i]);
										userData.putData("ComplexCartMultipleProd", "FluNDC1",dynamicproduct[i]);
										Thread.sleep(2000);
										count=count+1;
										Thread.sleep(1000);
											
											  Report.updateTestLog(Action, " after adding Count   :   " +count,
											  Status.DONE);
											 
										}else
										
										
											if(count==1)
											{
											
											  Report.updateTestLog(Action, " INSIDE count 2  :   " ,Status.DONE);
											 
											userData.putData("ComplexCartMultipleProd", "fluqty2",dynamicQty[i]);
											userData.putData("ComplexCartMultipleProd", "FluNDC2",dynamicproduct[i]);
											Thread.sleep(2000);
											//count=count+1;
											//Thread.sleep(1000);
											//Report.updateTestLog(Action," after adding Count   :   " +count,Status.PASS);
											}
										
										
										
									}
									
								} catch (Exception e) {
									System.out.println("No flu ");
									
								}	
							/*
							 * listPrice = Driver.findElement(By.
							 * xpath("//div[@class='row orderable-product-row']//div[2]//span[contains(text(),'"
							 * +dynamicproduct[i]+
							 * "')]/parent::div/parent::div/following-sibling::div[1]/div[1]/div"));
							 * listPrice.click(); System.out.println(listPrice.isDisplayed());
							 */
										
										
								
		
							} catch (Exception e) {
							
							listPrice = Driver.findElement(By.xpath("//div[@class='row orderable-product-row otherProduct']//div[2]//span[contains(text(),'"+dynamicproduct[i]+"')]/parent::div/parent::div/following-sibling::div[1]/div[1]/div"));
					    	

							addQty = Driver.findElement(By.xpath(
									"//div[@class='row orderable-product-row otherProduct']//div[2]//span[contains(text(),'"
											+ dynamicproduct[i]
											+ "')]/parent::div/parent::div/following-sibling::div[4]/div/input"));
							
							addQty.click();
							addQty.clear();
							addQty.sendKeys(dynamicQty[i]);

							Thread.sleep(2000);
							
							

							addToCart = Driver.findElement(By.xpath(
									"//div[@class='row orderable-product-row otherProduct']//div[2]//span[contains(text(),'"
											+ dynamicproduct[i]
											+ "')]/parent::div/parent::div/following-sibling::div[5]/a"));
							((JavascriptExecutor) Driver).executeScript("arguments[0].scrollIntoView(true);", addToCart);
							addToCart.click();
							Thread.sleep(1000);
							flu_Availabledoses();

							Report.updateTestLog(Action,
									" Product NDC :   " + dynamicproduct[i] + " ,  Product Qty :  " + dynamicQty[i],
									Status.PASS);
							
							
							
								try{
								
								String s=Driver.findElement(By.
										  xpath("//div[@class='row orderable-product-row otherProduct']//div[2]//span[contains(text(),'"
										  +dynamicproduct[i]+"')]/parent::div/parent::div/div[5]")).getText();
								
								  
								 
								if(s.contains("FLU"))
								{
									
									  
									 
									if(count==0)
									{
										Report.updateTestLog(Action,
											" INSIDE count 1   :  "+ count ,Status.DONE);
									
									userData.putData("ComplexCartMultipleProd", "fluqty1",dynamicQty[i]);
									userData.putData("ComplexCartMultipleProd", "FluNDC1",dynamicproduct[i]);
									Thread.sleep(2000);
									count=count+1;
									Thread.sleep(1000);
										
										  Report.updateTestLog(Action, " after adding Count   :   " +count,
										  Status.DONE);
										 
									}else
									
									
										if(count==1)
										{
										
										  Report.updateTestLog(Action, " INSIDE count 2  :   " ,Status.DONE);
										 
										userData.putData("ComplexCartMultipleProd", "fluqty2",dynamicQty[i]);
										userData.putData("ComplexCartMultipleProd", "FluNDC2",dynamicproduct[i]);
										Thread.sleep(2000);
										//count=count+1;
										//Thread.sleep(1000);
										//Report.updateTestLog(Action," after adding Count   :   " +count,Status.PASS);
										}
									
									
									
								}
								
							} catch (Exception e1) {
								System.out.println("No flu ");
								
							}			
							
							
							
							
						}
					} catch (Exception e) {
						
						
						
						
						listPrice = Driver.findElement(By.xpath("//div[@class='row orderable-product-row favProduct']//div[2]//span[contains(text(),'"+dynamicproduct[i]+"')]/parent::div/parent::div/following-sibling::div[1]/div[1]/div"));
				    	
						addQty = Driver.findElement(By.xpath(
								"//div[@class='row orderable-product-row favProduct']//div[2]//span[contains(text(),'"
										+ dynamicproduct[i]
										+ "')]/parent::div/parent::div/following-sibling::div[4]/div/input"));
						
						
						addQty.click();
						addQty.clear();
						addQty.sendKeys(dynamicQty[i]);

						Thread.sleep(2000);

						addToCart = Driver.findElement(By.xpath(
								"//div[@class='row orderable-product-row favProduct']//div[2]//span[contains(text(),'"
										+ dynamicproduct[i] + "')]/parent::div/parent::div/following-sibling::div[5]/a"));
						((JavascriptExecutor) Driver).executeScript("arguments[0].scrollIntoView(true);", addToCart);
						addToCart.click();
						Thread.sleep(2000);
						flu_Availabledoses();
						Thread.sleep(2000);
						Report.updateTestLog(Action,
								" Product NDC :   " + dynamicproduct[i] + " ,  Product Qty :  " + dynamicQty[i],
								Status.PASS);
						
						
						
						
						try{
							
							String s=Driver.findElement(By.
									  xpath("//div[@class='row orderable-product-row favProduct']//div[2]//span[contains(text(),'"
									  +dynamicproduct[i]+"')]/parent::div/parent::div/div[5]")).getText();
							
							  
							 
							if(s.contains("FLU"))
							{
								
								  
								 
								if(count==0)
								{
									Report.updateTestLog(Action,
										" INSIDE count 1   :  "+ count ,Status.DONE);
								
								userData.putData("ComplexCartMultipleProd", "fluqty1",dynamicQty[i]);
								userData.putData("ComplexCartMultipleProd", "FluNDC1",dynamicproduct[i]);
								Thread.sleep(2000);
								count=count+1;
								Thread.sleep(1000);
									
									  Report.updateTestLog(Action, " after adding Count   :   " +count,
									  Status.DONE);
									 
								}else
								
								
									if(count==1)
									{
									
									  Report.updateTestLog(Action, " INSIDE count 2  :   " ,Status.DONE);
									 
									userData.putData("ComplexCartMultipleProd", "fluqty2",dynamicQty[i]);
									userData.putData("ComplexCartMultipleProd", "FluNDC2",dynamicproduct[i]);
									Thread.sleep(2000);
									//count=count+1;
									//Thread.sleep(1000);
									//Report.updateTestLog(Action," after adding Count   :   " +count,Status.PASS);
									}
								
								
								
							}
							
						} catch (Exception e1) {
							System.out.println("No flu ");
							
						}			
						
						
						
						
						
						
						
					}
					
					
					
					
					/*
					 * String text1 = listPrice.getText(); System.out.println(text1); String[] split
					 * = text1.split("/"); Double valueOf1 = null; for (String string2 : split) { if
					 * (string2.contains("$")) { //contract price
					 * System.out.println(string2.toString().replace("$", "")); valueOf1 =
					 * Double.valueOf(string2.toString().replace("$", "")); } }
					 * Report.updateTestLog(Action, i+ "List Price : "+valueOf1, Status.PASS);
					 * //List price Report.updateTestLog(Action, i+"List Price : "+valueOf1,
					 * Status.PASS); userData.putData("Promotion", "List Price"+i,
					 * String.valueOf(valueOf1));
					 */

			
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
				}

				
				
				
				
				
				
				
				
				
				
				
			} catch (InterruptedException e) {
				Report.updateTestLog(Action, " Multiple Product Selection selection failed   ", Status.FAIL);

			}

		}
		


		

		@Action(object = ObjectType.BROWSER, desc = "Payment type: info check in Shipping Information ", input = InputType.NO)
		public void Payment_type_shippingInfo()

		{
			String Payment_type_SInfo = null;
			String Shipping_Title = null;
			String PayBy = null;
			// List<WebElement> ptype_shippingInfo =
			// Driver.findElements(By.xpath("//span[normalize-space()='Payment
			// type:']/parent::div/div/p"));
			// Report.updateTestLog(Action, "List of elements : "+
			// ptype_shippingInfo.size(), Status.DONE);

			List<WebElement> Shipping_Titlelist = Driver
					.findElements(By.xpath("//*[@id='content']//h2[@class='cartpage-title']"));

			for (int i = 1; i <= Shipping_Titlelist.size(); i++) {

				List<WebElement> ptype_shippingInfo = Driver
						.findElements(By.xpath("(//*[@id='content']//h2[@class='cartpage-title'])[" + i
								+ "]/parent::div/parent::div/parent::div//span[normalize-space()='Payment type:']/parent::div/div"));

				Shipping_Title = Driver
						.findElement(By.xpath("(//*[@id='content']//h2[@class='cartpage-title'])[" + i + "]")).getText();

				for (int j = 1; j <= ptype_shippingInfo.size(); j++) {
					try {
						Thread.sleep(2000);
						Payment_type_SInfo = Driver
								.findElement(By.xpath("((//*[@id='content']//h2[@class='cartpage-title'])[" + i
										+ "]/parent::div/parent::div/parent::div//span[normalize-space()='Payment type:']/parent::div/div)["
										+ j + "]"))
								.getText();
						// Report.updateTestLog(Action, " Paymnt info in 649 "+i+" ::
						// "+Payment_type_SInfo, Status.DONE);

						if (Payment_type_SInfo.contains("Pay at invoice due date") || Payment_type_SInfo.contains("Pay Now")
								|| Payment_type_SInfo.contains("Invoice Me")) {

							Report.updateTestLog(Action,
									Shipping_Title + "   Shipping Account having   ::  " + Payment_type_SInfo, Status.PASS);
						}

					} catch (Exception e) {
						Report.updateTestLog(Action, "Payment type: Information Issue  ", Status.FAIL);

					}

				}

				try {
					List<WebElement> payBy_orderPage = Driver
							.findElements(By.xpath("(//*[@id='content']//h2[@class='cartpage-title'])[" + i
									+ "]/parent::div/parent::div/parent::div//div[@class='row cart-account-row col-md-12 accountINFO gsk-box-productSection']/div[3]/div"));

					for (int k = 1; k <= payBy_orderPage.size(); k++) {

						PayBy = Driver.findElement(By.xpath("((//*[@id='content']//h2[@class='cartpage-title'])[" + i
								+ "]/parent::div/parent::div/parent::div//div[@class='row cart-account-row col-md-12 accountINFO gsk-box-productSection']/div[3]/div)["
								+ k + "]")).getText();

						Report.updateTestLog(Action,
								Shipping_Title + "   Shipping Account having   -:: PayBY option   ::-  " + PayBy,
								Status.PASS);
					}
				} catch (Exception e) {
					Report.updateTestLog(Action, " PayBy Option not avilable   ", Status.DONE);
				}

			}

		}
		
		
		
		/* ******************************************************************** OrderTitle and Ful Reservaion ******************************************/
		
		
		@Action(object = ObjectType.BROWSER, desc = "Order Confirmation Page  Detailes ", input = InputType.NO)
			
		public void  OrderConfirmation_Page() {
			
			try {
			List<WebElement> orders_list = Driver
					.findElements(By.xpath("(//div/p[contains(@class,'order-to-title')])"));
			
			for (int k = 1; k <= orders_list.size(); k++) {
				
				
				String olist=Driver.findElement(By.xpath("(//div/p[contains(@class,'order-to-title')])[" +k+ "]")).getText();
				
				String[] orderli=olist.split(" ");
				
				Report.updateTestLog(Action, "Order Number avilable  :::   "  +orderli[1], Status.PASS);
				
				userData.putData("ComplexCartMultipleProd", "Order"+k,orderli[1]);
				
				
				
				
			}
			
			
			
				
			} catch (Exception e) {
				
				Report.updateTestLog(Action, " Unable to get Order Details avilable   ", Status.FAIL);
			}
			
			
			
			
			try {
				List<WebElement> flu_orders_list = Driver
						.findElements(By.xpath("(//div/h2[contains(@class,'order-to-title')])"));
				
				for (int k = 1; k <= flu_orders_list.size(); k++) {
				
				String fluboard=	Driver.findElement(By.xpath("(//div/h2[contains(@class,'order-to-title')])["+k+"]")).getText();
				
	String[] fludash=fluboard.split(" ");
				
				Report.updateTestLog(Action, "Flu Reservation  Number :::   "  +fludash[2], Status.DONE);
				
				userData.putData("ComplexCartMultipleProd", "FluOrder"+k,fludash[2]);
				
				}
				
				
			}catch (Exception e) {
				Report.updateTestLog(Action, " No Flu dashboard details   ", Status.DONE);
			}
			
			
		}
		
		/* ******************************************* Order History ************************************************** */
		
		
		@Action(object = ObjectType.BROWSER, desc = "Order History  click on order number ", input = InputType.NO)
		public void OrderHistory_On_check() throws InterruptedException {
			String o1,o2,o3,fluorder1,fluorder2=null;
			int count=1;
			int flucount=1;
			o1= userData.getData("ComplexCartMultipleProd", "Order1");
			o2=userData.getData("ComplexCartMultipleProd", "Order2");
			o3=userData.getData("ComplexCartMultipleProd", "Order3");
			fluorder1=userData.getData("ComplexCartMultipleProd", "FluOrder1");
			fluorder2=userData.getData("ComplexCartMultipleProd", "FluOrder2");
			
			
			
			List<WebElement>  order_list=Driver.findElements(By.xpath("//*[@id='content']/div[3]/div/div[6]/div/div[6]"));
			for(int l=1;l<=order_list.size()-1;l++)
			{
				
				String ss=Driver.findElement(By.xpath("(//*[@id='content']/div[3]/div/div[6]/div/div[6]/a)["+l+"]")).getText();
				
				if(ss.equalsIgnoreCase(o1) &&(count==1) )
				
				{
					
					//Driver.findElement(By.xpath("(//*[@id='content']/div[3]/div/div[6]/div/div[6]/a)["+l+"]")).click();
					
					
				Driver.findElement(By.xpath("//*[@id='content']/div[3]/div/div[6]/div/div[6]/a[normalize-space()='"+ss+"']")).click();
					wait.until(ExpectedConditions
							.presenceOfElementLocated(By.xpath("//p[normalize-space()='Account Information']")));
					
					Report.updateTestLog(Action, " Order Details " +ss, Status.PASS);
					
					wait.until(ExpectedConditions
							.presenceOfElementLocated(By.xpath("//button[contains(text(),'Back to List of Orders')]")));
					
					Driver.findElement(By.xpath("//button[contains(text(),'Back to List of Orders')]")).click();
					
				count++;	
					
				}
				else if( (ss.equalsIgnoreCase(o2))&&(count==2) )
				{
					Driver.findElement(By.xpath("//*[@id='content']/div[3]/div/div[6]/div/div[6]/a[normalize-space()='"+ss+"']")).click();
					wait.until(ExpectedConditions
							.presenceOfElementLocated(By.xpath("//p[normalize-space()='Account Information']")));
					
					Report.updateTestLog(Action, " Order Details " +ss, Status.PASS);
					
					wait.until(ExpectedConditions
							.presenceOfElementLocated(By.xpath("//button[contains(text(),'Back to List of Orders')]")));
					
					Driver.findElement(By.xpath("//button[contains(text(),'Back to List of Orders')]")).click();
					
				count++;
				}
				
							
							
						} 
						
			try {
			wait.until(ExpectedConditions
					.presenceOfElementLocated(By.xpath("//a[normalize-space()='Reservations']")));	
			
			Driver.findElement(By.xpath("//a[normalize-space()='Reservations']")).click();
			
			wait.until(ExpectedConditions
					.presenceOfElementLocated(By.xpath("//h3[normalize-space()='Reservations']")));	
			
			
			
			Report.updateTestLog(Action, " Reservations Page Details " , Status.PASS);
			
			List<WebElement>  fluorder_list=Driver.findElements(By.xpath("//*[@id='dtReservation']/tbody/tr/td[1]/div/a/b/u"));
			
			for(int l=1;l<=fluorder_list.size();l++)
			{
				String ss=Driver.findElement(By.xpath("(//*[@id='dtReservation']/tbody/tr/td[1]/div/a/b/u)["+l+"]")).getText();
			
			if((ss.equalsIgnoreCase(fluorder1)) && (flucount==1))
				
			{
				
				Driver.findElement(By.xpath("//*[@id='dtReservation']/tbody/tr/td[1]/div/a/b/u[normalize-space()='"+ss+"']")).click();	
				wait.until(ExpectedConditions
						.presenceOfElementLocated(By.xpath("//p[normalize-space()='Account Information']")));
				
				Report.updateTestLog(Action, " FLU Order Details "+ss, Status.PASS);
				
				
				Thread.sleep(2000);
				flucount=flucount+1;
				Thread.sleep(2000);
				
				wait.until(ExpectedConditions
						.presenceOfElementLocated(By.xpath("//button[contains(text(),'Back to List of Reservations')]")));
				
				Driver.findElement(By.xpath("//button[contains(text(),'Back to List of Reservations')]")).click();
				
				Report.updateTestLog(Action, "  flucount Details "+flucount, Status.PASS);
				
				Thread.sleep(4000);
				//continue;
			}
			
			else
				if((ss.equalsIgnoreCase(fluorder2)) && (flucount==2))
					
				{
					
					Driver.findElement(By.xpath("//*[@id='dtReservation']/tbody/tr/td[1]/div/a/b/u[normalize-space()='"+ss+"']")).click();	
					wait.until(ExpectedConditions
							.presenceOfElementLocated(By.xpath("//p[normalize-space()='Account Information']")));
					
					Report.updateTestLog(Action, " FLU Order Details "+ss, Status.PASS);
					
					
					wait.until(ExpectedConditions
							.presenceOfElementLocated(By.xpath("//button[contains(text(),'Back to List of Reservations')]")));
					
					Driver.findElement(By.xpath("//button[contains(text(),'Back to List of Reservations')]")).click();
					
					
				//	flucount++;
					
					
				}
			
			
			}
			
			}
			catch (Exception e) {
				Report.updateTestLog(Action, " No Flu dashboard details   ", Status.DONE);
			}
			
			
		}
		
		
		
		
		
	/* *********************************************************************** Contract Checking code ********************************************* */
		
		@Action(object = ObjectType.BROWSER, desc = "Contract price details selecting ", input = InputType.YES)
		public void contractprice_check() throws InterruptedException {
			List<WebElement> findElements = Driver.findElements(By.xpath("//table/tbody/tr")); 
			List<String> e1 = new ArrayList<String>();
			int i=1; 
			for (WebElement webElement:findElements){
			String b = "";
				System.out.println(Driver.findElement(By.xpath("//tbody/tr[" + i + "]/td[6]")).getText());
				if (Driver.findElement(By.xpath("//tbody/tr[" + i + "]/td[6]")).getText().contains("Active")) { 
																												 
					String text =
					Driver.findElement(By.xpath("(//tbody//tr[" + i + "]//td[contains(text(),'')])[3]")).getText();
					String[] split = text.split(" ");
					String a = split[3].toString();
					String[] split2 = a.split("");
					
					for (int j = 0; j < 10; j++) {
						b = b + split2[j].toString();
					}
					System.out.println(b);
					e1.add(b);
				}
				i = i + 1;

			}
			Driver.findElement(By.id("order-active")).click(); 
			  Thread.sleep(10000);
			//for (String string : e1) 
			  for(int k=0;k<e1.size();k++)
			
			{
				  String string=e1.get(k);
				  
				System.out.println(string);

			  Thread.sleep(10000);
			 Driver.findElement(By.id("shiptosearch")).sendKeys(string);
			 
			// ((JavascriptExecutor) Driver).executeScript("arguments[0].scrollIntoView(true);",  Driver.findElement(By.xpath("//span[contains(text(),'1100551403')]")));
			 Driver.findElement(By.xpath("//span[contains(text(),'"+string+"')]")).click();
			 Driver.findElement(By.id("orderForThisAddressBtn")).click();
			 
			 Thread.sleep(10000);
			 if(Driver.findElement(By.xpath("//div[@id='account-information-div']/div[3]/div/div[1]/div[6]")).getText().contains("Not valid") || Driver.findElement(By.xpath("//div[@id='account-information-div']/div[3]/div/div[1]/div[6]")).getText().contains("Due to expire on") || Driver.findElement(By.xpath("//div[@id='account-information-div']/div[3]/div/div[2]/div[6]")).getText().contains("Class of trade:FEDERAL")) {
				 
				 Driver.findElement(By.id("changeShipToLink")).click();
				 System.out.println("state licence not valid");
			 }
			 
			 else {
				 
				

					
				 try {
					 Thread.sleep(2000);
						List<WebElement> cp_text = Driver.findElements(By.xpath("//div[@id='orderableProductList1']//form[contains(@id,'addToCartForm')]//div[@class='contract-price-display pre-name']//div[1]//div")); 
					
						
						

						if(cp_text.size()==0)
						{
							Report.updateTestLog(Action, " Contract price: details Available  is Zero ", Status.FAIL);
							Driver.findElement(By.id("changeShipToLink")).click();
						}
						else if(cp_text.size()>=1) {
							 String[] dynamicproduct = Data.split(",");
								
							 
							for (int l = 0; l <= dynamicproduct.length - 1; l++)
							{
							
							Report.updateTestLog(Action, " Contract price: details Available   "+cp_text.size() , Status.PASS);
							
							try {
							String ss=Driver.findElement(
									By.xpath("//div[@class='row orderable-product-row']//div[2]//span[contains(text(),'"+ dynamicproduct[l]+ "')]/parent::div//parent::div/parent::div//div[@class='contract-price-display pre-name']//div[1]//div")).getText();
							
							if(ss.contains("Contract price:"))
							{
								Report.updateTestLog(Action, " Contract price: details Available for   ::: " +dynamicproduct[l], Status.DONE);
								
								 userData.putData("Data", "Active ShipTo", string); 
								 
								 
									System.out.println("Active shipto");
									
									if(dynamicproduct.length-1==l)
									{
										 Report.updateTestLog(Action, " Breake  "+(dynamicproduct.length-1)  , Status.DONE);
									break;
									}
									
								
							}
									/*
									 * else { Driver.findElement(By.id("changeShipToLink")).click();
									 * Thread.sleep(10000);
									 * 
									 * Report.updateTestLog(Action,
									 * " Contract price: details Not  Available Please use another NDC  ",
									 * Status.FAIL); }
									 */
						
							}catch (Exception e) {
								Report.updateTestLog(Action, " Contract price: details not Available for  NDC ::: " +dynamicproduct[l] , Status.FAIL);
								
								Driver.findElement(By.id("changeShipToLink")).click();
								Thread.sleep(5000);
								 System.out.println("Contract price: not avilabe ");
								 
							
								 if(dynamicproduct.length-1==l)
									{
										 Report.updateTestLog(Action, " Breake  "+(dynamicproduct.length-1)  , Status.DONE);
									break;
									}
							}
						}
						
						}
						
					//break;
						
				 }catch (Exception e) {
							
							
							Driver.findElement(By.id("changeShipToLink")).click();
							Thread.sleep(5000);
							 System.out.println("Contract price: not avilabe ");
							 Report.updateTestLog(Action, " Contract price: details not Available after loop  ", Status.FAIL);
						}
				
			 }
				
			 try {
			if(e1.size()-1==k)
			{
				String ss =userData.getData("Data", "Active ShipTo");
		Report.updateTestLog(Action,k+ " :  No Active shipto's in this Account Use some other user ID " , Status.DONE);
				Thread.sleep(3000);
				 Driver.findElement(By.id("shiptosearch")).sendKeys(ss);
				 
					// ((JavascriptExecutor) Driver).executeScript("arguments[0].scrollIntoView(true);",  Driver.findElement(By.xpath("//span[contains(text(),'1100551403')]")));
					 Driver.findElement(By.xpath("//span[contains(text(),'"+ss+"')]")).click();
					 Driver.findElement(By.id("orderForThisAddressBtn")).click();
				 
			}	 
			}catch (Exception e) {
				Report.updateTestLog(Action," :  No Active shipto's ID " , Status.DONE);
				
			}
				
			 }
			
		}
		
		
		
		
		@Action(object = ObjectType.BROWSER, desc = "Selecting that NDC contractprice_detailscheck ", input = InputType.YES)	
		public void contractprice_detailscheck()
		{
			String cp_textckeck=null;
		
			 try {
				 Thread.sleep(2000);
				 
				 
				 
				 
				 
					List<WebElement> cp_text = Driver.findElements(By.xpath("//div[@id='orderableProductList1']//form[contains(@id,'addToCartForm')]//div[@class='contract-price-display pre-name']//div[1]//div")); 
				
					
			//		(//div[@id='orderableProductList1']//form[contains(@id,'addToCartForm')]//div[2]/div[2]/span)[5]/parent::div//parent::div/parent::div//div[@class='contract-price-display pre-name']//div[1]//div
	///parent::div/parent::div/following-sibling::div[4]/div/input
					if(cp_text.size()==0)
					{
						Report.updateTestLog(Action, " Contract price: details not Available   ", Status.FAIL);
						
					}
					else if(cp_text.size()>=1) {
						
						
						List<WebElement> all_ndc = Driver.findElements(By.xpath("(//div[@id='orderableProductList1']//form[contains(@id,'addToCartForm')]//div[2]/div[2]/span)"));
						
					for(int i=1;i<=all_ndc.size();i++) {
						
						try {
							
							
							cp_textckeck=		Driver.findElement(
									By.xpath("//div[@class='row orderable-product-row']//div[2]//span[contains(text(),'"
											+ Data+ "')]/parent::div//parent::div/parent::div//div[@class='contract-price-display pre-name']//div[1]//div")).getText();
							
							
							
							
							/*
							 * cp_textckeck=Driver.findElement(By.xpath(
							 * "(//div[@id='orderableProductList1']//form[contains(@id,'addToCartForm')]//div[2]/div[2]/span)["
							 * +i +"]" +
							 * "/parent::div//parent::div/parent::div//div[@class='contract-price-display pre-name']//div[1]//div"
							 * )).getText();
							 */
							  
							if(cp_textckeck.contains("Contract price:"))
							{
								Report.updateTestLog(Action, " Contract price: details Available it is in if case   ", Status.DONE);
								
								
								
							}else {
								
								Report.updateTestLog(Action, " Contract price: details Not  Available Please use another NDC  ", Status.FAIL);
							}
							  
							 	
						}catch (Exception e) {
							
							System.out.println("inside catch block:::");
							Report.updateTestLog(Action, " Contract price: details Not Available Please use another NDC  Catch ", Status.FAIL);
						}
						
						
					}	
						
						
					}
						
						
						
						
				
				
					
					
					}catch (Exception e) {
						
						
						Driver.findElement(By.id("changeShipToLink")).click();
						 System.out.println("Contract price: not avilabe ");
						 Report.updateTestLog(Action, " Contract price: details not Available   ", Status.FAIL);
					}
			
			
		}
		
		
		
		@Action(object = ObjectType.BROWSER,desc = "Product NDC [<Data>]",input = InputType.YES)
	    public void addQty1()  {
			String quantity="";
	    Driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    WebElement addQty=null;
	    
	    try {
	    	 try {
	    	    	quantity= userData.getData("ComplexCart", "quantity1");
	    	    	System.out.println("CC Sheet->"+quantity);
	    	    }catch (Exception e) {
	    	    	 quantity = userData.getData("Flu Reservation", "Qty");
	    	    }
		} catch (Exception e) {
			// TODO: handle exception
			 quantity = userData.getData("Promotion", "QTY_SplitShipment");
		}

		String[] dynamicQty=Data.split(",");
		
		for (int i=0; i < dynamicQty.length; i++)
	    {
			Report.updateTestLog(Action, " Product QTY   "+dynamicQty[i], Status.DONE);
	    
	    try {
	    try {
	    	addQty = Driver.findElement(By.xpath("//div[@class='row orderable-product-row otherProduct']//div[2]//span[contains(text(),'"+dynamicQty[i]+"')]/parent::div/parent::div/following-sibling::div[4]/div/input"));
	    	addQty.click();
	    	addQty.clear();
	    	addQty.sendKeys(quantity);
	    } catch (Exception e) {
	    	addQty = Driver.findElement(By.xpath("//div[@class='row orderable-product-row']//div[2]//span[contains(text(),'"+dynamicQty[i]+"')]/parent::div/parent::div/following-sibling::div[4]/div/input"));
	    	addQty.click();
	    	addQty.clear();
	    	addQty.sendKeys(quantity);
	    }
	    } catch (Exception e) {
	    	addQty = Driver.findElement(By.xpath("//div[@class='row orderable-product-row favProduct']//div[2]//span[contains(text(),'"+dynamicQty[i]+"')]/parent::div/parent::div/following-sibling::div[4]/div/input"));
	    	addQty.click();
	    	addQty.clear();
	    	addQty.sendKeys(quantity);
	    }  
	    }
	    }

		
		/* **************************************************************** Active shipto 2 ****************************** */
		
		
		@Action(object = ObjectType.BROWSER, desc = "Get Active shipTo_2 from addresses tab", input = InputType.NO)
		public void getActiveShipTo_Coc_2() throws InterruptedException {
			List<WebElement> findElements = Driver.findElements(By.xpath("//table/tbody/tr")); 
			List<String> e1 = new ArrayList<String>();
			int i=1; 
			for (WebElement webElement:findElements){
			String b = "";
				System.out.println(Driver.findElement(By.xpath("//tbody/tr[" + i + "]/td[6]")).getText());
				if (Driver.findElement(By.xpath("//tbody/tr[" + i + "]/td[6]")).getText().contains("Active")) { 
																												 
					String text =
					Driver.findElement(By.xpath("(//tbody//tr[" + i + "]//td[contains(text(),'')])[3]")).getText();
					String[] split = text.split(" ");
					String a = split[3].toString();
					String[] split2 = a.split("");
					
					for (int j = 0; j < 10; j++) {
						b = b + split2[j].toString();
					}
					System.out.println(b);
					e1.add(b);
				}
				i = i + 1;

			}
			Driver.findElement(By.id("order-active")).click(); 
			  Thread.sleep(10000);
			for (String string : e1) {
				System.out.println(string);

				//Driver.findElement(By.id("changeShipToLink")).click();
			//	 Report.updateTestLog(Action, " Ship to  :::  "+string, Status.DONE);
			  Thread.sleep(5000);
			  try {
			  if(Driver.findElement(By.xpath("//div[@id='change-ship-to-modal']/div[2]/div[2]")).getText().contains("Company"))
			  {
				  Driver.findElement(By.id("shiptosearch")).sendKeys(string);
				 // Report.updateTestLog(Action, " If condition inside to  :::  "+string, Status.DONE);
				  
				  // ((JavascriptExecutor)			  Driver).executeScript("arguments[0].scrollIntoView(true);",
				 // Driver.findElement(By.xpath("//span[contains(text(),'1100551403')]")));
				  Driver.findElement(By.xpath("//span[contains(text(),'"+string+"')]")).click(); 
				  Driver.findElement(By.id("orderForThisAddressBtn")).click();
				  Thread.sleep(5000);
				  
				  if(Driver.findElement(By.xpath("//div[@id='account-information-div']/div[3]/div/div[1]/div[6]")).getText().contains("Not valid") || Driver.findElement(By.xpath("//div[@id='account-information-div']/div[3]/div/div[1]/div[6]")).getText().contains("Due to expire on")|| Driver.findElement(By.xpath("//div[@id='account-information-div']/div[3]/div/div[2]/div[6]")).getText().contains("Class of trade:FEDERAL"))
					 {
						
						 Driver.findElement(By.id("changeShipToLink")).click();
						 System.out.println("State licence not valid");
					 }
					 else {
						 String data2 =  userData.getData("Data", "Active ShipTo");
							if (data2.contains(string)) {
								 Driver.findElement(By.id("changeShipToLink")).click();
								 
								}
							if (!data2.contains(string)) {
								System.out.println("Active shipto 2");
								userData.putData("Data", "Active ShipTo_2", string);
								Report.updateTestLog(Action, " Active Shipto num  :::  "+string, Status.DONE);
								break;
							}
					 }  
				  
				  
			  }
			  else {
				  
				  
				  Driver.findElement(By.id("changeShipToLink")).click();
				  Thread.sleep(5000);
	Driver.findElement(By.id("shiptosearch")).sendKeys(string);
				  
				  // ((JavascriptExecutor)			  Driver).executeScript("arguments[0].scrollIntoView(true);",
				 // Driver.findElement(By.xpath("//span[contains(text(),'1100551403')]")));
				  Driver.findElement(By.xpath("//span[contains(text(),'"+string+"')]")).click(); 
				  Driver.findElement(By.id("orderForThisAddressBtn")).click();
				  
				  Thread.sleep(5000);
				  
				  if(Driver.findElement(By.xpath("//div[@id='account-information-div']/div[3]/div/div[1]/div[6]")).getText().contains("Not valid") || Driver.findElement(By.xpath("//div[@id='account-information-div']/div[3]/div/div[1]/div[6]")).getText().contains("Due to expire on")|| Driver.findElement(By.xpath("//div[@id='account-information-div']/div[3]/div/div[2]/div[6]")).getText().contains("Class of trade:FEDERAL"))
					 {
						
						 Driver.findElement(By.id("changeShipToLink")).click();
						 System.out.println("State licence not valid");
					 }
					 else {
						 String data2 =  userData.getData("Data", "Active ShipTo");
							if (data2.contains(string)) {
								 Driver.findElement(By.id("changeShipToLink")).click();
								 
								}
							if (!data2.contains(string)) {
								System.out.println("Active shipto 2");
								userData.putData("Data", "Active ShipTo_2", string);
								Report.updateTestLog(Action, " Active Shipto num  :::  "+string, Status.DONE);	
								break;
							}
					 }
			  }
			  }
			  catch (Exception e) {
					
					
					//Report.updateTestLog(Action, "search option : ", Status.DONE);
					Driver.findElement(By.id("changeShipToLink")).click();
				}
			 
			 Thread.sleep(8000);
			
			}
		}
		
		
		public void flu_Availabledoses() 
	 {
			try {
				Thread.sleep(10000);
				String flu_popup_text=null;
				
				String flu_popup=Driver.findElement(By.xpath("//h4[contains(text(),'You have available doses')]")).getText();
				
				
				if(flu_popup.contains("You have available doses"))
				{
					System.out.println("You have available doses");
					Report.updateTestLog(Action, flu_popup + " :: Flu Doses PopUp displayed", Status.PASS);
					List<WebElement> flu_radio  = Driver.findElements(By.xpath("//*[@id='allocate-flu-doses-modal']/div[2]/div[2]/div/label/label"));
					
					try {
						for (int i = 1; i <= flu_radio.size(); i++) {
							
							
			flu_popup_text=Driver.findElement(By.xpath("(//*[@id='allocate-flu-doses-modal']/div[2]/div[2]/div/label/label/strong)["+i+"]")).getText();
					
			if(flu_popup_text.contains("None: Create a new reservation"))
				
			{
				System.out.println("Enter Create a new reservation loop");
				Driver.findElement(By.xpath("	//*[@id='allocate-flu-doses-modal']/div[2]/div[2]/div/input[@id='newAllocation']")).click();
				Thread.sleep(2000);
				
				Report.updateTestLog(Action," NewAllocation Radio button selected", Status.PASS);
				
				System.out.println("Enter Create a new reservation loop");
				Driver.findElement(By.xpath("//*[@id='allocate-flu-addToCart']/span")).click();
				
				Thread.sleep(6000);
				
			}
						
			
			
						}
							
							
					}catch (Exception e) {
						Report.updateTestLog(Action," No FluProduts Avialble ", Status.DONE);
						}
				}
				
			} catch (Exception e) {	
			}
			
		
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 }	
		
		
		
		/* ************************************************* Risb** */
		@Action(object = ObjectType.BROWSER,desc = "Edit CSV File [<Object>] with input as <+or-Date> from Current Date",input = InputType.YES)
        public void setDateFormatforStartDate() {
                  Locale locale = new Locale("en", "US");
                  Date date = new Date();
                  int formatDateValue = Integer.parseInt(Data);
                  DateFormat df = new SimpleDateFormat("MMM dd, yy, 12:00:00 a");
                  df.setTimeZone(TimeZone.getTimeZone("America/New_York"));
                  Calendar cell = Calendar.getInstance();
                  cell.setTime(date);
                  cell.add(Calendar.DATE, formatDateValue);
                  cell.set(Calendar.AM_PM, Calendar.AM);
                  String Date = df.format(cell.getTime());
                  userData.putData("Promotion", "FormattedStartDate", Date);
           
           }
           
           @Action(object = ObjectType.BROWSER,desc = "Edit CSV File [<Object>] with input as <+or-Date> from Current Date",input = InputType.YES)
        public void setDateFormatforEndDate() {
                  Locale locale = new Locale("en", "US");
                  Date date = new Date();
                  int formatDateValue = Integer.parseInt(Data);
                  DateFormat df = new SimpleDateFormat("MMM dd, yy, 11:59:59 a");
                  df.setTimeZone(TimeZone.getTimeZone("America/New_York"));
                  Calendar cell = Calendar.getInstance();
                  cell.setTime(date);
                  cell.add(Calendar.DATE, formatDateValue);
                  cell.set(Calendar.AM_PM, Calendar.PM);
                  String Date = df.format(cell.getTime());                    
                  userData.putData("Promotion", "FormattedEndDate", Date);
           }
           
           @Action(object = ObjectType.BROWSER,desc = "To Accept and Close the Pop-up ",input = InputType.NO)
        public void acceptCookiePreferance() {
                  Driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
                  try {
                        Driver.findElement(By.xpath("//button[@id='gsk-consent-settings-button']")).click();                           
                        Driver.findElement(By.xpath("//button[@id='gsk-consent-confirm']")).click();
                        Report.updateTestLog(Action, "The Cookie Pop-up is closed", Status.PASS);
                  }
                  catch (Exception e) {
                        Report.updateTestLog(Action, "The Cookie Pop-up is not displayed", Status.PASS);
                  }
                  
           }

		
           @Action(object = ObjectType.BROWSER,desc = "To Click on Elemenet if its Active else Report Element is Inactive",input = InputType.YES)
           public void clickIfActive() {
                     String elementXpath = Data;
                     JavascriptExecutor js = (JavascriptExecutor) Driver; 
                     
              try {
                     
                 Driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
                 WebElement object = Driver.findElement(By.xpath(Data));
                 js.executeScript("arguments[0].click", object);
                 Report.updateTestLog(Action, "The Element is Active and Click is performed", Status.PASS);
                     
              } catch (Exception e) {
                 Report.updateTestLog(Action, "The Element is Inactive and Click is not performed", Status.PASS);
              }
                     
                     
              }

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
}
